# @convex-dev/chef-cloud

Chef's cloud builds, for apps with
[`@convex-dev/feedback`](../../README.md). When an admin approves a request
in the Chef panel, Chef builds it: Claude Code in a Daytona sandbox, the
app's repo on Code Storage, a preview deployment, an email, and "Ship it" to
the live app. No Daytona, Code Storage or Resend accounts or keys: the
deployment's own service token is the credential, and usage lands on the
team's Convex bill.

This package is a Convex component next to the feedback component. It
brings Daytona, Code Storage and Resend (vendored from the marketplace's
dist branches) and `@convex-dev/workflow` and `@convex-dev/workpool` as its
own child components, so an app with just the feedback board installs none
of them.

## Install

From this repo's `dist/chef-cloud` branch, vendored as a tarball (the build
sandbox reaches only the npm registry), from the same commit as
`@convex-dev/feedback`:

```sh
npm pack github:convex/chef-cloud#dist/chef-cloud --pack-destination vendor
npm install ./vendor/convex-dev-chef-cloud-0.0.1.tgz
```

`npx chef init --cloud --write` (the `chef` CLI comes with
`@convex-dev/feedback`) does that, and the rest of this page.

```ts
// convex/convex.config.ts
import feedback from "@convex-dev/feedback/convex.config.js";
import chefCloud from "@convex-dev/chef-cloud/convex.config.js";

app.use(feedback);
app.use(chefCloud);
```

```ts
// convex/chef.ts, next to exposeChefApi
import { chefCloud } from "@convex-dev/chef-cloud";

export const {
  chefStep, chefSweep, chefCleanup, chefRunStart, chefShipStart, chefReconcile, chefRepairApply,
  chefSetup, chefSetupStatus, chefEnableCloudBuilds, chefDisableCloudBuilds, chefCreateWorkerKey,
  chefSetAdmin, chefSetPreviewDeployKey, chefSetDeployKey, chefCancelRun, chefMigrateAgentKeys,
  chefRepoSetup, chefRepoUploadUrl, chefRepoPushPack, chefGitCredential, chefRepoRefs, chefIos,
  chefPlanBatches,
} = chefCloud(components.feedback, components.chefCloud, { /* options */ });

// No convex/crons.ts: Chef schedules nothing recurring (the feedback
// package's README, "No crons: what Chef schedules and when").
// convex/http.ts:   mountChefAgentRoutes(http, components.feedback) from "@convex-dev/feedback/http"
```

All internal. The two components never call each other: these functions,
in the app, call both. Setup and `chefSetupStatus` check the feedback
component's contract version and refuse a mismatch, with a message saying
which package is older.

The options, setup by hand, the repo functions, local builds and "Ship it"
are in the feedback package's README, "Chef cloud builds", and the design in
`docs/chef-pipeline.md`.

## Testing

```ts
import feedbackTest from "@convex-dev/feedback/test";
import chefCloudTest from "@convex-dev/chef-cloud/test";

const t = convexTest(schema, modules);
feedbackTest.register(t);
chefCloudTest.register(t); // and its children
```

## Exports

| Path | What |
| --- | --- |
| `@convex-dev/chef-cloud` | `chefCloud`, `checkFeedbackContract`, the types; `chefCrons` (deprecated: registers nothing) |
| `/convex.config` | the component |
| `/effects`, `/launcher`, `/ship`, `/daytona` | the host-side steps chefCloud is made of, for a host that wires cloud builds by hand; each takes `{ feedback: components.feedback, cloud: components.chefCloud }` |
| `/test` | convex-test registration |
