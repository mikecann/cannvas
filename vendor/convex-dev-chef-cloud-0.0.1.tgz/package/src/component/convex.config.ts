import { defineComponent } from "convex/server";
import workflow from "@convex-dev/workflow/convex.config.js";
import workpool from "@convex-dev/workpool/convex.config.js";
// The marketplace components Chef's cloud builds use, vendored from the
// get-convex/marketplace dist branches (scripts/vendor-marketplace.mjs,
// vendor/marketplace/SOURCES.json). They run in gateway mode: the
// deployment's own service token is the credential, so there is no
// Daytona, Code Storage or Resend key anywhere, and usage is on the team's
// Convex bill. Unused (and costless) until an app sets up cloud builds.
import daytona from "../../vendor/marketplace/daytona/dist/component/convex.config.js";
import codestorage from "../../vendor/marketplace/codestorage/dist/component/convex.config.js";
import resend from "../../vendor/marketplace/resend/dist/component/convex.config.js";

// Installed next to @convex-dev/feedback (`app.use(feedback); app.use(chefCloud);`).
// It never calls the feedback component itself: everything between the two
// goes through the host's chefCloud(...) functions.
const component = defineComponent("chefCloud");

// One workflow per run and per ship, and a pool of one for the cleanup
// sweep, queued when a run or a ship ends (orchestration.ts).
component.use(workflow);
component.use(workpool, { name: "chefCleanup" });
// Sandboxes and their secrets, the app's git repo, and build emails.
component.use(daytona);
component.use(codestorage);
component.use(resend);

export default component;
