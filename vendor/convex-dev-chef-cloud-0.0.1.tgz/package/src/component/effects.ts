// The ledger of a run's side effects: what each call to Daytona or the
// mailer is about to do, and what it did, so a retried step looks before it
// repeats anything. The host's effects code (src/client/chefEffects.ts)
// asks the feedback component first whether the run may start something
// (chefEffects.checkIntent) and tells it what was done
// (chefEffects.recordEffect); this is only the ledger. Host-only, like
// every component function.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import { effectFields } from "./schema.js";

const vEffect = v.object({ _id: v.id("effects"), _creationTime: v.number(), ...effectFields });
// A preview deployed again after a transient failure: deploy:2, deploy:3.
const KEY = /^(sandbox:(build|deploy(:[2-9])?|demo|beta(:2)?)|exec:(runner|deploy(:[2-9])?|demo|beta(:2)?)|email:[a-z][a-z0-9-]{0,30})$/;
const RUN_ID = /^[A-Za-z0-9_-]{1,64}$/;

function check(args: { runId: string; key: string }) {
  if (!KEY.test(args.key)) throw new Error(`Bad effect key ${args.key}`);
  if (!RUN_ID.test(args.runId)) throw new Error("Bad run id");
}

async function find(ctx: QueryCtx, runId: string, key: string) {
  return await ctx.db
    .query("effects")
    .withIndex("by_runId_and_key", (q) => q.eq("runId", runId).eq("key", key))
    .unique();
}

/** What a keyed side effect of a run has done so far. */
export const get = query({
  args: { runId: v.string(), key: v.string() },
  returns: v.union(vEffect, v.null()),
  handler: async (ctx, args) => await find(ctx, args.runId, args.key),
});

/** Write the intent before the call. Repeating it returns the one already there. */
export const intent = mutation({
  args: { runId: v.string(), key: v.string() },
  returns: vEffect,
  handler: async (ctx, args) => {
    check(args);
    const existing = await find(ctx, args.runId, args.key);
    if (existing) return existing;
    const id = await ctx.db.insert("effects", {
      runId: args.runId,
      key: args.key,
      kind: args.key.startsWith("email:") ? "email" : args.key.startsWith("exec:") ? "exec" : "sandbox",
      status: "intent",
      createdAt: Date.now(),
    });
    return (await ctx.db.get("effects", id))!;
  },
});

/** Record what the call did: the sandbox id (created or adopted), the execution id or the email's message id. */
export const done = mutation({
  args: { runId: v.string(), key: v.string(), result: v.string(), adopted: v.optional(v.boolean()) },
  returns: v.object({ changed: v.boolean() }),
  handler: async (ctx, args) => {
    check(args);
    const e = await find(ctx, args.runId, args.key);
    if (!e) throw new Error("No intent for this effect");
    if (e.status === "done") return { changed: false };
    await ctx.db.patch("effects", e._id, {
      status: "done",
      result: args.result.slice(0, 200),
      ...(args.adopted !== undefined ? { adopted: args.adopted } : {}),
      doneAt: Date.now(),
    });
    return { changed: true };
  },
});

/** A run's effects, for tests and for looking at a run by hand. */
export const listForRun = query({
  args: { runId: v.string() },
  returns: v.array(vEffect),
  handler: async (ctx, args) =>
    await ctx.db
      .query("effects")
      .withIndex("by_runId_and_key", (q) => q.eq("runId", args.runId))
      .take(50),
});
