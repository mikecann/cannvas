// Chef cloud builds' orchestration (docs/chef-pipeline.md and README "Chef
// cloud builds"). The host writes one chefCloud(...) call
// (src/client/chefCloud.ts), which registers its step executor here, and
// registers its own chefRunStart, chefShipStart and chefReconcile with the
// feedback component. From then on:
//
// - the feedback component hands a claimed run to the host's chefRunStart,
//   which starts one workflow per run here (`start`), on the child
//   @convex-dev/workflow;
// - the workflow runs the launcher's steps in driveRun's order, each one an
//   action that calls the host's executor by its function handle. The
//   executor runs in the host because only the host can read its own
//   environment (the preview deploy key, CONVEX_SITE_URL), reach the
//   feedback component (runs, releases, the audit log) and know the host's
//   options (who gets the email). This component never calls the feedback
//   component;
// - waits are slices of at most 7 minutes (actions stop at 10), looped by
//   the workflow, as in the wishbox reference host;
// - "Ship to live" goes the same way: the host's chefShipStart starts the
//   ship's workflow (`startShip`);
// - nothing runs on a timer. The cleanup sweep runs on a pool of one, with
//   retries (`queueCleanup`), when a run finishes (the feedback component
//   schedules the host's chefCleanup) and when a ship's workflow ends; it
//   arms one delayed sweep for the oldest request branch's 14 days
//   (`armBranchSweep`). A run's workflow that fails or is cancelled
//   without finishing the run hands it to reconciliation at once (`runEnded`).
//
// Every function here is reachable only from the host's own functions
// (component functions never are from clients).
import { v } from "convex/values";
import type { FunctionHandle } from "convex/server";
import { WorkflowManager, vWorkflowId } from "@convex-dev/workflow";
import { Workpool, vResultValidator, type RetryBehavior } from "@convex-dev/workpool";
import { internalAction, internalMutation, internalQuery, mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc } from "./_generated/dataModel.js";
import { components, internal } from "./_generated/api.js";
import {
  MAX_SLICES,
  vRunOutcome,
  vShipOutcome,
  vStepArgs,
  vStepResult,
  type RunOutcome,
  type ShipOutcome,
  type StepArgs,
  type StepResult,
} from "../shared/cloudSteps.js";

export const workflow = new WorkflowManager(components.workflow);
const cleanupPool = new Workpool(components.chefCleanup, { maxParallelism: 1 });

// Every step is idempotent, so a transient gateway error is retried. What a
// retry can't change (a passed deadline, a failed self-test) the executor
// reports as `terminal` instead of throwing, and `call` fails the run with it
// at once, without spending a retry (a slice can be 7 minutes).
const retry: RetryBehavior = { maxAttempts: 3, initialBackoffMs: 2_000, base: 2 };

type StepCtx = { runAction: (fn: typeof internal.orchestration.step, args: StepArgs, opts: { retry: RetryBehavior | boolean }) => Promise<StepResult> };
/** A step, retried on what may pass; a terminal result is thrown as the run's error. */
async function call(step: StepCtx, args: StepArgs, opts: { retry: RetryBehavior | boolean } = { retry }): Promise<StepResult> {
  const r = await step.runAction(internal.orchestration.step, args, opts);
  if (r.terminal) throw new Error(r.terminal);
  return r;
}

const APP_NAME = /^[A-Za-z0-9][A-Za-z0-9 ._-]{0,62}$/;

export async function readConfig(ctx: QueryCtx): Promise<Doc<"config"> | null> {
  return await ctx.db
    .query("config")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
}

type ConfigPatch = Partial<Omit<Doc<"config">, "_id" | "_creationTime" | "key" | "updatedAt">>;

export async function patchConfig(ctx: MutationCtx, patch: ConfigPatch): Promise<void> {
  const row = await readConfig(ctx);
  if (row) await ctx.db.patch("config", row._id, { ...patch, updatedAt: Date.now() });
  else await ctx.db.insert("config", { key: "singleton", ...patch, updatedAt: Date.now() });
}

// ---------------------------------------------------------------- setup

/**
 * The host's setup: register its step executor (a function handle to
 * chefCloud's `chefStep`) and record the app's name. Safe to repeat; a new
 * handle replaces the old.
 */
export const register = mutation({
  args: { executor: v.string(), appName: v.optional(v.string()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (!args.executor.startsWith("function://")) throw new Error("executor must be a function handle");
    if (args.appName !== undefined && !APP_NAME.test(args.appName)) {
      throw new Error("appName must be 1 to 63 letters, digits, spaces, '.', '_' or '-'");
    }
    await patchConfig(ctx, {
      executorHandle: args.executor,
      ...(args.appName !== undefined ? { appName: args.appName } : {}),
    });
    return null;
  },
});

/** What is set up, for the host's status and executor. Nothing secret. */
export const config = query({
  args: {},
  returns: v.object({
    executor: v.boolean(),
    appName: v.union(v.string(), v.null()),
    repoName: v.union(v.string(), v.null()),
    repoUrl: v.union(v.string(), v.null()),
    gitHost: v.union(v.string(), v.null()),
  }),
  handler: async (ctx) => {
    const row = await readConfig(ctx);
    return {
      executor: !!row?.executorHandle,
      appName: row?.appName ?? null,
      repoName: row?.repoName ?? null,
      repoUrl: row?.repoUrl ?? null,
      gitHost: row?.gitHost ?? null,
    };
  },
});

export const executorHandle = internalQuery({
  args: {},
  returns: v.union(v.string(), v.null()),
  handler: async (ctx) => (await readConfig(ctx))?.executorHandle ?? null,
});

// ---------------------------------------------------------------- the run

export async function callExecutor(ctx: { runQuery: any; runAction: any }, args: StepArgs): Promise<StepResult> {
  const handle: string | null = await ctx.runQuery(internal.orchestration.executorHandle, {});
  if (!handle) throw new Error("Cloud builds aren't set up on this deployment: run chefSetup");
  return (await ctx.runAction(handle as FunctionHandle<"action", StepArgs, StepResult>, args)) as StepResult;
}

/** One step of a run: the host's executor does it, with the host's environment and adapters. */
export const step = internalAction({
  args: vStepArgs,
  returns: vStepResult,
  handler: async (ctx, args) => await callExecutor(ctx, args),
});

/** One workflow per cloud build: the launcher's steps in driveRun's order. */
export const run = workflow.define({
  args: { runId: v.string() },
  returns: vRunOutcome,
  handler: async (step, { runId }): Promise<RunOutcome> => {
    const s = internal.orchestration.step;
    try {
      const at = await call(step, { op: "begin", runId }, { retry });
      if (!at.active) return { outcome: "stopped", previewUrl: null, error: null };

      if (!at.built) {
        const launched = await call(step, { op: "launch", runId }, { retry });
        const sandboxId = launched.sandboxId!;
        const executionId = launched.executionId!;
        let passed = false;
        for (let i = 0; i < MAX_SLICES && !passed; i++) {
          const r = await call(step, { op: "awaitSelfTest", runId, sandboxId, executionId }, { retry });
          passed = !!r.passed;
        }
        if (!passed) throw new Error("The runner's self-test never reported");
        const live = await call(step, { op: "live", runId, sandboxId }, { retry });
        let applied: string | null = live.applied ?? null;
        let appliedAt = live.appliedAt ?? 0;
        let done = false;
        for (let i = 0; i < MAX_SLICES && !done; i++) {
          const r = await call(step, { op: "follow", runId, sandboxId, executionId, applied, appliedAt },
            { retry },
          );
          done = !!r.done;
          applied = r.applied ?? null;
          appliedAt = r.appliedAt ?? appliedAt;
        }
        if (!done) throw new Error("The build never reached pushed");
        await call(step, { op: "retire", runId }, { retry });
      }

      // A release merge ships through its release (chefShip.followMain):
      // no preview, no beta, no demo; built as soon as it is pushed.
      if (at.releaseMerge) {
        await call(step, { op: "finishMerge", runId }, { retry });
        return { outcome: "built", previewUrl: null, error: null };
      }

      // A change the web preview can't show (only the phone or Mac app,
      // tests, docs; src/chef/preview.ts): the preview or beta step says
      // `noPreview` and makes nothing; built, with no demo.
      let noPreview = false;
      const finishWithoutPreview = async (): Promise<RunOutcome> => {
        await call(step, { op: "finish", runId }, { retry });
        return { outcome: "built", previewUrl: null, error: null };
      };

      // The beta channel: the build on the app's persistent beta deployment,
      // after the preview ("also", best effort) or as it ("instead").
      // A transient failure (the network's) is tried once more (attempt 2).
      const toBeta = async (): Promise<string | null> => {
        let attempt = 1;
        for (let i = 0; i < MAX_SLICES; i++) {
          const b = await call(step, { op: "beta", runId, ...(attempt > 1 ? { attempt } : {}) }, { retry });
          if (b.noPreview) {
            noPreview = true;
            return null;
          }
          if (b.done) return b.previewUrl ?? null;
          if (b.outcome === "skipped") return null;
          if (!b.sandboxId) continue; // another build's deploy holds the beta: it waited a slice
          let again = false;
          for (let j = 0; j < MAX_SLICES && !again; j++) {
            const w = await call(step, {
                op: "awaitBeta",
                runId,
                sandboxId: b.sandboxId,
                executionId: b.executionId!,
                deploymentName: b.deploymentName!,
                startedAt: b.startedAt!,
                ...(attempt > 1 ? { attempt } : {}),
              },
              { retry },
            );
            if (w.done) return w.previewUrl ?? null;
            again = !!w.retry && attempt === 1;
          }
          if (!again) return null;
          attempt = 2;
        }
        return null;
      };

      // A preview deploy that dies for the platform's reasons is deployed
      // again (awaitPreview says `redeploy`), a bounded number of times.
      let previewUrl: string | null = null;
      if (at.beta === "instead") {
        previewUrl = await toBeta();
        if (noPreview) return await finishWithoutPreview();
        if (previewUrl === null) throw new Error("The beta deploy didn't finish");
      }
      for (let attempt = 1; attempt <= 3 && previewUrl === null; attempt++) {
        const started = await call(step, { op: "preview", runId, ...(attempt > 1 ? { attempt } : {}) }, { retry });
        if (started.noPreview) {
          noPreview = true;
          break;
        }
        if (started.reused) {
          previewUrl = started.previewUrl ?? null;
          break;
        }
        const sandboxId = started.sandboxId!;
        const executionId = started.executionId!;
        const sha = started.sha!;
        let redeploy = false;
        for (let i = 0; i < MAX_SLICES && previewUrl === null && !redeploy; i++) {
          const r = await call(step, { op: "awaitPreview", runId, sandboxId, executionId, sha, ...(attempt > 1 ? { attempt } : {}) },
            { retry },
          );
          previewUrl = r.previewUrl ?? null;
          redeploy = !!r.redeploy;
        }
        if (previewUrl === null && !redeploy) throw new Error("The preview deploy never finished");
      }
      if (noPreview) return await finishWithoutPreview();
      if (previewUrl === null) throw new Error("The preview deploy never finished");
      if (at.beta === "also") {
        try {
          await toBeta();
        } catch {
          // Best effort: the card says why the beta doesn't have it.
        }
      }
      // The demo video: best effort, never the run's failure.
      try {
        await call(step, { op: "demo", runId }, { retry: false });
      } catch {
        // The card says there's no video.
      }
      await call(step, { op: "finish", runId }, { retry });
      return { outcome: "built", previewUrl, error: null };
    } catch (e) {
      const error = (e instanceof Error ? e.message : String(e)).slice(0, 2000);
      const r = await step.runAction(s, { op: "fail", runId, error }, { retry });
      return { outcome: r.finished ? "failed" : "stopped", previewUrl: null, error };
    }
  },
});

/**
 * Start a claimed run's workflow. The feedback component hands each claimed
 * run once to the host's chefRunStart (chefOrchestrator.startRun), which
 * calls this. Returns the workflow's id.
 */
export const start = mutation({
  args: { runId: v.string() },
  returns: v.string(),
  handler: async (ctx, { runId }): Promise<string> =>
    String(
      await workflow.start(ctx, internal.orchestration.run, { runId }, { onComplete: internal.orchestration.runEnded, context: { runId } }),
    ),
});

/**
 * A run's workflow ended (onComplete: success, failure or cancel). Its own
 * `finish` and `fail` steps finish the run, and finishing frees the slot and
 * claims the next build. A workflow that failed or was cancelled before
 * that leaves the run active: the host's executor (`settle`) hands it to
 * reconciliation now, instead of waiting for its deadline check to find it
 * stale; that frees the slot and claims the next build in turn.
 */
export const runEnded = internalMutation({
  args: { workflowId: vWorkflowId, result: vResultValidator, context: v.object({ runId: v.string() }) },
  returns: v.null(),
  handler: async (ctx, { result, context }) => {
    if (result.kind === "success") return null;
    const error = result.kind === "failed" ? result.error : "the workflow was cancelled";
    await ctx.scheduler.runAfter(0, internal.orchestration.settle, { runId: context.runId, error: error.slice(0, 500) });
    return null;
  },
});

/** The host's side of runEnded: a run still active goes to reconciliation. */
export const settle = internalAction({
  args: { runId: v.string(), error: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await callExecutor(ctx, { op: "settle", runId: args.runId, error: args.error });
    return null;
  },
});

// ---------------------------------------------------------------- ship it

/**
 * One workflow per ship ("Ship to live" in the panel): driveShip's steps,
 * each one the host's executor's, with the script's wait in slices. The
 * ship script can run for up to 30 minutes, past an action's 10.
 */
export const ship = workflow.define({
  args: { releaseId: v.string() },
  returns: vShipOutcome,
  handler: async (step, { releaseId }): Promise<ShipOutcome> => {
    const s = internal.orchestration.step;
    let out: ShipOutcome;
    try {
      const at = await call(step, { op: "shipBegin", releaseId }, { retry });
      if (at.done) {
        out = { outcome: "live", siteUrl: at.siteUrl ?? null, error: null };
      } else {
        let siteUrl = at.siteUrl ?? undefined;
        if (!at.verified) {
          const started = await call(step, { op: "shipStart", releaseId }, { retry });
          if (started.following) {
            // Main moved: Chef merges it into the release, which ships again after.
            return await shipStopped(step, releaseId, started.outcome ?? null);
          }
          siteUrl = started.siteUrl ?? undefined;
          let done = false;
          for (let i = 0; i < MAX_SLICES && !done; i++) {
            const r = await call(step, {
                op: "shipAwait",
                releaseId,
                sandboxId: started.sandboxId!,
                executionId: started.executionId!,
                deploymentName: started.deploymentName!,
                startedAt: started.startedAt!,
                ...(siteUrl ? { siteUrl } : {}),
              },
              { retry },
            );
            done = !!r.done;
          }
          if (!done) throw new Error("The ship script never finished");
        }
        const went = await call(step, { op: "shipLive", releaseId }, { retry });
        if (went.following) return await shipStopped(step, releaseId, went.outcome ?? null);
        const fin = await call(step, { op: "shipFinish", releaseId, ...(siteUrl ? { siteUrl } : {}) }, { retry });
        out = { outcome: "live", siteUrl: fin.siteUrl ?? siteUrl ?? null, error: null };
      }
    } catch (e) {
      const error = (e instanceof Error ? e.message : String(e)).slice(0, 2000);
      const r = await step.runAction(s, { op: "shipFail", releaseId, error }, { retry });
      out = { outcome: r.outcome === "abandoned" ? "abandoned" : "failed", siteUrl: null, error };
    }
    // The sandbox and its git secret go either way; the sweep is the backstop.
    try {
      await step.runAction(s, { op: "shipCleanup", releaseId }, { retry });
    } catch {
      // Daytona's auto-delete and the sweep when the workflow ends (shipEnded) remove what's left.
    }
    return out;
  },
});

/** A ship that stopped because main moved: its sandbox goes; the release stays open and follows main. */
async function shipStopped(step: { runAction: (...a: any[]) => Promise<any> }, releaseId: string, reason: string | null): Promise<ShipOutcome> {
  try {
    await step.runAction(internal.orchestration.step, { op: "shipCleanup", releaseId }, { retry });
  } catch {
    // The sweep is the backstop.
  }
  return { outcome: "following", siteUrl: null, error: reason };
}

/**
 * Start a ship's workflow. The feedback component hands each "Ship to live"
 * to the host's chefShipStart (chefShip.approve), which calls this. Returns
 * the workflow's id.
 */
export const startShip = mutation({
  args: { releaseId: v.string() },
  returns: v.string(),
  handler: async (ctx, { releaseId }): Promise<string> =>
    String(await workflow.start(ctx, internal.orchestration.ship, { releaseId }, { onComplete: internal.orchestration.shipEnded, context: { releaseId } })),
});

/**
 * A ship's workflow ended (success, failure or cancel): the cleanup sweep
 * once, for whatever its own shipCleanup step didn't remove.
 */
export const shipEnded = internalMutation({
  args: { workflowId: vWorkflowId, result: vResultValidator, context: v.object({ releaseId: v.string() }) },
  returns: v.null(),
  handler: async (ctx) => {
    await enqueueCleanup(ctx);
    return null;
  },
});

// -------------------------------------------------------------- cleanup

const CLEANUP_RETRY: RetryBehavior = { maxAttempts: 3, initialBackoffMs: 30_000, base: 2 };
/** A branch sweep runs this long after the branch it's for is due. */
const BRANCH_SWEEP_SLACK_MS = 60_000;

/** The cleanup sweep on its pool of one, now or at `runAt`; false before cloud builds are set up. */
async function enqueueCleanup(ctx: MutationCtx, runAt?: number): Promise<boolean> {
  const row = await readConfig(ctx);
  if (!row?.executorHandle) return false;
  await cleanupPool.enqueueAction(ctx, internal.orchestration.cleanup, {}, {
    retry: CLEANUP_RETRY,
    ...(runAt !== undefined ? { runAt } : {}),
  });
  return true;
}

/**
 * The cleanup sweep, once, on its pool of one, with retries, once cloud
 * builds are set up: the host's chefCleanup calls it when a run finishes
 * (the feedback component schedules that), and `npx chef cleanup` by hand.
 * The host calls it only once Chef has ever run (the feedback component's
 * chefRuns.hasRuns): before that nothing of Chef's can exist.
 */
export const queueCleanup = mutation({
  args: {},
  returns: v.boolean(),
  handler: async (ctx) => await enqueueCleanup(ctx),
});

/**
 * One delayed sweep for the oldest request branch still waiting out its 14
 * days (the sweep says when, after each run). Only one is kept pending: a
 * sweep already due by then covers it, and each sweep arms the next.
 */
export const armBranchSweep = internalMutation({
  args: { at: v.number() },
  returns: v.boolean(),
  handler: async (ctx, { at }) => {
    const row = await readConfig(ctx);
    const now = Date.now();
    const runAt = Math.max(now, at + BRANCH_SWEEP_SLACK_MS);
    const pending = row?.branchSweepAt;
    if (pending !== undefined && pending > now && pending <= runAt) return false;
    if (!(await enqueueCleanup(ctx, runAt))) return false;
    await patchConfig(ctx, { branchSweepAt: runAt });
    return true;
  },
});

/** Leftover Chef sandboxes and secrets, and request branches older than 14 days. */
export const cleanup = internalAction({
  args: {},
  returns: v.object({ sandboxes: v.number(), secrets: v.number(), branches: v.number() }),
  handler: async (ctx) => {
    const r = await callExecutor(ctx, { op: "cleanup" });
    if (typeof r.nextBranchAt === "number") await ctx.runMutation(internal.orchestration.armBranchSweep, { at: r.nextBranchAt });
    return { sandboxes: r.sandboxes ?? 0, secrets: r.secrets ?? 0, branches: r.branches ?? 0 };
  },
});

// ---------------------------------------------------------------- the repo

/** Where the repo actions record the repo: its name, URL (no credentials) and host. */
export const recordRepo = internalMutation({
  args: { repoName: v.string(), repoUrl: v.string(), gitHost: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await patchConfig(ctx, args);
    return null;
  },
});

export const repoName = internalQuery({
  args: {},
  returns: v.union(v.string(), v.null()),
  handler: async (ctx) => (await readConfig(ctx))?.repoName ?? null,
});
