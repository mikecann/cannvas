// The app's own repository on Code Storage, through the child component in
// gateway mode (no Code Storage key). Chef's runner clones it and pushes each
// request's branch; the developer pushes `main` to it from their CLI.
//
// The host exposes these as internal functions (chefCloud's chefRepoSetup,
// chefRepoUploadUrl, chefRepoPushPack, chefGitCredential, chefRepoRefs), so
// only the deployment's own CLI (`npx convex run`) can call them, and audits
// every call with the operator's name in the feedback component's audit log.
// Tokens stay in the action: git runs over smart HTTP from here
// (src/shared/gitHttp.ts), and only `gitCredential` returns one,
// short-lived, for the developer's git credential helper.
//
// The rest (`readRefs`, `deleteRef`, `updateRef`, `mirror`, `basicAuth`) are
// the host executor's RefsApi and GitAuthApi.
import { ConvexError, v } from "convex/values";
import { action, mutation } from "./_generated/server.js";
import type { ActionCtx } from "./_generated/server.js";
import { components, internal } from "./_generated/api.js";
import { CodeStorage } from "../../vendor/marketplace/codestorage/dist/client/index.js";
import {
  credentialFromUrl,
  deleteBranch,
  headRef,
  isSha,
  listBranches,
  mirrorBranch,
  pushPack as pushPackOverHttp,
  readRefs as readRefsOverHttp,
  remoteFromUrl,
  updateRef as updateRefOverHttp,
  type Remote,
} from "../shared/gitHttp.js";

const codestorage = new CodeStorage(components.codestorage);

const REPO_NAME = /^[a-z0-9](?:[a-z0-9._-]{0,61}[a-z0-9])?$/;
/** A git credential for the developer's helper lives this long (10 minutes). */
export const CREDENTIAL_TTL_SECONDS = 600;
/** Tokens the executor and these actions use themselves. */
const INTERNAL_TTL_SECONDS = 120;
/** The largest pack chefRepoPushPack takes. A whole small app's history is a few MB. */
export const MAX_PACK_BYTES = 100 * 1024 * 1024;

/** A repo name Code Storage accepts, from the app's name: "My App" is "my-app". */
export function repoNameFor(appName: string): string {
  const name = appName
    .toLowerCase()
    .replace(/[^a-z0-9._-]+/g, "-")
    .replace(/^[^a-z0-9]+|[^a-z0-9]+$/g, "")
    .slice(0, 63)
    .replace(/[^a-z0-9]+$/, "");
  if (!REPO_NAME.test(name) || name.endsWith(".git") || name.includes("..")) throw new Error("no usable repo name");
  return name;
}

async function requireRepo(ctx: ActionCtx): Promise<string> {
  const name: string | null = await ctx.runQuery(internal.orchestration.repoName, {});
  if (!name) throw new ConvexError("The app has no repo yet: run chefRepoSetup");
  return name;
}

export async function remote(ctx: ActionCtx, write: boolean, ttlSeconds = INTERNAL_TTL_SECONDS): Promise<Remote> {
  const name = await requireRepo(ctx);
  const { url } = await codestorage.getRemoteURL(ctx, { name, write, ttlSeconds });
  return remoteFromUrl(url);
}

/** Our own messages, cut short. Never a response body: the request held a token. */
const message = (e: unknown) => (e instanceof Error ? e.message : String(e)).slice(0, 300);

// ---------------------------------------------------------------- developer CLI
//
// The host audits each of these (chefAudit.record in the feedback component,
// as `operator:<name>`), the failures too: these throw our own messages,
// never a response body.

/**
 * Create the app's repo on Code Storage, or adopt it if it exists, and
 * record its URL (no credentials) in Chef's cloud settings. Safe to repeat.
 */
export const setup = action({
  args: { name: v.string() },
  returns: v.object({ repo: v.string(), repoUrl: v.string(), gitHost: v.string(), created: v.boolean() }),
  handler: async (ctx, args) => {
    if (!REPO_NAME.test(args.name) || args.name.endsWith(".git")) {
      throw new ConvexError("repo names are 1 to 63 of a-z, 0-9, '.', '_' or '-'");
    }
    let created = true;
    try {
      await codestorage.createRepo(ctx, { name: args.name, defaultBranch: "main" });
    } catch (e) {
      if (!/409|repo_exists|already exists/i.test(message(e))) throw new Error(`Creating the repo failed: ${message(e)}`);
      created = false;
    }
    const { url } = await codestorage.getRemoteURL(ctx, { name: args.name, ttlSeconds: INTERNAL_TTL_SECONDS });
    const r = remoteFromUrl(url);
    const gitHost = new URL(r.url).host;
    await ctx.runMutation(internal.orchestration.recordRepo, { repoName: args.name, repoUrl: r.url, gitHost });
    return { repo: args.name, repoUrl: r.url, gitHost, created };
  },
});

/** Where the developer's CLI uploads a git pack for `pushPack`: this component's own file storage. */
export const uploadUrl = mutation({
  args: {},
  returns: v.string(),
  handler: async (ctx) => await ctx.storage.generateUploadUrl(),
});

/**
 * Push an uploaded pack: `ref` (a branch name or refs/heads/...) goes to
 * `newSha`, only if it is at `oldSha` now (omit `oldSha` for a new branch).
 * Never a force. Pushing the sha the branch already has is a no-op. The
 * upload is deleted either way.
 */
export const pushPack = action({
  args: {
    storageId: v.id("_storage"),
    ref: v.string(),
    oldSha: v.optional(v.union(v.string(), v.null())),
    newSha: v.string(),
  },
  returns: v.object({
    ref: v.string(),
    before: v.union(v.string(), v.null()),
    after: v.string(),
    updated: v.boolean(),
    bytes: v.number(),
  }),
  handler: async (ctx, args) => {
    try {
      const ref = headRef(args.ref);
      if (!isSha(args.newSha)) throw new ConvexError("newSha must be 40 lowercase hex characters");
      if (args.oldSha != null && !isSha(args.oldSha)) throw new ConvexError("oldSha must be 40 lowercase hex characters");
      const blob = await ctx.storage.get(args.storageId);
      if (blob === null) throw new ConvexError("The uploaded pack is gone; upload it again");
      if (blob.size > MAX_PACK_BYTES) throw new ConvexError(`The pack is over ${MAX_PACK_BYTES} bytes`);
      const pack = new Uint8Array(await blob.arrayBuffer());
      const r = await pushPackOverHttp(await remote(ctx, true), { ref, oldSha: args.oldSha ?? null, newSha: args.newSha, pack });
      return { ref, ...r, bytes: pack.length };
    } finally {
      await ctx.storage.delete(args.storageId).catch(() => {});
    }
  },
});

/**
 * A short-lived git credential (10 minutes) for the developer's git
 * credential helper: the repo's URL without credentials, the user name and
 * the token. Read-only unless `write`. The host audits it without the token.
 */
export const gitCredential = action({
  args: { write: v.boolean() },
  returns: v.object({
    repo: v.string(),
    remoteUrl: v.string(),
    username: v.string(),
    password: v.string(),
    expiresAt: v.number(),
  }),
  handler: async (ctx, args) => {
    const name = await requireRepo(ctx);
    const r = await codestorage.getRemoteURL(ctx, { name, write: args.write, ttlSeconds: CREDENTIAL_TTL_SECONDS });
    const cred = credentialFromUrl(r.url);
    const expiresAt = typeof r.expiresAt === "number" ? r.expiresAt : Date.now() + CREDENTIAL_TTL_SECONDS * 1000;
    return { repo: name, ...cred, expiresAt };
  },
});

/** Every branch and its sha, read with a read-only token. */
export const refs = action({
  args: {},
  returns: v.object({
    repo: v.string(),
    repoUrl: v.string(),
    refs: v.array(v.object({ ref: v.string(), sha: v.string() })),
  }),
  handler: async (ctx) => {
    const r = await remote(ctx, false);
    const branches = await listBranches(r);
    return {
      repo: await requireRepo(ctx),
      repoUrl: r.url,
      refs: Object.entries(branches)
        .map(([ref, sha]) => ({ ref, sha }))
        .sort((a, b) => a.ref.localeCompare(b.ref)),
    };
  },
});

// ---------------------------------------------------------------- the executor's

/** RefsApi.readRefs: the sha each branch points at, or null. */
export const readRefs = action({
  args: { refs: v.array(v.string()) },
  returns: v.array(v.object({ ref: v.string(), sha: v.union(v.string(), v.null()) })),
  handler: async (ctx, args) => {
    if (args.refs.length > 50) throw new Error("at most 50 refs");
    const got = await readRefsOverHttp(await remote(ctx, false), args.refs);
    return args.refs.map((ref) => ({ ref, sha: got[ref] ?? null }));
  },
});

/** RefsApi.deleteRef: a missing branch is success. */
export const deleteRef = action({
  args: { ref: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await deleteBranch(await remote(ctx, true), args.ref);
    return null;
  },
});

/** RefsApi.updateRef: a compare-and-swap, never a force (for "Ship it", `main` to chef's commit). */
export const updateRef = action({
  args: { ref: v.string(), from: v.string(), to: v.string() },
  returns: v.boolean(),
  handler: async (ctx, args) => await updateRefOverHttp(await remote(ctx, true), args),
});

/** A GitHub repository, as `owner/name`. */
export const GITHUB_REPO = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})\/[A-Za-z0-9._-]{1,100}$/;

/**
 * RefsApi.mirror: fast-forward `ref` (default `main`) on a GitHub repo to
 * this repo's `ref` (or `sha`), never a force; see mirrorBranch. The token
 * (a fine-grained token with Contents: write on that one repo) comes from
 * the host's environment and goes only into the Authorization header.
 */
export const mirror = action({
  args: { github: v.string(), token: v.string(), ref: v.optional(v.string()), sha: v.optional(v.string()), baseRef: v.optional(v.string()) },
  returns: v.union(
    v.object({ status: v.literal("current"), sha: v.string() }),
    v.object({ status: v.literal("pushed"), from: v.union(v.string(), v.null()), sha: v.string() }),
    v.object({ status: v.literal("ahead"), target: v.string(), sha: v.string() }),
    v.object({ status: v.literal("diverged"), target: v.string(), sha: v.string() }),
  ),
  handler: async (ctx, args) => {
    const repo = args.github.replace(/\.git$/, "");
    if (!GITHUB_REPO.test(repo) || repo.includes("..")) throw new Error("github must be owner/name");
    if (!args.token || /\s/.test(args.token)) throw new Error("no usable GitHub token");
    if (args.sha !== undefined && !isSha(args.sha)) throw new Error("bad sha");
    const target: Remote = { url: `https://github.com/${repo}.git`, basic: btoa(`x-access-token:${args.token}`) };
    try {
      return await mirrorBranch(await remote(ctx, false), target, {
        ref: args.ref ?? "main",
        ...(args.sha ? { sha: args.sha } : {}),
        ...(args.baseRef ? { baseRef: args.baseRef } : {}),
      });
    } catch (e) {
      throw new Error(`Mirroring to github.com/${repo} failed: ${message(e)}`);
    }
  },
});

/**
 * GitAuthApi.basicAuth: the value for a `chef-git-*` Daytona secret, a
 * pre-encoded Basic credential for the repo. Returned only to the host's
 * executor, which puts it straight into a Daytona secret.
 */
export const basicAuth = action({
  args: { access: v.union(v.literal("read"), v.literal("write")), ttlSeconds: v.number() },
  returns: v.string(),
  handler: async (ctx, args) => {
    if (!Number.isFinite(args.ttlSeconds) || args.ttlSeconds < 60 || args.ttlSeconds > 3600) {
      throw new Error("ttlSeconds must be 60 to 3600");
    }
    return (await remote(ctx, args.access === "write", Math.floor(args.ttlSeconds))).basic;
  },
});
