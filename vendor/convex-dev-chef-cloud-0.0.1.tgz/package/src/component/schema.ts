import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

// Ids from the feedback component (runs) are plain strings here: the two
// components never share a table, and the host passes them between.

export const effectFields = {
  // The feedback component's chefRuns id.
  runId: v.string(),
  // "sandbox:build", "sandbox:deploy", "exec:runner", "exec:deploy", "email:<kind>".
  key: v.string(),
  kind: v.union(v.literal("sandbox"), v.literal("exec"), v.literal("email")),
  status: v.union(v.literal("intent"), v.literal("done")),
  // The sandbox id, the execution id or the email provider's message id. Never a secret.
  result: v.optional(v.string()),
  adopted: v.optional(v.boolean()),
  createdAt: v.number(),
  doneAt: v.optional(v.number()),
};

export const vWarmState = v.union(
  // Asked for; the build is scheduled.
  v.literal("queued"),
  // Daytona is building it.
  v.literal("building"),
  // Active: sandboxes start from it.
  v.literal("ready"),
  // The build failed; tried again after `retryAt`, a few times at most.
  v.literal("failed"),
  // Not built: older warm snapshots couldn't be deleted to make room.
  v.literal("deferred"),
);

export const warmFields = {
  // sha256 of the chef-base recipe and the install's inputs (chefWarm.ts).
  key: v.string(),
  // chef-warm-<12 hex of the key>, the team's own Daytona snapshot name.
  name: v.string(),
  state: vWarmState,
  // The commit its files were read from.
  commit: v.string(),
  // The install's inputs, as runner/chef-install-plan.mjs hashes them.
  inputsHash: v.string(),
  // "npm" or "pnpm".
  manager: v.string(),
  createdAt: v.number(),
  // When its build was last scheduled: one stuck in `queued` is scheduled again after an hour.
  queuedAt: v.optional(v.number()),
  lastUsedAt: v.number(),
  // Sandboxes started from it.
  uses: v.number(),
  // Builds tried.
  attempts: v.number(),
  // Bytes, as Daytona reports it once built.
  size: v.optional(v.number()),
  builtAt: v.optional(v.number()),
  // Why it failed or was deferred: our own words, or Daytona's reason, cut short.
  error: v.optional(v.string()),
  retryAt: v.optional(v.number()),
};

export default defineSchema({
  // Chef cloud builds set up by the host's chefCloud(...) (src/client/chefCloud.ts,
  // orchestration.ts). One row. Nothing secret: the repo URL has no
  // credentials, and the handle is a function reference.
  config: defineTable({
    key: v.literal("singleton"),
    // The app's name, for the build emails.
    appName: v.optional(v.string()),
    // The app's repo on Code Storage (repo.setup): its name, its https URL
    // with no credentials in it, and that URL's host.
    repoName: v.optional(v.string()),
    repoUrl: v.optional(v.string()),
    gitHost: v.optional(v.string()),
    // The host's step executor (chefCloud's chefStep), as a function handle:
    // the run's and the ship's workflows call it for every step.
    executorHandle: v.optional(v.string()),
    // When the one pending request-branch sweep runs (orchestration
    // .armBranchSweep): at the oldest branch's 14 days, not hourly.
    branchSweepAt: v.optional(v.number()),
    updatedAt: v.number(),
  }).index("by_key", ["key"]),

  // Side effects keyed by (run, key): the intent is written before the call
  // and the result after, so a retry can look before it repeats anything
  // (docs/chef-pipeline.md, "Idempotency and reconciliation for every side
  // effect"). The run's own record (its sandbox ids, the audit log) is in
  // the feedback component; the host writes both (src/client/chefEffects.ts).
  effects: defineTable(effectFields).index("by_runId_and_key", ["runId", "key"]),

  // The app's warm snapshots (docs/chef-pipeline.md, "Warm snapshots";
  // src/client/chefWarm.ts): Daytona snapshots of its own, each chef-base's
  // recipe plus npm's cache (and pnpm's store) for one set of dependency
  // inputs, built only from files committed to its repo. One row per key;
  // a few at most (the host keeps `keep`, default 2, and deletes older ones).
  warmSnapshots: defineTable(warmFields).index("by_key", ["key"]),
});
