/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as effects from "../effects.js";
import type * as orchestration from "../orchestration.js";
import type * as providers from "../providers.js";
import type * as repo from "../repo.js";
import type * as warm from "../warm.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import { anyApi, componentsGeneric } from "convex/server";

const fullApi: ApiFromModules<{
  effects: typeof effects;
  orchestration: typeof orchestration;
  providers: typeof providers;
  repo: typeof repo;
  warm: typeof warm;
}> = anyApi as any;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
> = anyApi as any;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
> = anyApi as any;

export const components = componentsGeneric() as unknown as {
  workflow: import("@convex-dev/workflow/_generated/component.js").ComponentApi<"workflow">;
  chefCleanup: import("@convex-dev/workpool/_generated/component.js").ComponentApi<"chefCleanup">;
  daytona: import("../../../vendor/marketplace/daytona/dist/component/_generated/component.js").ComponentApi<"daytona">;
  codestorage: import("../../../vendor/marketplace/codestorage/dist/component/_generated/component.js").ComponentApi<"codestorage">;
  resend: import("../../../vendor/marketplace/resend/dist/component/_generated/component.js").ComponentApi<"resend">;
};
