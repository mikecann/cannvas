/* eslint-disable */
/**
 * Generated `ComponentApi` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type { FunctionReference } from "convex/server";

/**
 * A utility for referencing a Convex component's exposed API.
 *
 * Useful when expecting a parameter like `components.myComponent`.
 * Usage:
 * ```ts
 * async function myFunction(ctx: QueryCtx, component: ComponentApi) {
 *   return ctx.runQuery(component.someFile.someQuery, { ...args });
 * }
 * ```
 */
export type ComponentApi<Name extends string | undefined = string | undefined> =
  {
    effects: {
      done: FunctionReference<
        "mutation",
        "internal",
        { adopted?: boolean; key: string; result: string; runId: string },
        { changed: boolean },
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { key: string; runId: string },
        {
          _creationTime: number;
          _id: string;
          adopted?: boolean;
          createdAt: number;
          doneAt?: number;
          key: string;
          kind: "sandbox" | "exec" | "email";
          result?: string;
          runId: string;
          status: "intent" | "done";
        } | null,
        Name
      >;
      intent: FunctionReference<
        "mutation",
        "internal",
        { key: string; runId: string },
        {
          _creationTime: number;
          _id: string;
          adopted?: boolean;
          createdAt: number;
          doneAt?: number;
          key: string;
          kind: "sandbox" | "exec" | "email";
          result?: string;
          runId: string;
          status: "intent" | "done";
        },
        Name
      >;
      listForRun: FunctionReference<
        "query",
        "internal",
        { runId: string },
        Array<{
          _creationTime: number;
          _id: string;
          adopted?: boolean;
          createdAt: number;
          doneAt?: number;
          key: string;
          kind: "sandbox" | "exec" | "email";
          result?: string;
          runId: string;
          status: "intent" | "done";
        }>,
        Name
      >;
    };
    orchestration: {
      config: FunctionReference<
        "query",
        "internal",
        {},
        {
          appName: string | null;
          executor: boolean;
          gitHost: string | null;
          repoName: string | null;
          repoUrl: string | null;
        },
        Name
      >;
      queueCleanup: FunctionReference<
        "mutation",
        "internal",
        {},
        boolean,
        Name
      >;
      register: FunctionReference<
        "mutation",
        "internal",
        { appName?: string; executor: string },
        null,
        Name
      >;
      start: FunctionReference<
        "mutation",
        "internal",
        { runId: string },
        string,
        Name
      >;
      startShip: FunctionReference<
        "mutation",
        "internal",
        { releaseId: string },
        string,
        Name
      >;
    };
    providers: {
      createSandbox: FunctionReference<
        "action",
        "internal",
        {
          autoDeleteInterval?: number;
          autoStopInterval?: number;
          domainAllowList?: Array<string>;
          envVars?: Record<string, string>;
          labels?: Record<string, string>;
          networkAllowList?: Array<string>;
          networkBlockAll?: boolean;
          secrets?: Record<string, string>;
          snapshot?: string;
        },
        { sandboxId: string; state: string },
        Name
      >;
      createSecret: FunctionReference<
        "action",
        "internal",
        { hosts: Array<string>; name: string; value: string },
        null,
        Name
      >;
      deleteSandbox: FunctionReference<
        "action",
        "internal",
        { sandboxId: string },
        null,
        Name
      >;
      deleteSecret: FunctionReference<
        "action",
        "internal",
        { name: string },
        null,
        Name
      >;
      getExecution: FunctionReference<
        "action",
        "internal",
        { executionId: string },
        null | {
          exitCode?: number;
          status: "running" | "completed" | "failed";
        },
        Name
      >;
      listExecutions: FunctionReference<
        "action",
        "internal",
        { limit?: number; sandboxId: string },
        Array<{
          _id: string;
          exitCode?: number;
          input: string;
          status: "running" | "completed" | "failed";
        }>,
        Name
      >;
      listSandboxes: FunctionReference<
        "action",
        "internal",
        { limit?: number },
        Array<{
          labels?: Record<string, string>;
          sandboxId: string;
          state: string;
        }>,
        Name
      >;
      listSecrets: FunctionReference<
        "action",
        "internal",
        {},
        Array<{ name: string }>,
        Name
      >;
      readFile: FunctionReference<
        "action",
        "internal",
        { path: string; sandboxId: string },
        string,
        Name
      >;
      runBackground: FunctionReference<
        "action",
        "internal",
        { command: string; envs?: Record<string, string>; sandboxId: string },
        { executionId: string },
        Name
      >;
      sendEmail: FunctionReference<
        "mutation",
        "internal",
        {
          from: string;
          html?: string;
          idempotencyKey: string;
          subject: string;
          text: string;
          to: string;
        },
        string,
        Name
      >;
      updateNetworkSettings: FunctionReference<
        "action",
        "internal",
        {
          domainAllowList?: Array<string>;
          networkAllowList?: Array<string>;
          networkBlockAll?: boolean;
          sandboxId: string;
        },
        null,
        Name
      >;
      updateSecret: FunctionReference<
        "action",
        "internal",
        { hosts?: Array<string>; name: string; value?: string },
        null,
        Name
      >;
      writeFile: FunctionReference<
        "action",
        "internal",
        { content: string; path: string; sandboxId: string },
        null,
        Name
      >;
    };
    repo: {
      basicAuth: FunctionReference<
        "action",
        "internal",
        { access: "read" | "write"; ttlSeconds: number },
        string,
        Name
      >;
      deleteRef: FunctionReference<
        "action",
        "internal",
        { ref: string },
        null,
        Name
      >;
      gitCredential: FunctionReference<
        "action",
        "internal",
        { write: boolean },
        {
          expiresAt: number;
          password: string;
          remoteUrl: string;
          repo: string;
          username: string;
        },
        Name
      >;
      mirror: FunctionReference<
        "action",
        "internal",
        { github: string; ref?: string; sha?: string; token: string },
        | { sha: string; status: "current" }
        | { from: string | null; sha: string; status: "pushed" }
        | { sha: string; status: "ahead"; target: string }
        | { sha: string; status: "diverged"; target: string },
        Name
      >;
      pushPack: FunctionReference<
        "action",
        "internal",
        {
          newSha: string;
          oldSha?: string | null;
          ref: string;
          storageId: string;
        },
        {
          after: string;
          before: string | null;
          bytes: number;
          ref: string;
          updated: boolean;
        },
        Name
      >;
      readRefs: FunctionReference<
        "action",
        "internal",
        { refs: Array<string> },
        Array<{ ref: string; sha: string | null }>,
        Name
      >;
      refs: FunctionReference<
        "action",
        "internal",
        {},
        {
          refs: Array<{ ref: string; sha: string }>;
          repo: string;
          repoUrl: string;
        },
        Name
      >;
      setup: FunctionReference<
        "action",
        "internal",
        { name: string },
        { created: boolean; gitHost: string; repo: string; repoUrl: string },
        Name
      >;
      updateRef: FunctionReference<
        "action",
        "internal",
        { from: string; ref: string; to: string },
        boolean,
        Name
      >;
      uploadUrl: FunctionReference<"mutation", "internal", {}, string, Name>;
    };
    warm: {
      createSnapshot: FunctionReference<
        "action",
        "internal",
        {
          commit: string;
          context: Array<{
            mode?: number;
            path: string;
            repoPath?: string;
            sha256?: string;
            text?: string;
          }>;
          cpu?: number;
          disk?: number;
          dockerfile: string;
          memory?: number;
          name: string;
        },
        { state: string },
        Name
      >;
      deleteSnapshot: FunctionReference<
        "action",
        "internal",
        { name: string },
        null,
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { key: string },
        {
          attempts: number;
          builtAt?: number;
          commit: string;
          createdAt: number;
          error?: string;
          inputsHash: string;
          key: string;
          lastUsedAt: number;
          manager: string;
          name: string;
          queuedAt?: number;
          retryAt?: number;
          size?: number;
          state: "queued" | "building" | "ready" | "failed" | "deferred";
          uses: number;
        } | null,
        Name
      >;
      getSnapshot: FunctionReference<
        "action",
        "internal",
        { name: string },
        null | { errorReason?: string; size?: number; state: string },
        Name
      >;
      list: FunctionReference<
        "query",
        "internal",
        {},
        Array<{
          attempts: number;
          builtAt?: number;
          commit: string;
          createdAt: number;
          error?: string;
          inputsHash: string;
          key: string;
          lastUsedAt: number;
          manager: string;
          name: string;
          queuedAt?: number;
          retryAt?: number;
          size?: number;
          state: "queued" | "building" | "ready" | "failed" | "deferred";
          uses: number;
        }>,
        Name
      >;
      readFiles: FunctionReference<
        "action",
        "internal",
        {
          commit?: string;
          hash?: Array<string>;
          paths: Array<string>;
          ref?: string;
        },
        {
          commit: string;
          files: Array<{ path: string; text: string | null }>;
          sha256: Array<{ path: string; sha256: string | null }>;
        },
        Name
      >;
      remove: FunctionReference<
        "mutation",
        "internal",
        { key: string },
        null,
        Name
      >;
      request: FunctionReference<
        "mutation",
        "internal",
        {
          commit: string;
          inputsHash: string;
          key: string;
          manager: string;
          name: string;
        },
        {
          scheduled: boolean;
          state:
            "queued" | "building" | "ready" | "failed" | "deferred" | "off";
        },
        Name
      >;
      update: FunctionReference<
        "mutation",
        "internal",
        {
          attempt?: boolean;
          builtAt?: number;
          error?: string | null;
          key: string;
          retryAt?: number | null;
          size?: number;
          state?: "queued" | "building" | "ready" | "failed" | "deferred";
          used?: boolean;
        },
        null,
        Name
      >;
    };
  };
