// The marketplace components Chef composes (convex.config.ts), as the calls
// the host's cloud executor needs (src/client/chefCloud.ts): Daytona for
// sandboxes and their secrets, Resend for build emails. Each is a thin
// pass-through to the child component, so the host can build Chef's
// `SandboxApi` and `SecretsApi` with `daytonaEffects` over them, as a host
// with its own Daytona component does.
//
// The children run in gateway mode: a component sees none of the app's
// environment variables, so there is never a DAYTONA_API_KEY or
// RESEND_API_KEY here, and the deployment's service token is the
// credential. Component functions are callable only by the app's own
// functions, never by a client.
import { v } from "convex/values";
import { action, mutation } from "./_generated/server.js";
import { components } from "./_generated/api.js";
import { Daytona } from "../../vendor/marketplace/daytona/dist/client/index.js";
import { Resend } from "../../vendor/marketplace/resend/dist/client/index.js";

export const daytona = new Daytona(components.daytona);
// testMode off: Chef only ever emails the address the host configured.
const resend = new Resend(components.resend, { testMode: false });

const vRecord = v.record(v.string(), v.string());
const vNetwork = {
  networkBlockAll: v.optional(v.boolean()),
  networkAllowList: v.optional(v.array(v.string())),
  domainAllowList: v.optional(v.array(v.string())),
};
const vStatus = v.union(v.literal("running"), v.literal("completed"), v.literal("failed"));

export const createSandbox = action({
  args: {
    snapshot: v.optional(v.string()),
    envVars: v.optional(vRecord),
    secrets: v.optional(vRecord),
    labels: v.optional(vRecord),
    autoStopInterval: v.optional(v.number()),
    autoDeleteInterval: v.optional(v.number()),
    ...vNetwork,
  },
  returns: v.object({ sandboxId: v.string(), state: v.string() }),
  handler: async (ctx, args) => {
    const r = await daytona.createSandbox(ctx, args);
    return { sandboxId: r.sandboxId, state: r.state };
  },
});

export const deleteSandbox = action({
  args: { sandboxId: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await daytona.deleteSandbox(ctx, args);
    return null;
  },
});

export const listSandboxes = action({
  args: { limit: v.optional(v.number()) },
  returns: v.array(v.object({ sandboxId: v.string(), state: v.string(), labels: v.optional(vRecord) })),
  handler: async (ctx, args) => {
    const limit = Math.min(200, Math.max(1, Math.floor(args.limit ?? 100) || 100));
    const rows = await daytona.listSandboxes(ctx, { limit });
    return rows.map((r) => ({
      sandboxId: r.sandboxId,
      state: r.state,
      ...(r.labels !== undefined ? { labels: r.labels } : {}),
    }));
  },
});

export const updateNetworkSettings = action({
  args: { sandboxId: v.string(), ...vNetwork },
  returns: v.null(),
  handler: async (ctx, args) => {
    await daytona.updateNetworkSettings(ctx, args);
    return null;
  },
});

/**
 * Start a background command. `envs` reach only that command: the Daytona
 * component writes them to a private file the command sources and deletes,
 * and stores only the command.
 */
export const runBackground = action({
  args: { sandboxId: v.string(), command: v.string(), envs: v.optional(vRecord) },
  returns: v.object({ executionId: v.string() }),
  handler: async (ctx, args) => {
    const r = await daytona.runBackground(ctx, args);
    return { executionId: String(r.executionId) };
  },
});

export const getExecution = action({
  args: { executionId: v.string() },
  returns: v.union(v.null(), v.object({ status: vStatus, exitCode: v.optional(v.number()) })),
  handler: async (ctx, args) => {
    const e = await daytona.getExecution(ctx, args);
    if (!e) return null;
    return { status: e.status, ...(e.exitCode !== undefined ? { exitCode: e.exitCode } : {}) };
  },
});

export const listExecutions = action({
  args: { sandboxId: v.string(), limit: v.optional(v.number()) },
  returns: v.array(v.object({ _id: v.string(), input: v.string(), status: vStatus, exitCode: v.optional(v.number()) })),
  handler: async (ctx, args) => {
    const limit = Math.min(100, Math.max(1, Math.floor(args.limit ?? 50) || 50));
    const rows = await daytona.listExecutions(ctx, { sandboxId: args.sandboxId, limit });
    return rows.map((r) => ({
      _id: String(r._id),
      input: r.input,
      status: r.status,
      ...(r.exitCode !== undefined ? { exitCode: r.exitCode } : {}),
    }));
  },
});

export const readFile = action({
  args: { sandboxId: v.string(), path: v.string() },
  returns: v.string(),
  handler: async (ctx, args) => await daytona.readFile(ctx, args),
});

export const writeFile = action({
  args: { sandboxId: v.string(), path: v.string(), content: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await daytona.writeFile(ctx, args);
    return null;
  },
});

export const createSecret = action({
  args: { name: v.string(), value: v.string(), hosts: v.array(v.string()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    await daytona.createSecret(ctx, args);
    return null;
  },
});

export const updateSecret = action({
  args: { name: v.string(), value: v.optional(v.string()), hosts: v.optional(v.array(v.string())) },
  returns: v.null(),
  handler: async (ctx, args) => {
    await daytona.updateSecret(ctx, args);
    return null;
  },
});

export const deleteSecret = action({
  args: { name: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await daytona.deleteSecret(ctx, args);
    return null;
  },
});

/** Names only: a secret's value is never readable back. */
export const listSecrets = action({
  args: {},
  returns: v.array(v.object({ name: v.string() })),
  handler: async (ctx) => (await daytona.listSecrets(ctx)).map((s) => ({ name: s.name })),
});

/**
 * One build email through the Resend component, deduped by Chef's
 * idempotency key. The host only calls this with a `from` on a sending
 * domain verified for this deployment (chefCloud's `email.from`).
 */
export const sendEmail = mutation({
  args: {
    from: v.string(),
    to: v.string(),
    subject: v.string(),
    text: v.string(),
    html: v.optional(v.string()),
    idempotencyKey: v.string(),
  },
  returns: v.string(),
  handler: async (ctx, args) => {
    const id = await resend.sendEmail(ctx, {
      from: args.from,
      to: args.to,
      subject: args.subject,
      text: args.text,
      ...(args.html !== undefined ? { html: args.html } : {}),
      idempotencyKey: args.idempotencyKey,
    });
    return String(id);
  },
});
