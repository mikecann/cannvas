// Warm snapshots (docs/chef-pipeline.md, "Warm snapshots"): the app's own
// Daytona snapshots with its dependencies' caches in them, so a build, a
// preview deploy and "Ship it" install offline instead of from the registry.
// The host's code (src/client/chefWarm.ts) decides; this keeps the record
// (`warmSnapshots`), schedules the lazy build through the host's executor
// (op "warmBuild"), and does the parts that need this component's children:
// reading the dependency files of a commit from the app's repo (Code
// Storage, read-only token, in this action), and starting a snapshot build
// whose context is made of those files, fetched and checked here.
//
// Never imports @convex-dev/feedback: what the files mean (the install plan,
// the inputs, the key) is the host's to work out. Every function here is
// reachable only from the host's own functions.
import { v } from "convex/values";
import { action, internalAction, mutation, query } from "./_generated/server.js";
import { internal } from "./_generated/api.js";
import { callExecutor, readConfig } from "./orchestration.js";
import { remote } from "./repo.js";
import { daytona } from "./providers.js";
import { vWarmState, warmFields } from "./schema.js";
import { fetchCommit, isSha } from "../shared/gitHttp.js";

/** Builds of one key tried at most this many times. */
export const MAX_WARM_ATTEMPTS = 3;
/** A build still queued this long after it was scheduled is scheduled again. */
const QUEUED_STUCK_MS = 3600_000;
const KEY = /^[0-9a-f]{64}$/;
const NAME = /^chef-warm-[0-9a-f]{12}$/;

const vRow = v.object(warmFields);

const strip = <T extends { _id: unknown; _creationTime: unknown }>(r: T) => {
  const { _id, _creationTime, ...rest } = r;
  return rest;
};

/** One warm snapshot's record, by key. */
export const get = query({
  args: { key: v.string() },
  returns: v.union(vRow, v.null()),
  handler: async (ctx, { key }) => {
    const row = await ctx.db
      .query("warmSnapshots")
      .withIndex("by_key", (q) => q.eq("key", key))
      .unique();
    return row ? strip(row) : null;
  },
});

/** Every warm snapshot's record (a handful). */
export const list = query({
  args: {},
  returns: v.array(vRow),
  handler: async (ctx) => (await ctx.db.query("warmSnapshots").take(100)).map(strip),
});

/**
 * Ask for the warm snapshot of a key: the first time, the record (queued)
 * and its build, scheduled through the host's executor; a failed or
 * deferred one again once its `retryAt` has passed (a few times at most).
 * Never twice for one key at once: the record is the lock. Returns its
 * state and whether a build was scheduled now. Nothing without an executor.
 */
export const request = mutation({
  args: { key: v.string(), name: v.string(), commit: v.string(), inputsHash: v.string(), manager: v.string() },
  returns: v.object({ state: v.union(vWarmState, v.literal("off")), scheduled: v.boolean() }),
  handler: async (ctx, args) => {
    if (!KEY.test(args.key) || !NAME.test(args.name) || !isSha(args.commit) || !KEY.test(args.inputsHash)) {
      throw new Error("Bad warm snapshot request");
    }
    if (args.name !== `chef-warm-${args.key.slice(0, 12)}`) throw new Error("The name isn't the key's");
    if (!(await readConfig(ctx))?.executorHandle) return { state: "off" as const, scheduled: false };
    const now = Date.now();
    const row = await ctx.db
      .query("warmSnapshots")
      .withIndex("by_key", (q) => q.eq("key", args.key))
      .unique();
    if (row) {
      const again =
        row.attempts < MAX_WARM_ATTEMPTS &&
        (((row.state === "failed" || row.state === "deferred") && (row.retryAt ?? 0) <= now) ||
          // A scheduled build that never got going (its action failed before it said anything).
          (row.state === "queued" && now - (row.queuedAt ?? row.createdAt) > QUEUED_STUCK_MS));
      if (!again) return { state: row.state, scheduled: false };
      await ctx.db.patch("warmSnapshots", row._id, {
        state: "queued",
        commit: args.commit,
        queuedAt: now,
        error: undefined,
        retryAt: undefined,
        ...(row.state === "queued" ? { attempts: row.attempts + 1 } : {}),
      });
    } else {
      await ctx.db.insert("warmSnapshots", {
        key: args.key,
        name: args.name,
        state: "queued",
        commit: args.commit,
        inputsHash: args.inputsHash,
        manager: args.manager.slice(0, 20),
        createdAt: now,
        queuedAt: now,
        lastUsedAt: now,
        uses: 0,
        attempts: 0,
      });
    }
    await ctx.scheduler.runAfter(0, internal.warm.build, { key: args.key });
    return { state: "queued" as const, scheduled: true };
  },
});

/** The scheduled build: the host's executor does it (chefWarm.ts buildWarmSnapshot). */
export const build = internalAction({
  args: { key: v.string() },
  returns: v.null(),
  handler: async (ctx, { key }) => {
    await callExecutor(ctx, { op: "warmBuild", key });
    return null;
  },
});

/** Change a record: its state and what goes with it. `error: null` clears it. */
export const update = mutation({
  args: {
    key: v.string(),
    state: v.optional(vWarmState),
    size: v.optional(v.number()),
    builtAt: v.optional(v.number()),
    error: v.optional(v.union(v.string(), v.null())),
    retryAt: v.optional(v.union(v.number(), v.null())),
    attempt: v.optional(v.boolean()),
    used: v.optional(v.boolean()),
  },
  returns: v.null(),
  handler: async (ctx, a) => {
    const row = await ctx.db
      .query("warmSnapshots")
      .withIndex("by_key", (q) => q.eq("key", a.key))
      .unique();
    if (!row) return null;
    await ctx.db.patch("warmSnapshots", row._id, {
      ...(a.state !== undefined ? { state: a.state } : {}),
      ...(a.size !== undefined ? { size: a.size } : {}),
      ...(a.builtAt !== undefined ? { builtAt: a.builtAt } : {}),
      ...(a.error !== undefined ? { error: a.error === null ? undefined : a.error.slice(0, 500) } : {}),
      ...(a.retryAt !== undefined ? { retryAt: a.retryAt === null ? undefined : a.retryAt } : {}),
      ...(a.attempt ? { attempts: row.attempts + 1 } : {}),
      ...(a.used ? { uses: row.uses + 1, lastUsedAt: Date.now() } : {}),
    });
    return null;
  },
});

/** Forget a record, once its snapshot is deleted. */
export const remove = mutation({
  args: { key: v.string() },
  returns: v.null(),
  handler: async (ctx, { key }) => {
    const row = await ctx.db
      .query("warmSnapshots")
      .withIndex("by_key", (q) => q.eq("key", key))
      .unique();
    if (row) await ctx.db.delete("warmSnapshots", row._id);
    return null;
  },
});

// ---------------------------------------------------------------- the repo's files

/** The largest file readFiles returns as text, and all of them together. */
const MAX_TEXT_BYTES = 8 * 1024 * 1024;
/** The largest file readFiles hashes, and that createSnapshot takes (the gateway's per-file limit). */
const MAX_FILE_BYTES = 16 * 1024 * 1024;

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes as BufferSource));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * Files of one commit (or a branch's tip) of the app's repo, read here with
 * a read-only token: `paths` as text (null if missing, not a regular file,
 * or too big), `hash` as sha256 only. The host works out the warm install's
 * inputs from them (src/client/chefWarm.ts inputsFromRepo), with the same
 * functions the sandbox's installer runs on its checkout.
 */
export const readFiles = action({
  args: {
    ref: v.optional(v.string()),
    commit: v.optional(v.string()),
    paths: v.array(v.string()),
    hash: v.optional(v.array(v.string())),
  },
  returns: v.object({
    commit: v.string(),
    files: v.array(v.object({ path: v.string(), text: v.union(v.string(), v.null()) })),
    sha256: v.array(v.object({ path: v.string(), sha256: v.union(v.string(), v.null()) })),
  }),
  handler: async (ctx, args) => {
    if ((args.ref === undefined) === (args.commit === undefined)) throw new Error("Give a ref or a commit");
    if (args.paths.length > 20 || (args.hash?.length ?? 0) > 40) throw new Error("Too many paths");
    const c = await fetchCommit(await remote(ctx, false), {
      ...(args.ref !== undefined ? { ref: args.ref } : {}),
      ...(args.commit !== undefined ? { commit: args.commit } : {}),
    });
    const td = new TextDecoder();
    let total = 0;
    const files = args.paths.map((path) => {
      const b = c.read(path);
      if (!b || b.length > MAX_TEXT_BYTES || total + b.length > MAX_TEXT_BYTES) return { path, text: null };
      total += b.length;
      return { path, text: td.decode(b) };
    });
    const sha256: Array<{ path: string; sha256: string | null }> = [];
    for (const path of args.hash ?? []) {
      const b = c.read(path);
      sha256.push({ path, sha256: b && b.length <= MAX_FILE_BYTES ? await sha256Hex(b) : null });
    }
    return { commit: c.commit, files, sha256 };
  },
});

// ---------------------------------------------------------------- snapshots

const vContextFile = v.object({
  path: v.string(),
  mode: v.optional(v.number()),
  // Written as is (the Dockerfile's own files, package.json's install fields).
  text: v.optional(v.string()),
  // Or a file of the commit, fetched here and checked against its sha256.
  repoPath: v.optional(v.string()),
  sha256: v.optional(v.string()),
});

const CONTEXT_PATH = /^[A-Za-z0-9._@+-]+(\/[A-Za-z0-9._@+-]+)*$/;

/**
 * Start building a warm snapshot: the Dockerfile the host made, and its
 * context. Files from the repo are read here, at `commit`, and must have the
 * sha256 the host's key was made from, so the snapshot holds exactly what
 * was committed and keyed. Returns once Daytona has the build (usually
 * `pending`); getSnapshot follows it.
 */
export const createSnapshot = action({
  args: {
    name: v.string(),
    dockerfile: v.string(),
    commit: v.string(),
    context: v.array(vContextFile),
    cpu: v.optional(v.number()),
    memory: v.optional(v.number()),
    disk: v.optional(v.number()),
  },
  returns: v.object({ state: v.string() }),
  handler: async (ctx, args) => {
    if (!NAME.test(args.name)) throw new Error("Not a warm snapshot name");
    if (!isSha(args.commit)) throw new Error("Bad commit");
    if (args.context.length > 40) throw new Error("Too many context files");
    const fromRepo = args.context.filter((f) => f.repoPath !== undefined);
    const c = fromRepo.length ? await fetchCommit(await remote(ctx, false), { commit: args.commit }) : null;
    const context: Array<{ path: string; bytes: Uint8Array | string; mode?: number }> = [];
    for (const f of args.context) {
      if (!CONTEXT_PATH.test(f.path) || f.path.split("/").some((s) => s === "." || s === "..")) throw new Error(`Bad context path ${f.path}`);
      let bytes: Uint8Array | string;
      if (f.repoPath !== undefined) {
        const b = c!.read(f.repoPath);
        if (!b) throw new Error(`${f.repoPath} isn't in ${args.commit.slice(0, 12)}`);
        if (b.length > MAX_FILE_BYTES) throw new Error(`${f.repoPath} is over 16 MB`);
        if (!f.sha256 || (await sha256Hex(b)) !== f.sha256) throw new Error(`${f.repoPath} doesn't match its sha256`);
        bytes = b;
      } else if (f.text !== undefined) bytes = f.text;
      else throw new Error(`${f.path} has no content`);
      context.push({ path: f.path, bytes, ...(f.mode !== undefined ? { mode: f.mode } : {}) });
    }
    const r = await daytona.createSnapshot(ctx, {
      name: args.name,
      dockerfile: args.dockerfile,
      context,
      ...(args.cpu !== undefined ? { cpu: args.cpu } : {}),
      ...(args.memory !== undefined ? { memory: args.memory } : {}),
      ...(args.disk !== undefined ? { disk: args.disk } : {}),
    });
    return { state: r.state };
  },
});

/** A snapshot's state as Daytona last reported it, or null if there is none. */
export const getSnapshot = action({
  args: { name: v.string() },
  returns: v.union(
    v.null(),
    v.object({ state: v.string(), size: v.optional(v.number()), errorReason: v.optional(v.string()) }),
  ),
  handler: async (ctx, { name }) => {
    if (!NAME.test(name)) throw new Error("Not a warm snapshot name");
    const s = (await daytona.getSnapshot(ctx, { name })) ?? (await daytona.refreshSnapshot(ctx, { name }));
    if (!s) return null;
    return {
      state: s.state,
      ...(typeof s.size === "number" ? { size: s.size } : {}),
      ...(s.errorReason ? { errorReason: s.errorReason.slice(0, 300) } : {}),
    };
  },
});

/** Delete a warm snapshot (gone already is success). Refused while a live sandbox uses it: never forced. */
export const deleteSnapshot = action({
  args: { name: v.string() },
  returns: v.null(),
  handler: async (ctx, { name }) => {
    if (!NAME.test(name)) throw new Error("Not a warm snapshot name");
    await daytona.deleteSnapshot(ctx, { name });
    return null;
  },
});
