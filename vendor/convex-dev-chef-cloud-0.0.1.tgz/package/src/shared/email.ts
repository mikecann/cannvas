// The "build finished" and "build failed" emails. Two kinds of input:
//
// - trusted: URLs and shas the workflow built itself (preview URL, run
//   page, commit). These become the only links, and are still checked.
// - untrusted: the request title, the agent's summary, file paths it
//   changed, error text. These are scrubbed of secrets, shown with invisible
//   characters revealed, HTML-escaped, and defanged so mail clients don't
//   turn URLs in them into links.

import { scrub } from "@convex-dev/feedback/chef/scrub.js";
import { cleanMultiline, singleLine, truncate } from "@convex-dev/feedback/chef/text.js";

export type BuildEmailInput = {
  kind: "built" | "failed";
  /** The app's display name (trusted config). */
  appName: string;
  itemNumber: number;
  /** Untrusted: from the approved snapshot. */
  title: string;
  /** Untrusted: the agent's summary.md. */
  agentSummary?: string;
  /** Untrusted: paths from the diff. */
  filesChanged?: string[];
  /** Untrusted: error text from the runner or a step. */
  error?: string;
  /** Trusted: built by the workflow. */
  commitSha?: string;
  previewUrl?: string;
  /**
   * Trusted: the preview's one-time sign-in link, from the app's
   * loginLinkFunction, checked by the deploy script and the launcher. Shown
   * only in a built email with a preview, and only on the preview's own
   * origin; otherwise left out.
   */
  previewLoginUrl?: string;
  /**
   * Trusted: Chef's own fixed line for a built run with no preview, saying
   * why (src/chef/preview.ts NO_PREVIEW_NOTES). Shown as text, never a link.
   */
  note?: string;
  runPageUrl: string;
  /**
   * Trusted URLs: the run's screenshots in the component's file storage,
   * from the component itself (chefScreenshots.ts), never from a sandbox.
   * The name is the agent's and shown as untrusted text. A URL that fails
   * checkLink (a local backend's http storage) is left out, not thrown.
   */
  screenshots?: { name: string; url: string | null; width?: number; height?: number }[];
  /**
   * Hosts links may point at. Defaults to any `*.convex.cloud`,
   * `*.convex.site` or `*.convex.app` host; pass the panel's host too.
   */
  allowedLinkHosts?: (string | RegExp)[];
};

export type BuildEmail = { subject: string; html: string; text: string };

const DEFAULT_LINK_HOSTS: RegExp[] = [
  /^[a-z0-9-]+\.convex\.cloud$/,
  /^[a-z0-9-]+\.convex\.site$/,
  /^[a-z0-9-]+\.convex\.app$/,
];

const MAX_SUMMARY = 4000;
const MAX_ERROR = 1000;
const MAX_FILES = 50;
const MAX_SCREENSHOTS = 8;
const THUMB_WIDTH = 240;
const LOGIN_LINK_NOTE = "This link signs you in once and then expires. After that, open the preview and sign in as usual.";

/** Escapes text for HTML element content and quoted attribute values. */
export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/**
 * Breaks things mail clients turn into links: `scheme:` and `scheme://`
 * (http, https, javascript, data, mailto, ...) and `www.` hosts.
 */
export function defang(s: string): string {
  return s
    .replace(/\b([a-z][a-z0-9+.-]{1,15}):(\/\/)?/gi, (m, scheme: string, slashes?: string) =>
      /^(https?|ftp|javascript|vbscript|data|file|mailto|tel|sms|blob|ws|wss)$/i.test(scheme)
        ? `${scheme}[:]${slashes ?? ""}`
        : m,
    )
    .replace(/\bwww\./gi, "www[.]");
}

/** Untrusted text for display: secrets out, invisible chars shown, links defanged. */
function untrustedBlock(s: string, max: number): string {
  return defang(truncate(cleanMultiline(scrub(s)), max));
}

function untrustedLine(s: string, max: number): string {
  return defang(singleLine(scrub(s), max));
}

/**
 * Checks a trusted link: https only, no credentials, an allowed host.
 * Throws rather than dropping it, since a bad trusted URL is a bug.
 */
export function checkLink(
  url: string,
  allowedHosts: (string | RegExp)[] = DEFAULT_LINK_HOSTS,
): string {
  let u: URL;
  try {
    u = new URL(url);
  } catch {
    throw new Error("link is not a URL");
  }
  if (u.protocol !== "https:") throw new Error("link must be https");
  if (u.username !== "" || u.password !== "") {
    throw new Error("link must not carry credentials");
  }
  const host = u.hostname.toLowerCase();
  const ok = allowedHosts.some((h) =>
    typeof h === "string" ? h.toLowerCase() === host : h.test(host),
  );
  if (!ok) throw new Error(`link host ${host} is not allowed`);
  return u.toString();
}

/** Builds the email. Pure: the workflow sends it with an idempotency key. */
export function buildBuildEmail(input: BuildEmailInput): BuildEmail {
  if (!Number.isSafeInteger(input.itemNumber) || input.itemNumber <= 0) {
    throw new Error("itemNumber must be a positive integer");
  }
  const hosts = input.allowedLinkHosts ?? DEFAULT_LINK_HOSTS;
  const runPageUrl = checkLink(input.runPageUrl, hosts);
  const previewUrl =
    input.kind === "built" && input.previewUrl !== undefined
      ? checkLink(input.previewUrl, hosts)
      : undefined;
  let previewLoginUrl: string | undefined;
  if (previewUrl !== undefined && input.previewLoginUrl !== undefined) {
    try {
      const u = checkLink(input.previewLoginUrl, hosts);
      if (new URL(u).origin === new URL(previewUrl).origin) previewLoginUrl = u;
    } catch {
      // Left out: the plain preview link still works.
    }
  }
  let commit: string | undefined;
  if (input.commitSha !== undefined) {
    if (!/^[0-9a-f]{7,40}$/.test(input.commitSha)) throw new Error("bad commit sha");
    commit = input.commitSha.slice(0, 12);
  }

  const app = singleLine(input.appName, 60);
  const title = untrustedLine(input.title, 120);
  const summary =
    input.agentSummary !== undefined
      ? untrustedBlock(input.agentSummary, MAX_SUMMARY)
      : undefined;
  const error =
    input.error !== undefined ? untrustedBlock(input.error, MAX_ERROR) : undefined;
  const files = (input.filesChanged ?? []).slice(0, MAX_FILES).map((f) => untrustedLine(f, 200));
  const moreFiles = Math.max(0, (input.filesChanged?.length ?? 0) - MAX_FILES);
  const shots: { name: string; url: string; thumbHeight?: number }[] = [];
  let shotsWithheld = 0;
  for (const s of (input.screenshots ?? []).slice(0, MAX_SCREENSHOTS)) {
    let url: string;
    try {
      if (s.url === null) throw new Error("no url");
      url = checkLink(s.url, hosts);
    } catch {
      shotsWithheld++;
      continue;
    }
    const w = s.width;
    const h = s.height;
    const thumbHeight =
      w !== undefined && h !== undefined && Number.isFinite(w) && Number.isFinite(h) && w > 0 && h > 0
        ? Math.max(1, Math.min(2000, Math.round((h * THUMB_WIDTH) / w)))
        : undefined;
    shots.push({ name: untrustedLine(s.name, 40), url, ...(thumbHeight !== undefined ? { thumbHeight } : {}) });
  }

  const verb = input.kind === "built" ? "built" : "failed";
  const subject = singleLine(`[${app}] Chef ${verb} #${input.itemNumber}: ${title}`, 160);

  // Plain text.
  const text: string[] = [
    input.kind === "built"
      ? `Chef built request #${input.itemNumber}: ${title}`
      : `Chef couldn't build request #${input.itemNumber}: ${title}`,
    "",
  ];
  const note = input.kind === "built" && previewUrl === undefined && input.note !== undefined ? singleLine(input.note, 300) : undefined;
  if (previewUrl) text.push(`Preview: ${previewUrl}`);
  if (note) text.push(note);
  if (previewLoginUrl) {
    text.push(`Open the preview, signed in: ${previewLoginUrl}`, `  (${LOGIN_LINK_NOTE})`);
  }
  if (commit) text.push(`Commit: ${commit}`);
  text.push(`Run: ${runPageUrl}`, "");
  if (error) text.push("What went wrong:", error, "");
  if (shots.length > 0) {
    text.push("Screenshots (the build in its sandbox, with test data):", ...shots.map((s) => `  ${s.name}: ${s.url}`), "");
  }
  if (shotsWithheld > 0) text.push(`${shotsWithheld} screenshot link(s) left out: not on an allowed host.`, "");
  if (summary) text.push("The agent's summary (unverified):", summary, "");
  if (files.length > 0) {
    text.push("Files changed:", ...files.map((f) => `  ${f}`));
    if (moreFiles > 0) text.push(`  and ${moreFiles} more`);
    text.push("");
  }

  // HTML. Every interpolation is escaped; hrefs come only from checkLink.
  const e = escapeHtml;
  const pre = (s: string) =>
    `<div style="white-space:pre-wrap;font-family:ui-monospace,monospace;font-size:13px;background:#f6f6f6;padding:12px;border-radius:6px">${e(s)}</div>`;
  const html: string[] = [
    `<div style="font-family:-apple-system,system-ui,sans-serif;font-size:15px;line-height:1.5;color:#111">`,
    `<p>${
      input.kind === "built" ? "Chef built" : "Chef couldn't build"
    } request #${input.itemNumber}: <strong>${e(title)}</strong></p>`,
  ];
  if (previewUrl) {
    html.push(`<p><a href="${e(previewUrl)}">Open the preview</a></p>`);
  }
  if (note) html.push(`<p>${e(note)}</p>`);
  if (previewLoginUrl) {
    html.push(
      `<p><a href="${e(previewLoginUrl)}">Open the preview, signed in</a><br><span style="font-size:13px;color:#555">${e(LOGIN_LINK_NOTE)}</span></p>`,
    );
  }
  html.push(
    `<p>${commit ? `Commit <code>${e(commit)}</code> &middot; ` : ""}<a href="${e(runPageUrl)}">Run details</a></p>`,
  );
  if (error) html.push(`<p>What went wrong:</p>`, pre(error));
  if (shots.length > 0) {
    // Thumbnails and links only from checked storage URLs; the PNGs were
    // checked when stored. The name is escaped text.
    html.push(
      `<p>Screenshots (the build in its sandbox, with test data):</p>`,
      `<p>${shots
        .map(
          (s) =>
            `<a href="${e(s.url)}" style="display:inline-block;margin:0 8px 8px 0;text-decoration:none;color:#111;vertical-align:top"><img src="${e(s.url)}" alt="${e(s.name)}" width="${THUMB_WIDTH}"${
              s.thumbHeight !== undefined ? ` height="${s.thumbHeight}"` : ""
            } style="display:block;border:1px solid #ddd;border-radius:4px"><span style="font-size:13px">${e(s.name)}</span></a>`,
        )
        .join("")}</p>`,
    );
  }
  if (shotsWithheld > 0) html.push(`<p>${shotsWithheld} screenshot link(s) left out: not on an allowed host.</p>`);
  if (summary) html.push(`<p>The agent's summary (unverified):</p>`, pre(summary));
  if (files.length > 0) {
    html.push(
      `<p>Files changed:</p><ul>${files.map((f) => `<li><code>${e(f)}</code></li>`).join("")}${
        moreFiles > 0 ? `<li>and ${moreFiles} more</li>` : ""
      }</ul>`,
    );
  }
  html.push(`</div>`);

  return { subject, html: html.join("\n"), text: text.join("\n") };
}

// ------------------------------------------------------------------ ship

export type ShipEmailInput = {
  kind: "shipped" | "failed";
  /** The app's display name (trusted config). */
  appName: string;
  /** The release number. */
  seq: number;
  /** Trusted: the commit the host deployed. */
  sha: string;
  /** Trusted: the live site (the ship config's siteUrl, or the deployment's .convex.site). */
  siteUrl?: string;
  /** Untrusted: the requests the release covers, from their snapshots. */
  requests: { number: number | null; title: string }[];
  /** Untrusted: what failed. */
  error?: string;
  /** Whether main moved (it only moves once the live site is verified). */
  mainMoved?: boolean;
  /** Trusted: the panel. */
  panelUrl?: string;
  allowedLinkHosts?: (string | RegExp)[];
};

/**
 * "Release #n is live" or "Release #n didn't ship", for the owner. Pure,
 * like buildBuildEmail: request titles and the error are untrusted text.
 */
export function buildShipEmail(input: ShipEmailInput): BuildEmail {
  if (!Number.isSafeInteger(input.seq) || input.seq <= 0) throw new Error("seq must be a positive integer");
  if (!/^[0-9a-f]{40}$/.test(input.sha)) throw new Error("sha must be a commit id");
  const hosts = input.allowedLinkHosts ?? DEFAULT_LINK_HOSTS;
  const site = input.siteUrl ? checkLink(input.siteUrl, hosts) : null;
  const panel = input.panelUrl ? checkLink(input.panelUrl, hosts) : null;
  const app = singleLine(input.appName, 80);
  const short = input.sha.slice(0, 12);
  const reqs = input.requests.slice(0, MAX_FILES).map((r) => ({
    label: r.number !== null ? `#${r.number}` : "",
    title: untrustedLine(r.title, 200),
  }));
  const shipped = input.kind === "shipped";
  const subject = shipped
    ? `${app}: release #${input.seq} is live`
    : `${app}: release #${input.seq} didn't ship`;
  const lines: string[] = [];
  if (shipped) {
    lines.push(`Release #${input.seq} (${short}) is live, and main is now ${short}.`);
  } else {
    lines.push(`Release #${input.seq} (${short}) didn't ship.`);
    lines.push(input.mainMoved ? "main moved." : "main is where it was.");
    if (input.error) lines.push("", "What failed:", untrustedBlock(input.error, MAX_ERROR));
  }
  if (reqs.length) {
    lines.push("", shipped ? "Shipped:" : "In this release:");
    for (const r of reqs) lines.push(`- ${r.label ? r.label + " " : ""}${r.title}`);
  }
  if (site) lines.push("", `Open the app: ${site}`);
  if (panel) lines.push(`The panel: ${panel}`);
  const text = lines.join("\n") + "\n";
  const li = reqs.map((r) => `<li>${escapeHtml(r.label ? r.label + " " : "")}${escapeHtml(r.title)}</li>`).join("");
  const html = [
    `<p>${escapeHtml(lines[0])}</p>`,
    !shipped ? `<p>${escapeHtml(input.mainMoved ? "main moved." : "main is where it was.")}</p>` : "",
    !shipped && input.error ? `<pre>${escapeHtml(untrustedBlock(input.error, MAX_ERROR))}</pre>` : "",
    li ? `<p>${shipped ? "Shipped:" : "In this release:"}</p><ul>${li}</ul>` : "",
    site ? `<p><a href="${escapeHtml(site)}">Open the app</a></p>` : "",
    panel ? `<p><a href="${escapeHtml(panel)}">The panel</a></p>` : "",
  ].join("");
  return { subject, html, text };
}

// -------------------------------------------------------------- requester

export type LiveEmailInput = {
  /** The app's display name (trusted config). */
  appName: string;
  /** Untrusted: the request's title. */
  title: string;
  /** Trusted: where the app is (chefCloud's notify.appUrl, or the live site). */
  appUrl: string;
  allowedLinkHosts?: (string | RegExp)[];
};

/**
 * "“<title>” is live in <app>", for the person who asked for it. Short, and
 * pure like the others: the title is untrusted text, the one link checked.
 */
export function buildLiveEmail(input: LiveEmailInput): BuildEmail {
  const url = checkLink(input.appUrl, input.allowedLinkHosts ?? DEFAULT_LINK_HOSTS);
  const app = singleLine(input.appName, 80);
  const title = untrustedLine(input.title, 120);
  const subject = singleLine(`“${title}” is live in ${app}`, 160);
  const first = `You asked for “${title}”, and it's now live in ${app}.`;
  const text = `${first}\n\nOpen ${app}: ${url}\n\nThanks for asking for it.\n`;
  const html = [
    `<p>${escapeHtml(first)}</p>`,
    `<p><a href="${escapeHtml(url)}">Open ${escapeHtml(app)}</a></p>`,
    `<p>Thanks for asking for it.</p>`,
  ].join("");
  return { subject, html, text };
}
