// Git's smart HTTP protocol, just enough to read refs, push a pack, move a
// branch and delete one on Code Storage from a Convex action, to read a
// few files of one commit (fetchCommit, for warm snapshots), and to mirror
// a branch to another host (mirrorBranch, `main` to GitHub after a ship). Plain fetch, so
// it runs in the default runtime, and the token never leaves the action.
// No Convex imports: the component's actions and the tests use it.
//
// https://git-scm.com/docs/http-protocol and
// https://git-scm.com/docs/pack-protocol (protocol v0, no side band).

import { inflateZlib } from "./inflate.js";

export const ZERO_SHA = "0".repeat(40);
const SHA = /^[0-9a-f]{40}$/;
const enc = new TextEncoder();
const dec = new TextDecoder();
const USER_AGENT = "git/2.45.0 (convex-feedback)";

export const isSha = (s: unknown): s is string => typeof s === "string" && SHA.test(s);

/** One pkt-line: four hex digits of total length, then the payload. */
export function pktLine(payload: string | Uint8Array): Uint8Array {
  const body = typeof payload === "string" ? enc.encode(payload) : payload;
  const n = body.length + 4;
  if (n > 65520) throw new Error("pkt-line too long");
  const out = new Uint8Array(n);
  out.set(enc.encode(n.toString(16).padStart(4, "0")), 0);
  out.set(body, 4);
  return out;
}

export const FLUSH = enc.encode("0000");

/** pkt-lines until the end of the buffer; a flush packet is null. */
export function parsePktLines(buf: Uint8Array): Array<string | null> {
  const out: Array<string | null> = [];
  let i = 0;
  while (i + 4 <= buf.length) {
    const n = parseInt(dec.decode(buf.subarray(i, i + 4)), 16);
    if (Number.isNaN(n)) throw new Error("bad pkt-line length");
    if (n === 0) {
      out.push(null);
      i += 4;
      continue;
    }
    if (n < 4 || i + n > buf.length) throw new Error("truncated pkt-line");
    out.push(dec.decode(buf.subarray(i + 4, i + n)));
    i += n;
  }
  return out;
}

export type Advertisement = { refs: Record<string, string>; capabilities: string[] };

/**
 * The ref advertisement from `GET <repo>/info/refs?service=<service>`. An
 * empty repository advertises only `capabilities^{}` with the zero sha.
 */
export function parseAdvertisement(body: Uint8Array, service: string): Advertisement {
  const lines = parsePktLines(body);
  let k = 0;
  // Smart servers start with "# service=<service>" and a flush.
  if (lines[0]?.startsWith("# service=")) {
    if (lines[0].trim() !== `# service=${service}`) throw new Error("unexpected service");
    k = lines[1] === null ? 2 : 1;
  }
  const refs: Record<string, string> = {};
  let capabilities: string[] = [];
  for (; k < lines.length; k++) {
    const line = lines[k];
    if (line === null) break;
    let text = line.replace(/\n$/, "");
    const nul = text.indexOf("\0");
    if (nul >= 0) {
      capabilities = text.slice(nul + 1).split(" ").filter(Boolean);
      text = text.slice(0, nul);
    }
    const [sha, name] = text.split(" ");
    if (!isSha(sha) || !name) throw new Error("bad ref line");
    if (name === "capabilities^{}") continue;
    if (name.endsWith("^{}")) continue; // peeled tags
    refs[name] = sha;
  }
  return { refs, capabilities };
}

export type RefUpdate = { ref: string; old: string; new: string };

const REF_NAME = /^refs\/heads\/[A-Za-z0-9._/-]+$/;

/** A branch ref Chef will touch: refs/heads/..., no `..`, no trailing `/` or `.lock`. */
export function checkRefName(ref: string): void {
  if (!REF_NAME.test(ref) || ref.includes("..") || ref.endsWith("/") || ref.endsWith(".lock") || ref.includes("//")) {
    throw new Error("bad ref name");
  }
}

/** `refs/heads/<name>` for a branch name; full ref names pass through. */
export const headRef = (name: string) => (name.startsWith("refs/") ? name : `refs/heads/${name}`);

/**
 * The body of `POST <repo>/git-receive-pack`: the commands, a flush, then
 * the pack. A request that only deletes refs carries no pack.
 */
export function receivePackRequest(updates: RefUpdate[], pack: Uint8Array | null): Uint8Array<ArrayBuffer> {
  if (updates.length === 0) throw new Error("nothing to update");
  const parts: Uint8Array[] = [];
  updates.forEach((u, i) => {
    for (const s of [u.old, u.new]) if (!isSha(s)) throw new Error("bad sha in a ref update");
    checkRefName(u.ref);
    const caps = i === 0 ? "\0report-status" : "";
    parts.push(pktLine(`${u.old} ${u.new} ${u.ref}${caps}\n`));
  });
  parts.push(FLUSH);
  const onlyDeletes = updates.every((u) => u.new === ZERO_SHA);
  if (!onlyDeletes) {
    if (!isPack(pack)) throw new Error("a push needs a pack");
    parts.push(pack);
  }
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let at = 0;
  for (const p of parts) {
    out.set(p, at);
    at += p.length;
  }
  return out;
}

/** Starts with `PACK` and is at least a header and a trailer long. */
export function isPack(pack: Uint8Array | null | undefined): pack is Uint8Array {
  return !!pack && pack.length >= 32 && dec.decode(pack.subarray(0, 4)) === "PACK";
}

/**
 * A pack with no objects: `PACK`, version 2, zero objects, and the SHA-1 of
 * those 12 bytes. What a push sends when every object it needs is already on
 * the server (moving a branch to a commit another branch has).
 */
export async function emptyPack(): Promise<Uint8Array> {
  const header = new Uint8Array([0x50, 0x41, 0x43, 0x4b, 0, 0, 0, 2, 0, 0, 0, 0]);
  const sum = new Uint8Array(await crypto.subtle.digest("SHA-1", header));
  const out = new Uint8Array(32);
  out.set(header, 0);
  out.set(sum, 12);
  return out;
}

export type PushReport = { unpack: string; refs: Record<string, { ok: boolean; reason?: string }> };

/** The report-status the server sends back. */
export function parseReportStatus(body: Uint8Array): PushReport {
  const report: PushReport = { unpack: "missing", refs: {} };
  for (const line of parsePktLines(body)) {
    if (line === null) continue;
    const text = line.replace(/\n$/, "");
    if (text.startsWith("unpack ")) report.unpack = text.slice(7);
    else if (text.startsWith("ok ")) report.refs[text.slice(3)] = { ok: true };
    else if (text.startsWith("ng ")) {
      const rest = text.slice(3);
      const sp = rest.indexOf(" ");
      report.refs[sp < 0 ? rest : rest.slice(0, sp)] = { ok: false, reason: sp < 0 ? "" : rest.slice(sp + 1) };
    }
  }
  return report;
}

/** A remote: the repository's https URL (no credentials) and a Basic header value. */
export type Remote = { url: string; basic: string };

/**
 * Split a Code Storage remote URL (`https://t:<token>@host/org/repo.git`)
 * into the bare URL and a pre-encoded Basic credential. Neither is logged.
 */
export function remoteFromUrl(withCredentials: string): Remote {
  const u = new URL(withCredentials);
  if (u.protocol !== "https:") throw new Error("the remote must be https");
  const user = decodeURIComponent(u.username || "t");
  const pass = decodeURIComponent(u.password);
  if (!pass) throw new Error("the remote URL carries no token");
  u.username = "";
  u.password = "";
  return { url: u.toString().replace(/\/$/, ""), basic: btoa(`${user}:${pass}`) };
}

/** The user name and token in a Code Storage remote URL, for a git credential helper. */
export function credentialFromUrl(withCredentials: string): { remoteUrl: string; username: string; password: string } {
  const u = new URL(withCredentials);
  if (u.protocol !== "https:") throw new Error("the remote must be https");
  const username = decodeURIComponent(u.username || "t");
  const password = decodeURIComponent(u.password);
  if (!password) throw new Error("the remote URL carries no token");
  u.username = "";
  u.password = "";
  return { remoteUrl: u.toString().replace(/\/$/, ""), username, password };
}

type Fetch = (url: string, init?: RequestInit) => Promise<Response>;

async function advertisement(remote: Remote, service: string, f: Fetch): Promise<Advertisement> {
  const res = await f(`${remote.url}/info/refs?service=${service}`, {
    headers: { authorization: `Basic ${remote.basic}`, "user-agent": USER_AGENT },
  });
  // Never quote the response: it is the server's, and the request held a token.
  if (res.status === 404) throw new Error("repository not found");
  if (!res.ok) throw new Error(`git ${service} advertisement failed: HTTP ${res.status}`);
  return parseAdvertisement(new Uint8Array(await res.arrayBuffer()), service);
}

/** Every branch (`refs/heads/*`) and the sha it points at. */
export async function listBranches(remote: Remote, f: Fetch = fetch): Promise<Record<string, string>> {
  const { refs } = await advertisement(remote, "git-upload-pack", f);
  return Object.fromEntries(Object.entries(refs).filter(([name]) => name.startsWith("refs/heads/")));
}

/** The sha each branch points at, or null. */
export async function readRefs(
  remote: Remote,
  names: string[],
  f: Fetch = fetch,
): Promise<Record<string, string | null>> {
  const { refs } = await advertisement(remote, "git-upload-pack", f);
  return Object.fromEntries(names.map((n) => [n, refs[headRef(n)] ?? null]));
}

async function receivePack(remote: Remote, body: Uint8Array<ArrayBuffer>, f: Fetch): Promise<PushReport> {
  const res = await f(`${remote.url}/git-receive-pack`, {
    method: "POST",
    headers: {
      authorization: `Basic ${remote.basic}`,
      "content-type": "application/x-git-receive-pack-request",
      accept: "application/x-git-receive-pack-result",
      "user-agent": USER_AGENT,
    },
    body,
  });
  if (!res.ok) throw new Error(`git push failed: HTTP ${res.status}`);
  return parseReportStatus(new Uint8Array(await res.arrayBuffer()));
}

export type PushOutcome = { before: string | null; after: string; updated: boolean };

/**
 * Point `ref` at `newSha`, sending `pack` (which must hold every object
 * reachable from `newSha` that the server lacks; a full pack always does).
 *
 * Never a force: it is a compare-and-swap on what the server advertises.
 * `oldSha` is the sha the caller believes the branch is at, or null/omitted
 * for a branch that must not exist yet. Anything else is refused before
 * anything is sent. The caller (the developer's CLI) checks that `newSha`
 * descends from `oldSha`; pushing the sha the branch already has is a no-op.
 */
export async function pushPack(
  remote: Remote,
  args: { ref: string; oldSha?: string | null; newSha: string; pack: Uint8Array },
  f: Fetch = fetch,
): Promise<PushOutcome> {
  const ref = headRef(args.ref);
  checkRefName(ref);
  if (!isSha(args.newSha) || args.newSha === ZERO_SHA) throw new Error("newSha must be 40 lowercase hex characters");
  const expected = args.oldSha ?? null;
  if (expected !== null && !isSha(expected)) throw new Error("oldSha must be 40 lowercase hex characters");
  const { refs } = await advertisement(remote, "git-receive-pack", f);
  const before = refs[ref] ?? null;
  if (before === args.newSha) return { before, after: args.newSha, updated: false };
  if (before !== expected) {
    throw new Error(
      before === null
        ? `${ref} doesn't exist on the remote; push it without oldSha`
        : `${ref} is at ${before}, not ${expected ?? "(none)"}; fetch and push again (never forced)`,
    );
  }
  const report = await receivePack(
    remote,
    receivePackRequest([{ ref, old: before ?? ZERO_SHA, new: args.newSha }], args.pack),
    f,
  );
  if (report.unpack !== "ok") throw new Error(`git push: unpack ${report.unpack}`);
  const r = report.refs[ref];
  if (!r?.ok) throw new Error(`git push refused: ${r?.reason || "no status"}`);
  return { before, after: args.newSha, updated: true };
}

/**
 * Move a branch from `from` to `to`, only if it is at `from` now, with an
 * empty pack: `to` must already be on the server. Returns false, changing
 * nothing, if the branch is elsewhere. The caller checks that `to`
 * descends from `from`.
 */
export async function updateRef(
  remote: Remote,
  args: { ref: string; from: string; to: string },
  f: Fetch = fetch,
): Promise<boolean> {
  const ref = headRef(args.ref);
  checkRefName(ref);
  if (!isSha(args.from) || !isSha(args.to)) throw new Error("bad sha");
  const { refs } = await advertisement(remote, "git-receive-pack", f);
  const now = refs[ref] ?? null;
  if (now === args.to) return true;
  if (now !== args.from) return false;
  const report = await receivePack(remote, receivePackRequest([{ ref, old: args.from, new: args.to }], await emptyPack()), f);
  if (report.unpack !== "ok") throw new Error(`git push: unpack ${report.unpack}`);
  const r = report.refs[ref];
  if (!r?.ok) throw new Error(`git push refused: ${r?.reason || "no status"}`);
  return true;
}

/** Delete a branch. A branch that doesn't exist is success. */
export async function deleteBranch(remote: Remote, branch: string, f: Fetch = fetch): Promise<boolean> {
  const ref = headRef(branch);
  checkRefName(ref);
  const { refs } = await advertisement(remote, "git-receive-pack", f);
  const old = refs[ref];
  if (!old) return false;
  const report = await receivePack(remote, receivePackRequest([{ ref, old, new: ZERO_SHA }], null), f);
  const r = report.refs[ref];
  if (!r?.ok) throw new Error(`git delete refused: ${r?.reason || "no status"}`);
  return true;
}

// ---------------------------------------------------------------- reading files

/** The largest upload-pack response fetchCommit reads. */
export const MAX_FETCH_BYTES = 48 * 1024 * 1024;

const OBJ_COMMIT = 1;
const OBJ_TREE = 2;
const OBJ_BLOB = 3;
const OBJ_TAG = 4;
const OBJ_OFS_DELTA = 6;
const OBJ_REF_DELTA = 7;
const TYPE_NAMES: Record<number, string> = { [OBJ_COMMIT]: "commit", [OBJ_TREE]: "tree", [OBJ_BLOB]: "blob", [OBJ_TAG]: "tag" };

const hex = (b: Uint8Array) => Array.from(b, (x) => x.toString(16).padStart(2, "0")).join("");

type PackEntry = { start: number; type: number; size: number; dataStart: number; end: number; baseOffset?: number; baseOid?: string };

/** The entries of a pack (version 2 or 3), each inflated once to find where it ends. */
export function parsePack(pack: Uint8Array): PackEntry[] {
  if (pack.length < 32 || dec.decode(pack.subarray(0, 4)) !== "PACK") throw new Error("not a pack");
  const version = (pack[4] << 24) | (pack[5] << 16) | (pack[6] << 8) | pack[7];
  if (version !== 2 && version !== 3) throw new Error(`pack version ${version}`);
  const count = ((pack[8] << 24) | (pack[9] << 16) | (pack[10] << 8) | pack[11]) >>> 0;
  const entries: PackEntry[] = [];
  let p = 12;
  for (let n = 0; n < count; n++) {
    const start = p;
    if (p >= pack.length) throw new Error("truncated pack");
    let c = pack[p++];
    const type = (c >> 4) & 7;
    let size = c & 15;
    let shift = 4;
    while (c & 0x80) {
      if (p >= pack.length) throw new Error("truncated pack");
      c = pack[p++];
      size += (c & 0x7f) * 2 ** shift;
      shift += 7;
    }
    const e: PackEntry = { start, type, size, dataStart: 0, end: 0 };
    if (type === OBJ_OFS_DELTA) {
      c = pack[p++];
      let off = c & 127;
      while (c & 128) {
        c = pack[p++];
        off = (off + 1) * 128 + (c & 127);
      }
      e.baseOffset = start - off;
    } else if (type === OBJ_REF_DELTA) {
      e.baseOid = hex(pack.subarray(p, p + 20));
      p += 20;
    } else if (!TYPE_NAMES[type]) throw new Error(`bad pack object type ${type}`);
    e.dataStart = p;
    p = inflateZlib(pack, p, size).end;
    e.end = p;
    entries.push(e);
  }
  return entries;
}

/** A git delta applied to its base. */
export function applyDelta(base: Uint8Array, delta: Uint8Array): Uint8Array {
  let p = 0;
  const varint = () => {
    let v = 0;
    let shift = 0;
    let c: number;
    do {
      c = delta[p++];
      v += (c & 0x7f) * 2 ** shift;
      shift += 7;
    } while (c & 0x80);
    return v;
  };
  if (varint() !== base.length) throw new Error("delta base size mismatch");
  const out = new Uint8Array(varint());
  let o = 0;
  while (p < delta.length) {
    const op = delta[p++];
    if (op & 0x80) {
      let off = 0;
      let len = 0;
      for (let i = 0; i < 4; i++) if (op & (1 << i)) off += delta[p++] * 2 ** (8 * i);
      for (let i = 0; i < 3; i++) if (op & (1 << (4 + i))) len += delta[p++] * 2 ** (8 * i);
      if (len === 0) len = 0x10000;
      if (off + len > base.length || o + len > out.length) throw new Error("bad delta copy");
      out.set(base.subarray(off, off + len), o);
      o += len;
    } else if (op > 0) {
      if (o + op > out.length || p + op > delta.length) throw new Error("bad delta insert");
      out.set(delta.subarray(p, p + op), o);
      o += op;
      p += op;
    } else throw new Error("bad delta opcode");
  }
  if (o !== out.length) throw new Error("delta result size mismatch");
  return out;
}

/**
 * Every object in a pack by its id, resolving deltas. Each object is hashed
 * once; only commits and trees are kept, and a delta base only while a
 * later entry still needs it, so a pack with big files doesn't stay
 * inflated in memory. `get` inflates a blob again when it is asked for.
 */
export async function packObjects(
  pack: Uint8Array,
): Promise<{ get(oid: string): { type: string; data: Uint8Array } | undefined; ids(): string[]; size: number }> {
  const entries = parsePack(pack);
  const byOffset = new Map(entries.map((e, i) => [e.start, i]));
  const byOid = new Map<string, number>();
  // How many later OFS_DELTA entries still need each entry as their base.
  const needed = new Map<number, number>();
  for (const e of entries) {
    if (e.type === OBJ_OFS_DELTA) {
      const bi = byOffset.get(e.baseOffset!);
      if (bi === undefined) throw new Error("a delta's base is not in the pack");
      needed.set(bi, (needed.get(bi) ?? 0) + 1);
    }
  }
  const kept = new Map<number, { type: number; data: Uint8Array }>();
  const resolve = (i: number, depth = 0): { type: number; data: Uint8Array } | null => {
    const got = kept.get(i);
    if (got) return got;
    if (depth > 64) throw new Error("delta chain too long");
    const e = entries[i];
    const raw = inflateZlib(pack, e.dataStart, e.size).data;
    if (e.type !== OBJ_OFS_DELTA && e.type !== OBJ_REF_DELTA) return { type: e.type, data: raw };
    const bi = e.type === OBJ_OFS_DELTA ? byOffset.get(e.baseOffset!) : byOid.get(e.baseOid!);
    if (bi === undefined) return null; // a REF_DELTA base not hashed yet
    const base = resolve(bi, depth + 1);
    return base ? { type: base.type, data: applyDelta(base.data, raw) } : null;
  };
  const pending = new Set(entries.map((_, i) => i));
  // Rounds, for a REF_DELTA whose base comes later in the pack.
  while (pending.size > 0) {
    let progressed = false;
    for (const i of [...pending]) {
      const o = resolve(i);
      if (!o) continue;
      const head = enc.encode(`${TYPE_NAMES[o.type]} ${o.data.length}\0`);
      const all = new Uint8Array(head.length + o.data.length);
      all.set(head);
      all.set(o.data, head.length);
      byOid.set(hex(new Uint8Array(await crypto.subtle.digest("SHA-1", all))), i);
      if (o.type === OBJ_COMMIT || o.type === OBJ_TREE || (needed.get(i) ?? 0) > 0) kept.set(i, o);
      const e = entries[i];
      if (e.type === OBJ_OFS_DELTA) {
        const bi = byOffset.get(e.baseOffset!)!;
        const left = (needed.get(bi) ?? 1) - 1;
        needed.set(bi, left);
        const b = kept.get(bi);
        if (left <= 0 && b && b.type !== OBJ_COMMIT && b.type !== OBJ_TREE) kept.delete(bi);
      }
      pending.delete(i);
      progressed = true;
    }
    if (!progressed) throw new Error("a delta's base is not in the pack");
  }
  return {
    size: byOid.size,
    ids: () => [...byOid.keys()],
    get(oid) {
      const i = byOid.get(oid);
      if (i === undefined) return undefined;
      const o = resolve(i);
      return o ? { type: TYPE_NAMES[o.type], data: o.data } : undefined;
    },
  };
}

/** A tree object's entries. */
export function parseTree(data: Uint8Array): Array<{ mode: string; name: string; oid: string }> {
  const out: Array<{ mode: string; name: string; oid: string }> = [];
  let p = 0;
  while (p < data.length) {
    const sp = data.indexOf(0x20, p);
    const nul = data.indexOf(0, sp);
    if (sp < 0 || nul < 0 || nul + 21 > data.length) throw new Error("bad tree");
    out.push({ mode: dec.decode(data.subarray(p, sp)), name: dec.decode(data.subarray(sp + 1, nul)), oid: hex(data.subarray(nul + 1, nul + 21)) });
    p = nul + 21;
  }
  return out;
}

/** The pack in an upload-pack response (no side band): after the shallow lines, NAK or ACK. */
export function packFromUploadPack(body: Uint8Array): Uint8Array {
  let i = 0;
  while (i + 4 <= body.length) {
    if (dec.decode(body.subarray(i, i + 4)) === "PACK") return body.subarray(i);
    const n = parseInt(dec.decode(body.subarray(i, i + 4)), 16);
    if (Number.isNaN(n)) throw new Error("bad upload-pack response");
    if (n === 0) {
      i += 4;
      continue;
    }
    if (n < 4 || i + n > body.length) throw new Error("truncated upload-pack response");
    const line = dec.decode(body.subarray(i + 4, i + n)).trim();
    // The server's own words, never echoed: the request held a token.
    if (line.startsWith("ERR")) throw new Error("git fetch refused by the server");
    i += n;
  }
  throw new Error("no pack in the upload-pack response");
}

/** One commit's tree, fetched: its id, and the bytes of a regular file at a path (null if there is none). */
export type FetchedCommit = { commit: string; read(path: string): Uint8Array | null };

/**
 * One commit of the repo, to read files from: `ref` (a branch) or `commit`
 * (a sha the server lets us want: a branch tip, or any when it allows
 * that). A shallow fetch of just that commit when the server can, through
 * git's smart HTTP with a read-only token; nothing is written anywhere.
 * `read(path)` is a regular file's bytes, by path from the root, or null
 * where there is none (missing, a directory, a symlink, a submodule).
 */
export async function fetchCommit(
  remote: Remote,
  args: { ref?: string; commit?: string; maxBytes?: number },
  f: Fetch = fetch,
): Promise<FetchedCommit> {
  const adv = await advertisement(remote, "git-upload-pack", f);
  let want: string;
  if (args.ref !== undefined) {
    const sha = adv.refs[headRef(args.ref)];
    if (!sha) throw new Error(`${args.ref} doesn't exist on the remote`);
    want = sha;
  } else if (isSha(args.commit)) {
    want = args.commit;
    const tip = Object.values(adv.refs).includes(want);
    const anyWant = adv.capabilities.some((c) => c === "allow-reachable-sha1-in-want" || c === "allow-any-sha1-in-want");
    if (!tip && !anyWant) throw new Error("that commit is not a branch tip, and the server only serves tips");
  } else throw new Error("fetchCommit needs a ref or a commit");
  const caps = ["ofs-delta", "no-progress"].filter((c) => adv.capabilities.includes(c));
  const shallow = adv.capabilities.includes("shallow");
  const body = concatBytes([
    pktLine(`want ${want}${caps.length ? ` ${caps.join(" ")}` : ""}\n`),
    ...(shallow ? [pktLine("deepen 1\n")] : []),
    FLUSH,
    pktLine("done\n"),
  ]);
  const pack = await uploadPack(remote, body, args.maxBytes ?? MAX_FETCH_BYTES, "the commit's pack", f);
  const objects = await packObjects(pack);
  const commit = objects.get(want);
  if (!commit || commit.type !== "commit") throw new Error("the fetched pack doesn't hold the commit");
  const treeOid = /^tree ([0-9a-f]{40})$/m.exec(dec.decode(commit.data))?.[1];
  if (!treeOid) throw new Error("bad commit");
  const read = (path: string): Uint8Array | null => {
    const parts = path.split("/");
    if (parts.some((s) => s === "" || s === "." || s === "..")) throw new Error(`bad path ${path}`);
    let oid: string | null = treeOid;
    let mode = "40000";
    for (const part of parts) {
      const tree: { type: string; data: Uint8Array } | undefined = oid ? objects.get(oid) : undefined;
      if (!tree || tree.type !== "tree" || mode !== "40000") return null;
      const e: { mode: string; oid: string } | undefined = parseTree(tree.data).find((x) => x.name === part);
      if (!e) return null;
      oid = e.oid;
      mode = e.mode;
    }
    const blob = oid ? objects.get(oid) : undefined;
    return blob && blob.type === "blob" && (mode === "100644" || mode === "100755") ? blob.data : null;
  };
  return { commit: want, read };
}

/** `POST <repo>/git-upload-pack` with `body`, and the pack in its answer, at most `max` bytes. */
async function uploadPack(remote: Remote, body: Uint8Array<ArrayBuffer>, max: number, what: string, f: Fetch): Promise<Uint8Array> {
  const res = await f(`${remote.url}/git-upload-pack`, {
    method: "POST",
    headers: {
      authorization: `Basic ${remote.basic}`,
      "content-type": "application/x-git-upload-pack-request",
      accept: "application/x-git-upload-pack-result",
      "user-agent": USER_AGENT,
    },
    body,
  });
  if (!res.ok) throw new Error(`git fetch failed: HTTP ${res.status}`);
  const declared = Number(res.headers.get("content-length") ?? "0");
  if (declared > max) throw new Error(`${what} is over ${max} bytes`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (bytes.length > max) throw new Error(`${what} is over ${max} bytes`);
  return packFromUploadPack(bytes);
}

// ---------------------------------------------------------------- mirroring

/**
 * What `want` needs that a repository holding `haves` lacks, from `remote`'s
 * upload-pack: a whole pack (never thin, never shallow), so another server
 * can take it as it is. `ofsDelta` false asks for REF_DELTA entries only,
 * for a receiver that doesn't advertise ofs-delta.
 */
export async function fetchPack(
  remote: Remote,
  args: { want: string; haves?: string[]; ofsDelta?: boolean; maxBytes?: number },
  f: Fetch = fetch,
): Promise<Uint8Array> {
  if (!isSha(args.want)) throw new Error("want must be 40 lowercase hex characters");
  const adv = await advertisement(remote, "git-upload-pack", f);
  const tip = Object.values(adv.refs).includes(args.want);
  const anyWant = adv.capabilities.some((c) => c === "allow-reachable-sha1-in-want" || c === "allow-any-sha1-in-want");
  if (!tip && !anyWant) throw new Error("that commit is not a branch tip, and the server only serves tips");
  const caps = ["no-progress", ...(args.ofsDelta === false ? [] : ["ofs-delta"])].filter((c) => adv.capabilities.includes(c));
  const haves = (args.haves ?? []).filter(isSha);
  const body = concatBytes([
    pktLine(`want ${args.want}${caps.length ? ` ${caps.join(" ")}` : ""}\n`),
    FLUSH,
    ...haves.map((h) => pktLine(`have ${h}\n`)),
    pktLine("done\n"),
  ]);
  return await uploadPack(remote, body, args.maxBytes ?? MAX_FETCH_BYTES, "the pack", f);
}

export type MirrorOutcome =
  /** The target's branch was at `sha` already. */
  | { status: "current"; sha: string }
  /** The target's branch moved from `from` (null: it didn't exist) to `sha`. */
  | { status: "pushed"; from: string | null; sha: string }
  /** The target's branch is at `target`, which already holds `sha` (it's ahead): left alone. */
  | { status: "ahead"; target: string; sha: string }
  /** The target's branch is at `target`, which `sha` doesn't descend from: left alone. */
  | { status: "diverged"; target: string; sha: string };

/**
 * Fast-forward `ref` on `target` to `sha` (default: `ref` on `source`), with
 * the objects fetched from `source`. Never a force: when the target's branch
 * isn't an ancestor of `sha` (someone pushed there that the source doesn't
 * have), nothing is pushed and the outcome says `diverged`, or `ahead` when
 * the target already holds `sha`; the push itself is a compare-and-swap on
 * the sha just read.
 *
 * The fetch says `have <target's tip>`, so the pack holds only what the
 * target lacks, and the ancestry check needs nothing else: the target's tip
 * is an ancestor of `sha` exactly when some commit in that pack names it as
 * a parent (the commit just after it on the way to `sha` is in the pack,
 * since the target can't reach it; and every commit in the pack is
 * reachable from `sha`).
 */
export async function mirrorBranch(
  source: Remote,
  target: Remote,
  args: { ref: string; sha?: string; maxBytes?: number; baseRef?: string },
  f: Fetch = fetch,
): Promise<MirrorOutcome> {
  const ref = headRef(args.ref);
  const baseRef = args.baseRef ? headRef(args.baseRef) : null;
  if (baseRef) checkRefName(baseRef);
  checkRefName(ref);
  let sha = args.sha;
  if (sha === undefined) {
    sha = (await readRefs(source, [ref], f))[ref] ?? undefined;
    if (!sha) throw new Error(`${ref} doesn't exist on the source`);
  }
  if (!isSha(sha)) throw new Error("sha must be 40 lowercase hex characters");
  const adv = await advertisement(target, "git-receive-pack", f);
  const before = adv.refs[ref] ?? null;
  if (before === sha) return { status: "current", sha };
  // A new branch: what the target's baseRef (its main) already has needn't be sent again.
  const base = before === null && baseRef ? (adv.refs[baseRef] ?? null) : null;
  const haves = [before, base].filter((x): x is string => x !== null);
  const pack = await fetchPack(
    source,
    { want: sha, haves, ofsDelta: adv.capabilities.includes("ofs-delta"), maxBytes: args.maxBytes },
    f,
  );
  const objects = await packObjects(pack);
  if (objects.get(sha)?.type !== "commit") {
    // Nothing the target lacks: `sha` is reachable from the target's tip.
    if (before !== null && objects.size === 0) return { status: "ahead", target: before, sha };
    throw new Error("the fetched pack doesn't hold the commit");
  }
  if (before !== null) {
    const parentOf = (oid: string) => {
      const o = objects.get(oid);
      if (o?.type !== "commit") return [];
      return [...dec.decode(o.data).split("\n\n", 1)[0].matchAll(/^parent ([0-9a-f]{40})$/gm)].map((m) => m[1]);
    };
    if (!objects.ids().some((oid) => parentOf(oid).includes(before))) return { status: "diverged", target: before, sha };
  }
  await pushPack(target, { ref, oldSha: before, newSha: sha, pack }, f);
  return { status: "pushed", from: before, sha };
}

function concatBytes(parts: Uint8Array[]): Uint8Array<ArrayBuffer> {
  const out = new Uint8Array(parts.reduce((n, p) => n + p.length, 0));
  let at = 0;
  for (const p of parts) {
    out.set(p, at);
    at += p.length;
  }
  return out;
}
