// zlib inflate (RFC 1950 around RFC 1951) that also says how many input
// bytes the stream used: a git pack is zlib streams back to back with no
// lengths, so reading one needs to know where each ends, which
// DecompressionStream doesn't say. Plain TypeScript, no dependencies, for
// the default Convex runtime (src/shared/gitHttp.ts's fetchCommit).

class Bits {
  pos: number;
  bit = 0;
  bitCount = 0;
  constructor(
    readonly buf: Uint8Array,
    start: number,
  ) {
    this.pos = start;
  }
  need(n: number) {
    while (this.bitCount < n) {
      if (this.pos >= this.buf.length) throw new Error("inflate: unexpected end of data");
      this.bit |= this.buf[this.pos++] << this.bitCount;
      this.bitCount += 8;
    }
  }
  bits(n: number): number {
    if (n === 0) return 0;
    this.need(n);
    const v = this.bit & ((1 << n) - 1);
    this.bit >>>= n;
    this.bitCount -= n;
    return v;
  }
  /** Drop to the next byte boundary. */
  align() {
    this.bit = 0;
    this.bitCount = 0;
  }
}

type Huffman = { counts: Uint16Array; symbols: Uint16Array };

function huffman(lengths: Uint8Array | number[], n: number): Huffman {
  const counts = new Uint16Array(16);
  for (let i = 0; i < n; i++) counts[lengths[i]]++;
  counts[0] = 0;
  const offs = new Uint16Array(16);
  for (let i = 1; i < 16; i++) offs[i] = offs[i - 1] + counts[i - 1];
  const symbols = new Uint16Array(n);
  for (let i = 0; i < n; i++) if (lengths[i]) symbols[offs[lengths[i]]++] = i;
  return { counts, symbols };
}

function decodeSym(b: Bits, h: Huffman): number {
  let code = 0;
  let first = 0;
  let index = 0;
  for (let len = 1; len < 16; len++) {
    code |= b.bits(1);
    const count = h.counts[len];
    if (code - first < count) return h.symbols[index + (code - first)];
    index += count;
    first += count;
    first <<= 1;
    code <<= 1;
  }
  throw new Error("inflate: bad Huffman code");
}

const LEN_BASE = [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31, 35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258];
const LEN_EXTRA = [0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0];
const DIST_BASE = [
  1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193, 257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145, 8193, 12289, 16385,
  24577,
];
const DIST_EXTRA = [0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6, 7, 7, 8, 8, 9, 9, 10, 10, 11, 11, 12, 12, 13, 13];
const CL_ORDER = [16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15];

let fixed: { lit: Huffman; dist: Huffman } | null = null;
function fixedTables() {
  if (!fixed) {
    const l = new Uint8Array(288);
    l.fill(8, 0, 144);
    l.fill(9, 144, 256);
    l.fill(7, 256, 280);
    l.fill(8, 280, 288);
    fixed = { lit: huffman(l, 288), dist: huffman(new Uint8Array(30).fill(5), 30) };
  }
  return fixed;
}

/** A growable output buffer, bounded. */
class Out {
  buf: Uint8Array;
  len = 0;
  constructor(
    hint: number,
    readonly max: number,
  ) {
    this.buf = new Uint8Array(Math.max(64, Math.min(hint, max)));
  }
  room(n: number) {
    if (this.len + n > this.max) throw new Error("inflate: output over its limit");
    if (this.len + n <= this.buf.length) return;
    let size = this.buf.length * 2;
    while (size < this.len + n) size *= 2;
    const next = new Uint8Array(Math.min(size, Math.max(this.max, this.len + n)));
    next.set(this.buf.subarray(0, this.len));
    this.buf = next;
  }
  push(byte: number) {
    this.room(1);
    this.buf[this.len++] = byte;
  }
}

function inflateRaw(b: Bits, out: Out): void {
  for (;;) {
    const final = b.bits(1);
    const type = b.bits(2);
    if (type === 0) {
      b.align();
      if (b.pos + 4 > b.buf.length) throw new Error("inflate: unexpected end of data");
      const len = b.buf[b.pos] | (b.buf[b.pos + 1] << 8);
      const nlen = b.buf[b.pos + 2] | (b.buf[b.pos + 3] << 8);
      if ((len ^ 0xffff) !== nlen) throw new Error("inflate: bad stored block");
      b.pos += 4;
      if (b.pos + len > b.buf.length) throw new Error("inflate: unexpected end of data");
      out.room(len);
      out.buf.set(b.buf.subarray(b.pos, b.pos + len), out.len);
      out.len += len;
      b.pos += len;
    } else if (type === 1 || type === 2) {
      let lit: Huffman;
      let dist: Huffman;
      if (type === 1) ({ lit, dist } = fixedTables());
      else {
        const hlit = b.bits(5) + 257;
        const hdist = b.bits(5) + 1;
        const hclen = b.bits(4) + 4;
        const cl = new Uint8Array(19);
        for (let i = 0; i < hclen; i++) cl[CL_ORDER[i]] = b.bits(3);
        const clh = huffman(cl, 19);
        const lengths = new Uint8Array(hlit + hdist);
        for (let i = 0; i < hlit + hdist; ) {
          const sym = decodeSym(b, clh);
          if (sym < 16) lengths[i++] = sym;
          else {
            let rep: number;
            let val = 0;
            if (sym === 16) {
              if (i === 0) throw new Error("inflate: repeat with no length");
              val = lengths[i - 1];
              rep = 3 + b.bits(2);
            } else if (sym === 17) rep = 3 + b.bits(3);
            else rep = 11 + b.bits(7);
            if (i + rep > hlit + hdist) throw new Error("inflate: too many lengths");
            lengths.fill(val, i, i + rep);
            i += rep;
          }
        }
        lit = huffman(lengths.subarray(0, hlit), hlit);
        dist = huffman(lengths.subarray(hlit), hdist);
      }
      for (;;) {
        const sym = decodeSym(b, lit);
        if (sym < 256) out.push(sym);
        else if (sym === 256) break;
        else {
          const li = sym - 257;
          if (li >= 29) throw new Error("inflate: bad length symbol");
          const len = LEN_BASE[li] + b.bits(LEN_EXTRA[li]);
          const di = decodeSym(b, dist);
          if (di >= 30) throw new Error("inflate: bad distance symbol");
          const d = DIST_BASE[di] + b.bits(DIST_EXTRA[di]);
          if (d > out.len) throw new Error("inflate: distance too far back");
          out.room(len);
          for (let k = 0; k < len; k++) {
            out.buf[out.len] = out.buf[out.len - d];
            out.len++;
          }
        }
      }
    } else throw new Error("inflate: bad block type");
    if (final) return;
  }
}

/**
 * Inflate the zlib stream at `buf[start]`: `{ data, end }`, where `end` is
 * the offset just past its Adler-32 trailer (checked). `sizeHint` sizes the
 * output (a pack entry knows its size); `max` bounds it.
 */
export function inflateZlib(
  buf: Uint8Array,
  start = 0,
  sizeHint = 1024,
  max = 256 * 1024 * 1024,
): { data: Uint8Array; end: number } {
  if (start + 2 > buf.length) throw new Error("inflate: unexpected end of data");
  const cmf = buf[start];
  const flg = buf[start + 1];
  if ((cmf & 0x0f) !== 8 || ((cmf << 8) | flg) % 31 !== 0 || flg & 0x20) throw new Error("inflate: not a zlib stream");
  const b = new Bits(buf, start + 2);
  const out = new Out(sizeHint, max);
  inflateRaw(b, out);
  // Whole bytes only from here: any bits left over in the last byte are padding.
  b.align();
  if (b.pos + 4 > buf.length) throw new Error("inflate: unexpected end of data");
  const data = out.buf.subarray(0, out.len);
  let s1 = 1;
  let s2 = 0;
  for (let i = 0; i < data.length; ) {
    const n = Math.min(3800, data.length - i);
    for (let k = 0; k < n; k++, i++) {
      s1 += data[i];
      s2 += s1;
    }
    s1 %= 65521;
    s2 %= 65521;
  }
  const adler = ((s2 << 16) | s1) >>> 0;
  const want = ((buf[b.pos] << 24) | (buf[b.pos + 1] << 16) | (buf[b.pos + 2] << 8) | buf[b.pos + 3]) >>> 0;
  if (adler !== want) throw new Error("inflate: checksum mismatch");
  return { data: data.slice(), end: b.pos + 4 };
}
