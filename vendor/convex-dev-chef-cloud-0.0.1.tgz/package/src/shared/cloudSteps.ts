// The steps of one cloud build, as the run's workflow (src/component/orchestration.ts)
// asks the host's executor (chefCloud's `chefStep`, src/client/chefCloud.ts)
// to run them. Shared by both sides; validators only, no Convex server code.
import { v, type Infer } from "convex/values";

/** How long one wait step polls before handing back to the workflow: actions stop at 10 minutes. */
export const SLICE_MS = 7 * 60_000;
/** Between polls inside a slice. */
export const POLL_MS = 5_000;
/** A run's deadline is 90 minutes; each wait is at most a slice. Bounded anyway. */
export const MAX_SLICES = 20;
/** The phases after the push: the build sandbox's part is done. */
export const BUILT_PHASES = ["pushed", "previewing", "done"];

export const vStepOp = v.union(
  v.literal("begin"),
  v.literal("launch"),
  v.literal("awaitSelfTest"),
  v.literal("live"),
  v.literal("follow"),
  v.literal("retire"),
  v.literal("preview"),
  v.literal("awaitPreview"),
  // The demo video (src/client/chefDemo.ts), best effort, before finish.
  v.literal("demo"),
  // The beta channel (src/client/chefBeta.ts): start, then wait in slices.
  v.literal("beta"),
  v.literal("awaitBeta"),
  v.literal("finish"),
  // A release merge (main moved under Ship it): built once pushed, no preview.
  v.literal("finishMerge"),
  v.literal("fail"),
  v.literal("reconcile"),
  v.literal("cleanup"),
  // The run's workflow ended without finishing it (failed or cancelled):
  // the run goes to reconciliation now, not when it goes stale.
  v.literal("settle"),
  // "Ship it" (src/client/chefShip.ts), one workflow per ship.
  v.literal("shipBegin"),
  v.literal("shipStart"),
  v.literal("shipAwait"),
  v.literal("shipLive"),
  v.literal("shipFinish"),
  v.literal("shipFail"),
  v.literal("shipCleanup"),
  // A warm snapshot's build (src/client/chefWarm.ts), scheduled once per key.
  v.literal("warmBuild"),
);
export type StepOp = Infer<typeof vStepOp>;

/** One step's arguments: `op`, and what that op reads. Nothing secret ever goes here (it is journaled). */
export const vStepArgs = v.object({
  op: vStepOp,
  runId: v.optional(v.string()),
  sandboxId: v.optional(v.string()),
  executionId: v.optional(v.string()),
  applied: v.optional(v.union(v.string(), v.null())),
  appliedAt: v.optional(v.number()),
  sha: v.optional(v.string()),
  error: v.optional(v.string()),
  releaseId: v.optional(v.string()),
  deploymentName: v.optional(v.string()),
  siteUrl: v.optional(v.string()),
  startedAt: v.optional(v.number()),
  // warmBuild: the warm snapshot's key.
  key: v.optional(v.string()),
  // preview, awaitPreview: which deploy of the preview (2, 3 after a transient failure).
  attempt: v.optional(v.number()),
});
export type StepArgs = Infer<typeof vStepArgs>;

/** One step's result: the fields its op returns. */
export const vStepResult = v.object({
  // A failure no retry can change (a deadline, a failed self-test): the
  // workflow fails the run at once rather than retrying the step.
  terminal: v.optional(v.string()),
  active: v.optional(v.boolean()),
  built: v.optional(v.boolean()),
  sandboxId: v.optional(v.string()),
  executionId: v.optional(v.string()),
  passed: v.optional(v.boolean()),
  applied: v.optional(v.union(v.string(), v.null())),
  appliedAt: v.optional(v.number()),
  done: v.optional(v.boolean()),
  phase: v.optional(v.string()),
  reused: v.optional(v.boolean()),
  previewUrl: v.optional(v.union(v.string(), v.null())),
  sha: v.optional(v.string()),
  finished: v.optional(v.boolean()),
  emailId: v.optional(v.union(v.string(), v.null())),
  pushedToChef: v.optional(v.boolean()),
  sandboxes: v.optional(v.number()),
  secrets: v.optional(v.number()),
  branches: v.optional(v.number()),
  verified: v.optional(v.boolean()),
  deploymentName: v.optional(v.string()),
  siteUrl: v.optional(v.union(v.string(), v.null())),
  startedAt: v.optional(v.number()),
  outcome: v.optional(v.string()),
  state: v.optional(v.string()),
  // awaitPreview: the deploy failed for the platform's reasons; deploy it again.
  redeploy: v.optional(v.boolean()),
  // awaitBeta: the beta deploy failed for the network's reasons; start attempt 2.
  retry: v.optional(v.boolean()),
  // begin: the app's beta channel, if it has one.
  beta: v.optional(v.union(v.literal("also"), v.literal("instead"))),
  // begin: a release merge, which ships through its release: no preview.
  releaseMerge: v.optional(v.boolean()),
  // preview, beta: the change is nowhere the web preview serves (only the
  // phone or Mac app, tests, docs): no preview, no beta, no demo; built.
  noPreview: v.optional(v.boolean()),
  // shipStart, shipLive: main moved; Chef merges it into the release and the ship waits.
  following: v.optional(v.boolean()),
  // cleanup: when the oldest request branch not yet swept is due (null: none).
  nextBranchAt: v.optional(v.union(v.number(), v.null())),
});
export type StepResult = Infer<typeof vStepResult>;

export const vRunOutcome = v.object({
  outcome: v.union(v.literal("built"), v.literal("failed"), v.literal("stopped")),
  previewUrl: v.union(v.string(), v.null()),
  error: v.union(v.string(), v.null()),
});
export type RunOutcome = Infer<typeof vRunOutcome>;

export const vShipOutcome = v.object({
  outcome: v.union(v.literal("live"), v.literal("failed"), v.literal("abandoned"), v.literal("following")),
  siteUrl: v.union(v.string(), v.null()),
  error: v.union(v.string(), v.null()),
});
export type ShipOutcome = Infer<typeof vShipOutcome>;

/** How long a ship script may run before the ship fails (chefShip's default). */
export const SHIP_TIMEOUT_MS = 30 * 60_000;

/** The runner settings GET /chef-agent/run hands out under `config` (none secret). */
export const vCloudGates = v.union(v.literal("auto"), v.array(v.array(v.string())));
export const vCloudFrontend = v.union(
  v.literal(false),
  v.object({ command: v.array(v.string()), urlEnvVar: v.string(), distDir: v.string() }),
);
export const vCloudLocalEnv = v.union(v.literal("auto"), v.literal(false), v.array(v.string()));
