/**
 * Repair commits, the host's side (docs/chef-pipeline.md, "Repair commits";
 * the feedback component's chefRepairs.ts). Host-side like the launcher.
 *
 *   driveRepair   a failed run whose recovery says repair (an out-of-date
 *                 lockfile, tracked symlinks or env files): a repair sandbox
 *                 with no agent, a git token for the one push and egress to
 *                 the npm registry and Code Storage only, runs the delivered
 *                 runner/chef-repair.mjs on main as it is now, which pushes
 *                 a repair commit to chef-repair/<run8>-<kind>; the commit is
 *                 offered in the panel. Never fatal: a repair that can't be
 *                 made is recorded as failed, and the run's own failure says
 *                 what to do by hand.
 *   applyRepair   an admin's Apply: main moves from the main the repair was
 *                 made on to the repair (a compare-and-swap, never a force),
 *                 then the request builds again.
 *
 * Both are safe to repeat: the repair's row says where it is, the sandbox is
 * adopted by label and its command by its text, the push is to a new branch.
 */
import type { ChefApis } from "./apis.js";
import {
  DEAD_VALUE,
  REPAIR_LABEL,
  ROLE_LABEL,
  assertEgress,
  run8,
  type EffectsDeps,
  type RunCtx,
} from "./chefEffects.js";
import { NPM_REGISTRY } from "./chefLauncher.js";
import { deliveredScriptCommand, repairDelivery, writeDelivery } from "@convex-dev/feedback/delivery";

type Chef = ChefApis;

export const REPAIR_ROLE = "repair";
export const DEFAULT_REPAIR_RESULT_FILE = "/tmp/chef-repair-result.json";
const SHA40 = /^[0-9a-f]{40}$/;

export type RepairConfig = {
  gitHost: string;
  repoUrl: string;
  /** The snapshot the sandbox starts from (chef-base: node, git, npm). */
  snapshot: string;
  /** The name in the audit log. Default "chef-repair". */
  operator?: string;
  /** Life of the push token (default 600 seconds). */
  gitTokenTtlSeconds?: number;
};

export async function repairSecretName(runId: string): Promise<string> {
  return `chef-git-repair-${await run8(runId)}`;
}

/** The repair sandbox's egress: the npm registry (pnpm itself, the lockfile's packages) and Code Storage. */
export function repairEgress(cfg: Pick<RepairConfig, "gitHost">) {
  return { domainAllowList: [NPM_REGISTRY, cfg.gitHost] };
}

export const repairBranchFor = async (runId: string, kind: string) =>
  `chef-repair/${await run8(runId)}-${kind.replace(/[A-Z]/g, (c) => `-${c.toLowerCase()}`)}`;

type RepairResult = { kind: string; base: string; sha: string; branch: string; summary: string; files: { path: string; how: string }[] };

/** The script's result file: the commit, or why not. */
export function parseRepairResult(raw: string | null): { status: "pending" } | { status: "ok"; result: RepairResult } | { status: "failed"; reason: string } {
  if (raw === null || raw.trim() === "") return { status: "pending" };
  let r: any;
  try {
    r = JSON.parse(raw);
  } catch {
    return { status: "failed", reason: "the repair's result is not JSON" };
  }
  if (r && typeof r.error === "string") return { status: "failed", reason: r.error.slice(0, 500) };
  if (!r || !SHA40.test(r.sha ?? "") || !SHA40.test(r.base ?? "") || typeof r.summary !== "string" || typeof r.branch !== "string") {
    return { status: "failed", reason: "the repair's result is malformed" };
  }
  const files = Array.isArray(r.files)
    ? r.files.filter((f: any) => f && typeof f.path === "string" && typeof f.how === "string").slice(0, 50)
    : [];
  return { status: "ok", result: { kind: String(r.kind), base: r.base, sha: r.sha, branch: r.branch, summary: r.summary, files } };
}

/** Delete the repair's sandbox and its git secret. Safe to repeat. */
export async function cleanupRepair(deps: EffectsDeps, runId: string): Promise<void> {
  for (const s of await deps.sandboxes.listSandboxes()) {
    if (s.labels[REPAIR_LABEL] === runId) await deps.sandboxes.deleteSandbox(s.id);
  }
  const name = await repairSecretName(runId);
  if ((await deps.secrets.listSecrets()).some((s) => s.name === name)) {
    await deps.secrets.setSecret(name, DEAD_VALUE);
    await deps.secrets.deleteSecret(name);
  }
}

/**
 * Make the repair for a failed run, if its recovery says so and none was
 * made yet, and offer it. Polls the script for at most `untilMs` (a step's
 * slice); a repair that takes longer is recorded as failed. Never throws
 * for the repair's own problems.
 */
export async function driveRepair(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: RepairConfig; wait: { sleep: (ms: number) => Promise<void>; pollMs?: number; untilMs: number; now?: () => number } },
): Promise<{ status: "none" | "offered" | "failed" | "pending"; summary?: string; reason?: string }> {
  const cfg = args.config;
  const operator = cfg.operator ?? "chef-repair";
  const begun = await ctx.runMutation(chef.feedback.chefRepairs.begin, { operator, runId: args.runId });
  if (!begun) return { status: "none" };
  if (begun.status !== "making") return { status: begun.status === "failed" ? "failed" : begun.status === "offered" ? "offered" : "none" };
  const fail = async (reason: string) => {
    await ctx.runMutation(chef.feedback.chefRepairs.fail, { operator, repairId: begun.repairId, error: reason });
    return { status: "failed" as const, reason };
  };
  const now = args.wait.now ?? Date.now;
  try {
    const main = (await deps.refs.readRefs(["main"])).main;
    if (!main || !SHA40.test(main)) return await fail("the repo has no main to repair");
    if (!deps.git) return await fail("no GitAuthApi: can't mint a Code Storage token");
    const egress = repairEgress(cfg);
    assertEgress(egress);
    // The one push's token, live only while the sandbox is.
    const secret = await repairSecretName(args.runId);
    const value = await deps.git.basicAuth({ access: "write", ttlSeconds: cfg.gitTokenTtlSeconds ?? 600 });
    const created = await deps.secrets.createSecret({ name: secret, value, hosts: [cfg.gitHost] });
    if (!created.created) await deps.secrets.setSecret(secret, value);
    let sandboxId = (await deps.sandboxes.listSandboxes()).find((s) => s.labels[REPAIR_LABEL] === args.runId)?.id;
    if (!sandboxId) {
      sandboxId = (
        await deps.sandboxes.createSandbox({
          snapshot: cfg.snapshot,
          secrets: { CHEF_GIT_AUTH: secret },
          ...egress,
          autoStopInterval: 0,
          autoDeleteInterval: 30,
          labels: { [REPAIR_LABEL]: args.runId, [ROLE_LABEL]: REPAIR_ROLE },
        })
      ).id;
    }
    const d = await repairDelivery();
    const command = deliveredScriptCommand(d, "chef-repair.sh", main);
    let executionId = (await deps.sandboxes.listExecutions(sandboxId)).find((e) => e.command === command)?.executionId;
    if (!executionId) {
      await writeDelivery(deps.sandboxes, sandboxId, d);
      executionId = (
        await deps.sandboxes.startCommand(sandboxId, {
          command,
          envs: {
            CHEF_REPAIR_KIND: begun.kind,
            CHEF_REPO_URL: cfg.repoUrl,
            CHEF_REPAIR_BRANCH: await repairBranchFor(args.runId, begun.kind),
            CHEF_RESULT_FILE: DEFAULT_REPAIR_RESULT_FILE,
          },
        })
      ).executionId;
    }
    for (;;) {
      const st = parseRepairResult(await deps.sandboxes.readFile(sandboxId, DEFAULT_REPAIR_RESULT_FILE));
      if (st.status === "ok") {
        if (st.result.base !== main) return await fail("the repair was made on another main");
        await ctx.runMutation(chef.feedback.chefRepairs.offer, {
          operator,
          repairId: begun.repairId,
          branch: st.result.branch,
          sha: st.result.sha,
          baseSha: st.result.base,
          summary: st.result.summary,
          files: st.result.files,
        });
        return { status: "offered", summary: st.result.summary };
      }
      if (st.status === "failed") return await fail(st.reason);
      const e = await deps.sandboxes.execution(executionId);
      if (e && e.status !== "running") {
        const again = parseRepairResult(await deps.sandboxes.readFile(sandboxId, DEFAULT_REPAIR_RESULT_FILE));
        if (again.status === "pending") return await fail(`the repair script exited (${e.status}) without a result`);
        continue;
      }
      if (now() >= args.wait.untilMs) return await fail("the repair didn't finish in time");
      await args.wait.sleep(args.wait.pollMs ?? 5000);
    }
  } catch (e) {
    return await fail(`couldn't make the repair: ${(e instanceof Error ? e.message : String(e)).slice(0, 300)}`);
  } finally {
    try {
      await cleanupRepair(deps, args.runId);
    } catch {
      // The sweep and Daytona's auto-delete are the backstop.
    }
  }
}

/**
 * An admin applied the repair: main moves from the main it was made on to
 * the repair commit (compare-and-swap; a main that moved since is left
 * alone and the repair says so), then the request builds again.
 */
export async function applyRepair(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { repairId: string; operator?: string },
): Promise<{ applied: boolean; reason?: string; retry?: string }> {
  const operator = args.operator ?? "chef-repair";
  const r = (await ctx.runQuery(chef.feedback.chefRepairs.info, { repairId: args.repairId })) as {
    status: string;
    sha: string | null;
    baseSha: string | null;
  } | null;
  if (!r || r.status !== "applying" || !r.sha || !r.baseSha) return { applied: false, reason: "nothing to apply" };
  const fail = async (reason: string) => {
    await ctx.runMutation(chef.feedback.chefRepairs.fail, { operator, repairId: args.repairId, error: reason });
    return { applied: false, reason };
  };
  const main = (await deps.refs.readRefs(["main"])).main;
  if (main !== r.sha) {
    if (main !== r.baseSha) {
      return await fail(`main moved since the repair was made (it was ${r.baseSha.slice(0, 12)}, now ${(main ?? "gone").slice(0, 12)}); Try again, and Chef offers a new one if it's still needed`);
    }
    if (!deps.refs.updateRef) return await fail("RefsApi.updateRef is needed to move main");
    if (!(await deps.refs.updateRef("main", { from: r.baseSha, to: r.sha }))) return await fail("main moved while applying the repair; it was left alone");
  }
  const done = (await ctx.runMutation(chef.feedback.chefRepairs.applied, { operator, repairId: args.repairId, mainSha: r.sha })) as { retry: string };
  return { applied: true, retry: done.retry };
}
