/**
 * Side-effect adapters with reconciliation (docs/chef-pipeline.md,
 * "Idempotency and reconciliation for every side effect"). These run in the
 * host's actions (workflow steps, the reconciler, the cleanup sweep). The
 * Daytona, Code Storage and Resend calls go through the interfaces below; the
 * host wraps the marketplace components in them, tests use fakes.
 *
 * Every function here is safe to run again after a failure or a lost
 * response: it looks at remote state, or at what Convex recorded, before it
 * repeats anything.
 *
 *   import { ensureSandbox, reconcileRun } from "@convex-dev/chef-cloud/effects";
 *
 * Each takes `chef`, the host's two components (`{ feedback, cloud }`,
 * ChefApis): a run's state is the feedback component's, the ledger of its
 * side effects chef-cloud's.
 */
import type { FunctionReference } from "convex/server";
import { splitPreviewDeployKey } from "@convex-dev/feedback/chef/previewKey.js";
import { deploymentFromCloudUrl, splitHostDeployKey } from "@convex-dev/feedback/chef/deployKey.js";
import type { ChefApis } from "./apis.js";
import { scrub } from "@convex-dev/feedback/chef/scrub.js";
import type { WarmInputs } from "@convex-dev/feedback/install-plan";

// ----------------------------------------------------------------- interfaces

export type SandboxInfo = { id: string; labels: Record<string, string> };

/**
 * Egress for a sandbox. Set exactly one: `domainAllowList` (what Chef uses),
 * `networkAllowList` (IPv4 CIDRs) or `networkBlockAll: true`. Chef never
 * creates a sandbox without one (docs/chef-pipeline.md, "Egress, per
 * sandbox, fail-closed").
 */
export type Egress = {
  networkBlockAll?: boolean;
  networkAllowList?: string[];
  domainAllowList?: string[];
};

export type SandboxSpec = Egress & {
  snapshot?: string;
  /** `{ ENV_NAME: "secret-name" }`, mounted at creation. Values are placeholders in the sandbox. */
  secrets?: Record<string, string>;
  /** Never anything secret. */
  envVars?: Record<string, string>;
  labels?: Record<string, string>;
  /** Minutes idle before Daytona stops the sandbox; 0 never (a background runner doesn't count as activity). */
  autoStopInterval?: number;
  /** Minutes before Daytona deletes it on its own; the backstop if every delete is lost. */
  autoDeleteInterval?: number;
};

export type ExecutionInfo = {
  status: "running" | "completed" | "failed";
  exitCode?: number;
  /** The command's output, if the provider keeps it; only a failed deploy's reason reads it. */
  output?: string;
};

/** The Daytona calls Chef needs. Wraps `@convex-marketplace/daytona` in the host (src/client/chefDaytona.ts). */
export interface SandboxApi {
  /** The team's sandboxes (the gateway filters to the team; at most a few live). */
  listSandboxes(): Promise<SandboxInfo[]>;
  /** Must refuse a spec without egress (`assertEgress`). */
  createSandbox(spec: SandboxSpec & { labels: Record<string, string> }): Promise<{ id: string }>;
  /** Must treat "not found" as success. */
  deleteSandbox(id: string): Promise<void>;
  /** Replace a running sandbox's egress. */
  updateNetwork(id: string, egress: Egress): Promise<void>;
  /**
   * Start a command in the background. `envs` reach only that command: the
   * Daytona component writes them to a private file the command sources and
   * deletes, and stores only the command. The one secret Chef ever puts here
   * is the preview deploy key, for the deploy script (chefLauncher.startPreview).
   */
  startCommand(id: string, args: { command: string; envs?: Record<string, string> }): Promise<{ executionId: string }>;
  /** A background command's state, or null if unknown. */
  execution(executionId: string): Promise<ExecutionInfo | null>;
  /**
   * The sandbox's background commands, newest first, with the command each
   * ran. Used to adopt a command whose start response was lost.
   */
  listExecutions(id: string): Promise<Array<ExecutionInfo & { executionId: string; command: string }>>;
  /** A file's contents, or null if it doesn't exist (yet). */
  readFile(id: string, path: string): Promise<string | null>;
  /** Write a text file (the built frontend's base64 parts, for the deploy sandbox). */
  writeFile(id: string, path: string, content: string): Promise<void>;
}

const DOMAIN = /^(\*\.)?[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;
const CIDR = /^\d{1,3}(\.\d{1,3}){3}\/\d{1,2}$/;

/**
 * Fail closed: throws unless the spec restricts egress with exactly one of
 * the three fields, and any list it uses is non-empty and well formed. An
 * empty list would mean the tier's default, which can be the open internet.
 */
export function assertEgress(egress: Egress): void {
  const set = [
    egress.networkBlockAll !== undefined,
    egress.networkAllowList !== undefined,
    egress.domainAllowList !== undefined,
  ].filter(Boolean).length;
  if (set !== 1) throw new Error("Refusing a sandbox without exactly one egress restriction");
  if (egress.networkBlockAll !== undefined && egress.networkBlockAll !== true) {
    throw new Error("Refusing a sandbox with networkBlockAll false");
  }
  for (const [list, re] of [
    [egress.networkAllowList, CIDR],
    [egress.domainAllowList, DOMAIN],
  ] as const) {
    if (list === undefined) continue;
    if (!Array.isArray(list) || list.length === 0) throw new Error("Refusing a sandbox with an empty egress list");
    for (const x of list) if (typeof x !== "string" || !re.test(x)) throw new Error(`Bad egress entry ${String(x)}`);
  }
}

/** Daytona secrets through the gateway. Values are never readable back. */
export interface SecretsApi {
  /** Create, or adopt an existing secret of that name (the gateway does on 409). */
  createSecret(args: { name: string; value: string; hosts: string[] }): Promise<{ created: boolean }>;
  setSecret(name: string, value: string): Promise<void>;
  /** Must treat "not found" as success. */
  deleteSecret(name: string): Promise<void>;
  listSecrets(): Promise<Array<{ name: string }>>;
}

/** Code Storage refs. */
export interface RefsApi {
  /** The sha each ref points at, or null if it doesn't exist. */
  readRefs(refs: string[]): Promise<Record<string, string | null>>;
  /** Must treat "not found" as success. */
  deleteRef(ref: string): Promise<void>;
  /**
   * Move a branch from `from` to `to`, only if it is at `from` now: a
   * compare-and-swap, never a force (for "Ship it", `main` to chef's
   * commit). Returns false, changing nothing, if the branch is elsewhere.
   * The caller has checked that `to` descends from `from`. Only "Ship it"
   * needs it.
   */
  updateRef?(ref: string, args: { from: string; to: string }): Promise<boolean>;
  /**
   * Fast-forward `ref` (default `main`) on a GitHub repo (`owner/name`) to
   * this repo's, never a force (gitHttp's mirrorBranch): after "Ship it"
   * moves `main`, so GitHub (and Xcode Cloud, CI) follows what's live.
   */
  mirror?(args: { github: string; token: string; ref?: string; sha?: string; baseRef?: string }): Promise<MirrorOutcome>;
}

/** GitHub's REST API, for the iOS CI (chefIosCi.ts): Xcode Cloud's checks on a commit, and branch cleanup. */
export interface GithubApi {
  /** The commit's check runs; `forbidden` when the token can't read checks. */
  checkRuns(args: { github: string; token: string; sha: string }): Promise<
    | { ok: true; runs: Array<{ app: string; name: string; status: string; conclusion: string | null; url: string | null; title: string | null }> }
    | { ok: false; forbidden: boolean; status: number }
  >;
  /** Delete a branch; a missing one is success. */
  deleteBranch(args: { github: string; token: string; ref: string }): Promise<void>;
}

/** What a mirror did: see MirrorOutcome in src/shared/gitHttp.ts. */
export type MirrorOutcome =
  | { status: "current"; sha: string }
  | { status: "pushed"; from: string | null; sha: string }
  | { status: "ahead"; target: string; sha: string }
  | { status: "diverged"; target: string; sha: string };

/**
 * How Chef's emails go out: Resend through `@convex-marketplace/resend`, or
 * the app's own mailer (chefCloud's `notify.send`). Either takes an
 * idempotency key.
 */
export interface EmailApi {
  send(message: {
    to: string;
    subject: string;
    text: string;
    html?: string;
    idempotencyKey: string;
    /** Which email: "built", "failed", "shipped", "shipFailed", "requestShipped". */
    kind?: string;
  }): Promise<{ id: string }>;
  /**
   * A failed send is audited and logged, and the run or ship goes on
   * without the email instead of retrying the step. Set for the app's own
   * mailer, which may not deduplicate a retried key the way Resend does.
   */
  bestEffort?: boolean;
}

/**
 * Code Storage git credentials, minted by the host on its service token.
 * Returns the value for the `chef-git-*` secret: pre-encoded for Basic auth,
 * since Daytona only substitutes the placeholder verbatim.
 */
export interface GitAuthApi {
  basicAuth(args: { access: "read" | "write"; ttlSeconds: number }): Promise<string>;
}

/** One file of a warm snapshot's build context: given as text, or a committed file read from the repo and checked. */
export type WarmContextFile = { path: string; mode?: number } & (
  | { text: string; repoPath?: undefined; sha256?: undefined }
  | { repoPath: string; sha256: string; text?: undefined }
);

/** What a warm install depends on at one commit (runner/chef-install-plan.mjs warmInputs), read from the app's repo. */
export type WarmInputsAt = {
  commit: string;
  /** Why there can be no warm install here; then nothing else is set. */
  unsupported?: string;
  inputsHash?: string;
  inputs?: WarmInputs;
  /** package.json's install fields only, as the snapshot gets it. */
  packageJson?: string;
};

/**
 * Warm snapshots (src/client/chefWarm.ts) through chef-cloud's children:
 * the repo's files at a commit, and the team's own Daytona snapshots.
 */
export interface WarmApi {
  /**
   * Files of a commit (or a branch's tip) of the app's repo, as committed:
   * `paths` as text (null where there's no such regular file, or it's too
   * big), `hash` as sha256 only.
   */
  readFiles(args: { at: { ref: string } | { commit: string }; paths: string[]; hash?: string[] }): Promise<{
    commit: string;
    files: Record<string, string | null>;
    sha256: Record<string, string | null>;
  }>;
  /**
   * Start a snapshot build. Repo files in `context` are read at `commit` and
   * checked against their sha256 where the build is started, not here.
   */
  createSnapshot(args: {
    name: string;
    dockerfile: string;
    commit: string;
    context: WarmContextFile[];
    cpu?: number;
    memory?: number;
    disk?: number;
  }): Promise<{ state: string }>;
  /** A snapshot's state, or null if there is none. */
  getSnapshot(name: string): Promise<{ state: string; size?: number; errorReason?: string } | null>;
  /** Delete a snapshot; gone already is success. Must refuse (throw) rather than force while a sandbox uses it. */
  deleteSnapshot(name: string): Promise<void>;
}

export type EffectsDeps = {
  sandboxes: SandboxApi;
  secrets: SecretsApi;
  refs: RefsApi;
  email?: EmailApi;
  git?: GitAuthApi;
  /** Warm snapshots; without it every sandbox starts from the base snapshot. */
  warm?: WarmApi;
  /** GitHub's REST API (iOS CI). Default: githubRest, with global fetch. */
  github?: GithubApi;
  /** How the launcher fetches the built frontend from storage. Default: global fetch. */
  fetch?: (url: string) => Promise<Response>;
  /**
   * The preview deploy key. Default: the host's `CHEF_PREVIEW_DEPLOY_KEY`
   * env var, read in the action that needs it (readPreviewDeployKey).
   */
  previewDeployKey?: () => string | undefined;
  /**
   * The host's own deploy key, for "Ship it". Default: the host's
   * `CHEF_DEPLOY_KEY` env var, read in the action that needs it
   * (readHostDeployKey).
   */
  deployKey?: () => string | undefined;
  /**
   * Where shipped `main` is mirrored: a GitHub repo (`owner/name`) and a
   * token that can push to it. Default: the host's `CHEF_GITHUB_MIRROR` and
   * `CHEF_GITHUB_TOKEN` env vars, read in the action that mirrors
   * (readGithubMirror). Absent: no mirror.
   */
  githubMirror?: () => { github: string; token: string } | undefined;
  /** Tests: the beta channel's deploy key instead of its env var (chefBeta.ts). */
  betaDeployKey?: () => string | undefined;
  /** The host's own URL. Default: `CONVEX_CLOUD_URL`, which Convex sets in every function. */
  hostCloudUrl?: () => string | undefined;
};

/** The host's action ctx, or anything else that can run the component's functions. */
export type RunCtx = {
  runQuery<F extends FunctionReference<"query", any>>(fn: F, args: F["_args"]): Promise<F["_returnType"]>;
  runMutation<F extends FunctionReference<"mutation", any>>(fn: F, args: F["_args"]): Promise<F["_returnType"]>;
};

type Chef = ChefApis;

// ---------------------------------------------------------------- the ledger

type Effect = { status: "intent" | "done"; result?: string; adopted?: boolean; kind: "sandbox" | "exec" | "email" };

/** What a keyed side effect of a run has done so far (chef-cloud's ledger). */
export async function effectGet(ctx: RunCtx, chef: Chef, args: { runId: string; key: string }): Promise<Effect | null> {
  return (await ctx.runQuery(chef.cloud.effects.get, args)) as Effect | null;
}

/**
 * Write the intent before the call. The feedback component checks first
 * that the run may start it (only the active run creates a sandbox or a
 * command); throws if not.
 */
export async function effectIntent(ctx: RunCtx, chef: Chef, args: { runId: string; key: string }): Promise<Effect> {
  await ctx.runQuery(chef.feedback.chefEffects.checkIntent, args);
  return (await ctx.runMutation(chef.cloud.effects.intent, args)) as Effect;
}

/**
 * Record what the call did: on the run in the feedback component (its
 * sandbox id, the audit log), then in the ledger. A repeat after the ledger
 * has it is a no-op.
 */
export async function effectDone(
  ctx: RunCtx,
  chef: Chef,
  args: { runId: string; key: string; result: string; adopted?: boolean },
): Promise<void> {
  const e = await effectGet(ctx, chef, { runId: args.runId, key: args.key });
  if (!e) throw new Error("No intent for this effect");
  if (e.status === "done") return;
  await ctx.runMutation(chef.feedback.chefEffects.recordEffect, args);
  await ctx.runMutation(chef.cloud.effects.done, args);
}

// ---------------------------------------------------------------- names

/** What a secret holds when it is not live. Not a credential. */
export const DEAD_VALUE = "chef-dead";

export const RUN_LABEL = "chef-run";
export const ROLE_LABEL = "chef-role";
/** The label on a ship's deploy sandbox (src/client/chefShip.ts): the release id. */
export const RELEASE_LABEL = "chef-release";
/** A repair sandbox's label: the failed run it repairs (chefRepair.ts). */
export const REPAIR_LABEL = "chef-repair";
/**
 * The Daytona secret earlier versions kept the preview deploy key in. Nothing
 * uses it now (a Daytona secret is substituted only in headers, and the CLI
 * sends the key in request bodies); the cleanup sweep deletes a leftover one.
 */
export const PREVIEW_SECRET = "chef-preview-deploy";
/** The host env var holding the preview deploy key. */
export const PREVIEW_KEY_ENV = "CHEF_PREVIEW_DEPLOY_KEY";
/** The host env var holding its own deploy key, for "Ship it". */
export const DEPLOY_KEY_ENV = "CHEF_DEPLOY_KEY";
/** `owner/name` of the GitHub repo shipped `main` is mirrored to (optional). */
export const GITHUB_MIRROR_ENV = "CHEF_GITHUB_MIRROR";
/** A token that can push to it: fine-grained, Contents read and write, that one repo. */
export const GITHUB_TOKEN_ENV = "CHEF_GITHUB_TOKEN";

/** Eight hex characters of sha256(runId): short, stable, and spread evenly. */
export async function run8(runId: string): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(runId)));
  return Array.from(d.slice(0, 4), (b) => b.toString(16).padStart(2, "0")).join("");
}

export type SecretKind = "run" | "ai" | "git";

export async function runSecretNames(runId: string): Promise<Record<SecretKind, string>> {
  const r = await run8(runId);
  return { run: `chef-run-${r}`, ai: `chef-ai-${r}`, git: `chef-git-${r}` };
}

/** The deploy sandbox's one-time read-only git secret (docs, "The preview"). */
export async function deployGitSecretName(runId: string): Promise<string> {
  return `chef-git-${await run8(runId)}-ro`;
}

/** The beta deploy's one-time read-only git secret (chefBeta.ts). */
export async function betaGitSecretName(runId: string): Promise<string> {
  return `chef-git-${await run8(runId)}-beta`;
}

/** Every secret name a run can own. */
export async function allRunSecretNames(runId: string): Promise<string[]> {
  return [...Object.values(await runSecretNames(runId)), await deployGitSecretName(runId), await betaGitSecretName(runId)];
}

// ---------------------------------------------------------------- sandboxes

/**
 * Create the run's build or deploy sandbox, or adopt the one a lost response
 * left behind. Intent is written first; then the team's sandboxes are listed,
 * and one labelled for this run and role is adopted instead of creating a
 * second. Extra copies (which shouldn't exist) are deleted.
 */
export async function ensureSandbox(
  ctx: RunCtx,
  chef: Chef,
  api: SandboxApi,
  args: { runId: string; role: "build" | "deploy" | "demo" | "beta"; spec: SandboxSpec; attempt?: number },
): Promise<{ id: string; adopted: boolean }> {
  // Fail closed before anything is recorded or created.
  assertEgress(args.spec);
  // A preview deployed again (attempt 2, 3) is a new effect of its own.
  const key = `sandbox:${args.role}${args.attempt && args.attempt > 1 ? `:${args.attempt}` : ""}`;
  const prior = await effectGet(ctx, chef, { runId: args.runId, key });
  if (prior?.status === "done" && prior.result) return { id: prior.result, adopted: !!prior.adopted };
  await effectIntent(ctx, chef, { runId: args.runId, key });

  const mine = (await api.listSandboxes()).filter(
    (s) => s.labels[RUN_LABEL] === args.runId && s.labels[ROLE_LABEL] === args.role,
  );
  if (mine.length > 0) {
    const [keep, ...extra] = mine;
    for (const s of extra) await api.deleteSandbox(s.id);
    await effectDone(ctx, chef, {
      runId: args.runId,
      key,
      result: keep.id,
      adopted: true,
    });
    return { id: keep.id, adopted: true };
  }
  const created = await api.createSandbox({
    ...args.spec,
    labels: { ...(args.spec.labels ?? {}), [RUN_LABEL]: args.runId, [ROLE_LABEL]: args.role },
  });
  await effectDone(ctx, chef, {
    runId: args.runId,
    key,
    result: created.id,
    adopted: false,
  });
  return { id: created.id, adopted: false };
}

/** Delete a run's sandboxes of one role, found by label. Returns the ids deleted. */
export async function deleteRoleSandboxes(
  api: SandboxApi,
  runId: string,
  role: "build" | "deploy" | "demo" | "beta",
): Promise<string[]> {
  const ids = (await api.listSandboxes())
    .filter((s) => s.labels[RUN_LABEL] === runId && s.labels[ROLE_LABEL] === role)
    .map((s) => s.id);
  for (const id of ids) await api.deleteSandbox(id);
  return ids;
}

/** Delete every sandbox of a run: the recorded ids and anything labelled for it. */
export async function deleteRunSandboxes(
  api: SandboxApi,
  runId: string,
  recorded: string[] = [],
): Promise<string[]> {
  const ids = new Set(recorded);
  for (const s of await api.listSandboxes()) if (s.labels[RUN_LABEL] === runId) ids.add(s.id);
  for (const id of ids) await api.deleteSandbox(id);
  return [...ids];
}

// ---------------------------------------------------------------- secrets

/**
 * Create the run's three secrets with dead values, before the sandbox, so
 * they can be mounted at creation. A name left over from a lost response is
 * adopted and set dead again.
 */
export async function createRunSecrets(
  ctx: RunCtx,
  chef: Chef,
  api: SecretsApi,
  args: { runId: string; hosts: Record<SecretKind, string[]> },
): Promise<Record<SecretKind, string>> {
  const names = await runSecretNames(args.runId);
  // Recorded before the calls (and refused for a run that isn't active), so
  // the reconciler knows them even if every response is lost.
  await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, {
    runId: args.runId,
    names: Object.values(names),
    event: "created",
  });
  const adopted: string[] = [];
  for (const kind of ["run", "ai", "git"] as const) {
    const r = await api.createSecret({ name: names[kind], value: DEAD_VALUE, hosts: args.hosts[kind] });
    if (!r.created) {
      await api.setSecret(names[kind], DEAD_VALUE);
      adopted.push(names[kind]);
    }
  }
  if (adopted.length) {
    await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, { runId: args.runId, names: adopted, event: "adopted" });
  }
  return names;
}

/**
 * Give one run secret its real value. Convex checks first that the run is
 * still the active run; the value goes to Daytona only, never to Convex.
 */
export async function setRunSecret(
  ctx: RunCtx,
  chef: Chef,
  api: SecretsApi,
  args: { runId: string; kind: SecretKind; value: string },
): Promise<void> {
  const name = (await runSecretNames(args.runId))[args.kind];
  await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, { runId: args.runId, names: [name], event: "live" });
  await api.setSecret(name, args.value);
}

/** Set a run's secrets back to dead values. Repeating it is harmless. */
export async function killRunSecrets(
  ctx: RunCtx,
  chef: Chef,
  api: SecretsApi,
  args: { runId: string; names?: string[] },
): Promise<string[]> {
  const names = args.names ?? Object.values(await runSecretNames(args.runId));
  for (const n of names) await api.setSecret(n, DEAD_VALUE);
  await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, { runId: args.runId, names, event: "dead" });
  return names;
}

/** Delete a run's secrets. Deleting a missing one is success. */
export async function deleteRunSecrets(
  ctx: RunCtx,
  chef: Chef,
  api: SecretsApi,
  args: { runId: string; names?: string[] },
): Promise<string[]> {
  const names = args.names ?? Object.values(await runSecretNames(args.runId));
  for (const n of names) await api.deleteSecret(n);
  await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, { runId: args.runId, names, event: "deleted" });
  return names;
}

// ---------------------------------------------------------------- preview key

/**
 * The preview deploy key from the host's environment, checked. Throws a
 * message that never repeats any of it. Call it only in the action that
 * hands the key to the deploy script, and keep the value out of every
 * return value, log line and table.
 */
export function readPreviewDeployKey(deps: Pick<EffectsDeps, "previewDeployKey">): {
  key: string;
  prefix: string;
} {
  const raw = deps.previewDeployKey ? deps.previewDeployKey() : readEnv(PREVIEW_KEY_ENV);
  if (!raw) throw new Error(`${PREVIEW_KEY_ENV} is not set on this deployment (see setPreviewDeployKey)`);
  const { prefix, secret } = splitPreviewDeployKey(raw);
  return { key: `${prefix}|${secret}`, prefix };
}

/**
 * The GitHub mirror, if the host has one: `CHEF_GITHUB_MIRROR` (`owner/name`,
 * or a github.com URL) and `CHEF_GITHUB_TOKEN`. Undefined when the repo isn't
 * set; throws (never repeating the token) when the repo is set without a token.
 */
export function readGithubMirror(deps: Pick<EffectsDeps, "githubMirror">): { github: string; token: string } | undefined {
  if (deps.githubMirror) return deps.githubMirror();
  const raw = readEnv(GITHUB_MIRROR_ENV)?.trim();
  if (!raw) return undefined;
  const github = raw.replace(/^https:\/\/github\.com\//, "").replace(/\.git$/, "").replace(/\/$/, "");
  const token = readEnv(GITHUB_TOKEN_ENV)?.trim();
  if (!token) throw new Error(`${GITHUB_MIRROR_ENV} is set but ${GITHUB_TOKEN_ENV} isn't`);
  return { github, token };
}

function readEnv(name: string): string | undefined {
  // Actions have process.env; this module is also bundled for other places.
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  return env?.[name];
}

/**
 * Build plan step 16. Seth creates a preview deploy key for the app's
 * project in the Convex dashboard and sets it on the host deployment:
 *
 *   npx convex env set --prod CHEF_PREVIEW_DEPLOY_KEY "$KEY"
 *
 * then runs the host's `setPreviewDeployKey` admin action, which calls this.
 * It reads the key from the environment, refuses anything but a preview key
 * (a `prod:` or `dev:` key never goes near a sandbox), and stores only the
 * prefix (`preview:<team>:<project>`, not secret) in settings, audited. The
 * key itself stays in the env var: it is never an argument, a return value,
 * a row or a log line. Rotating it is the same two steps.
 *
 *   export const setPreviewDeployKey = internalAction({
 *     args: { adminUserId: v.string() },
 *     returns: v.object({ prefix: v.string() }),
 *     handler: (ctx, args) => setPreviewDeployKey(ctx, { feedback: components.feedback, cloud: components.chefCloud }, args),
 *   });
 */
export async function setPreviewDeployKey(
  ctx: RunCtx,
  chef: Chef,
  args: { adminUserId: string },
  deps: Pick<EffectsDeps, "previewDeployKey"> = {},
): Promise<{ prefix: string }> {
  let prefix: string;
  try {
    prefix = readPreviewDeployKey(deps).prefix;
  } catch (e) {
    await ctx.runMutation(chef.feedback.chefSettings.recordPreviewDeployKey, {
      adminUserId: args.adminUserId,
      outcome: "error",
    });
    throw e;
  }
  await ctx.runMutation(chef.feedback.chefSettings.setPreviewKeyPrefix, { adminUserId: args.adminUserId, prefix });
  await ctx.runMutation(chef.feedback.chefSettings.recordPreviewDeployKey, {
    adminUserId: args.adminUserId,
    outcome: "ok",
  });
  return { prefix };
}

// ---------------------------------------------------------------- host deploy key

/** This deployment's name, from CONVEX_CLOUD_URL (`https://<name>.convex.cloud`). */
export function hostDeploymentName(deps: Pick<EffectsDeps, "hostCloudUrl">): string {
  const url = deps.hostCloudUrl ? deps.hostCloudUrl() : readEnv("CONVEX_CLOUD_URL");
  const name = deploymentFromCloudUrl(url);
  if (!name) throw new Error("Can't tell this deployment's name: CONVEX_CLOUD_URL is not https://<name>.convex.cloud");
  return name;
}

/**
 * The host's own deploy key from its environment, checked: a `prod:` or
 * `dev:` key for exactly this deployment. Throws a message that never
 * repeats any of it. Call it only in the action that hands the key to the
 * ship script, and keep the value out of every return value, log line and
 * table.
 */
export function readHostDeployKey(deps: Pick<EffectsDeps, "deployKey" | "hostCloudUrl">): {
  key: string;
  prefix: string;
  deploymentName: string;
} {
  const raw = deps.deployKey ? deps.deployKey() : readEnv(DEPLOY_KEY_ENV);
  if (!raw) throw new Error(`${DEPLOY_KEY_ENV} is not set on this deployment (see setDeployKey)`);
  const { prefix, deploymentName, secret } = splitHostDeployKey(raw);
  const host = hostDeploymentName(deps);
  if (deploymentName !== host) {
    throw new Error(`${DEPLOY_KEY_ENV} is for ${prefix}, not this deployment (${host}); "Ship it" deploys only here`);
  }
  return { key: `${prefix}|${secret}`, prefix, deploymentName };
}

/**
 * Setup for "Ship it". Seth creates a deploy key for the host's own live
 * deployment (production, or the dev deployment the app runs on) in the
 * Convex dashboard and sets it on that deployment:
 *
 *   npx convex env set --prod CHEF_DEPLOY_KEY "$KEY"
 *
 * then runs the host's `setDeployKey` admin action, which calls this. It
 * reads the key from the environment, refuses a preview key or a key for any
 * other deployment, and stores only the prefix (`prod:<deployment>`, not
 * secret) in settings, audited. The key stays in the env var: never an
 * argument, a return value, a row or a log line.
 *
 *   export const setDeployKey = internalAction({
 *     args: { adminUserId: v.string() },
 *     returns: v.object({ prefix: v.string() }),
 *     handler: (ctx, args) => setDeployKey(ctx, { feedback: components.feedback, cloud: components.chefCloud }, args),
 *   });
 */
export async function setDeployKey(
  ctx: RunCtx,
  chef: Chef,
  args: { adminUserId: string },
  deps: Pick<EffectsDeps, "deployKey" | "hostCloudUrl"> = {},
): Promise<{ prefix: string }> {
  let prefix: string;
  try {
    prefix = readHostDeployKey(deps).prefix;
  } catch (e) {
    await ctx.runMutation(chef.feedback.chefSettings.recordDeployKey, {
      adminUserId: args.adminUserId,
      outcome: "error",
      // Our own messages, which never quote the key.
      reason: e instanceof Error ? e.message : "invalid",
    });
    throw e;
  }
  await ctx.runMutation(chef.feedback.chefSettings.setDeployKeyPrefix, { adminUserId: args.adminUserId, prefix });
  await ctx.runMutation(chef.feedback.chefSettings.recordDeployKey, { adminUserId: args.adminUserId, outcome: "ok" });
  return { prefix };
}

// ---------------------------------------------------------------- refs

/**
 * Read the refs back after a push. If the request branch and `chef` both
 * point at the commit the runner reported, the push happened, even if its
 * report was lost: the run moves to `pushed`. Raises an alert if `main` moved.
 */
export async function confirmPush(
  ctx: RunCtx,
  chef: Chef,
  api: RefsApi,
  args: { runId: string; branch: string | null },
): Promise<{ pushed: boolean; branchPushed: boolean; mainMoved: boolean }> {
  const names = ["chef", "main", ...(args.branch ? [args.branch] : [])];
  const refs = await api.readRefs(names);
  return await ctx.runMutation(chef.feedback.chefEffects.confirmPushFromRefs, {
    runId: args.runId,
    refs: {
      branch: args.branch ? (refs[args.branch] ?? null) : null,
      chef: refs.chef ?? null,
      main: refs.main ?? null,
    },
  });
}

// ---------------------------------------------------------------- email

/**
 * Send a run's email once. The provider gets idempotency key
 * `chef-<runId>-<kind>`, so a retry after a lost response is deduplicated
 * there; once the send is recorded, a repeat doesn't call the provider at all.
 * A failed send is audited (`email.failed`); it throws unless the EmailApi
 * is best effort, in which case the run goes on with no email (`id` null).
 */
export async function sendRunEmail(
  ctx: RunCtx,
  chef: Chef,
  api: EmailApi,
  args: { runId: string; kind: string; to: string; subject: string; text: string; html?: string },
): Promise<{ id: string | null; sent: boolean }> {
  if (!/^[a-z][a-z0-9-]{0,30}$/.test(args.kind)) throw new Error("Bad email kind");
  const key = `email:${args.kind}`;
  const prior = await effectGet(ctx, chef, { runId: args.runId, key });
  if (prior?.status === "done" && prior.result) return { id: prior.result, sent: false };
  await effectIntent(ctx, chef, { runId: args.runId, key });
  const idempotencyKey = `chef-${args.runId}-${args.kind}`;
  let res: { id: string };
  try {
    res = await api.send({
      to: args.to,
      subject: args.subject,
      text: args.text,
      ...(args.html !== undefined ? { html: args.html } : {}),
      idempotencyKey,
      kind: args.kind,
    });
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    console.error(`Chef: the ${args.kind} email for run ${args.runId} was not sent: ${error}`);
    await ctx.runMutation(chef.feedback.chefEffects.emailFailed, { runId: args.runId, key, error });
    if (api.bestEffort) return { id: null, sent: false };
    throw e;
  }
  await effectDone(ctx, chef, { runId: args.runId, key, result: res.id || idempotencyKey });
  return { id: res.id || idempotencyKey, sent: true };
}

// ---------------------------------------------------------------- reconcile

/**
 * The host's reconciler, for a run in `reconciling` (stale, cancelled, or its
 * key revoked). Its credentials are already revoked. In order: secrets dead,
 * sandboxes deleted, secrets deleted, refs read back, and only then
 * finishReconciled, which frees the slot. If any step throws, the run stays
 * reconciling and keeps the slot; running this again picks up where it was,
 * since every step is safe to repeat.
 */
export async function reconcileRun(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  runId: string,
): Promise<{ finished: boolean; pushedToChef: boolean }> {
  const info = await ctx.runQuery(chef.feedback.chefEffects.reconcileInfo, { runId });
  if (!info || info.status !== "reconciling") return { finished: false, pushedToChef: false };
  // The names Convex recorded, plus any of the run's names that exist
  // remotely (a create whose response was lost never got recorded).
  const existing = new Set((await deps.secrets.listSecrets()).map((s) => s.name));
  const computed = (await allRunSecretNames(runId)).filter((n) => existing.has(n));
  const names = Array.from(new Set([...info.secretNames, ...computed]));
  // Only names that exist can be set dead; a missing one has no value at all.
  const live = names.filter((n) => existing.has(n));
  if (live.length) await killRunSecrets(ctx, chef, deps.secrets, { runId, names: live });
  const sandboxes = await deleteRunSandboxes(deps.sandboxes, runId, info.sandboxIds);
  await deleteRunSecrets(ctx, chef, deps.secrets, { runId, names });
  let pushedToChef = false;
  if (info.commitSha) {
    const r = await confirmPush(ctx, chef, deps.refs, { runId, branch: info.branch });
    pushedToChef = r.pushed;
  }
  const { finished } = await ctx.runMutation(chef.feedback.chefEffects.finishReconciled, {
    runId,
    pushedToChef,
    cleanup: { sandboxesDeleted: sandboxes.length, secretsDeleted: names.length },
  });
  return { finished, pushedToChef };
}

// ---------------------------------------------------------------- sweep

/**
 * The cleanup sweep: deletes `chef-run` sandboxes and `chef-*` secrets that
 * no live run owns (a leftover `chef-preview-deploy` from earlier versions
 * too), `chef-release` sandboxes whose ship is no longer open, and request branches of runs finished more than 14 days ago. Meant
 * to run on the host's workpool with retries; every deletion is safe to
 * repeat.
 */
export async function runCleanupSweep(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  opts: { now?: number } = {},
): Promise<{ sandboxes: string[]; secrets: string[]; branches: number; errors: number }> {
  const live = await ctx.runQuery(chef.feedback.chefEffects.liveResources, {});
  const liveRuns = new Set<string>(live.runIds);
  const liveSecrets = new Set<string>(live.secretNames);
  for (const id of live.runIds) {
    for (const n of await allRunSecretNames(id)) liveSecrets.add(n);
  }
  let errors = 0;
  const attempt = async (fn: () => Promise<void>) => {
    try {
      await fn();
      return true;
    } catch {
      errors++;
      return false;
    }
  };

  const liveReleases = new Set<string>(live.releaseIds ?? []);
  // A repair sandbox (label chef-repair) and its git secret, while its repair is being made.
  const liveRepairs = new Set<string>(live.repairRunIds ?? []);
  for (const id of liveRepairs) liveSecrets.add(`chef-git-repair-${await run8(id)}`);
  const sandboxes: string[] = [];
  for (const s of await deps.sandboxes.listSandboxes()) {
    const owner = s.labels[RUN_LABEL];
    const release = s.labels[RELEASE_LABEL];
    const repair = s.labels[REPAIR_LABEL];
    // A ship's deploy sandbox belongs to its release while that is open.
    if (release !== undefined) {
      if (liveReleases.has(release)) continue;
    } else if (repair !== undefined) {
      if (liveRepairs.has(repair)) continue;
    } else if (owner === undefined || liveRuns.has(owner)) continue;
    if (await attempt(() => deps.sandboxes.deleteSandbox(s.id))) sandboxes.push(s.id);
  }

  const secrets: string[] = [];
  for (const { name } of await deps.secrets.listSecrets()) {
    // Includes a leftover chef-preview-deploy from earlier versions.
    if (!name.startsWith("chef-") || liveSecrets.has(name)) continue;
    const ok = await attempt(async () => {
      await deps.secrets.setSecret(name, DEAD_VALUE);
      await deps.secrets.deleteSecret(name);
    });
    if (ok) secrets.push(name);
  }

  let branches = 0;
  const due = await ctx.runQuery(chef.feedback.chefEffects.branchesToSweep, { now: opts.now ?? Date.now() });
  for (const r of due) {
    const ok = await attempt(async () => {
      if (r.branch) await deps.refs.deleteRef(r.branch);
      await ctx.runMutation(chef.feedback.chefEffects.markBranchSwept, { runId: r.runId, deleted: !!r.branch });
    });
    if (ok && r.branch) branches++;
  }

  await ctx.runMutation(chef.feedback.chefEffects.recordSweep, { sandboxes, secrets, branches, errors });
  // Let the workpool retry a sweep that hit errors; what it did is kept.
  if (errors > 0) throw new Error(`Cleanup sweep: ${errors} deletions failed`);
  return { sandboxes, secrets, branches, errors };
}

// ------------------------------------------------- a deploy script's failure

/** How many of a failed deploy script's last lines go into the run log. */
export const DEPLOY_LOG_TAIL_LINES = 80;
const DEPLOY_LOG_LINE = 500;

export type ScriptOutput = {
  /** The last lines it printed, scrubbed; [] when there is nothing to read. */
  tail: string[];
  /** Its last "<script>: error: <why>" line's <why>: what `die` said. */
  errorLine: string | null;
};

/**
 * A deploy script's own account of how it failed: the end of the scrubbed
 * copy of its output it keeps in `logFile` (CHEF_LOG_FILE), else the output
 * the provider kept for the execution; scrubbed again here, with the deploy
 * key's parts as known values. Never throws: a failure's reason must not
 * get lost in reading it.
 */
export async function deployScriptOutput(
  sandboxes: SandboxApi,
  args: { sandboxId: string; executionId: string; logFile: string; script: string; known?: string[] },
): Promise<ScriptOutput> {
  let text: string | null = null;
  try {
    text = await sandboxes.readFile(args.sandboxId, args.logFile);
  } catch {
    text = null;
  }
  if (text === null || text.trim() === "") {
    try {
      text = (await sandboxes.execution(args.executionId))?.output ?? null;
    } catch {
      text = null;
    }
  }
  if (text === null || text.trim() === "") return { tail: [], errorLine: null };
  // The end only: a long install log is mostly noise, and the cause is last.
  const clean = scrub(text.slice(-256 * 1024), { knownValues: (args.known ?? []).filter((k) => k.length >= 8) });
  const lines = clean
    .split("\n")
    .map((l) => l.replace(/\r$/, "").replace(/\s+$/, ""))
    .filter((l) => l !== "");
  const tail = lines.slice(-DEPLOY_LOG_TAIL_LINES).map((l) => (l.length > DEPLOY_LOG_LINE ? `${l.slice(0, DEPLOY_LOG_LINE)}...` : l));
  const prefix = `${args.script}: error: `;
  let errorLine: string | null = null;
  for (let i = lines.length - 1; i >= 0; i--) {
    if (lines[i].startsWith(prefix)) {
      errorLine = lines[i].slice(prefix.length).trim().slice(0, 500) || null;
      break;
    }
  }
  return { tail, errorLine };
}

/**
 * The line in a deploy script's output most likely to say why a step failed
 * (the CLI's own error), for a failure the script could only describe as
 * "failed while <step>". Null if none stands out.
 */
export function likelyCause(tail: readonly string[], script: string): string | null {
  for (let i = tail.length - 1; i >= 0; i--) {
    const l = tail[i].trim();
    if (l.startsWith(`${script}:`)) continue;
    if (/(^|\s)(✖|error\b|Error:|ERR_|failed\b|fatal:)/i.test(l)) return l.length > 300 ? `${l.slice(0, 297)}...` : l;
  }
  return null;
}
