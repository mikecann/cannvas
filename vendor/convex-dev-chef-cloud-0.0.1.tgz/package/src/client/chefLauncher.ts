/**
 * The build sandbox launcher (docs/chef-pipeline.md, "One run, step by step",
 * "Egress, per sandbox, fail-closed" and "Run credentials"). Host-side, like
 * src/client/chefEffects.ts: these run in the host's actions over the `SandboxApi`,
 * `SecretsApi`, `RefsApi`, `GitAuthApi` and `EmailApi` interfaces.
 *
 * Each exported step is safe to run again after a failure or a lost
 * response, so a host on `@convex-dev/workflow` makes each one a step:
 *
 *   launchBuild      secrets dead, sandbox with mounts and clone egress, runner started
 *   runnerStatus     poll the runner's status file until its egress self-test is in
 *   goLive           run credentials issued, secrets real, git read-only
 *   syncBuildPhase   poll; egress and the git secret follow the run's phase, and
 *                    the runner's requests for `agent` and `pushing` are granted
 *                    only once the sandbox is in the state that phase allows
 *   retireBuildSandbox  secrets dead, refs read back, sandbox and secrets deleted
 *   failRun          on any failure: the same cleanup, an email, finish failed
 *
 * and for the preview (docs, "The preview"):
 *
 *   startPreview     build sandbox gone first; a change the web preview can't
 *                    show (only the phone or Mac app, tests, docs) stops
 *                    here, with no preview (`skipped`); else a deploy sandbox with a read-only
 *                    git secret and the deploy egress list; the built frontend
 *                    written into it; the fixed script, with the preview deploy
 *                    key in that one command's environment
 *   previewStatus    poll the script's result
 *   completePreview  preview recorded with a link built here, sandbox and secret gone
 *   finishBuilt      the email with the preview link (or why there is none), then the run built
 *
 * `driveBuild`, `drivePreview` and `driveRun` run them in order with a
 * `sleep` between polls, for a host that drives the run from one action, and
 * for tests.
 *
 *   import { driveRun } from "@convex-dev/chef-cloud/launcher";
 *
 * The contract with the runner (runner/runner.ts):
 *
 * - It starts with `CHEF_API` and `CHEF_RUN_ID` only; its three secrets are
 *   placeholders whose values are dead. Daytona runs commands as `daytona`,
 *   and the runner must be root, so the command is
 *   `sudo -n --preserve-env=CHEF_API,CHEF_RUN_ID,CHEF_RUN_TOKEN,CHEF_GIT_AUTH,CHEF_AI_TOKEN <runner>`
 *   (`runnerStartCommand`): sudo's env_reset would otherwise drop the
 *   mounted placeholders. Names only; no value is ever in argv.
 * - Its first act is to create `<stateDir>/started` (readable, nothing
 *   secret in it), and it refuses to start if that exists. The state dir
 *   is root-owned 0711 and `started` and `status.json` are 0644, because
 *   Daytona's toolbox reads files as `daytona`, not root. A launch retried
 *   after a lost start response adopts the running command (startOnce).
 * - Before any request it runs the egress self-test and writes
 *   `<stateDir>/status.json` (`/opt/chef/state/status.json`):
 *   `{ runId, at, phase, ok, error?, selfTest?: { ok, probes: [{ probe,
 *   blocked, detail }] } }`. The launcher reads it through Daytona, since the
 *   run credential is still dead. `phase: "ready"` with a self-test whose
 *   probes were all blocked is what makes the credentials go live.
 * - It waits for `GET /chef-agent/run` to succeed, then reports
 *   `launched -> ready -> cloning`.
 * - After clone and install it reports `cloning -> cloned` and waits until
 *   the run's phase is `agent` (from `GET /run` or the heartbeat's `phase`)
 *   before it starts the agent. The launcher grants `agent` only after the
 *   git secret is dead and egress is the app's own host.
 * - After the guards and the commit it builds the frontend as the agent user
 *   with a placeholder Convex URL and uploads it to POST /chef-agent/artifact
 *   (runner/frontend-artifact.ts), still in `guards`; the deploy sandbox gets
 *   those files, never the repo's build. Then it reports `guards -> committed`
 *   with the commit facts and waits until the phase is `pushing`. The launcher grants
 *   it as soon as it has set the git write credential and added the git host
 *   to egress, with no settle: widening egress reaches a running sandbox
 *   only after 1 to 3 minutes (L2), so a fixed delay would be either too
 *   short or wasted. Instead the runner, once granted, probes the git host
 *   (`git ls-remote` with the credential) until it answers, bounded by
 *   `gitReachWaitMs` (5 minutes), and pushes only then. The git secret is
 *   dead before, so an answer means both the egress and the new value have
 *   arrived. It does the same before the clone.
 * - Narrowing is the other way round: it takes effect within seconds and cuts
 *   open connections, so `agent` is granted after a short fixed settle
 *   (`settleMs`, 10 seconds) once git is dead and egress is the app's host.
 *   The runner can't check that from inside, which is why the launcher waits.
 * - It reports `pushing -> pushed` after the pushes.
 * - Any failure: `status.json` with `ok: false`, `phase` (the stage) and a
 *   scrubbed `error`, and a nonzero exit. The launcher fails the run on
 *   either.
 */
import { classifyFailure } from "@convex-dev/feedback/chef/failures.js";
import { PREVIEW_REDEPLOYS, recover } from "@convex-dev/feedback/chef/recovery.js";
import type { ChefApis } from "./apis.js";
import {
  allRunSecretNames,
  deployGitSecretName,
  confirmPush,
  createRunSecrets,
  deleteRunSandboxes,
  deleteRunSecrets,
  deleteRoleSandboxes,
  effectDone,
  effectGet,
  effectIntent,
  ensureSandbox,
  deployScriptOutput,
  killRunSecrets,
  likelyCause,
  readPreviewDeployKey,
  runSecretNames,
  sendRunEmail,
  setRunSecret,
  type Egress,
  type EffectsDeps,
  type RunCtx,
  type SandboxApi,
} from "./chefEffects.js";
import { buildBuildEmail } from "../shared/email.js";
import { createWithWarm, pickWarm, recordWarmUse, type WarmPick, type WarmSettings } from "./chefWarm.js";
import { MAX_ARTIFACT_BYTES } from "@convex-dev/feedback/chef/frontend.js";
import { checkPreviewLoginUrl } from "@convex-dev/feedback/chef/previewLogin.js";
import { isRunPreviewName, previewNameFor, previewSkip, type PreviewSkip } from "@convex-dev/feedback/chef/preview.js";
import { RUNNER_ENV_NAMES } from "@convex-dev/feedback/chef/runnerEnv.js";
import { singleLine } from "@convex-dev/feedback/chef/text.js";
import {
  deliveredDeployCommand,
  deliveredRunnerCommand,
  deployDelivery,
  runnerDelivery,
  writeDelivery,
} from "@convex-dev/feedback/delivery";

type Chef = ChefApis;

// ---------------------------------------------------------------- config

export const NPM_REGISTRY = "registry.npmjs.org";
export const DEFAULT_RUNNER_COMMAND = "/opt/chef/bin/chef-runner";

/**
 * The command that starts the runner: root through passwordless sudo,
 * keeping exactly the variables the runner reads (src/chef/runnerEnv.ts).
 * Their values travel in the execution's envs and the sandbox's mounts,
 * never here. `-n` so a sudo that would prompt fails instead of hanging.
 */
export function runnerStartCommand(cfg: Pick<BuildConfig, "runnerCommand">): string {
  const runner = cfg.runnerCommand ?? DEFAULT_RUNNER_COMMAND;
  if (!ABS_PATH.test(runner)) throw new Error("runner paths must be absolute");
  return `sudo -n --preserve-env=${RUNNER_ENV_NAMES.join(",")} ${runner}`;
}
export const DEFAULT_STATUS_PATH = "/opt/chef/state/status.json";
/** The runner's start marker (runner/runner.ts), written before anything else. */
export const DEFAULT_MARKER_PATH = "/opt/chef/state/started";

/** Where the build email goes and what it links to. Links are built here, never taken from a sandbox. */
export type NotifyConfig = {
  to: string;
  appName: string;
  /** The run's page in the panel. */
  runPageUrl: (runId: string) => string;
  /** Hosts links may point at (buildBuildEmail's default: convex.cloud, .site, .app). */
  allowedLinkHosts?: (string | RegExp)[];
};

export type BuildConfig = {
  /** The app's `<deployment>.convex.site`: the Chef agent API and the inference proxy. */
  siteHost: string;
  /** The Code Storage git host. */
  gitHost: string;
  /** The pinned `chef-runner` Daytona snapshot. */
  snapshot: string;
  runnerCommand?: string;
  /** The runner's status file: its self-test, and any failure. */
  statusPath?: string;
  /** The runner's start marker, read to adopt a runner whose start response was lost. */
  markerPath?: string;
  /** Life of each Code Storage token (default 600 seconds). */
  gitTokenTtlSeconds?: number;
  /** Daytona deletes the sandbox on its own after this many minutes (default 120). */
  autoDeleteMinutes?: number;
  /**
   * How long after narrowing (git dead, egress the app's host only) before
   * `agent` is granted. Narrowing reached a running sandbox within 1.5 s
   * and cut open connections within 4 s in L2. Default 10000 ms. Widening
   * for the push has no settle; the runner waits until it sees the host.
   */
  settleMs?: number;
  notify?: NotifyConfig;
  /**
   * Deliver the runner instead of running one baked into the snapshot
   * (src/client/chefDelivery.ts): the launcher writes the runner bundle of
   * this package, its config and any skills into the build sandbox, and the
   * deploy scripts into the deploy sandbox, and the start commands install
   * them root-owned and check their sha256 before anything runs. For a base
   * image with no Chef code, such as `shared:chef-base-1`. Ignored when
   * `runnerCommand` (build) or `deployCommand` (preview) names a baked one.
   */
  deliver?: DeliverConfig;
  /**
   * Warm snapshots (src/client/chefWarm.ts): the build and preview sandboxes
   * start from the app's own snapshot with its dependencies' caches when one
   * is ready for their commit's lockfile, else from `snapshot` (and one is
   * built in the background). Only with the delivered runner and scripts on
   * chef-base, whose recipe the warm snapshot repeats. Absent: off.
   */
  warm?: WarmSettings;
};

export type DeliverConfig = {
  /** The runner's file config (runner.json). Default: defaultRunnerJson for the chef-base image. */
  runnerJson?: Record<string, unknown>;
  /** Skills for the build agent, `{ name: SKILL.md text }`, read-only to it. */
  skills?: Record<string, string>;
};

const SITE_HOST = /^[a-z0-9-]+\.convex\.site$/;
const HOST = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;
const ABS_PATH = /^\/[A-Za-z0-9_./-]+$/;

export function checkBuildConfig(cfg: BuildConfig): void {
  if (!SITE_HOST.test(cfg.siteHost ?? "")) throw new Error("siteHost must be <deployment>.convex.site");
  if (!HOST.test(cfg.gitHost ?? "")) throw new Error("gitHost must be a host name");
  if (!cfg.snapshot) throw new Error("snapshot is required");
  for (const p of [cfg.runnerCommand, cfg.statusPath, cfg.markerPath]) {
    if (p !== undefined && !ABS_PATH.test(p)) throw new Error("runner paths must be absolute");
  }
}

// ---------------------------------------------------------------- policy

export type BuildEgressPhase = "clone" | "agent" | "push";
export type GitAccess = "dead" | "read" | "write";

/** The build sandbox's egress for a phase (docs, the egress table). */
export function buildEgress(cfg: Pick<BuildConfig, "siteHost" | "gitHost">, phase: BuildEgressPhase): Egress {
  switch (phase) {
    case "clone":
      return { domainAllowList: [cfg.siteHost, cfg.gitHost, NPM_REGISTRY] };
    case "agent":
      return { domainAllowList: [cfg.siteHost] };
    case "push":
      return { domainAllowList: [cfg.siteHost, cfg.gitHost] };
  }
}

/**
 * What the build sandbox may reach, and what the git secret holds, in each
 * of the run's phases. Git is live only for clone and push, read-only for
 * the clone; the agent and the gates get the app's own host and nothing else.
 */
export function phasePolicy(phase: string): { egress: BuildEgressPhase; git: GitAccess } {
  switch (phase) {
    case "launched":
    case "ready":
    case "cloning":
      return { egress: "clone", git: "read" };
    case "committed":
    case "pushing":
      return { egress: "push", git: "write" };
    default:
      // cloned (asking for the agent phase), agent, gates, guards, and pushed onwards.
      return { egress: "agent", git: "dead" };
  }
}

/** The runner's requests, and the phase granted once the policy for it is applied. */
export const PHASE_GRANTS: Record<string, "agent" | "pushing"> = { cloned: "agent", committed: "pushing" };

/** The settle after narrowing, before `agent` is granted (BuildConfig.settleMs). */
export const DEFAULT_NARROW_SETTLE_MS = 10_000;

/**
 * How long a grant waits after its policy is applied. Only narrowing gets a
 * fixed wait; for `pushing` the runner probes the git host itself.
 */
export function grantSettleMs(grant: "agent" | "pushing", cfg: Pick<BuildConfig, "settleMs">): number {
  return grant === "agent" ? (cfg.settleMs ?? DEFAULT_NARROW_SETTLE_MS) : 0;
}

const policyKey = (p: { egress: BuildEgressPhase; git: GitAccess }) => `${p.egress}:${p.git}`;

// ---------------------------------------------------------------- status

export type RunnerStatus = {
  /** The egress self-test: not written yet, passed (every probe blocked), or failed. */
  selfTest: "pending" | "passed" | "failed";
  /** Set when the runner says it failed, or the file can't be trusted. */
  failed: string | null;
};

/**
 * The runner's `status.json`, written by root-owned runner code. The
 * self-test passed only if the file is for this run, says ok, and has at
 * least one probe, every one of them blocked. `error` is runner text,
 * already scrubbed; it is still treated as untrusted wherever it is shown.
 */
export function parseRunnerStatus(raw: string | null, runId: string): RunnerStatus {
  if (raw === null || raw.trim() === "") return { selfTest: "pending", failed: null };
  let o: { runId?: unknown; phase?: unknown; ok?: unknown; error?: unknown; selfTest?: unknown };
  try {
    o = JSON.parse(raw);
  } catch {
    return { selfTest: "failed", failed: "the runner's status file is not JSON" };
  }
  if (!o || typeof o !== "object") return { selfTest: "failed", failed: "the runner's status file is not an object" };
  if (o.runId !== runId) return { selfTest: "failed", failed: "the runner's status file is for another run" };
  const phase = typeof o.phase === "string" ? o.phase.slice(0, 40) : "unknown";
  let selfTest: RunnerStatus["selfTest"] = "pending";
  if (o.selfTest !== undefined) {
    const st = o.selfTest as { ok?: unknown; probes?: unknown };
    const probes = Array.isArray(st?.probes) ? (st.probes as Array<{ blocked?: unknown }>) : [];
    selfTest = st?.ok === true && probes.length > 0 && probes.every((p) => p && p.blocked === true) ? "passed" : "failed";
  }
  if (o.ok !== true) {
    const error = typeof o.error === "string" ? o.error.slice(0, 1000) : "no error given";
    return { selfTest: selfTest === "passed" ? "passed" : "failed", failed: `the runner failed in ${phase}: ${error}` };
  }
  if (selfTest === "failed") return { selfTest, failed: "egress self-test failed" };
  return { selfTest, failed: null };
}

export async function runnerStatus(
  sandboxes: SandboxApi,
  args: { runId: string; sandboxId: string; config: BuildConfig },
): Promise<RunnerStatus> {
  const raw = await sandboxes.readFile(args.sandboxId, args.config.statusPath ?? DEFAULT_STATUS_PATH);
  return parseRunnerStatus(raw, args.runId);
}

// ---------------------------------------------------------------- steps

export type RunInfo = {
  runId: string;
  seq: number;
  status: string;
  phase: string;
  startedVia: string;
  deadline: number;
  heartbeatAt: number;
  itemNumber: number | null;
  title: string;
  baseSha: string | null;
  branch: string | null;
  commitSha: string | null;
  filesChanged: string[];
  error: string | null;
  previewName: string | null;
  previewUrl: string | null;
  /** The one-time sign-in link, for the build email only. */
  previewLoginUrl?: string | null;
  previewKeyPrefix: string | null;
  /** A release merge (main moved under Ship it): no preview, no email; built once pushed. */
  releaseMerge?: boolean;
};

/** Thrown when the run stopped being active under the orchestration (cancelled, stale, revoked). */
export class RunNotActive extends Error {
  constructor(public readonly status: string) {
    super(`Run is ${status}, not active`);
    this.name = "RunNotActive";
  }
}

export async function getRunInfo(ctx: RunCtx, chef: Chef, runId: string): Promise<RunInfo> {
  const info = (await ctx.runQuery(chef.feedback.chefEffects.runInfo, { runId })) as RunInfo | null;
  if (!info) throw new Error("Run not found");
  return info;
}

async function activeInfo(ctx: RunCtx, chef: Chef, runId: string): Promise<RunInfo> {
  const info = await getRunInfo(ctx, chef, runId);
  if (info.status !== "active") throw new RunNotActive(info.status);
  return info;
}

/**
 * Start a background command once per run and key; a repeat returns the
 * recorded execution. An intent without its done record means an earlier
 * attempt may have started the command and lost the response, so the
 * sandbox is asked first, and a command found there is adopted, never
 * started again:
 *
 * - the newest execution of exactly this command in the run's sandbox is
 *   adopted if it is running, or if it ended and the command's marker file
 *   (`markerPath`, the runner's `started`) shows it got going;
 * - one that ended with no marker never got going, and is started again
 *   (the runner itself refuses a second start, by the same marker);
 * - no execution but a marker: it started and its record is gone; refused,
 *   since starting again would only meet the runner's refusal.
 *
 * Without `markerPath`, any execution of the command found is adopted.
 */
export async function startOnce(
  ctx: RunCtx,
  chef: Chef,
  sandboxes: SandboxApi,
  args: {
    runId: string;
    key: "exec:runner" | "exec:demo" | `exec:beta${string}` | `exec:deploy${string}`;
    sandboxId: string;
    command: string;
    envs: Record<string, string>;
    markerPath?: string;
  },
): Promise<string> {
  const prior = await effectGet(ctx, chef, { runId: args.runId, key: args.key });
  if (prior?.status === "done" && prior.result) return prior.result as string;
  if (prior) {
    const found = (await sandboxes.listExecutions(args.sandboxId)).find((e) => e.command === args.command);
    const marker = args.markerPath !== undefined ? await sandboxes.readFile(args.sandboxId, args.markerPath) : null;
    if (found && (found.status === "running" || args.markerPath === undefined || marker !== null)) {
      await effectDone(ctx, chef, {
        runId: args.runId,
        key: args.key,
        result: found.executionId,
        adopted: true,
      });
      return found.executionId;
    }
    if (!found && marker !== null) {
      throw new Error(`The ${args.key.slice(5)} started, but its execution can't be found; not starting it again`);
    }
  }
  await effectIntent(ctx, chef, { runId: args.runId, key: args.key });
  const { executionId } = await sandboxes.startCommand(args.sandboxId, { command: args.command, envs: args.envs });
  await effectDone(ctx, chef, { runId: args.runId, key: args.key, result: executionId });
  return executionId;
}

/**
 * Steps 2 to 4: the run's three secrets with dead values; the build sandbox
 * from the pinned snapshot with those secrets mounted at creation, egress set
 * to the clone list and nothing secret in its environment; then the runner,
 * whose environment is only the API URL and the run id. Refuses (before
 * creating anything) without egress, and for a run an external runner drives.
 */
export async function launchBuild(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: BuildConfig },
): Promise<{ sandboxId: string; executionId: string }> {
  const cfg = args.config;
  checkBuildConfig(cfg);
  const spec = buildEgress(cfg, "clone");
  const info = await activeInfo(ctx, chef, args.runId);
  if (info.startedVia === "enroll") throw new Error("An enrolled run is driven by its external runner");
  const names = await createRunSecrets(ctx, chef, deps.secrets, {
    runId: args.runId,
    hosts: { run: [cfg.siteHost], ai: [cfg.siteHost], git: [cfg.gitHost] },
  });
  // The app's warm snapshot for what the runner will check out (chef, else
  // main), if one is ready; else the base, and one is asked for. Looked up
  // only before the sandbox exists.
  const priorSandbox = await effectGet(ctx, chef, { runId: args.runId, key: "sandbox:build" });
  let pick: WarmPick | null = null;
  if (cfg.warm && priorSandbox?.status !== "done") {
    const refs = await deps.refs.readRefs(["chef", "main"]).catch(() => ({}) as Record<string, string | null>);
    const sha = refs.chef ?? refs.main ?? null;
    pick = sha ? await pickWarm(ctx, chef, deps, { at: { commit: sha }, settings: cfg.warm }) : null;
  }
  const { result: sbx, warm } = await createWithWarm(ctx, chef, deps, {
    pick,
    base: cfg.snapshot,
    create: (snapshot) =>
      ensureSandbox(ctx, chef, deps.sandboxes, {
        runId: args.runId,
        role: "build",
        spec: {
          snapshot,
          secrets: { CHEF_RUN_TOKEN: names.run, CHEF_AI_TOKEN: names.ai, CHEF_GIT_AUTH: names.git },
          ...spec,
          // The runner is a background command, which Daytona doesn't count as
          // activity; the run's own deadline and the delete below bound it.
          autoStopInterval: 0,
          autoDeleteInterval: cfg.autoDeleteMinutes ?? 120,
        },
      }),
  });
  if (pick) await recordWarmUse(ctx, chef, { runId: args.runId, role: "build", warm, pick });
  let command = runnerStartCommand(cfg);
  if (cfg.deliver && cfg.runnerCommand === undefined) {
    // The runner this package carries, written in before it starts. Not
    // again once the start is recorded: the runner has installed its copy.
    const d = await runnerDelivery(cfg.deliver);
    const started = await effectGet(ctx, chef, { runId: args.runId, key: "exec:runner" });
    if (started?.status !== "done") await writeDelivery(deps.sandboxes, sbx.id, d);
    command = deliveredRunnerCommand(d);
  }
  const executionId = await startOnce(ctx, chef, deps.sandboxes, {
    runId: args.runId,
    key: "exec:runner",
    sandboxId: sbx.id,
    command,
    envs: { CHEF_API: `https://${cfg.siteHost}`, CHEF_RUN_ID: args.runId },
    markerPath: cfg.markerPath ?? DEFAULT_MARKER_PATH,
  });
  return { sandboxId: sbx.id, executionId };
}

/** Put the egress and the git secret in the state a phase allows. Narrowing kills git first. */
async function applyPolicy(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; sandboxId: string; config: BuildConfig; phase: string },
): Promise<string> {
  const p = phasePolicy(args.phase);
  const egress = buildEgress(args.config, p.egress);
  if (p.git === "dead") {
    const git = (await runSecretNames(args.runId)).git;
    await killRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names: [git] });
    await deps.sandboxes.updateNetwork(args.sandboxId, egress);
  } else {
    if (!deps.git) throw new Error("No GitAuthApi: can't mint a Code Storage token");
    const value = await deps.git.basicAuth({ access: p.git, ttlSeconds: args.config.gitTokenTtlSeconds ?? 600 });
    await setRunSecret(ctx, chef, deps.secrets, { runId: args.runId, kind: "git", value });
    await deps.sandboxes.updateNetwork(args.sandboxId, egress);
  }
  return policyKey(p);
}

/**
 * Step 5: the credentials go live, and only after the runner's egress
 * self-test passed. It is read again here, whatever the caller saw: no
 * real value is set for a run whose sandbox hasn't proved its egress is
 * closed. Issuing again (a retry) revokes the earlier credentials.
 */
export async function goLive(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; sandboxId: string; config: BuildConfig },
): Promise<{ applied: string }> {
  const st = await runnerStatus(deps.sandboxes, args);
  if (st.failed) throw new Error(`Self-test: ${st.failed}`);
  if (st.selfTest !== "passed") throw new Error("The runner's self-test hasn't reported");
  const info = await activeInfo(ctx, chef, args.runId);
  const creds = (await ctx.runMutation(chef.feedback.chefAgent.issueRunCredentials, { runId: args.runId })) as {
    runner: string;
    inference: string;
  };
  await setRunSecret(ctx, chef, deps.secrets, { runId: args.runId, kind: "run", value: creds.runner });
  await setRunSecret(ctx, chef, deps.secrets, { runId: args.runId, kind: "ai", value: creds.inference });
  const applied = await applyPolicy(ctx, chef, deps, { ...args, phase: info.phase });
  return { applied };
}

/**
 * Steps 6 to 10, polled: make egress and the git secret match the run's
 * phase (narrowing to the app's host for the agent, the git host back for
 * the push with a write token, dead again after). When the runner asks for
 * `agent` (`cloned`) or `pushing` (`committed`), the phase is granted only
 * after that policy is applied, so the agent never starts while git is live
 * or egress is wide, and the push never starts before its credential is set
 * (the runner then waits until the git host answers; see the contract).
 * `applied` is what the last call applied, so an unchanged phase costs one
 * query. While pushing, the refs are read back too, so a push whose report
 * was lost still moves on.
 */
export async function syncBuildPhase(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: {
    runId: string;
    sandboxId: string;
    config: BuildConfig;
    applied: string | null;
    /** When `applied` was applied; an `agent` grant waits `settleMs` after it. */
    appliedAt?: number;
    now?: () => number;
  },
): Promise<{ phase: string; applied: string | null; appliedAt: number }> {
  const now = args.now ?? Date.now;
  let info = await activeInfo(ctx, chef, args.runId);
  if (info.phase === "pushing") {
    const r = await confirmPush(ctx, chef, deps.refs, { runId: args.runId, branch: info.branch });
    if (r.pushed) info = await activeInfo(ctx, chef, args.runId);
  }
  const want = policyKey(phasePolicy(info.phase));
  let applied = args.applied;
  let appliedAt = args.appliedAt ?? 0;
  if (want !== applied) {
    if (info.phase === "launched" && phasePolicy(info.phase).git !== "dead") {
      const st = await runnerStatus(deps.sandboxes, args);
      if (st.selfTest !== "passed" || st.failed) throw new Error("No live git credential before the self-test passes");
    }
    applied = await applyPolicy(ctx, chef, deps, { ...args, phase: info.phase });
    appliedAt = now();
  }
  const grant = PHASE_GRANTS[info.phase];
  if (grant && now() - appliedAt >= grantSettleMs(grant, args.config)) {
    // Only now, with the sandbox in the state the next phase allows.
    // PHASE_GRANTS has a grant only for "cloned" and "committed".
    const from = info.phase as "cloned" | "committed";
    await ctx.runMutation(chef.feedback.chefEffects.setPhase, { runId: args.runId, from, to: grant });
    return { phase: grant, applied, appliedAt };
  }
  return { phase: info.phase, applied, appliedAt };
}

/**
 * Step 11: the build sandbox goes. Its secrets are set dead, the refs read
 * back (and `main` checked), the sandbox deleted, then the secrets deleted.
 * Nothing in it is needed for the preview.
 */
export async function retireBuildSandbox(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string },
): Promise<{ sandboxes: string[] }> {
  const names = Object.values(await runSecretNames(args.runId));
  const existing = new Set((await deps.secrets.listSecrets()).map((s) => s.name));
  const live = names.filter((n) => existing.has(n));
  if (live.length) await killRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names: live });
  const info = await getRunInfo(ctx, chef, args.runId);
  if (info.commitSha) await confirmPush(ctx, chef, deps.refs, { runId: args.runId, branch: info.branch });
  const recorded = await effectGet(ctx, chef, { runId: args.runId, key: "sandbox:build" });
  const ids = new Set(await deleteRoleSandboxes(deps.sandboxes, args.runId, "build"));
  if (recorded?.result && !ids.has(recorded.result)) {
    await deps.sandboxes.deleteSandbox(recorded.result);
    ids.add(recorded.result);
  }
  await deleteRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names });
  return { sandboxes: [...ids] };
}

/**
 * Everything of a run's, in the order the doc gives for a failure: every
 * secret it can own set dead, every sandbox labelled for it (or recorded)
 * deleted, then the secrets deleted. Only the run's own names: never a
 * secret some other run or setup owns. Safe to repeat.
 */
export async function cleanupRun(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string },
): Promise<{ sandboxes: string[]; secrets: string[] }> {
  const info = await ctx.runQuery(chef.feedback.chefEffects.reconcileInfo, { runId: args.runId });
  const existing = new Set((await deps.secrets.listSecrets()).map((s) => s.name));
  const names = Array.from(new Set([...(info?.secretNames ?? []), ...(await allRunSecretNames(args.runId))]));
  const live = names.filter((n) => existing.has(n));
  if (live.length) await killRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names: live });
  const sandboxes = await deleteRunSandboxes(deps.sandboxes, args.runId, info?.sandboxIds ?? []);
  await deleteRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names });
  return { sandboxes, secrets: names };
}

/**
 * A failure at any step: cleanup, the "build failed" email (no preview
 * link), and the run finished as failed, which puts the item back in
 * `requested` with a devLog. A run that is no longer active (cancelled,
 * stale, revoked) belongs to the reconciler, which does the same cleanup.
 */
export async function failRun(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: { notify?: NotifyConfig }; error: string },
): Promise<{ finished: boolean }> {
  const info = await getRunInfo(ctx, chef, args.runId);
  if (info.status !== "active") return { finished: false };
  await cleanupRun(ctx, chef, deps, { runId: args.runId });
  const n = args.config.notify;
  if (n && deps.email && info.itemNumber !== null) {
    try {
      const mail = buildBuildEmail({
        kind: "failed",
        appName: n.appName,
        itemNumber: info.itemNumber,
        title: info.title,
        error: args.error,
        screenshots: await screenshotLinks(ctx, chef, args.runId),
        ...(info.commitSha ? { commitSha: info.commitSha } : {}),
        runPageUrl: n.runPageUrl(args.runId),
        ...(n.allowedLinkHosts ? { allowedLinkHosts: n.allowedLinkHosts } : {}),
      });
      await sendRunEmail(ctx, chef, deps.email, { runId: args.runId, kind: "failed", to: n.to, ...mail });
    } catch {
      // The run still has to finish and free the slot; the failure is in its devLog.
    }
  }
  return (await ctx.runMutation(chef.feedback.chefEffects.finishActive, {
    runId: args.runId,
    outcome: "failed",
    error: args.error.slice(0, 2000),
  })) as { finished: boolean };
}

// ---------------------------------------------------------------- driver

export type Waiter = {
  sleep: (ms: number) => Promise<void>;
  pollMs?: number;
  now?: () => number;
};

const DONE_BUILDING = new Set(["pushed", "previewing", "done"]);

async function checkExecution(sandboxes: SandboxApi, executionId: string, what: string) {
  const e = await sandboxes.execution(executionId);
  if (e && e.status !== "running") {
    throw new Error(`The ${what} exited (${e.status}${e.exitCode !== undefined ? `, code ${e.exitCode}` : ""})`);
  }
}

/**
 * Steps 2 to 11 in one go: launch, wait for the self-test, go live, follow
 * the phases to `pushed`, retire the build sandbox. Throws on any failure,
 * leaving cleanup to `failRun` (or `driveRun`, which calls it).
 */
export async function driveBuild(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: BuildConfig; wait: Waiter },
): Promise<{ sandboxId: string }> {
  const { sleep } = args.wait;
  const pollMs = args.wait.pollMs ?? 5000;
  const now = args.wait.now ?? Date.now;
  const { sandboxId, executionId } = await launchBuild(ctx, chef, deps, args);
  const deadline = (await getRunInfo(ctx, chef, args.runId)).deadline;
  const tick = async () => {
    if (now() > deadline) throw new Error("The run passed its deadline");
    await sleep(pollMs);
  };

  const status = () => runnerStatus(deps.sandboxes, { runId: args.runId, sandboxId, config: args.config });
  for (;;) {
    const st = await status();
    if (st.failed) throw new Error(st.selfTest === "failed" ? `Egress self-test failed: ${st.failed}` : st.failed);
    if (st.selfTest === "passed") break;
    await checkExecution(deps.sandboxes, executionId, "runner");
    await tick();
  }
  let applied: string | null = (await goLive(ctx, chef, deps, { runId: args.runId, sandboxId, config: args.config }))
    .applied;
  let appliedAt = now();
  for (;;) {
    const r = await syncBuildPhase(ctx, chef, deps, {
      runId: args.runId,
      sandboxId,
      config: args.config,
      applied,
      appliedAt,
      now,
    });
    applied = r.applied;
    appliedAt = r.appliedAt;
    if (DONE_BUILDING.has(r.phase)) break;
    const st = await status();
    if (st.failed) throw new Error(st.failed);
    await checkExecution(deps.sandboxes, executionId, "runner");
    await tick();
  }
  await retireBuildSandbox(ctx, chef, deps, { runId: args.runId });
  return { sandboxId };
}

// ---------------------------------------------------------------- preview

export const DEFAULT_DEPLOY_COMMAND = "/opt/chef/bin/chef-preview-deploy";
export const DEFAULT_RESULT_FILE = "/tmp/chef-preview-result.json";
/** Where the deploy script keeps a scrubbed copy of its output (CHEF_LOG_FILE), read when it fails. */
export const DEFAULT_DEPLOY_LOG_FILE = "/tmp/chef-preview.log";
/** The hosts the Convex CLI needs for a preview deploy (docs, "Hosts the Convex CLI calls"). */
export const CONVEX_DEPLOY_HOSTS = ["api.convex.dev", "*.convex.cloud"];

export type PreviewConfig = BuildConfig & {
  /** git URL of the app's repo on Code Storage, for the one checkout. */
  repoUrl: string;
  deployCommand?: string;
  resultFile?: string;
  /** The deploy script's log (CHEF_LOG_FILE); default DEFAULT_DEPLOY_LOG_FILE. */
  logFile?: string;
  /**
   * Whether the preview gets the frontend the runner built and uploaded
   * (runner/frontend-artifact.ts). Default true; a run without one fails.
   * False for an app with no frontend, matching the runner's config.
   */
  frontend?: boolean;
  /** Where the built frontend's base64 parts go in the deploy sandbox: <prefix>0.b64, ... */
  frontendPrefix?: string;
  /** A function to run on the new preview, as `module:function` (the script's CHEF_SEED). */
  seed?: string;
  /**
   * The app's function that returns `{url}`, a one-time sign-in link for the
   * preview, as `module:function` (for example "previewLogin:issue"; the
   * script's CHEF_LOGIN_LINK_FUNCTION). Run on the preview after the
   * frontend upload. The link must be https on the preview's own
   * `.convex.site`; it goes on the run row (admins only) and into the build
   * email, and never into a log.
   */
  loginLinkFunction?: string;
  /**
   * The demo video (src/client/chefDemo.ts): ask loginLinkFunction for a
   * second link for the demo, and record the agent's demo script on the
   * preview. Default off here; chefCloud turns it on.
   */
  demo?: false | { viewports?: ("phone" | "desktop")[] };
  /**
   * "admin-copy" preview data (src/client/chefPreviewData.ts): the app's
   * previewSeedFunction and its argument (the admin's export's one-time URL
   * and sha256), for the deploy script's CHEF_PREVIEW_SEED_*.
   */
  previewSeed?: { fn: string; args: string };
};

export const DEFAULT_FRONTEND_PREFIX = "/tmp/chef-frontend.";
/** Raw bytes per base64 part: a multiple of 3, so the parts join into one valid string. */
const PART_BYTES = 3 * 1024 * 1024;

/** The deploy sandbox's egress: the CLI's hosts, the npm registry for the install (npm ci, or pnpm fetched by npm exec), and Code Storage for the checkout. */
export function deployEgress(cfg: Pick<BuildConfig, "gitHost">): Egress {
  return { domainAllowList: [...CONVEX_DEPLOY_HOSTS, NPM_REGISTRY, cfg.gitHost] };
}

const SHA40 = /^[0-9a-f]{40}$/;
const PREFIX = /^preview:[^:|\s]+:[^:|\s]+$/;
const SEED = /^[A-Za-z0-9_][A-Za-z0-9_./]*(:[A-Za-z0-9_]+)?$/;
const DEPLOYMENT_NAME = /^[a-z0-9-]{1,64}$/;

/**
 * The run's preview deployment name: its request's, `chef-req-<number>`
 * (src/chef/preview.ts), so a retry or follow-up build of the request
 * replaces its earlier preview instead of taking a new slot on the Convex
 * team. `chef-<sha12>` for a run with no request number.
 */
export { previewNameFor };

/**
 * Why a run gets no web preview, or null: every file it changed is the
 * phone or Mac app's, a test or a doc (src/chef/preview.ts previewSkip). A
 * release merge has its own no-preview path; a run that already has a
 * preview keeps it.
 */
export function previewSkipOf(info: Pick<RunInfo, "filesChanged" | "releaseMerge" | "previewUrl">): PreviewSkip | null {
  if (info.releaseMerge || info.previewUrl) return null;
  return previewSkip(info.filesChanged);
}

/** The preview's link, built from its deployment name: the frontend is on its `.convex.site`. */
export const previewUrlFor = (deploymentName: string) => `https://${deploymentName}.convex.site`;

export type PreviewStatus =
  | { status: "pending" }
  | { status: "ok"; previewName: string; deploymentName: string; loginUrl?: string; demoLoginUrl?: string; adminCopy?: boolean }
  /** `log`: the deploy script's last lines, scrubbed, when it failed and they could be read. */
  | { status: "failed"; reason: string; log?: string[] };

/**
 * The deploy script's result line, `chef-preview-result {...}` without the
 * prefix (runner/chef-preview-deploy.sh writes it to CHEF_RESULT_FILE). Only
 * the deployment name is used, and only if the rest agrees with it; the
 * sandbox ran repo code, so its URLs are not taken as links.
 */
export function parsePreviewResult(raw: string | null, sha: string, itemNumber: number | null = null): PreviewStatus {
  if (raw === null || raw.trim() === "") return { status: "pending" };
  let r: { sha?: unknown; previewName?: unknown; deploymentName?: unknown; convexUrl?: unknown; loginUrl?: unknown; demoLoginUrl?: unknown; adminCopy?: unknown; error?: unknown };
  try {
    r = JSON.parse(raw.trim().replace(/^chef-preview-result /, ""));
  } catch {
    return { status: "failed", reason: "preview result is not JSON" };
  }
  if (!r || typeof r !== "object") return { status: "failed", reason: "preview result is not an object" };
  // The script failed and said why ({"sha","error"}): its `die` message, or
  // what it was doing when something else failed.
  if (typeof r.error === "string") {
    const why = singleLine(r.error, 500);
    return { status: "failed", reason: why || "the deploy script failed" };
  }
  if (r.sha !== sha) return { status: "failed", reason: "preview result is for another commit" };
  // The request's name; or the commit's, from a deploy script baked into
  // a snapshot before previews were per request (it ignores CHEF_PREVIEW_NAME).
  if (!isRunPreviewName(r.previewName, { itemNumber, sha })) return { status: "failed", reason: "preview name is not the request's" };
  if (typeof r.deploymentName !== "string" || !DEPLOYMENT_NAME.test(r.deploymentName)) {
    return { status: "failed", reason: "bad deployment name" };
  }
  if (r.convexUrl !== `https://${r.deploymentName}.convex.cloud`) {
    return { status: "failed", reason: "the URL doesn't match the deployment name" };
  }
  // The sign-in link, only if it is on this preview's own site; otherwise
  // the preview simply has none. Never part of a reason or a log.
  const loginUrl = r.loginUrl === undefined ? null : checkPreviewLoginUrl(r.loginUrl, r.deploymentName);
  const demoLoginUrl = r.demoLoginUrl === undefined ? null : checkPreviewLoginUrl(r.demoLoginUrl, r.deploymentName);
  return {
    status: "ok",
    previewName: r.previewName,
    deploymentName: r.deploymentName,
    ...(loginUrl ? { loginUrl } : {}),
    ...(demoLoginUrl ? { demoLoginUrl } : {}),
    ...(typeof r.adminCopy === "boolean" ? { adminCopy: r.adminCopy } : {}),
  };
}

export type StartedPreview =
  | { reused: true; previewName: string; previewUrl: string; skipped?: undefined }
  | { reused: false; sandboxId: string; executionId: string; sha: string; skipped?: undefined }
  /** The change is nowhere the web preview serves: no preview (previewSkipOf). */
  | { reused: false; skipped: true; note: string };

/** Bytes as base64, without Buffer (the default Convex runtime has btoa). */
function toBase64(bytes: Uint8Array): string {
  let out = "";
  // 3 * 8192 bytes per btoa call: a multiple of 3, so the pieces join cleanly.
  for (let i = 0; i < bytes.length; i += 3 * 8192) {
    const slice = bytes.subarray(i, i + 3 * 8192);
    let bin = "";
    for (let j = 0; j < slice.length; j++) bin += String.fromCharCode(slice[j]);
    out += btoa(bin);
  }
  return out;
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes as BufferSource));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

/**
 * The built frontend into the deploy sandbox: fetched from the component's
 * storage (the URL stays in this action), checked against the sha256 the
 * upload recorded and against the run's commit, and written through the
 * Daytona file API as base64 text parts. The deploy script checks the
 * sha256 again before it unpacks anything.
 */
export async function sendFrontend(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; sandboxId: string; sha: string; prefix: string },
): Promise<{ parts: number; sha256: string }> {
  const art = await ctx.runQuery(chef.feedback.chefArtifact.forRun, { runId: args.runId });
  if (!art) throw new Error("The runner uploaded no built frontend for this run");
  if (art.commitSha !== args.sha) throw new Error("The built frontend is for another commit");
  if (art.size > MAX_ARTIFACT_BYTES) throw new Error("The built frontend is over the size cap");
  const doFetch = deps.fetch ?? ((url: string) => fetch(url));
  const res = await doFetch(art.url);
  if (!res.ok) throw new Error(`Could not fetch the built frontend (${res.status})`);
  const bytes = new Uint8Array(await res.arrayBuffer());
  if (bytes.length !== art.size || (await sha256Hex(bytes)) !== art.sha256) {
    throw new Error("The built frontend doesn't match its recorded sha256");
  }
  let parts = 0;
  for (let i = 0; i < bytes.length; i += PART_BYTES) {
    await deps.sandboxes.writeFile(args.sandboxId, `${args.prefix}${parts}.b64`, toBase64(bytes.subarray(i, i + PART_BYTES)));
    parts++;
  }
  return { parts, sha256: art.sha256 };
}

/**
 * Step 12, started: the build sandbox and its secrets go first (a no-op if
 * they already went), then the deploy sandbox from the same pinned snapshot
 * with one secret mounted, a read-only git secret made for this checkout, and
 * the deploy egress list. Then the built frontend is written into it, and
 * the fixed deploy script starts.
 *
 * The preview deploy key is read from the host's env var here and goes
 * only into the deploy script's own environment (`envs` of that one
 * command): never the sandbox's env, never a mount, never argv, never a
 * row. The deploy sandbox runs no repo code (docs, "What protects the key").
 *
 * A retry reuses what exists: a preview already recorded for this commit
 * skips the sandbox entirely, an adopted sandbox keeps its running script.
 *
 * A change the web preview can't show (previewSkipOf: only the phone or Mac
 * app, tests, docs) gets no preview at all: the build sandbox still goes,
 * the run log says why, and no deploy sandbox or Convex deployment is made
 * (`skipped`). The run then finishes built, like a release merge.
 */
export async function startPreview(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: PreviewConfig; attempt?: number },
): Promise<StartedPreview> {
  // A preview deployed again after a transient failure has effects of its own.
  const suffix = args.attempt && args.attempt > 1 ? `:${args.attempt}` : "";
  const cfg = args.config;
  checkBuildConfig(cfg);
  if (!cfg.repoUrl || /\s/.test(cfg.repoUrl)) throw new Error("repoUrl is required");
  if (cfg.deployCommand !== undefined && !ABS_PATH.test(cfg.deployCommand)) throw new Error("deployCommand must be absolute");
  if (cfg.resultFile !== undefined && !ABS_PATH.test(cfg.resultFile)) throw new Error("resultFile must be absolute");
  if (cfg.logFile !== undefined && !ABS_PATH.test(cfg.logFile)) throw new Error("logFile must be absolute");
  if (cfg.frontendPrefix !== undefined && !ABS_PATH.test(cfg.frontendPrefix)) throw new Error("frontendPrefix must be absolute");
  if (cfg.seed !== undefined && !SEED.test(cfg.seed)) throw new Error("seed must be a function name");
  if (cfg.loginLinkFunction !== undefined && !SEED.test(cfg.loginLinkFunction)) {
    throw new Error("loginLinkFunction must be a function name");
  }
  if (cfg.previewSeed !== undefined && (!SEED.test(cfg.previewSeed.fn) || cfg.previewSeed.args.length > 4096 || !cfg.previewSeed.args.startsWith("{"))) {
    throw new Error("previewSeed must be a function name and a JSON object");
  }

  let info = await activeInfo(ctx, chef, args.runId);
  const sha = info.commitSha;
  if (!sha || !SHA40.test(sha)) throw new Error("The run has no pushed commit to preview");
  if (!["pushed", "previewing"].includes(info.phase)) throw new Error(`Can't preview a run in ${info.phase}`);
  const previewName = previewNameFor({ itemNumber: info.itemNumber, sha });
  if (info.previewName && isRunPreviewName(info.previewName, { itemNumber: info.itemNumber, sha }) && info.previewUrl) {
    return { reused: true, previewName: info.previewName, previewUrl: info.previewUrl };
  }
  const skip = previewSkipOf(info);
  if (skip) return { reused: false, skipped: true, note: await skipPreview(ctx, chef, deps, { runId: args.runId, skip }) };

  // The build sandbox is gone before the deploy sandbox exists.
  await retireBuildSandbox(ctx, chef, deps, { runId: args.runId });
  const left = (await deps.sandboxes.listSandboxes()).filter(
    (s) => s.labels["chef-run"] === args.runId && s.labels["chef-role"] === "build",
  );
  if (left.length) throw new Error("The build sandbox is still there");

  if (info.phase === "pushed") {
    await ctx.runMutation(chef.feedback.chefEffects.setPhase, { runId: args.runId, from: "pushed", to: "previewing" });
    info = await activeInfo(ctx, chef, args.runId);
  }
  const prefix = info.previewKeyPrefix;
  if (!prefix || !PREFIX.test(prefix)) throw new Error("No preview deploy key is set up (setPreviewDeployKey)");
  // Checked before any sandbox exists. Only the prefix is ever compared or shown.
  const deployKey = readPreviewDeployKey(deps);
  if (deployKey.prefix !== prefix) {
    throw new Error(
      `CHEF_PREVIEW_DEPLOY_KEY is for ${deployKey.prefix}, but settings say ${prefix}; run setPreviewDeployKey again`,
    );
  }

  // The one checkout's read token, recorded before it exists.
  const ro = await deployGitSecretName(args.runId);
  const existing = await effectGet(ctx, chef, { runId: args.runId, key: `sandbox:deploy${suffix}` });
  if (existing?.status !== "done") {
    if (!deps.git) throw new Error("No GitAuthApi: can't mint a Code Storage token");
    await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, { runId: args.runId, names: [ro], event: "created" });
    const value = await deps.git.basicAuth({ access: "read", ttlSeconds: cfg.gitTokenTtlSeconds ?? 600 });
    const r = await deps.secrets.createSecret({ name: ro, value, hosts: [cfg.gitHost] });
    if (!r.created) await deps.secrets.setSecret(ro, value);
    await ctx.runMutation(chef.feedback.chefEffects.recordSecrets, { runId: args.runId, names: [ro], event: "live" });
  }

  // The warm snapshot for this commit's lockfile, if one is ready.
  const pick =
    cfg.warm && existing?.status !== "done" ? await pickWarm(ctx, chef, deps, { at: { commit: sha }, settings: cfg.warm }) : null;
  const { result: sbx, warm } = await createWithWarm(ctx, chef, deps, {
    pick,
    base: cfg.snapshot,
    create: (snapshot) =>
      ensureSandbox(ctx, chef, deps.sandboxes, {
        runId: args.runId,
        role: "deploy",
        ...(args.attempt ? { attempt: args.attempt } : {}),
        spec: {
          snapshot,
          secrets: { CHEF_GIT_AUTH: ro },
          ...deployEgress(cfg),
          autoStopInterval: 0,
          autoDeleteInterval: cfg.autoDeleteMinutes ?? 120,
        },
      }),
  });
  if (pick) await recordWarmUse(ctx, chef, { runId: args.runId, role: "deploy", warm, pick });

  const frontendPrefix = cfg.frontendPrefix ?? DEFAULT_FRONTEND_PREFIX;
  let frontendEnvs: Record<string, string> = { CHEF_FRONTEND: "0" };
  const started = await effectGet(ctx, chef, { runId: args.runId, key: `exec:deploy${suffix}` });
  if (cfg.frontend !== false && started?.status !== "done") {
    const fe = await sendFrontend(ctx, chef, deps, { runId: args.runId, sandboxId: sbx.id, sha, prefix: frontendPrefix });
    frontendEnvs = {
      CHEF_FRONTEND: "1",
      CHEF_FRONTEND_PREFIX: frontendPrefix,
      CHEF_FRONTEND_PARTS: String(fe.parts),
      CHEF_FRONTEND_SHA256: fe.sha256,
    };
  }

  let command = `${cfg.deployCommand ?? DEFAULT_DEPLOY_COMMAND} ${sha}`;
  if (cfg.deliver && cfg.deployCommand === undefined) {
    const d = await deployDelivery();
    if (started?.status !== "done") await writeDelivery(deps.sandboxes, sbx.id, d);
    command = deliveredDeployCommand(d, sha);
  }
  const executionId = await startOnce(ctx, chef, deps.sandboxes, {
    runId: args.runId,
    key: `exec:deploy${suffix}`,
    sandboxId: sbx.id,
    command,
    envs: {
      CHEF_PREVIEW_DEPLOY_KEY: deployKey.key,
      // The request's preview: deploying it again replaces it (src/chef/preview.ts).
      CHEF_PREVIEW_NAME: previewName,
      CHEF_REPO_URL: cfg.repoUrl,
      CHEF_RESULT_FILE: cfg.resultFile ?? DEFAULT_RESULT_FILE,
      ...(cfg.logFile !== undefined ? { CHEF_LOG_FILE: cfg.logFile } : {}),
      ...frontendEnvs,
      ...(cfg.seed !== undefined ? { CHEF_SEED: cfg.seed } : {}),
      ...(cfg.loginLinkFunction !== undefined ? { CHEF_LOGIN_LINK_FUNCTION: cfg.loginLinkFunction } : {}),
      ...(cfg.loginLinkFunction !== undefined && cfg.demo ? { CHEF_DEMO_LOGIN: "1" } : {}),
      // The admin's export's one-time URL travels only in this command's env.
      ...(cfg.previewSeed ? { CHEF_PREVIEW_SEED_FUNCTION: cfg.previewSeed.fn, CHEF_PREVIEW_SEED_ARGS: cfg.previewSeed.args } : {}),
    },
  });
  return { reused: false, sandboxId: sbx.id, executionId, sha };
}

/**
 * No preview for this run: its change is nowhere the web preview serves.
 * The build sandbox goes (as before a deploy), and the run log says why.
 * Safe to repeat. Returns the note for people.
 */
export async function skipPreview(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; skip: PreviewSkip },
): Promise<string> {
  await retireBuildSandbox(ctx, chef, deps, { runId: args.runId });
  try {
    await ctx.runMutation(chef.feedback.chefEffects.appendRunLog, {
      runId: args.runId,
      lines: [`chef-launcher: no preview: ${args.skip.note}`],
    });
  } catch {
    // The log is best effort; the card and the email say it too.
  }
  return args.skip.note;
}

/**
 * Poll the deploy script: its result file, or the script having exited
 * without one. A failure carries the script's own reason (its result's
 * error, else its last "error:" line, else what its output says last) and
 * its last lines, scrubbed, for the run log (`previewFailed`).
 */
export async function previewStatus(
  sandboxes: SandboxApi,
  args: {
    sandboxId: string;
    executionId: string;
    sha: string;
    /** The run's request number, for its preview's name (src/chef/preview.ts); null for none. */
    itemNumber?: number | null;
    config: Pick<PreviewConfig, "resultFile" | "logFile">;
    /** Values to scrub from the script's output besides the patterns: the deploy key's. */
    known?: string[];
  },
): Promise<PreviewStatus> {
  const raw = await sandboxes.readFile(args.sandboxId, args.config.resultFile ?? DEFAULT_RESULT_FILE);
  let r = parsePreviewResult(raw, args.sha, args.itemNumber ?? null);
  if (r.status === "pending") {
    const e = await sandboxes.execution(args.executionId);
    if (!e || e.status === "running") return { status: "pending" };
    // It may have written the file just before exiting.
    r = parsePreviewResult(await sandboxes.readFile(args.sandboxId, args.config.resultFile ?? DEFAULT_RESULT_FILE), args.sha, args.itemNumber ?? null);
    if (r.status === "pending") {
      r = { status: "failed", reason: `the deploy script exited (${e.status}${e.exitCode !== undefined ? `, code ${e.exitCode}` : ""}) without a result` };
    }
  }
  if (r.status !== "failed") return r;
  const out = await deployScriptOutput(sandboxes, {
    sandboxId: args.sandboxId,
    executionId: args.executionId,
    logFile: args.config.logFile ?? DEFAULT_DEPLOY_LOG_FILE,
    script: "chef-preview-deploy",
    ...(args.known ? { known: args.known } : {}),
  });
  let reason = r.reason;
  if (/without a result$/.test(reason) && out.errorLine) reason = out.errorLine;
  if (/^the deploy script (failed|exited)/.test(reason)) {
    const cause = likelyCause(out.tail, "chef-preview-deploy");
    if (cause) reason = `${reason}: ${cause}`;
  }
  return { status: "failed", reason, ...(out.tail.length ? { log: out.tail } : {}) };
}

/** The deploy key's parts, to scrub from the script's output; [] if it can't be read here. */
export function previewKnownValues(deps: Pick<EffectsDeps, "previewDeployKey">): string[] {
  try {
    const { key } = readPreviewDeployKey(deps);
    return [key, key.slice(key.indexOf("|") + 1)];
  } catch {
    return [];
  }
}

/**
 * A failed preview deploy: the script's last lines into the run's log
 * (chefRunLogs, after the runner's), best effort, and the error that fails
 * the run with the script's reason (classified in src/chef/failures.ts).
 */
export async function previewFailed(
  ctx: RunCtx,
  chef: Chef,
  args: { runId: string; status: { reason: string; log?: string[] } },
): Promise<Error> {
  const lines = [
    `chef-launcher: the preview deploy failed: ${args.status.reason}`,
    ...(args.status.log?.length
      ? ["chef-launcher: the deploy script's last lines:", ...args.status.log.map((l) => `deploy: ${l}`)]
      : ["chef-launcher: the deploy script left no output to read"]),
  ];
  try {
    await ctx.runMutation(chef.feedback.chefEffects.appendRunLog, { runId: args.runId, lines });
  } catch {
    // The reason still reaches the run's failure below.
  }
  return new Error(`Preview deploy failed: ${args.status.reason}`);
}

/**
 * A preview deploy that failed for the platform's reasons (the script died
 * without a result, the provider: src/chef/recovery.ts, transient) is
 * deployed again, at most PREVIEW_REDEPLOYS more times: the failed one's
 * sandbox and secret go, its last lines go into the run log, and the
 * caller starts the next attempt. False for anything else, which fails the
 * run as before.
 */
export async function previewRedeploy(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; status: { reason: string; log?: string[] }; attempt: number },
): Promise<boolean> {
  const failure = classifyFailure(`Preview deploy failed: ${args.status.reason}`);
  const d = recover(failure, { source: "preview", errorText: args.status.reason, attempt: args.attempt });
  if (d.action !== "retry" || args.attempt > PREVIEW_REDEPLOYS) return false;
  try {
    await ctx.runMutation(chef.feedback.chefEffects.appendRunLog, {
      runId: args.runId,
      lines: [
        `chef-launcher: the preview deploy failed (${args.status.reason}); deploying it again (attempt ${args.attempt + 1})`,
        ...(args.status.log ?? []).slice(-20).map((l) => `deploy: ${l}`),
      ],
    });
  } catch {
    // The log is best effort.
  }
  await retireDeploySandbox(ctx, chef, deps, { runId: args.runId });
  return true;
}

/** Delete the deploy sandbox and its read-only git secret. Safe to repeat. */
export async function retireDeploySandbox(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string },
): Promise<void> {
  const ro = await deployGitSecretName(args.runId);
  if ((await deps.secrets.listSecrets()).some((s) => s.name === ro)) {
    await killRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names: [ro] });
  }
  await deleteRoleSandboxes(deps.sandboxes, args.runId, "deploy");
  await deleteRunSecrets(ctx, chef, deps.secrets, { runId: args.runId, names: [ro] });
}

/**
 * Step 12, done: record the preview with the link built here from the
 * deployment name, then delete the deploy sandbox and its git secret.
 */
export async function completePreview(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; sha: string; previewName: string; deploymentName: string; loginUrl?: string; demoLoginUrl?: string },
): Promise<{ previewName: string; previewUrl: string }> {
  const rec = (await ctx.runMutation(chef.feedback.chefEffects.recordPreview, {
    runId: args.runId,
    sha: args.sha,
    previewName: args.previewName,
    deploymentName: args.deploymentName,
    ...(args.loginUrl !== undefined ? { loginUrl: args.loginUrl } : {}),
    ...(args.demoLoginUrl !== undefined ? { demoLoginUrl: args.demoLoginUrl } : {}),
  })) as { previewName: string; previewUrl: string };
  if (rec.previewUrl !== previewUrlFor(args.deploymentName)) throw new Error("Preview URL mismatch");
  await retireDeploySandbox(ctx, chef, deps, { runId: args.runId });
  return rec;
}

/**
 * The run's screenshots for the build email: storage URLs from the
 * component, never from a sandbox. None if they can't be read; the email
 * still goes.
 */
async function screenshotLinks(
  ctx: RunCtx,
  chef: Chef,
  runId: string,
): Promise<{ name: string; url: string | null; width: number; height: number }[]> {
  try {
    const rows = (await ctx.runQuery(chef.feedback.chefScreenshots.runScreenshotsForHost, { runId })) as {
      name: string;
      url: string | null;
      width: number;
      height: number;
    }[];
    return rows.map((r) => ({ name: r.name, url: r.url, width: r.width, height: r.height }));
  } catch {
    return [];
  }
}

/**
 * Step 13: the "built" email, with the preview link and the commit the
 * workflow knows, through the EmailApi with idempotency key
 * `chef-<runId>-built`; then the run moves to `done` and finishes built.
 * A run whose change the web preview can't show (previewSkipOf) has no
 * preview: its email says why instead.
 */
export async function finishBuilt(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: { notify?: NotifyConfig } },
): Promise<{ finished: boolean; emailId: string | null }> {
  const info = await activeInfo(ctx, chef, args.runId);
  const skip = previewSkipOf(info);
  if (!info.commitSha || (!info.previewUrl && !skip)) throw new Error("No recorded preview to announce");
  let emailId: string | null = null;
  const n = args.config.notify;
  if (n && deps.email && info.itemNumber !== null) {
    const mail = buildBuildEmail({
      kind: "built",
      appName: n.appName,
      itemNumber: info.itemNumber,
      title: info.title,
      commitSha: info.commitSha,
      ...(info.previewUrl ? { previewUrl: info.previewUrl } : {}),
      ...(info.previewUrl && info.previewLoginUrl ? { previewLoginUrl: info.previewLoginUrl } : {}),
      ...(skip ? { note: skip.note } : {}),
      filesChanged: info.filesChanged,
      screenshots: await screenshotLinks(ctx, chef, args.runId),
      runPageUrl: n.runPageUrl(args.runId),
      ...(n.allowedLinkHosts ? { allowedLinkHosts: n.allowedLinkHosts } : {}),
    });
    emailId = (await sendRunEmail(ctx, chef, deps.email, { runId: args.runId, kind: "built", to: n.to, ...mail })).id;
  }
  if (info.phase === "previewing") {
    await ctx.runMutation(chef.feedback.chefEffects.setPhase, { runId: args.runId, from: "previewing", to: "done" });
  }
  const { finished } = (await ctx.runMutation(chef.feedback.chefEffects.finishActive, {
    runId: args.runId,
    outcome: "built",
  })) as { finished: boolean };
  return { finished, emailId };
}

/** Step 12 in one go: start (or reuse), poll, record, clean up. */
export async function drivePreview(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: PreviewConfig; wait: Waiter },
): Promise<{ previewName: string; previewUrl: string; reused: boolean } | { previewName: null; previewUrl: null; reused: false; skipped: true }> {
  let attempt = 1;
  let started = await startPreview(ctx, chef, deps, args);
  if (started.skipped) return { previewName: null, previewUrl: null, reused: false, skipped: true };
  if (started.reused) {
    await retireDeploySandbox(ctx, chef, deps, { runId: args.runId });
    return { previewName: started.previewName, previewUrl: started.previewUrl, reused: true };
  }
  const now = args.wait.now ?? Date.now;
  const { deadline, itemNumber } = await getRunInfo(ctx, chef, args.runId);
  const known = previewKnownValues(deps);
  for (;;) {
    const st = await previewStatus(deps.sandboxes, { ...started, itemNumber, config: args.config, known });
    if (st.status === "failed" && (await previewRedeploy(ctx, chef, deps, { runId: args.runId, status: st, attempt }))) {
      attempt++;
      const again = await startPreview(ctx, chef, deps, { ...args, attempt });
      if (again.skipped) return { previewName: null, previewUrl: null, reused: false, skipped: true };
      if (again.reused) return { previewName: again.previewName, previewUrl: again.previewUrl, reused: true };
      started = again;
      continue;
    }
    if (st.status === "ok") {
      const rec = await completePreview(ctx, chef, deps, {
        runId: args.runId,
        sha: started.sha,
        previewName: st.previewName,
        deploymentName: st.deploymentName,
        ...(st.loginUrl !== undefined ? { loginUrl: st.loginUrl } : {}),
        ...(st.demoLoginUrl !== undefined ? { demoLoginUrl: st.demoLoginUrl } : {}),
      });
      return { ...rec, reused: false };
    }
    if (st.status === "failed") throw await previewFailed(ctx, chef, { runId: args.runId, status: st });
    if (now() > deadline) throw new Error("The run passed its deadline");
    await activeInfo(ctx, chef, args.runId);
    await ctx.runMutation(chef.feedback.chefEffects.orchestratorHeartbeat, { runId: args.runId });
    await args.wait.sleep(args.wait.pollMs ?? 5000);
  }
}

/**
 * The whole run after the claim: build, preview, email, finish. Any failure
 * goes through `failRun`. A run stopped under it (cancelled, stale, revoked)
 * is left to the reconciler.
 */
export async function driveRun(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: PreviewConfig; wait: Waiter },
): Promise<{ outcome: "built" | "failed" | "stopped"; previewUrl?: string; error?: string }> {
  try {
    const info = await activeInfo(ctx, chef, args.runId);
    if (!DONE_BUILDING.has(info.phase)) await driveBuild(ctx, chef, deps, args);
    const p = await drivePreview(ctx, chef, deps, args);
    await finishBuilt(ctx, chef, deps, args);
    return { outcome: "built", ...(p.previewUrl ? { previewUrl: p.previewUrl } : {}) };
  } catch (e) {
    if (e instanceof RunNotActive) return { outcome: "stopped" };
    const error = e instanceof Error ? e.message : String(e);
    const { finished } = await failRun(ctx, chef, deps, { runId: args.runId, config: args.config, error });
    return { outcome: finished ? "failed" : "stopped", error };
  }
}
