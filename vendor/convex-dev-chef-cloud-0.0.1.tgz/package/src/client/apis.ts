import type { ComponentApi as FeedbackComponentApi } from "@convex-dev/feedback/_generated/component.js";
import type { ComponentApi as CloudComponentApi } from "../component/_generated/component.js";

export type { FeedbackComponentApi, CloudComponentApi };

/**
 * The two components chef-cloud's host-side code works with, as the host
 * installed them: `{ feedback: components.feedback, cloud: components.chefCloud }`.
 * The feedback component has the runs, releases, settings and the audit log;
 * chef-cloud has the effect ledger, the repo and the workflows. Neither
 * calls the other: this code, in the host's functions, calls both.
 */
export type ChefApis = { feedback: FeedbackComponentApi; cloud: CloudComponentApi };
