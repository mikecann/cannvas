/**
 * "Ship it": the cloud release (docs/chef-pipeline.md, "Ship it: a cloud
 * release"). Host-side, like the launcher (src/client/chefLauncher.ts): these
 * run in the host's actions over the same `SandboxApi`, `SecretsApi`,
 * `RefsApi`, `GitAuthApi` and `EmailApi`.
 *
 * An admin pressed "Ship to live" in the panel with the hash of the diff
 * `main..chef` they read (chefShip.approve in the component). That opened a
 * `cloud` release, approved, and scheduled the host's shipper, which calls
 * `driveShip`:
 *
 *   startShip     main checked (still the diff's base; if it moved, Chef
 *                 merges it into the release and the ship waits:
 *                 followMain), the host's deploy key checked
 *                 against this deployment; a deploy sandbox with the same
 *                 egress and the same no-repo-code rule as the preview's,
 *                 the kept frontend written into it, and the fixed ship
 *                 script started with the key in that one command's env
 *   shipStatus    poll the script's result file
 *   recordDeploy  each target as the state machine records it: the backend,
 *                 then the static hosting upload (Convex deploy and the
 *                 upload aren't one atomic step)
 *   verifyShip    a GET of the live site, and the health check's answer
 *   goLive        `main` fast-forwarded to chef's commit (compare-and-swap
 *                 from the diff's base, never a force), only after that;
 *                 then mirrored to GitHub when the host has a mirror
 *                 (mirrorMain, best effort)
 *   finishShip    the release done (requests completed, requesters
 *                 notified), the owner's email
 *   cleanupShip   the sandbox and its git secret gone, either way
 *
 * A failure before the backend deploy abandons the release: nothing reached
 * production and `main` is where it was. After it, the release stays open
 * with the error, `main` unmoved, each target as recorded; "Ship to live"
 * again resumes it, and `chef-release rollback` can roll it back.
 */
import { classifyFailure } from "@convex-dev/feedback/chef/failures.js";
import { checkPreviewLoginUrl } from "@convex-dev/feedback/chef/previewLogin.js";
import { recover } from "@convex-dev/feedback/chef/recovery.js";
import type { ChefApis } from "./apis.js";
import {
  RELEASE_LABEL,
  ROLE_LABEL,
  assertEgress,
  deployScriptOutput,
  likelyCause,
  readGithubMirror,
  readHostDeployKey,
  run8,
  type MirrorOutcome,
  type EffectsDeps,
  type RunCtx,
  type SandboxApi,
} from "./chefEffects.js";
import { CONVEX_DEPLOY_HOSTS, DEFAULT_FRONTEND_PREFIX, NPM_REGISTRY, sendFrontend, type Waiter } from "./chefLauncher.js";
import { buildLiveEmail, buildShipEmail } from "../shared/email.js";
import { deliveredScriptCommand, shipDelivery, writeDelivery } from "@convex-dev/feedback/delivery";
import { createWithWarm, pickWarm, recordWarmUse, type WarmSettings } from "./chefWarm.js";

type Chef = ChefApis;

export const DEFAULT_SHIP_COMMAND = "/opt/chef/bin/chef-ship-deploy";
export const DEFAULT_SHIP_RESULT_FILE = "/tmp/chef-ship-result.json";
/** Where the ship script keeps a scrubbed copy of its output (CHEF_LOG_FILE), read when it fails. */
export const DEFAULT_SHIP_LOG_FILE = "/tmp/chef-ship.log";
export const SHIP_ROLE = "ship";
const DEFAULT_OPERATOR = "chef-ship";

export type ShipConfig = {
  /** The Code Storage git host. */
  gitHost: string;
  /** git URL of the app's repo on Code Storage, for the one checkout. */
  repoUrl: string;
  /** The pinned `chef-runner` Daytona snapshot (it carries the ship script). */
  snapshot: string;
  shipCommand?: string;
  /**
   * Deliver the ship script and its helpers into the sandbox (as the
   * launcher's `deliver` does for the runner): for a base image with no
   * Chef code, such as `shared:chef-base-1`. Ignored with `shipCommand`.
   */
  deliver?: boolean;
  resultFile?: string;
  /** The ship script's log (CHEF_LOG_FILE); default DEFAULT_SHIP_LOG_FILE. */
  logFile?: string;
  /**
   * Whether the release has a frontend: the one the runner built and Chef
   * kept (default true; a release without one is refused). False for an app
   * with no frontend.
   */
  frontend?: boolean;
  frontendPrefix?: string;
  /** A function to run once the backend is deployed, as `module:function` (a post-deploy migration). */
  migration?: string;
  /** A function that throws unless the live app is healthy, as `module:function`; run after the upload. */
  healthCheck?: string;
  /**
   * The live site, fetched to verify the ship. Default
   * `https://<deployment>.convex.site`, where static hosting serves.
   */
  siteUrl?: string;
  /** Daytona deletes the sandbox on its own after this many minutes (default 60). */
  autoDeleteMinutes?: number;
  /** Life of the checkout's Code Storage read token (default 600 seconds). */
  gitTokenTtlSeconds?: number;
  /** How long the ship script may take (default 30 minutes). */
  timeoutMs?: number;
  /** The name in the audit log (default "chef-ship"). */
  operator?: string;
  /**
   * Roll back on its own when a ship reaches production and then fails its
   * checks: the release before it, redeployed, main left where it was.
   * Default true.
   */
  autoRollback?: boolean;
  /** Warm snapshots (src/client/chefWarm.ts), as for the build and the preview. Absent: off. */
  warm?: WarmSettings;
  notify?: {
    to: string;
    appName: string;
    panelUrl?: string;
    /** Where the requesters' "it's live" emails link. Default: the live site. */
    appUrl?: string;
    allowedLinkHosts?: (string | RegExp)[];
    /** A requester's address (chefCloud's notify.requesterEmail), or null: no email for them. */
    requesterEmail?: (userId: string) => Promise<string | null>;
  };
};

const HOST = /^[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)+$/;
const ABS_PATH = /^\/[A-Za-z0-9_./-]+$/;
const FN = /^[A-Za-z0-9_][A-Za-z0-9_./]*(:[A-Za-z0-9_]+)?$/;
const SHA40 = /^[0-9a-f]{40}$/;
const SHA256 = /^[0-9a-f]{64}$/;
const DEPLOYMENT_NAME = /^[a-z0-9][a-z0-9-]{0,63}$/;

export function checkShipConfig(cfg: ShipConfig): void {
  if (!HOST.test(cfg.gitHost ?? "")) throw new Error("gitHost must be a host name");
  if (!cfg.repoUrl || /\s/.test(cfg.repoUrl)) throw new Error("repoUrl is required");
  if (!cfg.snapshot) throw new Error("snapshot is required");
  for (const p of [cfg.shipCommand, cfg.resultFile, cfg.frontendPrefix, cfg.logFile]) {
    if (p !== undefined && !ABS_PATH.test(p)) throw new Error("ship paths must be absolute");
  }
  if (cfg.migration !== undefined && !FN.test(cfg.migration)) throw new Error("migration must be a function name");
  if (cfg.healthCheck !== undefined && !FN.test(cfg.healthCheck)) throw new Error("healthCheck must be a function name");
  if (cfg.siteUrl !== undefined) {
    const u = new URL(cfg.siteUrl);
    if (u.protocol !== "https:" || u.username || u.password) throw new Error("siteUrl must be https, with no credentials");
  }
}

/** The ship sandbox's egress: the preview deploy's list. */
export function shipEgress(cfg: Pick<ShipConfig, "gitHost">) {
  return { domainAllowList: [...CONVEX_DEPLOY_HOSTS, NPM_REGISTRY, cfg.gitHost] };
}

/** The checkout's read-only git secret: named for the release. */
export async function shipGitSecretName(releaseId: string): Promise<string> {
  return `chef-git-ship-${await run8(releaseId)}-ro`;
}

export type ShipInfo = {
  releaseId: string;
  seq: number;
  kind: string;
  state: string;
  open: boolean;
  sha: string;
  baseSha: string;
  approvedDiffHash: string | null;
  artifactDigest: string | null;
  shipRunId: string | null;
  sandboxId: string | null;
  executionId: string | null;
  sandboxIntent: boolean;
  mainSha: string | null;
  deployKeyPrefix: string | null;
  /** itemId and createdBy are missing from an older feedback component: no requester emails then. */
  requests: { number: number | null; title: string; itemId?: string; createdBy?: string; removed?: boolean }[];
  /** How many ship attempts started. */
  attempts: number;
  /** The idempotency keys of the emails already sent for this release. */
  emailKeys: string[];
  /** A rollback (Chef's automatic one): the release it rolls back, and the one it restores. */
  rollbackOf?: number | null;
  restores?: number | null;
  /** An earlier commit of this release reached production before main moved (contract 13). */
  deployedSha?: string | null;
  /** The release follows main: Chef is merging, or a person decides; nothing to ship now. */
  following?: boolean;
};

/** Thrown for a ship that must not go on: nothing has reached production, and the release is abandoned. */
export class ShipRefused extends Error {
  constructor(message: string) {
    super(message);
    this.name = "ShipRefused";
  }
}

const ORDER = ["pinned", "diffReady", "approved", "backendDeployed", "frontendPublished", "verified", "live", "done"];
const reached = (state: string, than: string) => ORDER.indexOf(state) >= ORDER.indexOf(than);

export async function shipInfo(ctx: RunCtx, chef: Chef, releaseId: string): Promise<ShipInfo> {
  const info = (await ctx.runQuery(chef.feedback.chefShip.info, { releaseId })) as ShipInfo | null;
  if (!info) throw new Error("Release not found");
  // A cloud ship, or the rollback Chef drives after one failed its checks.
  if (info.kind !== "cloud" && !(info.kind === "rollback" && info.shipRunId)) throw new Error(`Release #${info.seq} is not a cloud ship`);
  return info;
}

const operatorOf = (cfg: ShipConfig) => cfg.operator ?? DEFAULT_OPERATOR;

async function record(
  ctx: RunCtx,
  chef: Chef,
  cfg: ShipConfig,
  releaseId: string,
  event:
    | "attempt"
    | "sandboxIntent"
    | "sandbox"
    | "secret"
    | "exec"
    | "deployment"
    | "error"
    | "cleanup"
    | "email"
    | "emailFailed"
    | "mirror",
  extra: Record<string, string | boolean> = {},
) {
  await ctx.runMutation(chef.feedback.chefShip.record, { operator: operatorOf(cfg), releaseId, event, ...extra });
}

async function step(
  ctx: RunCtx,
  chef: Chef,
  cfg: ShipConfig,
  releaseId: string,
  to: "backendDeployed" | "frontendPublished" | "verified" | "live" | "done",
  facts: { mergeSha?: string; checks?: { name: string; ok: boolean }[]; mainSha?: string } = {},
) {
  const base = { operator: operatorOf(cfg), releaseId, to };
  await ctx.runMutation(chef.feedback.chefReleases.step, { ...base, phase: "begin" });
  await ctx.runMutation(chef.feedback.chefReleases.step, { ...base, phase: "complete", ...facts });
}

// ---------------------------------------------------------------- start

export type StartedShip = { sandboxId: string; executionId: string; deploymentName: string };
/** Main moved under the release: Chef merges it in (followMain) and the ship waits; nothing was created. */
export type FollowingShip = { following: true; reason: string };

/** Whether a release has code in production: a deploy step recorded, or an earlier commit deployed before it followed main. */
export function reachedProduction(info: Pick<ShipInfo, "state" | "deployedSha">): boolean {
  return reached(info.state, "backendDeployed") || !!info.deployedSha;
}

/**
 * Main moved under an open release: the feedback component's followMain
 * merges it into the release (docs/chef-pipeline.md, "When main moves under
 * Ship it"). The release stays open on its approval; the ship stops here and
 * starts again when the merge is in (or a person decides).
 */
async function followMain(ctx: RunCtx, chef: Chef, cfg: ShipConfig, info: ShipInfo, mainSha: string): Promise<FollowingShip> {
  const r = await ctx.runMutation(chef.feedback.chefShip.followMain, { operator: operatorOf(cfg), releaseId: info.releaseId, mainSha });
  return {
    following: true,
    reason: r.following
      ? `main moved (it was ${info.baseSha.slice(0, 12)}, now ${mainSha.slice(0, 12)}): Chef is merging it into release #${info.seq}; it ships on the same approval if the change is the same`
      : `main moved (now ${mainSha.slice(0, 12)}), and release #${info.seq} waits for a person: ${r.reason ?? "refused"}`,
  };
}

/**
 * Start (or adopt) the ship script. Before anything is created: a main that
 * moved since the release's commit was made is merged in first (the ship
 * waits, `following`; until the backend is deployed, after which the same
 * commit is deployed again and goLive follows main); refused: a deploy key
 * that isn't for this deployment or doesn't match settings, and a missing or
 * mismatched frontend. Chef's own tip doesn't matter: the approval fixed
 * what ships, and newer builds there wait for their own.
 */
export async function startShip(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig },
): Promise<StartedShip | FollowingShip> {
  const cfg = args.config;
  checkShipConfig(cfg);
  const info = await shipInfo(ctx, chef, args.releaseId);
  if (info.following) return { following: true, reason: `release #${info.seq} is following main` };
  const rollback = info.kind === "rollback";
  if (!info.open) throw new ShipRefused(`Release #${info.seq} is ${info.state}`);
  // A rollback is approved by the failed ship it undoes: it starts pinned.
  if (!rollback && !reached(info.state, "approved")) throw new ShipRefused(`Release #${info.seq} isn't approved`);
  if (!SHA40.test(info.sha) || !SHA40.test(info.baseSha)) throw new ShipRefused("The release has no commit");

  // A rollback redeploys the release before, whatever main says.
  const main = rollback ? info.baseSha : (await deps.refs.readRefs(["main"])).main;
  const deployed = reached(info.state, "backendDeployed");
  if (main !== info.baseSha && main !== info.sha) {
    if (!main || !SHA40.test(main)) throw new ShipRefused(`main is gone (it was ${info.baseSha.slice(0, 12)})`);
    // Main moved since the release's commit (a hotfix, another ship, `chef
    // sync`): nothing more reaches production until it is merged in. After
    // the backend deploy the same commit goes on, and goLive follows main.
    if (!deployed) return await followMain(ctx, chef, cfg, info, main);
  }

  // Checked before any sandbox exists. Only the prefix is ever compared or shown.
  const deployKey = readHostDeployKey(deps);
  if (!info.deployKeyPrefix) throw new ShipRefused("No deploy key is set up (setDeployKey)");
  if (deployKey.prefix !== info.deployKeyPrefix) {
    throw new ShipRefused(`CHEF_DEPLOY_KEY is for ${deployKey.prefix}, but settings say ${info.deployKeyPrefix}; run setDeployKey again`);
  }
  if (cfg.frontend !== false && (!info.artifactDigest || !SHA256.test(info.artifactDigest) || !info.shipRunId)) {
    throw new ShipRefused("This build kept no frontend to publish");
  }
  const siteUrl = cfg.siteUrl ?? `https://${deployKey.deploymentName}.convex.site`;
  await record(ctx, chef, cfg, args.releaseId, "attempt");
  await record(ctx, chef, cfg, args.releaseId, "deployment", { deploymentName: deployKey.deploymentName, siteUrl });

  // The one checkout's read token, under a name recorded before it exists.
  const secretName = await shipGitSecretName(args.releaseId);
  if (!info.executionId) {
    if (!deps.git) throw new Error("No GitAuthApi: can't mint a Code Storage token");
    await record(ctx, chef, cfg, args.releaseId, "secret", { secretName });
    const value = await deps.git.basicAuth({ access: "read", ttlSeconds: cfg.gitTokenTtlSeconds ?? 600 });
    const r = await deps.secrets.createSecret({ name: secretName, value, hosts: [cfg.gitHost] });
    if (!r.created) await deps.secrets.setSecret(secretName, value);
  }

  // The warm snapshot for the release's lockfile, if one is ready.
  const pick = cfg.warm && !info.sandboxId ? await pickWarm(ctx, chef, deps, { at: { commit: info.sha }, settings: cfg.warm }) : null;
  const { result: sandboxId, warm } = await createWithWarm(ctx, chef, deps, {
    pick,
    base: cfg.snapshot,
    create: (snapshot) =>
      ensureShipSandbox(ctx, chef, deps.sandboxes, {
        releaseId: args.releaseId,
        cfg,
        snapshot,
        secretName,
        recorded: info.sandboxId,
      }),
  });
  if (pick) await recordWarmUse(ctx, chef, { releaseId: args.releaseId, role: "ship", warm, pick });

  const delivery = cfg.deliver && cfg.shipCommand === undefined ? await shipDelivery() : null;
  const command = delivery
    ? deliveredScriptCommand(delivery, "chef-ship-deploy.sh", info.sha)
    : `${cfg.shipCommand ?? DEFAULT_SHIP_COMMAND} ${info.sha}`;
  if (info.executionId && (await deps.sandboxes.execution(info.executionId))) {
    return { sandboxId, executionId: info.executionId, deploymentName: deployKey.deploymentName };
  }
  const found = (await deps.sandboxes.listExecutions(sandboxId)).find((e) => e.command === command);
  if (found) {
    await record(ctx, chef, cfg, args.releaseId, "exec", { executionId: found.executionId, adopted: true });
    return { sandboxId, executionId: found.executionId, deploymentName: deployKey.deploymentName };
  }

  let frontendEnvs: Record<string, string> = { CHEF_FRONTEND: "0" };
  if (cfg.frontend !== false) {
    const prefix = cfg.frontendPrefix ?? DEFAULT_FRONTEND_PREFIX;
    const fe = await sendFrontend(ctx, chef, deps, { runId: info.shipRunId!, sandboxId, sha: info.sha, prefix });
    if (fe.sha256 !== info.artifactDigest) throw new ShipRefused("The kept frontend isn't the release's artifact");
    frontendEnvs = {
      CHEF_FRONTEND: "1",
      CHEF_FRONTEND_PREFIX: prefix,
      CHEF_FRONTEND_PARTS: String(fe.parts),
      CHEF_FRONTEND_SHA256: fe.sha256,
    };
  }
  // The ship script this package carries, written in and checked by the
  // command before it runs.
  if (delivery) await writeDelivery(deps.sandboxes, sandboxId, delivery);
  // The key goes only into this one command's environment: never the
  // sandbox's env, a mount, argv or a row. The script runs no repo code.
  const { executionId } = await deps.sandboxes.startCommand(sandboxId, {
    command,
    envs: {
      CHEF_DEPLOY_KEY: deployKey.key,
      CHEF_DEPLOYMENT_NAME: deployKey.deploymentName,
      // A rollback's commit is older than main: it only has to be itself.
      CHEF_MAIN_SHA: rollback ? info.sha : info.baseSha,
      CHEF_REPO_URL: cfg.repoUrl,
      CHEF_RESULT_FILE: cfg.resultFile ?? DEFAULT_SHIP_RESULT_FILE,
      ...(cfg.logFile !== undefined ? { CHEF_LOG_FILE: cfg.logFile } : {}),
      ...frontendEnvs,
      ...(cfg.migration !== undefined ? { CHEF_MIGRATION: cfg.migration } : {}),
      ...(cfg.healthCheck !== undefined ? { CHEF_HEALTH_CHECK: cfg.healthCheck } : {}),
    },
  });
  await record(ctx, chef, cfg, args.releaseId, "exec", { executionId });
  return { sandboxId, executionId, deploymentName: deployKey.deploymentName };
}

/** Create the ship sandbox, or adopt the one labelled for this release. The intent is recorded first. */
async function ensureShipSandbox(
  ctx: RunCtx,
  chef: Chef,
  sandboxes: SandboxApi,
  args: { releaseId: string; cfg: ShipConfig; snapshot: string; secretName: string; recorded: string | null },
): Promise<string> {
  const egress = shipEgress(args.cfg);
  assertEgress(egress);
  const mine = (await sandboxes.listSandboxes()).filter(
    (s) => s.labels[RELEASE_LABEL] === args.releaseId && s.labels[ROLE_LABEL] === SHIP_ROLE,
  );
  if (mine.length > 0) {
    const keep = mine.find((s) => s.id === args.recorded) ?? mine[0];
    for (const s of mine) if (s.id !== keep.id) await sandboxes.deleteSandbox(s.id);
    if (keep.id !== args.recorded) {
      await record(ctx, chef, args.cfg, args.releaseId, "sandbox", { sandboxId: keep.id, adopted: true });
    }
    return keep.id;
  }
  await record(ctx, chef, args.cfg, args.releaseId, "sandboxIntent");
  const created = await sandboxes.createSandbox({
    snapshot: args.snapshot,
    secrets: { CHEF_GIT_AUTH: args.secretName },
    ...egress,
    autoStopInterval: 0,
    autoDeleteInterval: args.cfg.autoDeleteMinutes ?? 60,
    labels: { [RELEASE_LABEL]: args.releaseId, [ROLE_LABEL]: SHIP_ROLE },
  });
  await record(ctx, chef, args.cfg, args.releaseId, "sandbox", { sandboxId: created.id });
  return created.id;
}

// ---------------------------------------------------------------- status

/** What the ship script reports (runner/chef-ship-deploy.sh writes it after each step). */
export type ShipResult = {
  sha: string;
  deploymentName: string;
  /** The checkout's commit descends from main (the diff's base). */
  mainIsAncestor: boolean;
  backend: boolean;
  migration: "ok" | "skipped";
  /** The functions of the release's own post-deploy steps (chef-post-deploy.json) that finished, in order. */
  postDeploy: string[];
  /** The beta channel's one-time copy of the admin's data (CHEF_SEED_FUNCTION). */
  seed: "ok" | "failed" | "skipped";
  frontend: "ok" | "skipped" | "pending";
  frontendSha256: string | null;
  healthCheck: "ok" | "failed" | "skipped" | "pending";
  /** The beta channel's demo sign-in link (CHEF_DEMO_LOGIN_FUNCTION), on exactly this deployment's site. */
  demoLoginUrl: string | null;
  done: boolean;
  error: string | null;
};

export type ShipStatus =
  | { status: "pending"; result: ShipResult | null }
  | { status: "ok"; result: ShipResult }
  /** `log`: the ship script's last lines, scrubbed, when they could be read. */
  | { status: "failed"; reason: string; result: ShipResult | null; log?: string[] };

/**
 * The script's result file. Only the facts listed in ShipResult are read,
 * and only if they agree with the release: the same commit, the expected
 * deployment. `error` is the script's own text, untrusted.
 */
export function parseShipResult(raw: string | null, sha: string, deploymentName: string): ShipStatus {
  if (raw === null || raw.trim() === "") return { status: "pending", result: null };
  let o: Record<string, unknown>;
  try {
    o = JSON.parse(raw.trim());
  } catch {
    return { status: "failed", reason: "ship result is not JSON", result: null };
  }
  if (!o || typeof o !== "object") return { status: "failed", reason: "ship result is not an object", result: null };
  if (o.sha !== sha) return { status: "failed", reason: "ship result is for another commit", result: null };
  if (typeof o.deploymentName !== "string" || !DEPLOYMENT_NAME.test(o.deploymentName) || o.deploymentName !== deploymentName) {
    return { status: "failed", reason: "ship result is for another deployment", result: null };
  }
  const pick = <T extends string>(x: unknown, allowed: readonly T[], dflt: T): T =>
    allowed.includes(x as T) ? (x as T) : dflt;
  const result: ShipResult = {
    sha,
    deploymentName,
    mainIsAncestor: o.mainIsAncestor === true,
    backend: o.backend === true,
    migration: pick(o.migration, ["ok", "skipped"] as const, "skipped"),
    postDeploy: Array.isArray(o.postDeploy)
      ? o.postDeploy.filter((f): f is string => typeof f === "string" && FN.test(f)).slice(0, 10)
      : [],
    seed: pick(o.seed, ["ok", "failed", "skipped"] as const, "skipped"),
    frontend: pick(o.frontend, ["ok", "skipped", "pending"] as const, "pending"),
    frontendSha256: typeof o.frontendSha256 === "string" && SHA256.test(o.frontendSha256) ? o.frontendSha256 : null,
    healthCheck: pick(o.healthCheck, ["ok", "failed", "skipped", "pending"] as const, "pending"),
    demoLoginUrl: checkPreviewLoginUrl(o.demoLoginUrl, deploymentName),
    done: o.done === true,
    error: typeof o.error === "string" ? o.error.slice(0, 1000) : null,
  };
  if (result.error !== null) return { status: "failed", reason: result.error, result };
  if (result.done) return { status: "ok", result };
  return { status: "pending", result };
}

/**
 * Poll the ship script. A failure carries the script's own reason (its
 * result's error, else its last "error:" line) and its last lines,
 * scrubbed, for the run log (`shipFailed`).
 */
export async function shipStatus(
  sandboxes: SandboxApi,
  args: {
    sandboxId: string;
    executionId: string;
    sha: string;
    deploymentName: string;
    config: Pick<ShipConfig, "resultFile" | "logFile">;
    /** Values to scrub from the script's output besides the patterns: the deploy key's. */
    known?: string[];
  },
): Promise<ShipStatus> {
  const path = args.config.resultFile ?? DEFAULT_SHIP_RESULT_FILE;
  let r = parseShipResult(await sandboxes.readFile(args.sandboxId, path), args.sha, args.deploymentName);
  if (r.status === "pending") {
    const e = await sandboxes.execution(args.executionId);
    if (!e || e.status === "running") return r;
    const again = parseShipResult(await sandboxes.readFile(args.sandboxId, path), args.sha, args.deploymentName);
    r =
      again.status !== "pending"
        ? again
        : {
            status: "failed",
            reason: `the ship script exited (${e.status}${e.exitCode !== undefined ? `, code ${e.exitCode}` : ""}) without finishing`,
            result: again.result,
          };
  }
  if (r.status !== "failed") return r;
  const out = await deployScriptOutput(sandboxes, {
    sandboxId: args.sandboxId,
    executionId: args.executionId,
    logFile: args.config.logFile ?? DEFAULT_SHIP_LOG_FILE,
    script: "chef-ship-deploy",
    ...(args.known ? { known: args.known } : {}),
  });
  let reason = r.reason;
  if (/without finishing$/.test(reason) && out.errorLine) reason = out.errorLine;
  if (/^the ship script (failed|exited)/.test(reason)) {
    const cause = likelyCause(out.tail, "chef-ship-deploy");
    if (cause) reason = `${reason}: ${cause}`;
  }
  return { ...r, reason, ...(out.tail.length ? { log: out.tail } : {}) };
}

/** The host deploy key's parts, to scrub from the ship script's output and nothing else; [] if unreadable. */
export function shipKnownValues(deps: Pick<EffectsDeps, "deployKey" | "hostCloudUrl">): string[] {
  try {
    const { key } = readHostDeployKey(deps);
    return [key, key.slice(key.indexOf("|") + 1)];
  } catch {
    return [];
  }
}

/**
 * A failed ship: the script's last lines into the log of the run whose
 * commit it shipped (chefRunLogs), best effort, and the error the release
 * records (shown in the panel) with the script's reason.
 */
export async function shipFailed(
  ctx: RunCtx,
  chef: Chef,
  args: { releaseId: string; status: { reason: string; log?: string[] } },
): Promise<Error> {
  try {
    const info = await shipInfo(ctx, chef, args.releaseId);
    if (info.shipRunId) {
      await ctx.runMutation(chef.feedback.chefEffects.appendRunLog, {
        runId: info.shipRunId,
        lines: [
          `chef-launcher: Ship it (release #${info.seq}) failed: ${args.status.reason}`,
          ...(args.status.log?.length
            ? ["chef-launcher: the ship script's last lines:", ...args.status.log.map((l) => `ship: ${l}`)]
            : ["chef-launcher: the ship script left no output to read"]),
        ],
      });
    }
  } catch {
    // The reason still reaches the release's error below.
  }
  return new Error(`Ship failed: ${args.status.reason}`);
}

// ---------------------------------------------------------------- record

/**
 * Record what reached production, target by target: the backend once the
 * script deployed it, then the static hosting upload with the release's
 * artifact digest, then `frontendPublished`. Called with partial results
 * too, so a failed upload still leaves the backend recorded.
 */
export async function recordDeploy(
  ctx: RunCtx,
  chef: Chef,
  args: { releaseId: string; config: ShipConfig; result: ShipResult },
): Promise<void> {
  const cfg = args.config;
  let info = await shipInfo(ctx, chef, args.releaseId);
  const r = args.result;
  if (!r.backend) return;
  if (!r.mainIsAncestor) throw new Error("The script didn't confirm chef descends from main");
  if (info.state === "approved" || (info.kind === "rollback" && info.state === "pinned")) {
    await step(ctx, chef, cfg, args.releaseId, "backendDeployed", { mergeSha: info.sha });
    info = await shipInfo(ctx, chef, args.releaseId);
  }
  if (info.state !== "backendDeployed") return;
  if (cfg.frontend !== false) {
    if (r.frontend !== "ok") return;
    if (r.frontendSha256 !== info.artifactDigest) throw new Error("The script published a frontend other than the release's");
    await ctx.runMutation(chef.feedback.chefReleases.recordTarget, {
      operator: operatorOf(cfg),
      releaseId: args.releaseId,
      target: "staticHosting",
      digest: info.artifactDigest!,
      detail: `static hosting on ${r.deploymentName}`,
    });
  }
  await step(ctx, chef, cfg, args.releaseId, "frontendPublished");
}

// ---------------------------------------------------------------- verify

/**
 * The checks for `verified`: the live site answers a GET with 2xx, and the
 * health check (if configured) passed in the sandbox. A failed check leaves
 * the release at frontendPublished and `main` where it was.
 */
export async function verifyShip(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig; result: ShipResult; siteUrl: string },
): Promise<{ name: string; ok: boolean }[]> {
  const info = await shipInfo(ctx, chef, args.releaseId);
  if (reached(info.state, "verified")) return [];
  const doFetch = deps.fetch ?? ((url: string) => fetch(url));
  let siteOk = false;
  try {
    const res = await doFetch(args.siteUrl);
    siteOk = res.status >= 200 && res.status < 300;
  } catch {
    siteOk = false;
  }
  const checks = [{ name: "site", ok: siteOk }];
  if (args.config.healthCheck !== undefined) checks.push({ name: "healthCheck", ok: args.result.healthCheck === "ok" });
  // The release's own post-deploy steps: the script stops at one that fails, so these all ran.
  for (const fn of args.result.postDeploy) checks.push({ name: `postDeploy ${fn}`, ok: true });
  const failed = checks.filter((c) => !c.ok).map((c) => c.name);
  if (failed.length) throw new Error(`Verification failed: ${failed.join(", ")}`);
  await step(ctx, chef, args.config, args.releaseId, "verified", { checks });
  return checks;
}

/**
 * `main` to chef's commit, only after verification: a compare-and-swap from
 * the diff's base (the ship script checked the commit descends from it), so
 * a `main` that moved meanwhile is left alone and the ship stops.
 */
export async function goLive(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig },
): Promise<void | FollowingShip> {
  const info = await shipInfo(ctx, chef, args.releaseId);
  if (reached(info.state, "live")) return;
  if (info.following) return { following: true, reason: `release #${info.seq} is following main` };
  if (info.state !== "verified") throw new Error(`Release #${info.seq} is ${info.state}, not verified`);
  let main = (await deps.refs.readRefs(["main"])).main;
  // A rollback leaves main where it is: the failed ship never moved it.
  if (info.kind === "rollback") {
    if (!main || !SHA40.test(main)) throw new Error("main is gone");
    await step(ctx, chef, args.config, args.releaseId, "live", { mainSha: main });
    return;
  }
  if (main !== info.sha) {
    if (main === info.baseSha) {
      if (!deps.refs.updateRef) throw new Error("RefsApi.updateRef is needed to move main");
      const moved = await deps.refs.updateRef("main", { from: info.baseSha, to: info.sha });
      if (!moved) main = (await deps.refs.readRefs(["main"])).main;
    }
    if (main !== info.baseSha && main !== info.sha) {
      // Main moved during the ship. What is live is verified and approved, so
      // nothing rolls back: Chef merges the new main into the release and
      // deploys the merge on the same approval (or asks once), then moves main.
      if (!main || !SHA40.test(main)) throw new Error("main is gone");
      return await followMain(ctx, chef, args.config, info, main);
    }
    const after = (await deps.refs.readRefs(["main"])).main;
    if (after !== info.sha) throw new Error("main didn't move to the release");
  }
  await step(ctx, chef, args.config, args.releaseId, "live", { mainSha: info.sha });
  await mirrorMain(ctx, chef, deps, { releaseId: args.releaseId, config: args.config });
}

/**
 * `main` to GitHub, when the host mirrors there (CHEF_GITHUB_MIRROR and
 * CHEF_GITHUB_TOKEN): Code Storage's `main`, which just went live, fast-
 * forwarded onto GitHub's, never a force. So GitHub, and whatever builds
 * from it (Xcode Cloud, CI), follows what is live. Best effort: what's live
 * is live, so a mirror that fails, or finds commits on GitHub that `main`
 * doesn't have, is recorded on the release and in the audit log, and the
 * ship goes on. Never throws.
 */
export async function mirrorMain(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig },
): Promise<MirrorOutcome | null> {
  let github = "CHEF_GITHUB_MIRROR";
  const recordMirror = async (extra: Record<string, string>) => {
    try {
      await record(ctx, chef, args.config, args.releaseId, "mirror", { mirrorGithub: github, ...extra });
    } catch (e) {
      console.error(`Chef: the GitHub mirror's outcome was not recorded: ${e instanceof Error ? e.message : String(e)}`);
    }
  };
  try {
    const m = readGithubMirror(deps);
    if (!m) return null;
    github = m.github;
    if (!deps.refs.mirror) throw new Error("RefsApi.mirror is needed to mirror main");
    const out = await deps.refs.mirror({ github: m.github, token: m.token, ref: "main" });
    await recordMirror({
      mirrorStatus: out.status,
      mirrorSha: out.sha,
      ...(out.status === "ahead" || out.status === "diverged" ? { mirrorTarget: out.target } : {}),
      ...(out.status === "diverged"
        ? { error: `github.com/${m.github} main is at ${out.target.slice(0, 7)}, which main doesn't have; left alone` }
        : {}),
    });
    return out;
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    console.error(`Chef: mirroring main to GitHub failed: ${error}`);
    await recordMirror({ mirrorStatus: "failed", error });
    return null;
  }
}

/** The release done (items completed, requesters notified), then the owner's email and the requesters'. */
export async function finishShip(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig; siteUrl: string },
): Promise<{ emailId: string | null }> {
  let info = await shipInfo(ctx, chef, args.releaseId);
  if (info.state === "live") {
    await step(ctx, chef, args.config, args.releaseId, "done");
    info = await shipInfo(ctx, chef, args.releaseId);
  }
  // A rollback's email went when it started (failShip): nothing to announce.
  if (info.kind === "rollback") return { emailId: null };
  const emailId = await shipEmail(ctx, chef, deps, { info, config: args.config, kind: "shipped", siteUrl: args.siteUrl });
  if (info.state === "done") await requesterEmails(ctx, chef, deps, { info, config: args.config, siteUrl: args.siteUrl });
  return { emailId };
}

/**
 * Each request's requester hears it's live: one short email per request,
 * once per release (`release-<n>-item-<itemId>`, recorded like the owner's).
 * Not someone with no address, nor the owner, who has the release email. A
 * failure is logged and audited; the ship is done either way.
 */
async function requesterEmails(ctx: RunCtx, chef: Chef, deps: EffectsDeps, args: { info: ShipInfo; config: ShipConfig; siteUrl: string }) {
  const n = args.config.notify;
  if (!n?.requesterEmail || !deps.email) return;
  const owner = n.to.trim().toLowerCase();
  for (const r of args.info.requests) {
    if (!r.itemId || !r.createdBy || r.removed) continue;
    const idempotencyKey = `release-${args.info.seq}-item-${r.itemId}`;
    if (args.info.emailKeys.includes(idempotencyKey)) continue;
    try {
      const to = (await n.requesterEmail(r.createdBy))?.trim();
      if (!to || to.toLowerCase() === owner) continue;
      const mail = buildLiveEmail({
        appName: n.appName,
        title: r.title,
        appUrl: n.appUrl ?? args.siteUrl,
        ...(n.allowedLinkHosts ? { allowedLinkHosts: n.allowedLinkHosts } : {}),
      });
      await deps.email.send({ to, ...mail, idempotencyKey, kind: "requestShipped" });
      await record(ctx, chef, args.config, args.info.releaseId, "email", { emailKey: idempotencyKey });
    } catch (e) {
      const error = e instanceof Error ? e.message : String(e);
      console.error(`Chef: the "it's live" email for request ${r.itemId} in release #${args.info.seq} was not sent: ${error}`);
      try {
        await record(ctx, chef, args.config, args.info.releaseId, "emailFailed", { emailKey: idempotencyKey, error });
      } catch {
        // Auditing is best effort here too.
      }
    }
  }
}

async function shipEmail(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { info: ShipInfo; config: ShipConfig; kind: "shipped" | "failed"; siteUrl?: string; error?: string; mainMoved?: boolean },
): Promise<string | null> {
  const n = args.config.notify;
  if (!n || !deps.email) return null;
  // One "shipped" email per release, one "failed" per attempt: a retried
  // step finds its key recorded and sends nothing.
  const idempotencyKey =
    args.kind === "failed" ? `release-${args.info.seq}-failed-${args.info.attempts}` : `release-${args.info.seq}-shipped`;
  if (args.info.emailKeys.includes(idempotencyKey)) return null;
  try {
    const mail = buildShipEmail({
      kind: args.kind,
      appName: n.appName,
      seq: args.info.seq,
      sha: args.info.sha,
      requests: args.info.requests,
      ...(args.siteUrl ? { siteUrl: args.siteUrl } : {}),
      ...(args.error ? { error: args.error } : {}),
      ...(args.mainMoved !== undefined ? { mainMoved: args.mainMoved } : {}),
      ...(n.panelUrl ? { panelUrl: n.panelUrl } : {}),
      ...(n.allowedLinkHosts ? { allowedLinkHosts: n.allowedLinkHosts } : {}),
    });
    const { id } = await deps.email.send({
      to: n.to,
      ...mail,
      idempotencyKey,
      kind: args.kind === "failed" ? "shipFailed" : "shipped",
    });
    await record(ctx, chef, args.config, args.info.releaseId, "email", { emailId: id || idempotencyKey, emailKey: idempotencyKey });
    return id || idempotencyKey;
  } catch (e) {
    // The release's state is the record; the email is a courtesy.
    const error = e instanceof Error ? e.message : String(e);
    console.error(`Chef: the ${args.kind} email for release #${args.info.seq} was not sent: ${error}`);
    try {
      await record(ctx, chef, args.config, args.info.releaseId, "emailFailed", { emailKey: idempotencyKey, error });
    } catch {
      // Auditing is best effort here too.
    }
    return null;
  }
}

/** The ship's sandbox and git secret go: set dead, deleted. Safe to repeat. */
export async function cleanupShip(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig },
): Promise<{ sandboxes: string[] }> {
  const ids = (await deps.sandboxes.listSandboxes())
    .filter((s) => s.labels[RELEASE_LABEL] === args.releaseId)
    .map((s) => s.id);
  for (const id of ids) await deps.sandboxes.deleteSandbox(id);
  const name = await shipGitSecretName(args.releaseId);
  if ((await deps.secrets.listSecrets()).some((s) => s.name === name)) {
    await deps.secrets.setSecret(name, "chef-dead");
    await deps.secrets.deleteSecret(name);
  }
  await record(ctx, chef, args.config, args.releaseId, "cleanup");
  return { sandboxes: ids };
}

/**
 * A ship that failed: the error recorded; a release nothing of which reached
 * production abandoned, so the next build can ship; a later one left open
 * with `main` unmoved. The owner's email either way. Safe to repeat.
 */
export async function failShip(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig; error: string; refused?: boolean },
): Promise<{ outcome: "failed" | "abandoned"; error: string }> {
  const cfg = args.config;
  const error = args.error;
  let info: ShipInfo | null = null;
  try {
    info = await shipInfo(ctx, chef, args.releaseId);
  } catch {
    // Not ours to finish.
  }
  if (!info || !info.open) return { outcome: "failed", error };
  await record(ctx, chef, cfg, args.releaseId, "error", { error });
  // What Chef does about it (src/chef/recovery.ts): the platform's failures
  // are tried again, with the release left open; refusals never are.
  const decision = args.refused
    ? null
    : recover(classifyFailure(error), { source: "ship", errorText: error, attempt: Math.max(1, info.attempts) });
  if (decision?.action === "retry") {
    const scheduled = await ctx.runMutation(chef.feedback.chefShip.retryLater, {
      operator: operatorOf(cfg),
      releaseId: args.releaseId,
      inMs: decision.inMs,
    });
    if (scheduled) return { outcome: "failed", error: `${error} (Chef tries again in ${Math.max(1, Math.round(decision.inMs / 60_000))} min)` };
  }
  let outcome: "failed" | "abandoned" = "failed";
  // Automatic rollback: the backend reached production and then the ship
  // failed its checks (or a step after the deploy): Chef redeploys the
  // release before it and leaves main where it was. Never for a rollback.
  let rolledBack = "";
  if (info.kind === "cloud" && reachedProduction(info) && cfg.autoRollback !== false && !args.refused) {
    const rb = await ctx.runMutation(chef.feedback.chefShip.autoRollback, { operator: operatorOf(cfg), releaseId: args.releaseId, reason: error });
    rolledBack = rb.rolledBack ? ` Chef is rolling back to release #${rb.restores}.` : ` Chef couldn't roll back: ${rb.reason ?? "refused"}.`;
  }
  if (!reachedProduction(info)) {
    // Nothing reached production: give the release up, so the next build can ship.
    await ctx.runMutation(chef.feedback.chefReleases.abandon, {
      operator: operatorOf(cfg),
      releaseId: args.releaseId,
      reason: error.slice(0, 500),
    });
    outcome = "abandoned";
  }
  let mainMoved = false;
  try {
    const main = (await deps.refs.readRefs(["main"])).main;
    mainMoved = main !== info.baseSha && main !== info.sha;
  } catch {
    // Unknown; the email says main is where it was only if it read so.
  }
  await shipEmail(ctx, chef, deps, { info, config: cfg, kind: "failed", error: `${error}${rolledBack}`, mainMoved });
  return { outcome, error: `${error}${rolledBack}` };
}

/** Whether a release's state is at or past `than` (pinned, ..., verified, live, done). */
export const shipReached = reached;

// ---------------------------------------------------------------- driver

/**
 * The whole ship in one action, for a host whose shipper is a plain action
 * (and for tests): start, poll, record each target, verify, move main,
 * finish, clean up. A refusal or a failure before the backend deploy
 * abandons the release; a later failure leaves it open with the error and
 * `main` unmoved. The owner gets an email either way.
 */
export async function driveShip(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { releaseId: string; config: ShipConfig; wait: Waiter },
): Promise<{ outcome: "live" | "failed" | "abandoned" | "following"; error?: string; siteUrl?: string }> {
  const cfg = args.config;
  const now = args.wait.now ?? Date.now;
  let siteUrl: string | undefined;
  try {
    const info = await shipInfo(ctx, chef, args.releaseId);
    if (!info.open && info.state === "done") return { outcome: "live" };
    if (!reached(info.state, "verified")) {
      const started = await startShip(ctx, chef, deps, args);
      if ("following" in started) return { outcome: "following", error: started.reason };
      siteUrl = cfg.siteUrl ?? `https://${started.deploymentName}.convex.site`;
      const deadline = now() + (cfg.timeoutMs ?? 30 * 60_000);
      let result: ShipResult;
      const known = shipKnownValues(deps);
      for (;;) {
        const st = await shipStatus(deps.sandboxes, { ...started, sha: info.sha, config: cfg, known });
        if (st.result) await recordDeploy(ctx, chef, { releaseId: args.releaseId, config: cfg, result: st.result });
        if (st.status === "ok") {
          result = st.result;
          break;
        }
        if (st.status === "failed") throw await shipFailed(ctx, chef, { releaseId: args.releaseId, status: st });
        if (now() > deadline) throw new Error("The ship script took too long");
        await args.wait.sleep(args.wait.pollMs ?? 5000);
      }
      await verifyShip(ctx, chef, deps, { releaseId: args.releaseId, config: cfg, result, siteUrl });
    }
    siteUrl ??= cfg.siteUrl ?? `https://${readHostDeployKey(deps).deploymentName}.convex.site`;
    const went = await goLive(ctx, chef, deps, args);
    if (went) return { outcome: "following", error: went.reason };
    await finishShip(ctx, chef, deps, { releaseId: args.releaseId, config: cfg, siteUrl });
    return { outcome: "live", siteUrl };
  } catch (e) {
    const error = e instanceof Error ? e.message : String(e);
    return await failShip(ctx, chef, deps, { releaseId: args.releaseId, config: cfg, error, refused: e instanceof ShipRefused });
  } finally {
    try {
      await cleanupShip(ctx, chef, deps, args);
    } catch {
      // The sweep and Daytona's auto-delete are the backstop.
    }
  }
}
