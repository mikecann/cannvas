// @convex-dev/chef-cloud: Chef's cloud builds, next to @convex-dev/feedback.
//
//   // convex/convex.config.ts
//   import feedback from "@convex-dev/feedback/convex.config.js";
//   import chefCloud from "@convex-dev/chef-cloud/convex.config.js";
//   app.use(feedback);
//   app.use(chefCloud);
//
//   // convex/chef.ts
//   import { chefCloud } from "@convex-dev/chef-cloud";
//   export const { chefStep, ... } = chefCloud(components.feedback, components.chefCloud, options);
//
// The host-side pieces it is made of are exported too, for a host that
// wires cloud builds by hand: `/effects`, `/launcher`, `/ship`, `/daytona`.
export {
  chefCloud,
  chefCrons,
  checkFeedbackContract,
  composedDeps,
  sendEmailApi,
  DEFAULT_FRONTEND,
  FEEDBACK_CONTRACT,
  NO_ADMIN,
  OPERATOR_USER,
} from "./chefCloud.js";
export type { ChefCloudOptions, ChefCloudFrontend, ChefEmail, ChefSend } from "./chefCloud.js";
export type { ChefApis, CloudComponentApi, FeedbackComponentApi } from "./apis.js";
export { planBatches } from "./chefPlanner.js";
export type { PlannerOptions } from "./chefPlanner.js";
