/**
 * `SandboxApi` and `SecretsApi` over the `@convex-marketplace/daytona`
 * component's client, for the host's actions. Typed against the shape of
 * that client, so this package doesn't depend on it:
 *
 *   import { Daytona } from "@convex-marketplace/daytona";
 *   import { daytonaEffects } from "@convex-dev/chef-cloud/daytona";
 *   const daytona = new Daytona(components.daytona);
 *   // in an action:
 *   const { sandboxes, secrets } = daytonaEffects(daytona, ctx);
 *
 * Chef runs only in gateway mode (no DAYTONA_API_KEY in the host): in direct
 * mode Daytona returns real secret values from `GET /sandbox/{id}/secrets`.
 */
import { assertEgress, type Egress, type SandboxApi, type SecretsApi } from "./chefEffects.js";

type Network = { networkBlockAll?: boolean; networkAllowList?: string[]; domainAllowList?: string[] };

/** The methods of `Daytona` (packages/daytona/src/client) that Chef uses. */
export interface DaytonaLike<Ctx> {
  createSandbox(
    ctx: Ctx,
    args: Network & {
      snapshot?: string;
      envVars?: Record<string, string>;
      secrets?: Record<string, string>;
      labels?: Record<string, string>;
      autoStopInterval?: number;
      autoDeleteInterval?: number;
      userKey?: string;
    },
  ): Promise<{ sandboxId: string; state: string }>;
  deleteSandbox(ctx: Ctx, args: { sandboxId: string }): Promise<unknown>;
  listSandboxes(
    ctx: Ctx,
    args?: { userKey?: string; limit?: number },
  ): Promise<Array<{ sandboxId: string; state: string; labels?: Record<string, string> }>>;
  updateNetworkSettings(ctx: Ctx, args: Network & { sandboxId: string }): Promise<unknown>;
  runBackground(
    ctx: Ctx,
    args: { sandboxId: string; command: string; envs?: Record<string, string> },
  ): Promise<{ executionId: string }>;
  getExecution(
    ctx: Ctx,
    args: { executionId: string },
  ): Promise<{ status: "running" | "completed" | "failed"; exitCode?: number; result?: string } | null>;
  listExecutions(
    ctx: Ctx,
    args: { sandboxId: string; limit?: number },
  ): Promise<Array<{ _id: string; input: string; status: "running" | "completed" | "failed"; exitCode?: number }>>;
  readFile(ctx: Ctx, args: { sandboxId: string; path: string }): Promise<string>;
  writeFile(ctx: Ctx, args: { sandboxId: string; path: string; content: string }): Promise<unknown>;
  createSecret(ctx: Ctx, args: { name: string; value: string; hosts: string[] }): Promise<unknown>;
  updateSecret(ctx: Ctx, args: { name: string; value?: string; hosts?: string[] }): Promise<unknown>;
  deleteSecret(ctx: Ctx, args: { name: string; force?: boolean }): Promise<unknown>;
  listSecrets(ctx: Ctx): Promise<Array<{ name: string }>>;
}

const NOT_FOUND = /\b404\b|not found|no such file/i;

function network(e: Egress): Network {
  return {
    ...(e.networkBlockAll !== undefined ? { networkBlockAll: e.networkBlockAll } : {}),
    ...(e.networkAllowList !== undefined ? { networkAllowList: [...e.networkAllowList] } : {}),
    ...(e.domainAllowList !== undefined ? { domainAllowList: [...e.domainAllowList] } : {}),
  };
}

export function daytonaEffects<Ctx>(
  daytona: DaytonaLike<Ctx>,
  ctx: Ctx,
  opts: { userKey?: string } = {},
): { sandboxes: SandboxApi; secrets: SecretsApi } {
  const sandboxes: SandboxApi = {
    async listSandboxes() {
      const rows = await daytona.listSandboxes(ctx, {
        ...(opts.userKey !== undefined ? { userKey: opts.userKey } : {}),
        limit: 100,
      });
      return rows
        .filter((r) => r.state !== "destroyed")
        .map((r) => ({ id: r.sandboxId, labels: r.labels ?? {} }));
    },
    async createSandbox(spec) {
      // Fail closed here too, whoever calls it.
      assertEgress(spec);
      const created = await daytona.createSandbox(ctx, {
        ...(spec.snapshot !== undefined ? { snapshot: spec.snapshot } : {}),
        ...(spec.secrets !== undefined ? { secrets: { ...spec.secrets } } : {}),
        ...(spec.envVars !== undefined ? { envVars: { ...spec.envVars } } : {}),
        ...network(spec),
        labels: { ...spec.labels },
        ...(spec.autoStopInterval !== undefined ? { autoStopInterval: spec.autoStopInterval } : {}),
        ...(spec.autoDeleteInterval !== undefined ? { autoDeleteInterval: spec.autoDeleteInterval } : {}),
        ...(opts.userKey !== undefined ? { userKey: opts.userKey } : {}),
      });
      return { id: created.sandboxId };
    },
    async deleteSandbox(id) {
      // The component treats a 404 as success.
      await daytona.deleteSandbox(ctx, { sandboxId: id });
    },
    async updateNetwork(id, egress) {
      assertEgress(egress);
      await daytona.updateNetworkSettings(ctx, { sandboxId: id, ...network(egress) });
    },
    async startCommand(id, args) {
      // The component never stores `envs`: it uploads them to a private file
      // the command sources and deletes, keeps only the command (`input`)
      // and the command's own output (`result`), and redacts env values from
      // stored errors. The deploy script scrubs its output of the key.
      const r = await daytona.runBackground(ctx, {
        sandboxId: id,
        command: args.command,
        ...(args.envs !== undefined ? { envs: { ...args.envs } } : {}),
      });
      return { executionId: String(r.executionId) };
    },
    async execution(executionId) {
      const e = await daytona.getExecution(ctx, { executionId });
      if (!e) return null;
      return {
        status: e.status,
        ...(e.exitCode !== undefined ? { exitCode: e.exitCode } : {}),
        // The command's own output, as the component kept it (the deploy
        // scripts scrub theirs); read only for a failed deploy's reason.
        ...(typeof e.result === "string" ? { output: e.result } : {}),
      };
    },
    async listExecutions(id) {
      // Newest first. `input` is the command as started (envs travel apart).
      const rows = await daytona.listExecutions(ctx, { sandboxId: id, limit: 50 });
      return rows.map((r) => ({
        executionId: String(r._id),
        command: r.input,
        status: r.status,
        ...(r.exitCode !== undefined ? { exitCode: r.exitCode } : {}),
      }));
    },
    async readFile(id, path) {
      try {
        return await daytona.readFile(ctx, { sandboxId: id, path });
      } catch (err) {
        if (NOT_FOUND.test(String((err as Error)?.message ?? err))) return null;
        throw err;
      }
    },
    async writeFile(id, path, content) {
      await daytona.writeFile(ctx, { sandboxId: id, path, content });
    },
  };

  const secrets: SecretsApi = {
    async createSecret({ name, value, hosts }) {
      // The gateway adopts a leftover name on 409, but doesn't say so; look first.
      const exists = (await daytona.listSecrets(ctx)).some((s) => s.name === name);
      if (exists) {
        await daytona.updateSecret(ctx, { name, value, hosts });
        return { created: false };
      }
      await daytona.createSecret(ctx, { name, value, hosts });
      return { created: true };
    },
    async setSecret(name, value) {
      await daytona.updateSecret(ctx, { name, value });
    },
    async deleteSecret(name) {
      // No `force`: Chef deletes the sandboxes that mount a secret first.
      await daytona.deleteSecret(ctx, { name });
    },
    async listSecrets() {
      return (await daytona.listSecrets(ctx)).map((s) => ({ name: s.name }));
    },
  };

  return { sandboxes, secrets };
}
