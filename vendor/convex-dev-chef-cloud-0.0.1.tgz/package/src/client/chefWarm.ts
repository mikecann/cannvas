/**
 * Warm snapshots (docs/chef-pipeline.md, "Warm snapshots"): per-app Daytona
 * snapshots with the app's dependencies already fetched, so the build, the
 * preview deploy and "Ship it" install offline in their sandboxes instead of
 * from the registry. Host-side, over chefEffects' `WarmApi`, like the rest
 * of the launcher.
 *
 * - Built only from trusted, committed inputs: chef-base's own recipe
 *   (src/shared/chefBase.ts, the same pinned image and tools) plus one layer
 *   whose context is package.json's install fields, the lockfile and its
 *   `file:` tarballs, read from the app's repo at one commit by chef-cloud
 *   and checked against the sha256s the key was made from. Never anything a
 *   sandbox (or an agent in one) produced, no app code, no secrets: the
 *   layer runs the very install runner/chef-install.mjs runs, with
 *   `--ignore-scripts`, and keeps only npm's cache (and pnpm's store) under
 *   /opt/chef/warm/<inputsHash>/ with a WARM.json marker.
 * - Keyed by sha256(format, chef-base recipe, inputsHash), where inputsHash
 *   (runner/chef-install-plan.mjs) covers the install command and package
 *   manager version, the lockfile, package.json's install fields and every
 *   tarball. The name is `chef-warm-<12 hex>`.
 * - Lazy: a launch that finds no ready snapshot for its key asks for one
 *   (`warm.request`, which schedules `warmBuild` through the executor, once
 *   per key) and starts from the base snapshot as before. It never waits.
 * - Used by matching only: the sandbox's install (runner/chef-install.mjs)
 *   checks the marker against the checkout's own inputs and installs
 *   normally on any difference, and npm and pnpm check every package
 *   against the lockfile's integrity even when they install offline.
 * - At most `keep` (default 2) per app: older ones are deleted before a new
 *   one is built; one that can't be deleted (a sandbox still uses it) means
 *   no new one for now (`deferred`), never a forced delete.
 */
import { WARM_RECOVERY } from "@convex-dev/feedback/chef/recovery.js";
import type { ChefApis } from "./apis.js";
import type { EffectsDeps, RunCtx, WarmApi, WarmContextFile, WarmInputsAt } from "./chefEffects.js";
import { CHEF_BASE_FILES, CHEF_BASE_SNAPSHOT } from "../shared/chefBase.js";
import {
  MAX_LOCKFILE_BYTES,
  PLAN_FILES,
  WARM_MARKER,
  WARM_ROOT,
  installPlanFrom,
  lockfileTarballs,
  sha256Hex,
  warmInputs,
  warmPackageJson,
  warmCaches,
  warmDirFor,
  warmInstallArgv,
  warmKey,
  warmMarker,
  warmSnapshotName,
  type InstallPlan,
} from "@convex-dev/feedback/install-plan";

type Chef = ChefApis;

/** Warm snapshots kept per app, by default. The gateway allows 5 snapshots per team. */
export const WARM_KEEP = 2;
/** A sandbox made from a warm snapshot gets these, as one from chef-base would (Daytona's defaults for it). */
export const WARM_RESOURCES = { cpu: 2, memory: 4, disk: 10 };
/**
 * A failed build is tried again after this long, a few times at most
 * (warm.ts MAX_WARM_ATTEMPTS): warm snapshots' row in the recovery table
 * (@convex-dev/feedback src/chef/recovery.ts WARM_RECOVERY).
 */
export const WARM_RETRY_MS = WARM_RECOVERY.retryAfterMs;
/** A build deferred for want of room is tried again after this long. */
export const WARM_DEFER_MS = 6 * 3600_000;

/** The launcher's switch: on with `keep`, off when absent. */
export type WarmSettings = { keep?: number };

/**
 * The base a warm snapshot is built from: chef-base's name and the sha256
 * over its recipe's files, modes and paths. Part of every key.
 */
export async function chefBaseId(): Promise<string> {
  const lines: string[] = [];
  for (const f of CHEF_BASE_FILES) lines.push(`${await sha256Hex(f.content)} ${f.mode.toString(8)} ${f.path}\n`);
  return `${CHEF_BASE_SNAPSHOT}@${await sha256Hex(lines.join(""))}`;
}

const TOKEN = /^[A-Za-z0-9@=._:/+-]+$/;

/**
 * The warm snapshot's Dockerfile and build context: chef-base's recipe and
 * files, and before its final `USER daytona` one layer that installs from
 * the committed files (as root, without scripts, into
 * /opt/chef/warm/<inputsHash>), drops everything but the caches, and writes
 * the marker last. Repo files are named by path and sha256; chef-cloud
 * fetches and checks them when it starts the build.
 */
export function warmDockerfile(args: {
  key: string;
  base: string;
  inputsHash: string;
  inputs: NonNullable<WarmInputsAt["inputs"]>;
  packageJson: string;
}): { dockerfile: string; context: WarmContextFile[] } {
  const recipe = CHEF_BASE_FILES.find((f) => f.path === "Dockerfile")!.content;
  const at = recipe.lastIndexOf("\nUSER daytona\n");
  if (at < 0) throw new Error("chef-base's recipe has no final USER daytona");
  const plan = (
    args.inputs.manager === "pnpm"
      ? { manager: "pnpm", lockfile: args.inputs.lockfile.name, version: args.inputs.version!, argv: args.inputs.argv }
      : { manager: "npm", lockfile: args.inputs.lockfile.name, argv: args.inputs.argv }
  ) as InstallPlan;
  const dir = warmDirFor(WARM_ROOT, args.inputsHash);
  const argv = warmInstallArgv(plan, warmCaches(dir), { offline: false });
  for (const t of argv) if (!TOKEN.test(t)) throw new Error(`can't put ${JSON.stringify(t)} in the warm install`);
  if (!/^[A-Za-z0-9._-]+$/.test(plan.lockfile)) throw new Error("bad lockfile name");
  const marker = JSON.stringify(warmMarker({ key: args.key, base: args.base, inputsHash: args.inputsHash, inputs: args.inputs }));
  if (marker.includes("'")) throw new Error("can't put the marker in the warm install");
  const layer = [
    "",
    "# ---- Warm install (@convex-dev/chef-cloud, src/client/chefWarm.ts) ----",
    "# Only files committed to the app's repo, read at one commit: package.json's",
    `# install fields, ${plan.lockfile} and its file: tarballs. No app code, no secrets.`,
    "# The install runner/chef-install.mjs runs, without scripts; only npm's",
    "# cache (and pnpm's store) is kept, with the marker written last.",
    "USER root",
    "COPY warm/ /opt/chef/warm-src/",
    "RUN set -eu \\",
    " && cd /opt/chef/warm-src \\",
    " && test ! -e .npmrc \\",
    ` && ${argv.join(" ")} \\`,
    ` && rm -rf /opt/chef/warm-src ${dir}/npm-cache/_logs /root/.npm/_logs \\`,
    ` && printf '%s\\n' '${marker}' > ${dir}/${WARM_MARKER} \\`,
    " && chown -R root:root /opt/chef/warm \\",
    " && chmod -R u+rwX,go+rX,go-w /opt/chef/warm",
  ].join("\n");
  const dockerfile = recipe.slice(0, at) + "\n" + layer + "\n" + recipe.slice(at);
  const context: WarmContextFile[] = [
    ...CHEF_BASE_FILES.filter((f) => f.path !== "Dockerfile").map((f) => ({ path: f.path, mode: f.mode, text: f.content })),
    { path: "warm/package.json", text: args.packageJson },
    { path: `warm/${plan.lockfile}`, repoPath: plan.lockfile, sha256: args.inputs.lockfile.sha256 },
    ...args.inputs.tarballs.map((t) => ({ path: `warm/${t.path}`, repoPath: t.path, sha256: t.sha256 })),
  ];
  return { dockerfile, context };
}

/**
 * The warm install's inputs at a commit (or a branch's tip), from the files
 * committed there: runner/chef-install-plan.mjs's own functions, as the
 * sandbox's installer runs them on its checkout, so both make the same
 * inputsHash. `packageJson` is the install fields only, all a warm snapshot
 * gets of package.json. Or `unsupported`, with why there can be no warm install.
 */
export async function inputsFromRepo(warm: WarmApi, at: { ref: string } | { commit: string }): Promise<WarmInputsAt> {
  const r = await warm.readFiles({ at, paths: [...PLAN_FILES] });
  const files = {
    exists: (name: string) => r.files[name] !== undefined && r.files[name] !== null,
    read: (name: string, max: number) => {
      const t = r.files[name] ?? null;
      return t !== null && t.length <= max ? t : null;
    },
  };
  const plan = installPlanFrom(files);
  let hashes: Record<string, string | null> = {};
  if (!("error" in plan)) {
    const lock = files.read(plan.lockfile, MAX_LOCKFILE_BYTES);
    const tb = lock === null ? null : lockfileTarballs(lock, plan.manager);
    if (tb?.paths && tb.paths.length > 0) {
      hashes = (await warm.readFiles({ at: { commit: r.commit }, paths: [], hash: tb.paths })).sha256;
    }
  }
  const w = await warmInputs(files, async (path) => hashes[path] ?? null);
  if (w.unsupported !== undefined) return { commit: r.commit, unsupported: w.unsupported };
  return {
    commit: r.commit,
    inputsHash: w.inputsHash,
    inputs: w.inputs,
    packageJson: JSON.stringify(warmPackageJson(files.read("package.json", MAX_LOCKFILE_BYTES)), null, 2) + "\n",
  };
}

/** Which snapshot a sandbox starts from: a warm one and its key, or none and why. */
export type WarmPick = { snapshot: string; key: string } | { snapshot: null; key: string | null; why: string };

const message = (e: unknown) => (e instanceof Error ? e.message : String(e)).slice(0, 300);

const FAILED = /error|fail/i;

/**
 * The warm snapshot for the dependencies at `at` (a commit, or a branch's
 * tip), if one is ready. If none is, asks for its build (once per key) and
 * returns none: the caller starts from the base snapshot and never waits.
 * A build in progress is looked at, and marked ready or failed. Any error
 * is none, with why.
 */
export async function pickWarm(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { at: { ref: string } | { commit: string }; settings: WarmSettings | undefined | false; now?: () => number },
): Promise<WarmPick> {
  if (!args.settings) return { snapshot: null, key: null, why: "warm snapshots are off" };
  const warm = deps.warm;
  if (!warm) return { snapshot: null, key: null, why: "no warm snapshot adapter" };
  const now = args.now ?? Date.now;
  const found: { key: string | null } = { key: null };
  const lookup = async (): Promise<WarmPick> => {
    const at = await inputsFromRepo(warm, args.at);
    if (at.unsupported !== undefined || !at.inputsHash || !at.inputs) {
      return { snapshot: null, key: null, why: `no warm install: ${at.unsupported ?? "no inputs"}` };
    }
    const key = await warmKey({ base: await chefBaseId(), inputsHash: at.inputsHash });
    found.key = key;
    const name = warmSnapshotName(key);
    const row = await ctx.runQuery(chef.cloud.warm.get, { key });
    let state = row?.state ?? null;
    if (state === "building") {
      const s = await warm.getSnapshot(name);
      if (s?.state === "active") {
        await ctx.runMutation(chef.cloud.warm.update, {
          key,
          state: "ready",
          builtAt: now(),
          error: null,
          ...(s.size !== undefined ? { size: s.size } : {}),
        });
        state = "ready";
      } else if (!s || FAILED.test(s.state)) {
        await ctx.runMutation(chef.cloud.warm.update, {
          key,
          state: "failed",
          error: s ? `the build failed (${s.state}${s.errorReason ? `: ${s.errorReason}` : ""})` : "the snapshot is gone",
          retryAt: now() + WARM_RETRY_MS,
        });
        if (s) await warm.deleteSnapshot(name).catch(() => {});
        return { snapshot: null, key, why: "its warm snapshot's build failed" };
      } else return { snapshot: null, key, why: `its warm snapshot is still building (${s.state})` };
    }
    if (state === "ready") return { snapshot: name, key };
    const r = await ctx.runMutation(chef.cloud.warm.request, {
      key,
      name,
      commit: at.commit,
      inputsHash: at.inputsHash,
      manager: at.inputs.manager,
    });
    return {
      snapshot: null,
      key,
      why: r.scheduled ? "no warm snapshot yet; its build is scheduled" : `its warm snapshot is ${r.state}`,
    };
  };
  try {
    return await lookup();
  } catch (e) {
    return { snapshot: null, key: found.key, why: `the warm lookup failed: ${message(e)}` };
  }
}

/**
 * Create a sandbox from the picked warm snapshot, else from `base`. If it
 * can't start from the warm one, and that one is no longer active, it is
 * marked failed (built again later) and the sandbox starts from the base:
 * a warm snapshot never fails a run. Counts each use.
 */
export async function createWithWarm<T>(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { pick: WarmPick | null; base: string; create: (snapshot: string) => Promise<T>; now?: () => number },
): Promise<{ result: T; warm: { snapshot: string; key: string } | null }> {
  const pick = args.pick;
  if (!pick || pick.snapshot === null) return { result: await args.create(args.base), warm: null };
  try {
    const result = await args.create(pick.snapshot);
    await ctx.runMutation(chef.cloud.warm.update, { key: pick.key, used: true }).catch(() => {});
    return { result, warm: { snapshot: pick.snapshot, key: pick.key } };
  } catch (e) {
    const s = await deps.warm?.getSnapshot(pick.snapshot).catch(() => undefined);
    if (s === null || (s && s.state !== "active")) {
      await ctx
        .runMutation(chef.cloud.warm.update, {
          key: pick.key,
          state: "failed",
          error: `a sandbox couldn't start from it: ${message(e)}`,
          retryAt: (args.now ?? Date.now)() + WARM_RETRY_MS,
        })
        .catch(() => {});
    }
    return { result: await args.create(args.base), warm: null };
  }
}

/** Say which snapshot a run's sandbox started from: on the run's provenance and in the audit log, or why not. Best effort. */
export async function recordWarmUse(
  ctx: RunCtx,
  chef: Chef,
  args: { runId?: string; releaseId?: string; role: "build" | "deploy" | "ship"; warm: { snapshot: string; key: string } | null; pick: WarmPick | null },
): Promise<void> {
  try {
    if (args.warm && args.runId && args.role !== "ship") {
      await ctx.runMutation(chef.feedback.chefEffects.recordWarm, {
        runId: args.runId,
        role: args.role,
        snapshot: args.warm.snapshot,
        key: args.warm.key,
      });
      return;
    }
    if (!args.pick) return;
    await ctx.runMutation(chef.feedback.chefAudit.record, {
      actor: "system:orchestrator",
      action: args.warm ? "warm.used" : "warm.none",
      outcome: "ok",
      ...(args.warm ? { target: args.warm.snapshot } : {}),
      ...(args.runId ? { runId: args.runId } : {}),
      ...(!args.warm && args.pick.snapshot === null ? { reason: args.pick.why } : {}),
      detail: {
        role: args.role,
        key: args.warm?.key ?? args.pick.key ?? null,
        ...(args.releaseId ? { releaseId: args.releaseId } : {}),
      },
    });
  } catch {
    // Provenance is a record, not a step: the sandbox is up either way.
  }
}

/**
 * The scheduled build of one key's warm snapshot (op "warmBuild"), once per
 * request: room first (at most `keep`, deleting the least recently used;
 * none deleted means none built, `deferred`), then the inputs read again at
 * the recorded commit and checked against the key, then Daytona's build,
 * which runs on its own (a later launch sees it ready). Returns the state.
 */
export async function buildWarmSnapshot(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { key: string; settings: WarmSettings | undefined | false; now?: () => number },
): Promise<{ state: string }> {
  const now = args.now ?? Date.now;
  const row = await ctx.runQuery(chef.cloud.warm.get, { key: args.key });
  if (!row || row.state !== "queued") return { state: row?.state ?? "gone" };
  const fail = async (state: "failed" | "deferred", error: string, retryMs: number) => {
    await ctx.runMutation(chef.cloud.warm.update, { key: args.key, state, error, retryAt: now() + retryMs, attempt: true });
    return { state };
  };
  if (!args.settings) return await fail("failed", "warm snapshots are off", WARM_RETRY_MS);
  const warm = deps.warm;
  if (!warm) return await fail("failed", "no warm snapshot adapter", WARM_RETRY_MS);
  const keep = Math.min(4, Math.max(1, Math.floor(args.settings.keep ?? WARM_KEEP)));

  // Room: the least recently used go first. Never forced.
  const rows = await ctx.runQuery(chef.cloud.warm.list, {});
  const live = rows
    .filter((r) => r.key !== args.key && (r.state === "ready" || r.state === "building"))
    .sort((a, b) => b.lastUsedAt - a.lastUsedAt);
  let blocked: string | null = null;
  for (const old of live.slice(keep - 1)) {
    try {
      await warm.deleteSnapshot(old.name);
      await ctx.runMutation(chef.cloud.warm.remove, { key: old.key });
    } catch (e) {
      blocked = `${old.name}: ${message(e)}`;
      await ctx.runMutation(chef.cloud.warm.update, { key: old.key, error: `couldn't be deleted: ${message(e)}` });
    }
  }
  // Records of builds that won't be tried again, past a few.
  const dead = rows.filter((r) => r.key !== args.key && (r.state === "failed" || r.state === "deferred")).sort((a, b) => b.createdAt - a.createdAt);
  for (const old of dead.slice(4)) await ctx.runMutation(chef.cloud.warm.remove, { key: old.key });
  if (blocked) {
    return await fail("deferred", `older warm snapshots couldn't be deleted (${blocked}); not building past ${keep}`, WARM_DEFER_MS);
  }

  // A build retried after a lost response: Daytona may have it already.
  const existing = await warm.getSnapshot(row.name);
  if (existing?.state === "active") {
    await ctx.runMutation(chef.cloud.warm.update, {
      key: args.key,
      state: "ready",
      builtAt: now(),
      error: null,
      ...(existing.size !== undefined ? { size: existing.size } : {}),
    });
    return { state: "ready" };
  }
  if (existing && !FAILED.test(existing.state)) {
    await ctx.runMutation(chef.cloud.warm.update, { key: args.key, state: "building" });
    return { state: "building" };
  }
  if (existing) {
    try {
      await warm.deleteSnapshot(row.name);
    } catch (e) {
      return await fail("failed", `its failed build couldn't be deleted: ${message(e)}`, WARM_RETRY_MS);
    }
  }

  // The inputs again, at the commit the request named: they must still make this key.
  let at: WarmInputsAt;
  try {
    at = await inputsFromRepo(warm, { commit: row.commit });
  } catch (e) {
    return await fail("failed", `couldn't read the dependency files: ${message(e)}`, WARM_RETRY_MS);
  }
  if (at.unsupported !== undefined || !at.inputsHash || !at.inputs || at.packageJson === undefined) {
    return await fail("failed", `no warm install: ${at.unsupported ?? "no inputs"}`, WARM_RETRY_MS);
  }
  const base = await chefBaseId();
  if ((await warmKey({ base, inputsHash: at.inputsHash })) !== args.key) {
    return await fail("failed", "the commit's dependency files don't make this key", WARM_RETRY_MS);
  }
  const { dockerfile, context } = warmDockerfile({
    key: args.key,
    base,
    inputsHash: at.inputsHash,
    inputs: at.inputs,
    packageJson: at.packageJson,
  });
  await ctx.runMutation(chef.cloud.warm.update, { key: args.key, state: "building", attempt: true, error: null, retryAt: null });
  try {
    await warm.createSnapshot({ name: row.name, dockerfile, commit: row.commit, context, ...WARM_RESOURCES });
  } catch (e) {
    await ctx.runMutation(chef.cloud.warm.update, {
      key: args.key,
      state: "failed",
      error: `the build didn't start: ${message(e)}`,
      retryAt: now() + WARM_RETRY_MS,
    });
    return { state: "failed" };
  }
  return { state: "building" };
}
