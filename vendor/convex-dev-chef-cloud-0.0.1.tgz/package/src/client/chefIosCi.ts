/**
 * The iOS CI (docs/ios-xcode-cloud.md, "Every iOS build, before Ship it").
 * Chef's sandboxes run Linux, so they never compile an app's Swift. When a
 * build is built and touched the iOS app (`paths`, default `ios/`), its
 * commit goes to the host's GitHub mirror as `chef-ios/<seq>`, which a
 * second Xcode Cloud workflow (start condition: branch changes, prefix
 * `chef-ios/`) builds; Chef reads the result back from GitHub's checks onto
 * the run (chefIos.recordCi), where the Ship card shows it, then deletes the
 * branch. Best effort: Ship it never waits for it.
 *
 * One host action, chefCiCheck, does one step and schedules itself again
 * while there's something to wait for; "finish" schedules the first. No
 * crons (contract 12).
 *
 * The token is the mirror's (CHEF_GITHUB_TOKEN): Contents read and write to
 * push and delete the branch, and Commit statuses: read to see Xcode Cloud's
 * result (it posts one per build, linking to App Store Connect; fine-grained
 * tokens can't read check runs).
 */
import type { ChefApis } from "./apis.js";
import { readGithubMirror, type EffectsDeps, type GithubApi, type RunCtx } from "./chefEffects.js";

type Chef = ChefApis;

export type IosCiConfig = {
  /** Paths whose change sends a build to CI. Default ["ios/"]. */
  paths?: string[];
  /** The GitHub branch prefix the Xcode Cloud workflow watches. Default "chef-ios/". */
  refPrefix?: string;
  /** Between looks at GitHub's checks. Default 3 minutes. */
  pollMs?: number;
  /** Give up waiting for Xcode Cloud after this long. Default 2 hours. */
  giveUpMs?: number;
};

export const IOS_CI_DEFAULTS = { paths: ["ios/"], refPrefix: "chef-ios/", pollMs: 3 * 60_000, giveUpMs: 2 * 60 * 60_000 };

type CiStatus = "pending" | "passed" | "failed" | "none" | "error";
type CiCheck = { status: CiStatus; ref: string; sha: string; at: number; url?: string; detail?: string };

export function touchesPaths(files: string[], paths: string[]): boolean {
  return files.some((f) => paths.some((p) => f === p || f.startsWith(p.endsWith("/") ? p : `${p}/`)));
}

/** Xcode Cloud's check runs (by its GitHub app), as one verdict; null while any is still going. */
export function xcodeCloudVerdict(
  runs: Array<{ app: string; name: string; status: string; conclusion: string | null; url: string | null; title: string | null }>,
): { status: "passed" | "failed"; url?: string; detail?: string } | null | "none" {
  const xc = runs.filter((r) => /xcode cloud/i.test(r.app));
  if (!xc.length) return "none";
  if (xc.some((r) => r.status !== "completed")) return null;
  const bad = xc.find((r) => !["success", "neutral", "skipped"].includes(r.conclusion ?? ""));
  const pick = bad ?? xc[0];
  return {
    status: bad ? "failed" : "passed",
    ...(pick.url ? { url: pick.url } : {}),
    ...(bad ? { detail: `${bad.name}: ${bad.title ?? bad.conclusion ?? "failed"}` } : {}),
  };
}

/** Xcode Cloud's commit statuses link to its builds in App Store Connect. */
const XCODE_CLOUD_BUILD = /^https:\/\/appstoreconnect\.apple\.com\/.*\/ci\/builds\//;

/** GitHub's REST API with global fetch: the default GithubApi. */
export function githubRest(f: typeof fetch = fetch): GithubApi {
  const headers = (token: string) => ({
    authorization: `Bearer ${token}`,
    accept: "application/vnd.github+json",
    "x-github-api-version": "2022-11-28",
  });
  return {
    // The commit's statuses (Commit statuses: read), Xcode Cloud's read as check runs.
    async checkRuns({ github, token, sha }) {
      const res = await f(`https://api.github.com/repos/${github}/commits/${sha}/status?per_page=100`, { headers: headers(token) });
      if (!res.ok) return { ok: false, forbidden: res.status === 403 || res.status === 404, status: res.status };
      const body = (await res.json()) as { statuses?: Array<Record<string, any>> };
      return {
        ok: true,
        runs: (body.statuses ?? [])
          .filter((x) => typeof x.target_url === "string" && XCODE_CLOUD_BUILD.test(x.target_url))
          .map((x) => ({
            app: "Xcode Cloud",
            name: String(x.context ?? ""),
            status: x.state === "pending" ? "in_progress" : "completed",
            conclusion: x.state === "success" ? "success" : x.state === "pending" ? null : "failure",
            url: x.target_url as string,
            title: typeof x.description === "string" ? x.description : null,
          })),
      };
    },
    async deleteBranch({ github, token, ref }) {
      const res = await f(`https://api.github.com/repos/${github}/git/refs/heads/${ref.split("/").map(encodeURIComponent).join("/")}`, {
        method: "DELETE",
        headers: headers(token),
      });
      if (!res.ok && res.status !== 404 && res.status !== 422) throw new Error(`deleting ${ref} on GitHub: HTTP ${res.status}`);
    },
  };
}

/**
 * One step for a run: push its commit to GitHub (the first time), or look at
 * Xcode Cloud's checks. Returns how long until the next look, or null when
 * there's nothing more to do. Records what it found on the run; never throws
 * for GitHub's or Xcode Cloud's problems.
 */
export async function iosCiStep(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: IosCiConfig; operator: string; now?: () => number },
): Promise<{ again: number | null; status: CiStatus | "skipped" }> {
  const cfg = { ...IOS_CI_DEFAULTS, ...args.config };
  const now = args.now ?? Date.now;
  const info = (await ctx.runQuery(chef.feedback.chefEffects.runInfo, { runId: args.runId })) as {
    seq: number;
    status: string;
    commitSha: string | null;
    filesChanged: string[];
    ciCheck?: CiCheck;
  } | null;
  if (!info || info.status !== "built" || !info.commitSha) return { again: null, status: "skipped" };
  const sha = info.commitSha;
  const prior = info.ciCheck?.sha === sha ? info.ciCheck : undefined;
  if (prior && prior.status !== "pending") return { again: null, status: prior.status };
  if (!prior && !touchesPaths(info.filesChanged, cfg.paths)) return { again: null, status: "skipped" };
  const mirror = readGithubMirror(deps);
  if (!mirror) return { again: null, status: "skipped" };
  const ref = prior?.ref ?? `${cfg.refPrefix}${info.seq}`;
  const record = async (status: CiStatus, extra: { url?: string; detail?: string; at?: number } = {}) => {
    const check: CiCheck = { status, ref, sha, at: extra.at ?? now(), ...(extra.url ? { url: extra.url } : {}), ...(extra.detail ? { detail: extra.detail } : {}) };
    await ctx.runMutation(chef.feedback.chefIos.recordCi, { operator: args.operator, runId: args.runId, check });
  };
  const github = deps.github ?? githubRest();
  const cleanup = async () => {
    try {
      await github.deleteBranch({ github: mirror.github, token: mirror.token, ref });
    } catch (e) {
      console.error(`Chef: ${ref} wasn't deleted from GitHub: ${e instanceof Error ? e.message : String(e)}`);
    }
  };

  if (!prior) {
    try {
      if (!deps.refs.mirror) throw new Error("RefsApi.mirror is needed");
      await deps.refs.mirror({ github: mirror.github, token: mirror.token, ref, sha, baseRef: "main" });
    } catch (e) {
      await record("error", { detail: `pushing ${ref} to GitHub failed: ${e instanceof Error ? e.message : String(e)}` });
      return { again: null, status: "error" };
    }
    await record("pending");
    return { again: cfg.pollMs, status: "pending" };
  }

  const r = await github.checkRuns({ github: mirror.github, token: mirror.token, sha });
  if (!r.ok) {
    if (r.forbidden) {
      await record("error", { detail: "The GitHub token can't read commit statuses: give CHEF_GITHUB_TOKEN Commit statuses: read" });
      return { again: null, status: "error" };
    }
    return { again: cfg.pollMs, status: "pending" }; // GitHub had a moment; look again
  }
  const verdict = xcodeCloudVerdict(r.runs);
  if (verdict === null || (verdict === "none" && now() - prior.at < cfg.giveUpMs)) {
    if (now() - prior.at >= cfg.giveUpMs) {
      await record("none", { detail: `Xcode Cloud didn't finish ${ref} within ${Math.round(cfg.giveUpMs / 60_000)} minutes` });
      await cleanup();
      return { again: null, status: "none" };
    }
    return { again: cfg.pollMs, status: "pending" };
  }
  if (verdict === "none") {
    await record("none", {
      detail: `Xcode Cloud didn't build ${ref}: add a workflow that starts on branch changes to ${cfg.refPrefix}*`,
    });
    await cleanup();
    return { again: null, status: "none" };
  }
  await record(verdict.status, { ...(verdict.url ? { url: verdict.url } : {}), ...(verdict.detail ? { detail: verdict.detail } : {}) });
  await cleanup();
  return { again: null, status: verdict.status };
}
