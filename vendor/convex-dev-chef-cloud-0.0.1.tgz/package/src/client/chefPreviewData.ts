/**
 * Previews with the admin's own data, the host's side (docs/chef-pipeline.md,
 * "Preview data"; the feedback component's chefPreviewData.ts).
 *
 * Off unless the app opts in (chefCloud's `previewData`, with its two hooks)
 * and an app admin turns "admin-copy" on. Then, before each preview deploy,
 * `prepareAdminCopy` runs the app's `exportForPreviewFunction` (an internal
 * query on this, the live deployment) for that admin's own rows only,
 * checks the answer names exactly that admin and fits the cap, and stores
 * it in the feedback component (once per run, audited by size and hash).
 * The deploy script then runs the app's `previewSeedFunction` on the
 * preview with the export's one-time URL and sha256, and signs the admin's
 * link in as the user it copied. The export is deleted once the preview is
 * made or the run ends.
 *
 * The contract, with an example, is in the docs. What's true either way:
 * the export runs only with the setting on, only for the admin it names,
 * never for another user; files are off unless the option says so.
 */
import type { FunctionReference } from "convex/server";
import type { ChefApis } from "./apis.js";
import type { RunCtx } from "./chefEffects.js";

type Chef = ChefApis;

export const DEFAULT_PREVIEW_EXPORT_BYTES = 4 * 1024 * 1024;
export const MAX_PREVIEW_EXPORT_BYTES = 8 * 1024 * 1024;

/** The app's export: an internal query on the live deployment. */
export type ExportForPreviewFunction = FunctionReference<
  "query",
  "internal",
  { userId: string; maxBytes: number; includeFiles: boolean },
  unknown
>;

export type PreviewDataOptions = {
  /**
   * The live deployment's export of one user's own rows: an internal query
   * taking `{ userId, maxBytes, includeFiles }` and answering a JSON object
   * whose `userId` is the one asked for (Chef checks), at most `maxBytes`
   * of JSON.
   */
  exportFunction: ExportForPreviewFunction;
  /**
   * The preview's import, as `module:function`: an internal action taking
   * `{ exportUrl, sha256, bytes }` that fetches the export, checks its
   * sha256, inserts it, and answers `{ userId }`, the copied user on the
   * preview. Keep it (and the export) in a file the build's guards protect,
   * such as convex/chefPipeline.ts, so no build can change them.
   */
  seedFunction: string;
  /** The export's cap in bytes of JSON. Default 4 MB, at most 8 MB. */
  maxBytes?: number;
  /** Whether the export may include files (the app decides what that means). Default false. */
  includeFiles?: boolean;
};

const FN = /^[A-Za-z0-9_][A-Za-z0-9_./]*(:[A-Za-z0-9_]+)?$/;

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes as BufferSource));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

/** The host's ctx for the export: it runs a query of the app's and stores through a component action. */
export type PreviewDataCtx = RunCtx & {
  runAction<F extends FunctionReference<"action", any>>(fn: F, args: F["_args"]): Promise<F["_returnType"]>;
};

/**
 * Before a preview deploy: the admin's export, made once and stored, and the
 * seed function's argument for the deploy script. Null when "admin-copy" is
 * off, or the export can't be made (the preview then has its demo data, and
 * the run's log says why).
 */
export async function prepareAdminCopy(
  ctx: PreviewDataCtx,
  chef: Chef,
  args: { runId: string; options: PreviewDataOptions; log?: (line: string) => Promise<void> },
): Promise<{ fn: string; args: string } | null> {
  const o = args.options;
  if (!FN.test(o.seedFunction)) throw new Error("previewData.seedFunction must be a function name");
  const log = args.log ?? (async () => {});
  const st = (await ctx.runQuery(chef.feedback.chefPreviewData.settingsForHost, {})) as { mode: string; userId: string | null };
  if (st.mode !== "admin-copy" || !st.userId) return null;
  let e = (await ctx.runQuery(chef.feedback.chefPreviewData.exportUrl, { runId: args.runId })) as {
    url: string;
    sha256: string;
    bytes: number;
    userId: string;
  } | null;
  if (!e || e.userId !== st.userId) {
    const maxBytes = Math.min(Math.max(1024, o.maxBytes ?? DEFAULT_PREVIEW_EXPORT_BYTES), MAX_PREVIEW_EXPORT_BYTES);
    let data: unknown;
    try {
      data = await ctx.runQuery(o.exportFunction, { userId: st.userId, maxBytes, includeFiles: o.includeFiles === true });
    } catch (err) {
      await log(`chef-launcher: the admin's data wasn't exported (${(err instanceof Error ? err.message : String(err)).slice(0, 200)}); the preview gets demo data`);
      return null;
    }
    if (!data || typeof data !== "object" || Array.isArray(data) || (data as { userId?: unknown }).userId !== st.userId) {
      await log("chef-launcher: the export didn't name exactly the admin who turned admin-copy on; nothing copied");
      return null;
    }
    const bytes = new TextEncoder().encode(JSON.stringify(data));
    if (bytes.length > maxBytes) {
      await log(`chef-launcher: the admin's export is ${bytes.length} bytes, over the ${maxBytes} cap; the preview gets demo data`);
      return null;
    }
    const sha256 = await sha256Hex(bytes);
    const r = (await ctx.runAction(chef.feedback.chefPreviewData.storeExport, {
      runId: args.runId,
      userId: st.userId,
      bytes: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer,
      sha256,
    })) as { stored: boolean; reason?: string };
    if (!r.stored) {
      await log(`chef-launcher: the admin's export wasn't stored (${r.reason ?? "refused"}); the preview gets demo data`);
      return null;
    }
    e = (await ctx.runQuery(chef.feedback.chefPreviewData.exportUrl, { runId: args.runId })) as typeof e;
    if (!e) return null;
    await log(`chef-launcher: the admin's own data exported (${bytes.length} bytes) for the preview`);
  }
  return { fn: o.seedFunction, args: JSON.stringify({ exportUrl: e.url, sha256: e.sha256, bytes: e.bytes }) };
}
