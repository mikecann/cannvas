/**
 * The demo video, the host's side (docs/chef-pipeline.md, "The demo video";
 * the feedback component's chefDemo.ts). After the preview deploys, a demo
 * sandbox plays the agent's demo script (data, checked twice:
 * src/chef/demo.ts) against the preview with the image's Playwright,
 * recording a phone and a desktop screen, at most 45 seconds each
 * (runner/demo-record.ts, delivered as chef-demo.mjs). Best effort: the
 * build is built either way, and a failure is a note on the card.
 *
 * The demo sandbox has no secret: the only credential it sees is the
 * throwaway demo session's one-time sign-in link, passed to that one
 * command's env (never argv, a mount or a row, and cleared from the run
 * after). Its egress is the preview's two hosts only, and the browser aborts
 * any other request. Each video comes back as base64 parts through
 * Daytona's file API, is checked by sha256 and size, and goes into the
 * feedback component's storage.
 */
import type { FunctionReference } from "convex/server";
import type { ChefApis } from "./apis.js";
import { deleteRoleSandboxes, ensureSandbox, effectGet, type EffectsDeps, type RunCtx } from "./chefEffects.js";
import { startOnce } from "./chefLauncher.js";
import { deliveredScriptCommand, demoDelivery, writeDelivery } from "@convex-dev/feedback/delivery";

type Chef = ChefApis;

/** The host's action ctx: the demo stores its videos through a component action. */
export type ActionRunCtx = RunCtx & {
  runAction<F extends FunctionReference<"action", any>>(fn: F, args: F["_args"]): Promise<F["_returnType"]>;
};

export const DEMO_OUT = "/tmp/chef-demo";
const SHA40 = /^[0-9a-f]{40}$/;
const SHA256 = /^[0-9a-f]{64}$/;
const DEPLOYMENT = /^https:\/\/([a-z0-9][a-z0-9-]{0,63})\.convex\.site$/;
const MAX_PARTS = 4;

export type DemoConfig = {
  /** The snapshot the sandbox starts from (chef-base: node, Playwright, Chromium). */
  snapshot: string;
  /** Default phone, then desktop. */
  viewports?: ("phone" | "desktop")[];
  /** Daytona deletes the sandbox on its own after this many minutes (default 20). */
  autoDeleteMinutes?: number;
};

/** The demo sandbox's egress: the preview's site and its backend, nothing else. */
export function demoEgress(deploymentName: string) {
  return { domainAllowList: [`${deploymentName}.convex.site`, `${deploymentName}.convex.cloud`] };
}

function fromBase64(text: string): Uint8Array {
  const bin = atob(text.trim());
  const out = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", bytes as BufferSource));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

type Video = {
  viewport: "phone" | "desktop";
  parts: number;
  bytes: number;
  sha256: string;
  durationMs: number;
  done: number;
  steps: number;
  failed?: { step: number; what: string; reason: string };
  timedOut?: boolean;
};

/** The recorder's result file, checked; null while there is none. */
export function parseDemoResult(raw: string | null): { ok: true; videos: Video[] } | { ok: false; error: string } | null {
  if (raw === null || raw.trim() === "") return null;
  let r: any;
  try {
    r = JSON.parse(raw);
  } catch {
    return { ok: false, error: "the demo's result is not JSON" };
  }
  if (!r || r.ok !== true) return { ok: false, error: typeof r?.error === "string" ? r.error.slice(0, 300) : "the demo failed" };
  const videos: Video[] = [];
  for (const x of Array.isArray(r.videos) ? r.videos.slice(0, 2) : []) {
    if (!x || (x.viewport !== "phone" && x.viewport !== "desktop")) continue;
    if (!Number.isInteger(x.parts) || x.parts < 1 || x.parts > MAX_PARTS || !SHA256.test(x.sha256 ?? "")) continue;
    videos.push({
      viewport: x.viewport,
      parts: x.parts,
      bytes: Number(x.bytes) || 0,
      sha256: x.sha256,
      durationMs: Math.max(0, Number(x.durationMs) || 0),
      done: Math.max(0, Number(x.done) || 0),
      steps: Math.max(0, Number(x.steps) || 0),
      ...(x.failed && typeof x.failed.what === "string" && typeof x.failed.reason === "string" && Number.isInteger(x.failed.step)
        ? // The reason carries what the page said (runner/demo-page.ts), scrubbed; 700 fits both.
          { failed: { step: x.failed.step, what: x.failed.what.slice(0, 200), reason: x.failed.reason.slice(0, 700) } }
        : {}),
      ...(x.timedOut === true ? { timedOut: true } : {}),
    });
  }
  return { ok: true, videos };
}

/**
 * Record the demo for a run whose preview is deployed, store the videos and
 * finish. Never throws for the demo's own problems; returns what happened.
 */
export async function driveDemo(
  ctx: ActionRunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: DemoConfig; wait: { sleep: (ms: number) => Promise<void>; pollMs?: number; untilMs: number; now?: () => number } },
): Promise<{ status: "none" | "recorded" | "failed"; videos?: number; note?: string }> {
  const info = (await ctx.runQuery(chef.feedback.chefDemo.forHost, { runId: args.runId })) as {
    status: string;
    commitSha: string | null;
    previewUrl: string | null;
    demoScript: { steps: unknown[] } | null;
    loginUrl: string | null;
    recorded: string[];
  } | null;
  if (!info || info.status !== "active") return { status: "none" };
  const finish = async (note?: string) => {
    await ctx.runMutation(chef.feedback.chefDemo.finish, { runId: args.runId, ...(note ? { note } : {}) });
  };
  if (!info.demoScript || info.demoScript.steps.length === 0) {
    await finish("The agent didn't write a demo script, so there's no video.");
    return { status: "none" };
  }
  if (info.recorded.length > 0) {
    await finish();
    return { status: "recorded", videos: info.recorded.length };
  }
  const m = DEPLOYMENT.exec(info.previewUrl ?? "");
  if (!m || !info.commitSha || !SHA40.test(info.commitSha)) {
    await finish("There's no preview to record.");
    return { status: "none" };
  }
  const deploymentName = m[1];
  const now = args.wait.now ?? Date.now;
  const fail = async (note: string) => {
    await finish(note);
    return { status: "failed" as const, note };
  };
  try {
    const sbx = await ensureSandbox(ctx, chef, deps.sandboxes, {
      runId: args.runId,
      role: "demo",
      spec: {
        snapshot: args.config.snapshot,
        ...demoEgress(deploymentName),
        autoStopInterval: 0,
        autoDeleteInterval: args.config.autoDeleteMinutes ?? 20,
      },
    });
    const d = await demoDelivery();
    const command = deliveredScriptCommand(d, "chef-demo.sh", info.commitSha);
    const started = await effectGet(ctx, chef, { runId: args.runId, key: "exec:demo" });
    if (started?.status !== "done") await writeDelivery(deps.sandboxes, sbx.id, d);
    const executionId = await startOnce(ctx, chef, deps.sandboxes, {
      runId: args.runId,
      key: "exec:demo",
      sandboxId: sbx.id,
      command,
      envs: {
        CHEF_DEMO_ORIGIN: `https://${deploymentName}.convex.site`,
        CHEF_DEMO_HOSTS: demoEgress(deploymentName).domainAllowList.join(","),
        CHEF_DEMO_SCRIPT: JSON.stringify(info.demoScript),
        CHEF_DEMO_OUT: DEMO_OUT,
        CHEF_DEMO_VIEWPORTS: (args.config.viewports ?? ["phone", "desktop"]).join(","),
        ...(info.loginUrl ? { CHEF_DEMO_LOGIN_URL: info.loginUrl } : {}),
      },
    });
    let result: ReturnType<typeof parseDemoResult> = null;
    for (;;) {
      result = parseDemoResult(await deps.sandboxes.readFile(sbx.id, `${DEMO_OUT}/result.json`));
      if (result) break;
      const e = await deps.sandboxes.execution(executionId);
      if (e && e.status !== "running") {
        result = parseDemoResult(await deps.sandboxes.readFile(sbx.id, `${DEMO_OUT}/result.json`));
        if (!result) return await fail(`The demo recorder stopped (${e.status}) without a video.`);
        break;
      }
      if (now() >= args.wait.untilMs) return await fail("The demo didn't finish in time.");
      await args.wait.sleep(args.wait.pollMs ?? 5000);
    }
    if (!result.ok) return await fail(`The demo couldn't be recorded: ${result.error}`);
    let stored = 0;
    for (const v of result.videos) {
      const chunks: Uint8Array[] = [];
      for (let i = 0; i < v.parts; i++) {
        const text = await deps.sandboxes.readFile(sbx.id, `${DEMO_OUT}/${v.viewport}.${i}.b64`);
        if (text === null) throw new Error(`part ${i} of the ${v.viewport} video is missing`);
        chunks.push(fromBase64(text));
      }
      const bytes = new Uint8Array(chunks.reduce((n, c) => n + c.length, 0));
      let at = 0;
      for (const c of chunks) {
        bytes.set(c, at);
        at += c.length;
      }
      if ((await sha256Hex(bytes)) !== v.sha256) continue;
      const r = (await ctx.runAction(chef.feedback.chefDemo.storeVideo, {
        runId: args.runId,
        viewport: v.viewport,
        bytes: bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) as ArrayBuffer,
        sha256: v.sha256,
        durationMs: v.durationMs,
        done: v.done,
        steps: v.steps,
        ...(v.failed ? { failed: v.failed } : {}),
        ...(v.timedOut ? { timedOut: true } : {}),
      })) as { stored: boolean };
      if (r.stored) stored++;
    }
    const failed = result.videos.find((v) => v.failed)?.failed;
    const note = stored === 0 ? "The demo ran but no video came back." : failed ? `The demo stopped at step ${failed.step + 1} (${failed.what}): ${failed.reason}` : undefined;
    await finish(note);
    return { status: stored > 0 ? "recorded" : "failed", videos: stored, ...(note ? { note } : {}) };
  } catch (e) {
    return await fail(`The demo couldn't be recorded: ${(e instanceof Error ? e.message : String(e)).slice(0, 200)}`);
  } finally {
    try {
      await deleteRoleSandboxes(deps.sandboxes, args.runId, "demo");
    } catch {
      // The run's cleanup and Daytona's auto-delete are the backstop.
    }
  }
}
