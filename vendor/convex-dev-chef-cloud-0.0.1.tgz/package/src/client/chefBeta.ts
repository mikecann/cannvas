/**
 * The beta channel, the host's side (docs/chef-pipeline.md, "The beta
 * channel"; the feedback component's chefBeta.ts). Off unless chefCloud's
 * `beta` option is set.
 *
 * A successful build is deployed to the app's persistent beta deployment,
 * after its throwaway preview (`mode: "also"`, the default, best effort) or
 * in place of it (`mode: "instead"`, the beta is then the run's preview and
 * a failed beta deploy fails the run). The deploy is the ship's: a deploy
 * sandbox with no agent and no repo code, the delivered
 * runner/chef-ship-deploy.sh, the frontend the build kept, and the beta's
 * deploy key (CHEF_BETA_DEPLOY_KEY by default) in that one command's env.
 * The key must be for a deployment other than this one: the beta is never
 * live. `main` doesn't move; "Promote to everyone" is Ship it.
 *
 * One deploy at a time (the component's lease). With "admin-copy" preview
 * data on, the first deploy to a beta seeds it with the admin's copy
 * (chefPreviewData.ts's export, the app's previewSeedFunction), once.
 */
import { classifyFailure } from "@convex-dev/feedback/chef/failures.js";
import type { ChefApis } from "./apis.js";
import {
  assertEgress,
  betaGitSecretName,
  deleteRoleSandboxes,
  DEAD_VALUE,
  ensureSandbox,
  effectGet,
  type EffectsDeps,
  type RunCtx,
} from "./chefEffects.js";
import { DEFAULT_FRONTEND_PREFIX, sendFrontend, startOnce } from "./chefLauncher.js";
import { shipEgress, shipStatus } from "./chefShip.js";
import { prepareAdminCopy, type PreviewDataCtx, type PreviewDataOptions } from "./chefPreviewData.js";
import { splitHostDeployKey } from "@convex-dev/feedback/chef/deployKey.js";
import { deliveredScriptCommand, shipDelivery, writeDelivery } from "@convex-dev/feedback/delivery";

type Chef = ChefApis;

export const DEFAULT_BETA_KEY_ENV = "CHEF_BETA_DEPLOY_KEY";
export const BETA_RESULT_FILE = "/tmp/chef-beta-result.json";
export const BETA_LOG_FILE = "/tmp/chef-beta.log";
/** A beta deploy that takes longer fails (the ship's limit). */
export const BETA_TIMEOUT_MS = 30 * 60_000;

export type BetaOptions = {
  /** The env var on this deployment holding the beta's deploy key. Default CHEF_BETA_DEPLOY_KEY. */
  deployKeyEnv?: string;
  /** Where beta testers open the beta (its frontend's https origin). */
  siteUrl: string;
  /** "also" (default): after the preview, best effort. "instead": the beta is the run's preview. */
  mode?: "also" | "instead";
};

export type BetaConfig = {
  gitHost: string;
  repoUrl: string;
  snapshot: string;
  siteUrl: string;
  /** The beta's deploy key, read from the env only here. */
  readKey: () => string | undefined;
  keyEnv: string;
  /** This deployment's name: the beta must be another one. */
  hostDeploymentName: string;
  frontend: boolean;
  mode: "also" | "instead";
  previewData?: PreviewDataOptions;
  migration?: string;
  /**
   * The app's previewLoginFunction, when the beta is the run's preview and
   * the demo video is on: the deploy asks it for the demo's one-time
   * sign-in link (CHEF_DEMO_LOGIN_FUNCTION), so the demo opens signed in.
   */
  demoLoginFunction?: string;
  gitTokenTtlSeconds?: number;
};

export type BetaStarted =
  | { status: "skipped"; note: string }
  | { status: "busy" }
  | { status: "done"; previewUrl: string | null }
  | { status: "started"; sandboxId: string; executionId: string; deploymentName: string };

function betaKey(cfg: BetaConfig) {
  const raw = cfg.readKey();
  if (!raw) throw new Error(`${cfg.keyEnv} is not set on this deployment (npx chef init --beta <deployment>)`);
  const k = splitHostDeployKey(raw);
  if (k.deploymentName === cfg.hostDeploymentName) {
    throw new Error(`${cfg.keyEnv} is for this deployment (${k.prefix}); the beta must be a deployment of its own`);
  }
  return { key: `${k.prefix}|${k.secret}`, prefix: k.prefix, deploymentName: k.deploymentName };
}

/** Clean up the beta deploy's sandbox and its git secret. Safe to repeat. */
export async function cleanupBeta(deps: EffectsDeps, runId: string): Promise<void> {
  await deleteRoleSandboxes(deps.sandboxes, runId, "beta");
  const name = await betaGitSecretName(runId);
  if ((await deps.secrets.listSecrets()).some((s) => s.name === name)) {
    await deps.secrets.setSecret(name, DEAD_VALUE);
    await deps.secrets.deleteSecret(name);
  }
}

/**
 * Start (or adopt) the beta deploy for a built run. `busy` while another
 * run's deploy holds the beta; `done` when this run is already on it.
 */
export async function startBeta(
  ctx: PreviewDataCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: { runId: string; config: BetaConfig; log?: (line: string) => Promise<void>; attempt?: number },
): Promise<BetaStarted> {
  // A second attempt (after a transient failure) is an effect of its own: a new sandbox, a new execution.
  const suffix = args.attempt && args.attempt > 1 ? ":2" : "";
  const cfg = args.config;
  // Checked before anything is recorded or created. Only the prefix is ever shown.
  const key = betaKey(cfg);
  const begun = (await ctx.runMutation(chef.feedback.chefBeta.begin, {
    runId: args.runId,
    deploymentName: key.deploymentName,
    siteUrl: cfg.siteUrl,
  })) as { status: "busy" } | { status: "done"; siteUrl: string } | { status: "inactive" } | { status: "go"; sha: string; baseSha: string; seedWanted: boolean };
  if (begun.status === "busy") return { status: "busy" };
  if (begun.status === "inactive") return { status: "skipped", note: "The run isn't active" };
  if (begun.status === "done") return { status: "done", previewUrl: `https://${key.deploymentName}.convex.site` };

  const egress = shipEgress(cfg);
  assertEgress(egress);
  const secretName = await betaGitSecretName(args.runId);
  const started = await effectGet(ctx, chef, { runId: args.runId, key: `exec:beta${suffix}` });
  if (started?.status !== "done") {
    if (!deps.git) throw new Error("No GitAuthApi: can't mint a Code Storage token");
    const value = await deps.git.basicAuth({ access: "read", ttlSeconds: cfg.gitTokenTtlSeconds ?? 600 });
    const r = await deps.secrets.createSecret({ name: secretName, value, hosts: [cfg.gitHost] });
    if (!r.created) await deps.secrets.setSecret(secretName, value);
  }
  const sbx = await ensureSandbox(ctx, chef, deps.sandboxes, {
    runId: args.runId,
    role: "beta",
    ...(suffix ? { attempt: 2 } : {}),
    spec: { snapshot: cfg.snapshot, secrets: { CHEF_GIT_AUTH: secretName }, ...egress, autoStopInterval: 0, autoDeleteInterval: 60 },
  });
  const delivery = await shipDelivery();
  const command = deliveredScriptCommand(delivery, "chef-ship-deploy.sh", begun.sha);

  let frontendEnvs: Record<string, string> = { CHEF_FRONTEND: "0" };
  let seedEnvs: Record<string, string> = {};
  if (started?.status !== "done") {
    if (cfg.frontend) {
      const fe = await sendFrontend(ctx, chef, deps, { runId: args.runId, sandboxId: sbx.id, sha: begun.sha, prefix: DEFAULT_FRONTEND_PREFIX });
      frontendEnvs = {
        CHEF_FRONTEND: "1",
        CHEF_FRONTEND_PREFIX: DEFAULT_FRONTEND_PREFIX,
        CHEF_FRONTEND_PARTS: String(fe.parts),
        CHEF_FRONTEND_SHA256: fe.sha256,
      };
    }
    // Seeded once per beta, from the admin's copy, when it's on.
    if (begun.seedWanted && cfg.previewData) {
      const seed = await prepareAdminCopy(ctx, chef, { runId: args.runId, options: cfg.previewData, ...(args.log ? { log: args.log } : {}) });
      if (seed) seedEnvs = { CHEF_SEED_FUNCTION: seed.fn, CHEF_SEED_ARGS: seed.args };
    }
    await writeDelivery(deps.sandboxes, sbx.id, delivery);
  }
  // The beta's key goes only into this one command's env: never the
  // sandbox's env, a mount, argv or a row. The script runs no repo code.
  const executionId = await startOnce(ctx, chef, deps.sandboxes, {
    runId: args.runId,
    key: `exec:beta${suffix}`,
    sandboxId: sbx.id,
    command,
    envs: {
      CHEF_DEPLOY_KEY: key.key,
      CHEF_DEPLOYMENT_NAME: key.deploymentName,
      CHEF_MAIN_SHA: begun.baseSha,
      CHEF_REPO_URL: cfg.repoUrl,
      CHEF_RESULT_FILE: BETA_RESULT_FILE,
      CHEF_LOG_FILE: BETA_LOG_FILE,
      CHEF_WORKDIR: "/tmp/chef-beta",
      ...frontendEnvs,
      ...seedEnvs,
      ...(cfg.migration !== undefined ? { CHEF_MIGRATION: cfg.migration } : {}),
      ...(cfg.demoLoginFunction !== undefined ? { CHEF_DEMO_LOGIN_FUNCTION: cfg.demoLoginFunction } : {}),
    },
  });
  return { status: "started", sandboxId: sbx.id, executionId, deploymentName: key.deploymentName };
}

/**
 * Poll the beta deploy until `untilMs`. Done (deployed or failed) records it,
 * drops the admin's export, and cleans up; otherwise `{ done: false }`.
 */
export async function awaitBeta(
  ctx: RunCtx,
  chef: Chef,
  deps: EffectsDeps,
  args: {
    runId: string;
    sandboxId: string;
    executionId: string;
    deploymentName: string;
    asPreview: boolean;
    /** When the deploy started (the step's startedAt): past BETA_TIMEOUT_MS it fails. */
    startedAt: number;
    /** 1, or 2 for the one try again after a transient failure. */
    attempt?: number;
    wait: { sleep: (ms: number) => Promise<void>; pollMs?: number; untilMs: number; now?: () => number };
  },
): Promise<{ done: boolean; ok?: boolean; previewUrl?: string | null; note?: string; retry?: boolean }> {
  const sha = ((await ctx.runQuery(chef.feedback.chefEffects.runInfo, { runId: args.runId })) as { commitSha: string | null } | null)?.commitSha ?? "";
  const now = args.wait.now ?? Date.now;
  const end = async (ok: boolean, note?: string, seeded?: boolean, demoLoginUrl?: string | null) => {
    const r = (await ctx.runMutation(chef.feedback.chefBeta.finish, {
      runId: args.runId,
      ok,
      ...(note ? { note } : {}),
      ...(seeded !== undefined ? { seeded } : {}),
      ...(demoLoginUrl ? { demoLoginUrl } : {}),
      ...(args.asPreview ? { asPreview: true } : {}),
    })) as { previewUrl: string | null } | null;
    await ctx.runMutation(chef.feedback.chefPreviewData.dropExport, { runId: args.runId });
    try {
      await cleanupBeta(deps, args.runId);
    } catch {
      // The run's cleanup and the sweep are the backstop.
    }
    return { done: true, ok, previewUrl: r?.previewUrl ?? null, ...(note ? { note } : {}) };
  };
  for (;;) {
    // shipStatus: a failure carries the script's own error line (from its
    // log) rather than just "exited without finishing".
    const st = await shipStatus(deps.sandboxes, {
      sandboxId: args.sandboxId,
      executionId: args.executionId,
      sha,
      deploymentName: args.deploymentName,
      config: { resultFile: BETA_RESULT_FILE, logFile: BETA_LOG_FILE },
    });
    if (st.status === "ok") {
      const seeded = st.result.seed === "skipped" ? undefined : st.result.seed === "ok";
      return await end(true, seeded === false ? "The admin's copy wasn't seeded into the beta" : undefined, seeded, st.result.demoLoginUrl);
    }
    if (st.status === "failed") {
      // A network failure (fetch failed, a reset connection) isn't the
      // build's: the deploy is tried once more, from a new sandbox, before
      // it counts (the workflow starts attempt 2).
      if ((args.attempt ?? 1) < 2 && classifyFailure(st.reason).kind === "transient") {
        try {
          await cleanupBeta(deps, args.runId);
        } catch {
          // The next attempt's sandbox has its own key; the sweep is the backstop.
        }
        return { done: false, retry: true, note: `The beta deploy failed for the network's reasons (${st.reason.slice(0, 200)}); trying it once more` };
      }
      return await end(false, `The beta deploy failed: ${st.reason.replace(/^the ship script/, "the deploy script")}`);
    }
    if (now() - args.startedAt > BETA_TIMEOUT_MS) return await end(false, "The beta deploy didn't finish in time");
    if (now() >= args.wait.untilMs) return { done: false };
    await args.wait.sleep(args.wait.pollMs ?? 5000);
  }
}
