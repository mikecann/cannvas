/**
 * Chef cloud builds in one call. @convex-dev/chef-cloud composes everything a
 * cloud build needs (Daytona, Code Storage and Resend in gateway mode, and
 * @convex-dev/workflow) as its own child components, next to
 * @convex-dev/feedback, so an app with just the feedback board installs none
 * of it. A host with cloud builds writes:
 *
 *   // convex/convex.config.ts
 *   app.use(feedback);
 *   app.use(chefCloud);
 *
 *   // convex/chef.ts, next to exposeChefApi
 *   import { chefCloud } from "@convex-dev/chef-cloud";
 *
 *   export const {
 *     chefStep, chefSweep, chefCleanup, chefRunStart, chefShipStart, chefReconcile, chefRepairApply,
 *     chefSetup, chefSetupStatus, chefEnableCloudBuilds, chefDisableCloudBuilds, chefCreateWorkerKey,
 *     chefSetAdmin, chefSetPreviewDeployKey, chefSetDeployKey, chefCancelRun, chefMigrateAgentKeys,
 *     chefRepoSetup, chefRepoUploadUrl, chefRepoPushPack, chefGitCredential, chefRepoRefs, chefIos,
 *     chefPlanBatches, chefCiCheck,
 *   } = chefCloud(components.feedback, components.chefCloud);
 *
 *   // convex/http.ts:   mountChefAgentRoutes(http, components.feedback);
 *
 * No crons: nothing here runs on a timer. A build starts when it is
 * approved, when the one before it finishes, and when cloud builds or
 * auto-build turn on; whatever can get stuck (a run, a ship) has one
 * deadline check scheduled for the moment it would be stuck; the cleanup
 * runs once when a run or a ship ends. `chefCrons` is a no-op kept for apps
 * whose convex/crons.ts still calls it.
 *
 * then runs `npx convex run chef:chefSetup` once (or `npx chef init --cloud`
 * does it all). Everything here is internal: only the deployment's own
 * functions and its CLI can call it.
 *
 * The two components never call each other. Everything between them happens
 * here, in the host's functions:
 *
 * - `chefStep` is the executor: the run's and the ship's workflows, in
 *   chef-cloud, call it by function handle for every step, so the steps run
 *   here, where the host's environment is (CONVEX_SITE_URL,
 *   CHEF_PREVIEW_DEPLOY_KEY, CHEF_DEPLOY_KEY), where both components are
 *   reachable, and where the host's options are (who gets the build email).
 *   The steps are the launcher's (src/client/chefLauncher.ts) in driveRun's
 *   order, and "Ship it"'s (src/client/chefShip.ts) in driveShip's, and the
 *   waits are polling slices of at most 7 minutes, since an action stops at 10.
 * - `chefRunStart`, `chefShipStart`, `chefReconcile`, `chefCleanup` and
 *   `chefPlanBatches` are what the feedback component schedules (setup
 *   registers their handles there): a claimed run's workflow, a "Ship to
 *   live"'s workflow, a stale or cancelled run's cleanup, the cleanup sweep
 *   once a run finished, and the batch planner when more than one approved
 *   request is waiting at a claim.
 *
 * Setup and chefSetupStatus check the feedback component's contract version
 * first (CHEF_CONTRACT_VERSION in @convex-dev/feedback), and refuse with a
 * clear message if it isn't the one this package was built for.
 */
import {
  createFunctionHandle,
  internalActionGeneric,
  internalMutationGeneric,
  makeFunctionReference,
  type Crons,
  type GenericActionCtx,
  type GenericMutationCtx,
} from "convex/server";
import { ConvexError, v } from "convex/values";
import { chefAdmin, OPERATOR_USER, NO_ADMIN } from "@convex-dev/feedback";
import type { ChefApis, CloudComponentApi, FeedbackComponentApi } from "./apis.js";
import {
  hostDeploymentName,
  readHostDeployKey,
  reconcileRun,
  runCleanupSweep,
  setDeployKey,
  setPreviewDeployKey,
  type EffectsDeps,
  type EmailApi,
  type SandboxApi,
} from "./chefEffects.js";
import {
  cleanupShip,
  failShip,
  finishShip,
  goLive as goLiveShip,
  recordDeploy,
  shipFailed,
  shipInfo,
  shipKnownValues,
  shipReached,
  shipStatus,
  startShip,
  verifyShip,
  type ShipConfig,
} from "./chefShip.js";
import { daytonaEffects, type DaytonaLike } from "./chefDaytona.js";
import { applyRepair, driveRepair } from "./chefRepair.js";
import { iosCiStep, type IosCiConfig } from "./chefIosCi.js";
import { driveDemo } from "./chefDemo.js";
import { prepareAdminCopy, type PreviewDataOptions } from "./chefPreviewData.js";
import { planBatches, vPlanArgs, type PlannerOptions } from "./chefPlanner.js";
import { DEFAULT_BETA_KEY_ENV, awaitBeta, cleanupBeta, startBeta, type BetaConfig, type BetaOptions } from "./chefBeta.js";
import {
  completePreview,
  failRun,
  finishBuilt,
  getRunInfo,
  goLive,
  launchBuild,
  previewFailed,
  previewKnownValues,
  previewRedeploy,
  previewStatus,
  retireBuildSandbox,
  retireDeploySandbox,
  runnerStatus,
  skipPreview,
  previewSkipOf,
  startPreview,
  syncBuildPhase,
  RunNotActive,
  type NotifyConfig,
  type PreviewConfig,
} from "./chefLauncher.js";

/** A step failure no retry can change: chefStep reports it as `terminal` instead of throwing. */
class Terminal extends Error {
  constructor(message: string) {
    super(message);
    this.name = "Terminal";
  }
}
import { DEFAULT_BASE_SNAPSHOT, RUNNER_VERSION, defaultRunnerJson } from "@convex-dev/feedback/delivery";
import { WARM_KEEP, buildWarmSnapshot, type WarmSettings } from "./chefWarm.js";
import {
  BUILT_PHASES,
  POLL_MS,
  SHIP_TIMEOUT_MS,
  SLICE_MS,
  vStepArgs,
  vStepResult,
  type StepArgs,
  type StepResult,
} from "../shared/cloudSteps.js";

type ActionCtx = GenericActionCtx<any>;
type MutationCtx = GenericMutationCtx<any>;

export { NO_ADMIN, OPERATOR_USER };

/**
 * The feedback component's contract version this package was built for
 * (CHEF_CONTRACT_VERSION in @convex-dev/feedback, src/chef/contract.ts). A
 * literal, not an import: it is what this build of chef-cloud speaks,
 * whatever @convex-dev/feedback the app has installed.
 */
export const FEEDBACK_CONTRACT = 16;

/**
 * Refuse unless the installed feedback component offers the contract this
 * package was built for. Run at setup and in chefSetupStatus.
 */
export async function checkFeedbackContract(
  ctx: { runQuery: (fn: any, args: any) => Promise<any> },
  feedback: FeedbackComponentApi,
): Promise<number> {
  const same = "Install @convex-dev/feedback and @convex-dev/chef-cloud from the same commit (README, \"Try it in your app\"), then push again.";
  let got: number;
  try {
    got = (await ctx.runQuery(feedback.contract.version, {})).version;
  } catch {
    throw new ConvexError(
      `@convex-dev/chef-cloud needs @convex-dev/feedback's contract ${FEEDBACK_CONTRACT}, and the installed @convex-dev/feedback ` +
        `has no contract version: it is older than this chef-cloud. ${same}`,
    );
  }
  if (got !== FEEDBACK_CONTRACT) {
    throw new ConvexError(
      `@convex-dev/chef-cloud needs @convex-dev/feedback's contract ${FEEDBACK_CONTRACT}, and the installed one offers ${got}: ` +
        `${got > FEEDBACK_CONTRACT ? "chef-cloud is older than feedback" : "feedback is older than chef-cloud"}. ${same}`,
    );
  }
  return got;
}

export type ChefCloudFrontend = false | { command: string[]; urlEnvVar: string; distDir: string };

export type ChefCloudOptions = {
  /** The app's name, in build emails. Default "your app". */
  appName?: string;
  /**
   * The Convex module these functions are exported from, under convex/
   * (default "chef", for convex/chef.ts next to exposeChefApi). Setup
   * registers `<module>:chefStep` as the executor.
   */
  module?: string;
  /**
   * The repo's name on Code Storage. Default "app": the gateway keeps each
   * deployment's repos apart, so this only has to be unique in this app.
   */
  repoName?: string;
  /**
   * The Daytona snapshot both sandboxes start from. Default: the
   * CHEF_RUNNER_SNAPSHOT env var if set, else the shared `chef-base-1`
   * image every team can use, with no app or Chef code in it.
   */
  snapshot?: string;
  /**
   * A runner baked into the snapshot (for example /opt/chef/bin/chef-runner).
   * Default: none, and the launcher delivers this package's runner into the
   * sandbox at run time and checks it there.
   */
  runnerPath?: string;
  /** A baked deploy script, likewise (for example /opt/chef/bin/chef-preview-deploy). */
  deployPath?: string;
  /** A baked "Ship it" script, likewise (for example /opt/chef/bin/chef-ship-deploy). */
  shipPath?: string;
  /**
   * Warm snapshots (docs/chef-pipeline.md, "Warm snapshots"): the app's own
   * Daytona snapshots, built in the background from the dependency files
   * committed to its repo (chef-base's recipe plus npm's cache, or pnpm's
   * store), so builds, previews and "Ship it" install offline instead of
   * from the registry. A sandbox uses one only when it's ready and made
   * from exactly its commit's lockfile; otherwise it starts from chef-base
   * as before. Each one is a snapshot on the team's Daytona storage (a few
   * GB); `keep` of them (default 2) at most. Default true; only with the
   * default snapshot and the delivered runner and scripts. The
   * CHEF_WARM_SNAPSHOTS env var set to 0 turns it off without a deploy.
   */
  warmSnapshots?: boolean | { keep?: number };
  /**
   * "Ship it", the panel's "Ship to live": deploys chef's commit to this
   * deployment with the key in CHEF_DEPLOY_KEY (chefSetDeployKey), then
   * moves `main`.
   */
  ship?: {
    /** A function to run once the backend is deployed, as `module:function` (a migration). */
    migration?: string;
    /** A function that throws unless the live app is healthy, as `module:function`. */
    healthCheck?: string;
    /** The live site to check. Default https://<deployment>.convex.site. */
    siteUrl?: string;
    /**
     * When a ship reaches production and then fails its checks, redeploy the
     * release before it on its own (main stays where it was). Default true.
     */
    autoRollback?: boolean;
  };
  /** Overrides merged over the delivered runner's config (runner.json) for chef-base. */
  runner?: Record<string, unknown>;
  /** Skills for the build agent, `{ name: SKILL.md text }`, delivered read-only. */
  skills?: Record<string, string>;
  /**
   * The checks after the agent. Default "auto": `npm run typecheck`, `npm
   * run lint` and `npm test`, each if package.json has that script.
   */
  gates?: "auto" | string[][];
  /** The frontend build. Default Vite: `npm run build`, VITE_CONVEX_URL, dist. `false` for none. */
  frontend?: ChefCloudFrontend;
  /**
   * Sets the env vars the app's convex.config requires on the agent's local
   * backend. Default "auto": `npm run chef:local-env` if package.json has it.
   */
  localEnv?: "auto" | false | string[];
  /**
   * Fix rounds: when a check that passed before the build fails after the
   * agent, the agent gets that check's output and another session, up to
   * this many times, within the run's spend cap and deadline. 0 to 5,
   * default 3. A check that already failed before the build never blocks it.
   */
  fixRounds?: number;
  /** The app's function that returns `{ url }`, a one-time sign-in link for a preview, as `module:function`. */
  previewLoginFunction?: string;
  /** A function to run on each new preview, as `module:function`. */
  seed?: string;
  /**
   * The demo video (docs/chef-pipeline.md, "The demo video"): after the
   * preview deploys, the agent's demo script is played in a browser on the
   * preview, signed in with a second one-time link from
   * previewLoginFunction, and recorded on a phone and a desktop screen, at
   * most 45 seconds each. Default on; `false` turns it off.
   */
  demo?: false | { viewports?: ("phone" | "desktop")[] };
  /**
   * Previews with the admin's own data (docs/chef-pipeline.md, "Preview
   * data"): the app's two hooks, an export on this deployment and an import
   * on the preview. Opt-in twice: nothing is copied until an app admin also
   * turns "admin-copy" on in the panel (default "demo"), and then only that
   * admin's own rows.
   */
  previewData?: PreviewDataOptions;
  /**
   * The beta channel (docs/chef-pipeline.md, "The beta channel"): a
   * persistent deployment of the app's own, for its beta testers. A
   * successful build is deployed there after its preview (`mode: "also"`,
   * the default) or instead of one (`"instead"`), with the deploy key in
   * `deployKeyEnv` (default CHEF_BETA_DEPLOY_KEY; `npx chef init --beta
   * <deployment>` makes it). The Ship card then says "Promote to
   * everyone". Off by default.
   */
  beta?: BetaOptions;
  /**
   * Chef's emails to the owner: a build is ready or failed, a release
   * shipped or didn't. Off unless `send` or `from` is set. With `send`,
   * every email goes through the app's own mailer. Otherwise, with `from`,
   * Chef sends through its bundled Resend component (packages/resend in the
   * marketplace), on a sending domain verified for this deployment.
   */
  notify?: {
    /**
     * The app's own mailer. Called from the host's step action, so it has
     * the app's ctx, env and components. Pass `idempotencyKey` on to the
     * provider: Chef records each key it sent and never calls `send` twice
     * for one, but a send whose response is lost is retried with the same
     * key. Return the provider's id if there is one. A throw is logged and
     * audited, and the build or ship goes on without the email.
     */
    send?: ChefSend;
    /** The sender for Chef's bundled Resend. Unused when `send` is set. */
    from?: string;
    /** The recipient, or a function that finds it (the owner's address). Null sends nothing. */
    to: string | ((ctx: ActionCtx) => Promise<string | null>);
    /** Where links point. Default: this deployment's .convex.site. */
    appUrl?: string;
    /** The page for one run. Default: the app itself, where the panel shows it. */
    runPageUrl?: (runId: string) => string;
    /**
     * A requester's address, for the short "it's live" email each person
     * whose request shipped gets (to `appUrl`). Null, or no function: no
     * email for them. The owner's own requests are left to the release email.
     */
    requesterEmail?: (ctx: ActionCtx, userId: string) => Promise<string | null>;
  };
  /**
   * Batching (docs/chef-pipeline.md, "Batching"): when more than one approved
   * request is waiting, one cheap model call (Haiku, through the Convex AI
   * gateway) groups the ones that touch the same part of the app into one
   * build, at most 4 to a build. On by default; `false` turns it off (every
   * request builds alone). An admin can also turn it off with the
   * component's `cloudBatching` setting.
   */
  batching?: false | PlannerOptions;
  /**
   * iOS CI (chefIosCi.ts, docs/ios-xcode-cloud.md): a built build that
   * changed the iOS app goes to the GitHub mirror as `chef-ios/<seq>` for an
   * Xcode Cloud workflow to build, and the Ship card shows the result. Needs
   * the mirror (CHEF_GITHUB_MIRROR, CHEF_GITHUB_TOKEN with Commit statuses: read) and
   * `chefCiCheck` exported. Off unless given.
   */
  iosCi?: IosCiConfig;
  /** The operator name the CLI functions write to the audit log. Default "cli". */
  operator?: string;
  /** Tests and custom setups: the adapters instead of the composed components. */
  deps?: (ctx: ActionCtx) => EffectsDeps;
  /** Tests: how long a wait step polls, and between polls. Defaults 7 minutes and 5 seconds. */
  timing?: { sliceMs?: number; pollMs?: number };
};

/** One of Chef's emails, as `notify.send` receives it: already built, escaped and scrubbed. */
export type ChefEmail = {
  to: string;
  subject: string;
  html: string;
  text: string;
  /** `chef-<runId>-built`, `release-<n>-shipped`, ...: pass it on to the provider. */
  idempotencyKey: string;
  kind: "built" | "failed" | "shipped" | "shipFailed" | "requestShipped" | "approvalNeeded" | (string & {});
};

/** chefCloud's `notify.send`: the app's own mailer. */
export type ChefSend = (ctx: ActionCtx, msg: ChefEmail) => Promise<{ id?: string } | void>;

/** Chef's EmailApi over the app's own mailer: best effort, the key as the id when there is none. */
export function sendEmailApi(ctx: ActionCtx, send: ChefSend): EmailApi {
  return {
    bestEffort: true,
    async send(m) {
      const r = await send(ctx, {
        to: m.to,
        subject: m.subject,
        html: m.html ?? "",
        text: m.text,
        idempotencyKey: m.idempotencyKey,
        kind: m.kind ?? "unknown",
      });
      const id = r && typeof r.id === "string" && r.id ? r.id : m.idempotencyKey;
      return { id };
    },
  };
}

export const DEFAULT_FRONTEND: Exclude<ChefCloudFrontend, false> = {
  command: ["npm", "run", "build"],
  urlEnvVar: "VITE_CONVEX_URL",
  distDir: "dist",
};

function readEnv(name: string): string | undefined {
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  return env?.[name];
}

const sleep = (ms: number) => (ms > 0 ? new Promise<void>((r) => setTimeout(r, ms)) : Promise.resolve());

/**
 * Chef's EffectsDeps over chef-cloud's children: Daytona through `providers`
 * (with daytonaEffects' semantics), Code Storage refs and git tokens through
 * `repo`, email through `providers` when `from` is set.
 */
export function composedDeps(ctx: ActionCtx, cloud: CloudComponentApi, email?: { from: string }): EffectsDeps {
  const p = cloud.providers;
  const daytona: DaytonaLike<ActionCtx> = {
    createSandbox: async (c, a) => {
      const { userKey: _userKey, ...rest } = a;
      return await c.runAction(p.createSandbox, rest);
    },
    deleteSandbox: async (c, a) => await c.runAction(p.deleteSandbox, a),
    listSandboxes: async (c, a) => await c.runAction(p.listSandboxes, a?.limit !== undefined ? { limit: a.limit } : {}),
    updateNetworkSettings: async (c, a) => await c.runAction(p.updateNetworkSettings, a),
    runBackground: async (c, a) => await c.runAction(p.runBackground, a),
    getExecution: async (c, a) => await c.runAction(p.getExecution, a),
    listExecutions: async (c, a) => await c.runAction(p.listExecutions, a),
    readFile: async (c, a) => await c.runAction(p.readFile, a),
    writeFile: async (c, a) => await c.runAction(p.writeFile, a),
    createSecret: async (c, a) => await c.runAction(p.createSecret, a),
    updateSecret: async (c, a) => await c.runAction(p.updateSecret, a),
    deleteSecret: async (c, a) => await c.runAction(p.deleteSecret, { name: a.name }),
    listSecrets: async (c) => await c.runAction(p.listSecrets, {}),
  };
  const { sandboxes, secrets } = daytonaEffects(daytona, ctx);
  const r = cloud.repo;
  const w = cloud.warm;
  return {
    sandboxes,
    secrets,
    warm: {
      readFiles: async ({ at, paths, hash }) => {
        const r = await ctx.runAction(w.readFiles, { ...at, paths, ...(hash ? { hash } : {}) });
        return {
          commit: r.commit,
          files: Object.fromEntries(r.files.map((f: { path: string; text: string | null }) => [f.path, f.text])),
          sha256: Object.fromEntries(r.sha256.map((f: { path: string; sha256: string | null }) => [f.path, f.sha256])),
        };
      },
      createSnapshot: async (a) => await ctx.runAction(w.createSnapshot, { ...a, context: a.context.map((f) => ({ ...f })) }),
      getSnapshot: async (name) => await ctx.runAction(w.getSnapshot, { name }),
      deleteSnapshot: async (name) => {
        await ctx.runAction(w.deleteSnapshot, { name });
      },
    },
    refs: {
      async readRefs(refs) {
        const rows = await ctx.runAction(r.readRefs, { refs });
        return Object.fromEntries(rows.map((x: { ref: string; sha: string | null }) => [x.ref, x.sha]));
      },
      async deleteRef(ref) {
        await ctx.runAction(r.deleteRef, { ref });
      },
      async updateRef(ref, { from, to }) {
        return await ctx.runAction(r.updateRef, { ref, from, to });
      },
      async mirror(a) {
        return await ctx.runAction(r.mirror, a);
      },
    },
    git: {
      async basicAuth({ access, ttlSeconds }) {
        return await ctx.runAction(r.basicAuth, { access, ttlSeconds });
      },
    },
    ...(email
      ? {
          email: {
            async send(m) {
              const id = await ctx.runMutation(p.sendEmail, { ...m, from: email.from });
              return { id: String(id) };
            },
          },
        }
      : {}),
  };
}

const vFrontend = v.union(
  v.literal(false),
  v.object({ command: v.array(v.string()), urlEnvVar: v.string(), distDir: v.string() }),
);

export function chefCloud(feedback: FeedbackComponentApi, cloud: CloudComponentApi, options: ChefCloudOptions = {}) {
  if (!feedback || !cloud || typeof (cloud as unknown as { orchestration?: unknown }).orchestration !== "object") {
    // Earlier versions took chefCloud(components.feedback, options).
    throw new Error(
      "chefCloud takes both components: chefCloud(components.feedback, components.chefCloud, options), " +
        "with app.use(chefCloud) from @convex-dev/chef-cloud/convex.config in convex/convex.config.ts",
    );
  }
  const chef: ChefApis = { feedback, cloud };
  const module = options.module ?? "chef";
  if (!/^[A-Za-z0-9_/]+$/.test(module)) throw new Error("module must be a path under convex/, like chefCloud or chef/cloud");
  const operator = options.operator ?? "cli";
  if (!/^[A-Za-z0-9_.:@-]{1,64}$/.test(operator)) throw new Error("operator must be a short name without spaces");
  const appName = options.appName ?? "your app";
  const repoName = options.repoName ?? "app";
  if (!/^[a-z0-9](?:[a-z0-9._-]{0,61}[a-z0-9])?$/.test(repoName) || repoName.endsWith(".git")) {
    throw new Error("repoName must be 1 to 63 of a-z, 0-9, '.', '_' or '-'");
  }
  const sliceMs = options.timing?.sliceMs ?? SLICE_MS;
  const pollMs = options.timing?.pollMs ?? POLL_MS;
  const gates = options.gates ?? "auto";
  const frontend = options.frontend ?? DEFAULT_FRONTEND;
  const localEnv = options.localEnv ?? "auto";
  const fixRounds = options.fixRounds;
  if (fixRounds !== undefined && (!Number.isInteger(fixRounds) || fixRounds < 0 || fixRounds > 5)) {
    throw new Error("fixRounds must be a whole number from 0 to 5");
  }
  const safeAppName = appName.replace(/[^A-Za-z0-9 ._-]/g, "").slice(0, 63).trim() || "app";
  const stepRef = makeFunctionReference<"action", StepArgs, StepResult>(`${module}:chefStep`);
  const runStartRef = makeFunctionReference<"mutation", { runId: string }, null>(`${module}:chefRunStart`);
  const shipStartRef = makeFunctionReference<"mutation", { releaseId: string }, null>(`${module}:chefShipStart`);
  const reconcileRef = makeFunctionReference<"action", { runId: string }, null>(`${module}:chefReconcile`);
  const repairApplyRef = makeFunctionReference<"action", { repairId: string }, null>(`${module}:chefRepairApply`);
  const ciCheckRef = makeFunctionReference<"action", { runId: string }, null>(`${module}:chefCiCheck`);
  const cleanupRef = makeFunctionReference<"mutation", Record<string, never>, null>(`${module}:chefCleanup`);
  const planRef = makeFunctionReference<"action", Record<string, unknown>, null>(`${module}:chefPlanBatches`);

  // Read when used, not captured here, so the options object stays the one source.
  const sendOf = () => options.notify?.send;
  const emailOn = () => !!(options.notify && (sendOf() || options.notify.from));

  const depsFor = (ctx: ActionCtx): EffectsDeps => {
    const send = sendOf();
    const from = options.notify?.from;
    const deps = options.deps
      ? options.deps(ctx)
      : composedDeps(ctx, cloud, !send && from ? { from } : undefined);
    // The app's own mailer, when it has one, sends every email Chef sends.
    return send ? { ...deps, email: sendEmailApi(ctx, send) } : deps;
  };

  const snapshot = () => options.snapshot ?? readEnv("CHEF_RUNNER_SNAPSHOT") ?? DEFAULT_BASE_SNAPSHOT;

  /**
   * Warm snapshots' settings, or undefined when they're off: by the option,
   * by CHEF_WARM_SNAPSHOTS=0, or because the sandboxes don't start from
   * chef-base with the delivered code (a warm snapshot repeats chef-base's
   * recipe, and the delivered installer is what checks its marker).
   */
  const warmSettings = (baked: string | undefined): WarmSettings | undefined => {
    const opt = options.warmSnapshots ?? true;
    if (opt === false || /^(0|false|off|no)$/i.test(readEnv("CHEF_WARM_SNAPSHOTS") ?? "")) return undefined;
    if (snapshot() !== DEFAULT_BASE_SNAPSHOT || baked !== undefined) return undefined;
    return { keep: typeof opt === "object" && opt.keep !== undefined ? opt.keep : WARM_KEEP };
  };

  /** The app's https origin for links in emails. */
  const appUrl = () => {
    const site = readEnv("CONVEX_SITE_URL");
    return (options.notify?.appUrl ?? site ?? "").replace(/\/$/, "");
  };

  /**
   * The run's config, from the host's environment, the component's record
   * of the repo, and the options. Throws with the setup step that's missing,
   * which fails the run with that message.
   */
  const config = async (ctx: ActionCtx): Promise<PreviewConfig & { notify?: NotifyConfig }> => {
    const site = readEnv("CONVEX_SITE_URL");
    if (!site) throw new Error("CONVEX_SITE_URL is not set: cloud builds run on a Convex cloud deployment");
    const repo = await ctx.runQuery(cloud.orchestration.config, {});
    if (!repo.repoUrl || !repo.gitHost) throw new Error("The app has no repo on Code Storage yet: run chefSetup");
    let notify: NotifyConfig | undefined;
    if (options.notify && emailOn()) {
      const n = options.notify;
      const to = typeof n.to === "function" ? await n.to(ctx) : n.to;
      const base = appUrl();
      if (to && base) {
        notify = {
          to,
          appName,
          runPageUrl: n.runPageUrl ?? (() => base),
          allowedLinkHosts: [/\.convex\.(cloud|site|app)$/, new URL(base).hostname],
        };
      }
    }
    return {
      siteHost: new URL(site).host,
      gitHost: repo.gitHost,
      repoUrl: repo.repoUrl,
      snapshot: snapshot(),
      ...(options.runnerPath !== undefined
        ? { runnerCommand: options.runnerPath }
        : {
            deliver: {
              runnerJson: { ...defaultRunnerJson({ skills: Object.keys(options.skills ?? {}).length > 0 }), ...options.runner },
              ...(options.skills ? { skills: options.skills } : {}),
            },
          }),
      ...(options.deployPath !== undefined ? { deployCommand: options.deployPath } : {}),
      ...(warmSettings(options.runnerPath ?? options.deployPath) ? { warm: warmSettings(options.runnerPath ?? options.deployPath) } : {}),
      frontend: frontend !== false,
      ...(options.previewLoginFunction !== undefined ? { loginLinkFunction: options.previewLoginFunction } : {}),
      ...(options.demo !== false ? { demo: options.demo ?? {} } : {}),
      ...(options.seed !== undefined ? { seed: options.seed } : {}),
      ...(notify ? { notify } : {}),
    };
  };

  /** "Ship it"'s config: the same repo, snapshot and email, the ship options. */
  const shipConfig = async (ctx: ActionCtx): Promise<ShipConfig> => {
    const repo = await ctx.runQuery(cloud.orchestration.config, {});
    if (!repo.repoUrl || !repo.gitHost) throw new Error("The app has no repo on Code Storage yet: run chefSetup");
    let notify: ShipConfig["notify"];
    if (options.notify && emailOn()) {
      const n = options.notify;
      const to = typeof n.to === "function" ? await n.to(ctx) : n.to;
      const base = appUrl();
      if (to && base) {
        notify = {
          to,
          appName,
          panelUrl: base,
          appUrl: base,
          allowedLinkHosts: [/\.convex\.(cloud|site|app)$/, new URL(base).hostname],
          ...(n.requesterEmail ? { requesterEmail: (userId: string) => n.requesterEmail!(ctx, userId) } : {}),
        };
      }
    }
    return {
      gitHost: repo.gitHost,
      repoUrl: repo.repoUrl,
      snapshot: snapshot(),
      ...(options.shipPath !== undefined ? { shipCommand: options.shipPath } : { deliver: true }),
      ...(warmSettings(options.shipPath) ? { warm: warmSettings(options.shipPath) } : {}),
      frontend: frontend !== false,
      ...(options.ship?.migration !== undefined ? { migration: options.ship.migration } : {}),
      ...(options.ship?.healthCheck !== undefined ? { healthCheck: options.ship.healthCheck } : {}),
      ...(options.ship?.siteUrl !== undefined ? { siteUrl: options.ship.siteUrl } : {}),
      ...(options.ship?.autoRollback === false ? { autoRollback: false } : {}),
      ...(notify ? { notify } : {}),
    };
  };

  /** The beta channel's config: the same repo and snapshot, the beta's key read only here. */
  const betaConfig = async (ctx: ActionCtx, deps: EffectsDeps): Promise<BetaConfig> => {
    const b = options.beta;
    if (!b) throw new Error("No beta channel is configured");
    const repo = await ctx.runQuery(cloud.orchestration.config, {});
    if (!repo.repoUrl || !repo.gitHost) throw new Error("The app has no repo on Code Storage yet: run chefSetup");
    const keyEnv = b.deployKeyEnv ?? DEFAULT_BETA_KEY_ENV;
    return {
      gitHost: repo.gitHost,
      repoUrl: repo.repoUrl,
      snapshot: snapshot(),
      siteUrl: b.siteUrl,
      keyEnv,
      readKey: () => (deps.betaDeployKey ? deps.betaDeployKey() : readEnv(keyEnv)),
      hostDeploymentName: hostDeploymentName(deps),
      frontend: frontend !== false,
      mode: b.mode ?? "also",
      ...(options.previewData ? { previewData: options.previewData } : {}),
      ...(options.ship?.migration !== undefined ? { migration: options.ship.migration } : {}),
      // The beta as the run's preview: its demo video needs a sign-in link too.
      ...((b.mode ?? "also") === "instead" && options.demo !== false && options.previewLoginFunction !== undefined
        ? { demoLoginFunction: options.previewLoginFunction }
        : {}),
    };
  };

  const liveSiteUrl = (deps: EffectsDeps, cfg: Pick<ShipConfig, "siteUrl">) =>
    cfg.siteUrl ?? `https://${readHostDeployKey(deps).deploymentName}.convex.site`;

  const requireActive = async (ctx: ActionCtx, runId: string) => {
    const info = await getRunInfo(ctx, chef, runId);
    if (info.status !== "active") throw new Terminal(`Run is ${info.status}, not active`);
    return info;
  };

  const checkExecution = async (sandboxes: SandboxApi, executionId: string, what: string) => {
    const e = await sandboxes.execution(executionId);
    if (e && e.status !== "running") {
      throw new Terminal(`The ${what} exited (${e.status}${e.exitCode !== undefined ? `, code ${e.exitCode}` : ""})`);
    }
  };

  const need = <T>(x: T | undefined, what: string): T => {
    if (x === undefined) throw new Terminal(`step is missing ${what}`);
    return x;
  };

  /** One step of a run, as the component's workflow asks for it. Every step is safe to repeat. */
  const runStep = async (ctx: ActionCtx, a: StepArgs): Promise<StepResult> => {
    const deps = depsFor(ctx);
    switch (a.op) {
      case "begin": {
        const info = await getRunInfo(ctx, chef, need(a.runId, "runId"));
        return {
          active: info.status === "active",
          built: BUILT_PHASES.includes(info.phase),
          ...(options.beta ? { beta: options.beta.mode ?? "also" } : {}),
          ...(info.releaseMerge ? { releaseMerge: true } : {}),
        };
      }
      case "launch": {
        // GET /chef-agent/run hands out what this code says now.
        await syncRunnerConfig(ctx);
        const r = await launchBuild(ctx, chef, deps, { runId: need(a.runId, "runId"), config: await config(ctx) });
        return { sandboxId: r.sandboxId, executionId: r.executionId };
      }
      case "awaitSelfTest": {
        const runId = need(a.runId, "runId");
        const sandboxId = need(a.sandboxId, "sandboxId");
        const executionId = need(a.executionId, "executionId");
        const cfg = await config(ctx);
        const { deadline } = await requireActive(ctx, runId);
        const until = Date.now() + sliceMs;
        for (;;) {
          const st = await runnerStatus(deps.sandboxes, { runId, sandboxId, config: cfg });
          if (st.failed) throw new Terminal(st.selfTest === "failed" ? `Egress self-test failed: ${st.failed}` : st.failed);
          if (st.selfTest === "passed") return { passed: true };
          await checkExecution(deps.sandboxes, executionId, "runner");
          if (Date.now() > deadline) throw new Terminal("The run passed its deadline");
          if (Date.now() + pollMs >= until) return { passed: false };
          await sleep(pollMs);
        }
      }
      case "live": {
        const r = await goLive(ctx, chef, deps, {
          runId: need(a.runId, "runId"),
          sandboxId: need(a.sandboxId, "sandboxId"),
          config: await config(ctx),
        });
        return { applied: r.applied, appliedAt: Date.now() };
      }
      case "follow": {
        const runId = need(a.runId, "runId");
        const sandboxId = need(a.sandboxId, "sandboxId");
        const executionId = need(a.executionId, "executionId");
        const cfg = await config(ctx);
        const { deadline } = await getRunInfo(ctx, chef, runId);
        const until = Date.now() + sliceMs;
        let applied = a.applied ?? null;
        let appliedAt = a.appliedAt ?? 0;
        for (;;) {
          const r = await syncBuildPhase(ctx, chef, deps, { runId, sandboxId, config: cfg, applied, appliedAt });
          applied = r.applied;
          appliedAt = r.appliedAt;
          if (BUILT_PHASES.includes(r.phase)) return { done: true, phase: r.phase, applied, appliedAt };
          const st = await runnerStatus(deps.sandboxes, { runId, sandboxId, config: cfg });
          if (st.failed) throw new Terminal(st.failed);
          await checkExecution(deps.sandboxes, executionId, "runner");
          if (Date.now() > deadline) throw new Terminal("The run passed its deadline");
          if (Date.now() + pollMs >= until) return { done: false, phase: r.phase, applied, appliedAt };
          await sleep(pollMs);
        }
      }
      case "retire": {
        await retireBuildSandbox(ctx, chef, deps, { runId: need(a.runId, "runId") });
        return {};
      }
      case "preview": {
        const runId = need(a.runId, "runId");
        // A change the web preview can't show: no preview, and no admin's
        // export made for one (src/chef/preview.ts).
        const info = await requireActive(ctx, runId);
        const skip = previewSkipOf(info);
        if (skip) {
          await skipPreview(ctx, chef, deps, { runId, skip });
          return { noPreview: true };
        }
        let cfg = await config(ctx);
        // "admin-copy": the admin's own rows, exported once for this preview.
        if (options.previewData) {
          const seed = await prepareAdminCopy(ctx, chef, {
            runId,
            options: options.previewData,
            log: async (line) => {
              await ctx.runMutation(feedback.chefEffects.appendRunLog, { runId, lines: [line] });
            },
          });
          if (seed) cfg = { ...cfg, previewSeed: seed };
        }
        const started = await startPreview(ctx, chef, deps, { runId, config: cfg, ...(a.attempt ? { attempt: a.attempt } : {}) });
        if (started.skipped) return { noPreview: true };
        if (started.reused) {
          await retireDeploySandbox(ctx, chef, deps, { runId });
          return { reused: true, previewUrl: started.previewUrl };
        }
        return { reused: false, sandboxId: started.sandboxId, executionId: started.executionId, sha: started.sha };
      }
      case "awaitPreview": {
        const runId = need(a.runId, "runId");
        const sandboxId = need(a.sandboxId, "sandboxId");
        const executionId = need(a.executionId, "executionId");
        const sha = need(a.sha, "sha");
        const cfg = await config(ctx);
        const until = Date.now() + sliceMs;
        const known = previewKnownValues(deps);
        const { itemNumber } = await getRunInfo(ctx, chef, runId);
        for (;;) {
          const st = await previewStatus(deps.sandboxes, { sandboxId, executionId, sha, itemNumber, config: cfg, known });
          if (st.status === "ok") {
            const rec = await completePreview(ctx, chef, deps, {
              runId,
              sha,
              previewName: st.previewName,
              deploymentName: st.deploymentName,
              ...(st.loginUrl ? { loginUrl: st.loginUrl } : {}),
              ...(st.demoLoginUrl ? { demoLoginUrl: st.demoLoginUrl } : {}),
            });
            // The admin's export goes as soon as the preview has (or hasn't) taken it.
            await ctx.runMutation(feedback.chefPreviewData.dropExport, {
              runId,
              ...(st.adminCopy !== undefined ? { seeded: st.adminCopy } : {}),
            });
            return { done: true, previewUrl: rec.previewUrl };
          }
          if (st.status === "failed") {
            // The platform's failure: deploy it again (src/chef/recovery.ts).
            if (await previewRedeploy(ctx, chef, deps, { runId, status: st, attempt: a.attempt ?? 1 })) {
              return { done: false, previewUrl: null, redeploy: true };
            }
            throw await previewFailed(ctx, chef, { runId, status: st });
          }
          const info = await requireActive(ctx, runId);
          if (Date.now() > info.deadline) throw new Terminal("The run passed its deadline");
          // Nothing inside the deploy sandbox reports to Chef; keep the run fresh.
          await ctx.runMutation(feedback.chefEffects.orchestratorHeartbeat, { runId });
          if (Date.now() + pollMs >= until) return { done: false, previewUrl: null };
          await sleep(pollMs);
        }
      }
      case "demo": {
        if (options.demo === false) return {};
        const runId = need(a.runId, "runId");
        await driveDemo(ctx, chef, deps, {
          runId,
          config: { snapshot: snapshot(), ...(options.demo?.viewports ? { viewports: options.demo.viewports } : {}) },
          wait: { sleep, pollMs, untilMs: Date.now() + sliceMs },
        });
        return {};
      }
      case "beta": {
        const runId = need(a.runId, "runId");
        if (!options.beta) return { outcome: "skipped" };
        // The beta is a web deploy too: a change it can't show doesn't go there.
        {
          const info = await requireActive(ctx, runId);
          const skip = previewSkipOf(info);
          if (skip) {
            await skipPreview(ctx, chef, deps, { runId, skip });
            return { noPreview: true };
          }
        }
        const instead = options.beta.mode === "instead";
        const cfg = await betaConfig(ctx, deps);
        const log = async (line: string) => {
          await ctx.runMutation(feedback.chefEffects.appendRunLog, { runId, lines: [line] });
        };
        try {
          if (instead) {
            const info = await requireActive(ctx, runId);
            if (info.phase === "pushed") await ctx.runMutation(feedback.chefEffects.setPhase, { runId, from: "pushed", to: "previewing" });
          }
          const until = Date.now() + sliceMs;
          for (;;) {
            const r = await startBeta(ctx, chef, deps, { runId, config: cfg, log, ...(a.attempt ? { attempt: a.attempt } : {}) });
            if (r.status === "started") {
              await log(`chef-launcher: deploying to the beta (${r.deploymentName})`);
              return { sandboxId: r.sandboxId, executionId: r.executionId, deploymentName: r.deploymentName, startedAt: Date.now() };
            }
            if (r.status === "done") return { done: true, previewUrl: r.previewUrl };
            if (r.status === "skipped") return { outcome: "skipped" };
            // Another build's deploy holds the beta.
            if (Date.now() + pollMs >= until) return {};
            await sleep(pollMs);
          }
        } catch (e) {
          const why = (e instanceof Error ? e.message : String(e)).slice(0, 300);
          await log(`chef-launcher: the beta deploy didn't start: ${why}`);
          await ctx.runMutation(feedback.chefBeta.finish, { runId, ok: false, note: `The beta deploy didn't start: ${why}` });
          await cleanupBeta(deps, runId).catch(() => {});
          if (instead) throw e;
          return { outcome: "skipped" };
        }
      }
      case "awaitBeta": {
        const runId = need(a.runId, "runId");
        const r = await awaitBeta(ctx, chef, deps, {
          runId,
          sandboxId: need(a.sandboxId, "sandboxId"),
          executionId: need(a.executionId, "executionId"),
          deploymentName: need(a.deploymentName, "deploymentName"),
          startedAt: need(a.startedAt, "startedAt"),
          asPreview: options.beta?.mode === "instead",
          ...(a.attempt ? { attempt: a.attempt } : {}),
          wait: { sleep, pollMs, untilMs: Date.now() + sliceMs },
        });
        if ((r.done || r.retry) && r.note) await ctx.runMutation(feedback.chefEffects.appendRunLog, { runId, lines: [`chef-launcher: ${r.note}`] });
        if (r.retry) return { done: false, retry: true };
        if (r.done && !r.ok && options.beta?.mode === "instead") throw new Error(r.note ?? "The beta deploy failed");
        return r.done ? { done: true, previewUrl: r.previewUrl ?? null } : { done: false };
      }
      case "finishMerge": {
        const runId = need(a.runId, "runId");
        const info = await getRunInfo(ctx, chef, runId);
        if (!info.releaseMerge) throw new Terminal("Not a release merge");
        const r = (await ctx.runMutation(feedback.chefEffects.finishActive, { runId, outcome: "built" })) as { finished: boolean };
        return { finished: r.finished };
      }
      case "finish": {
        const runId = need(a.runId, "runId");
        const r = await finishBuilt(ctx, chef, deps, { runId, config: await config(ctx) });
        // iOS CI: chefCiCheck decides whether this build goes (it changed the app, there's a mirror).
        if (r.finished && options.iosCi) {
          try {
            await ctx.scheduler.runAfter(0, ciCheckRef, { runId });
          } catch (e) {
            console.error(`Chef: iOS CI wasn't started for run ${runId} (export chefCiCheck): ${e instanceof Error ? e.message : String(e)}`);
          }
        }
        return { finished: r.finished, emailId: r.emailId };
      }
      case "fail": {
        let cfg: { notify?: NotifyConfig };
        try {
          cfg = await config(ctx);
        } catch {
          cfg = {}; // a missing setup step: fail without the email
        }
        const runId = need(a.runId, "runId");
        const r = await failRun(ctx, chef, deps, { runId, config: cfg, error: need(a.error, "error") });
        // A repo problem Chef can fix mechanically: make the repair commit
        // and offer it (src/chef/recovery.ts, appFixable). Never fatal.
        try {
          const repo = await ctx.runQuery(cloud.orchestration.config, {});
          if (repo.repoUrl && repo.gitHost) {
            await driveRepair(ctx, chef, deps, {
              runId,
              config: { gitHost: repo.gitHost, repoUrl: repo.repoUrl, snapshot: snapshot(), operator: `chef-cloud:${operator}` },
              wait: { sleep, pollMs, untilMs: Date.now() + sliceMs },
            });
          }
        } catch (e) {
          console.error(`Chef: the repair for run ${runId} wasn't made: ${e instanceof Error ? e.message : String(e)}`);
        }
        return { finished: r.finished };
      }
      case "reconcile": {
        const r = await reconcileRun(ctx, chef, deps, need(a.runId, "runId"));
        return { finished: r.finished, pushedToChef: r.pushedToChef };
      }
      case "cleanup": {
        const r = await runCleanupSweep(ctx, chef, deps);
        // The next request branch to expire: chef-cloud sweeps once more then.
        const nextBranchAt: number | null = await ctx.runQuery(feedback.chefEffects.nextBranchExpiry, {});
        return { sandboxes: r.sandboxes.length, secrets: r.secrets.length, branches: r.branches, nextBranchAt };
      }
      case "settle": {
        // The run's workflow failed or was cancelled: a run still active goes to reconciliation.
        const settled = await ctx.runMutation(feedback.chefWatchdog.workflowEnded, { runId: need(a.runId, "runId"), error: a.error ?? "stopped" });
        return { finished: false, done: settled };
      }
      case "shipBegin": {
        const info = await shipInfo(ctx, chef, need(a.releaseId, "releaseId"));
        const siteUrl = options.ship?.siteUrl ?? null;
        if (!info.open && info.state === "done") return { done: true, verified: true, siteUrl };
        return { done: false, verified: shipReached(info.state, "verified"), siteUrl };
      }
      case "shipStart": {
        const cfg = await shipConfig(ctx);
        const started = await startShip(ctx, chef, deps, { releaseId: need(a.releaseId, "releaseId"), config: cfg });
        if ("following" in started) return { following: true, outcome: started.reason };
        return {
          sandboxId: started.sandboxId,
          executionId: started.executionId,
          deploymentName: started.deploymentName,
          siteUrl: cfg.siteUrl ?? `https://${started.deploymentName}.convex.site`,
          startedAt: Date.now(),
        };
      }
      case "shipAwait": {
        const releaseId = need(a.releaseId, "releaseId");
        const cfg = await shipConfig(ctx);
        const info = await shipInfo(ctx, chef, releaseId);
        const sandboxId = need(a.sandboxId, "sandboxId");
        const executionId = need(a.executionId, "executionId");
        const deploymentName = need(a.deploymentName, "deploymentName");
        const siteUrl = a.siteUrl ?? cfg.siteUrl ?? `https://${deploymentName}.convex.site`;
        const deadline = need(a.startedAt, "startedAt") + SHIP_TIMEOUT_MS;
        const until = Date.now() + sliceMs;
        const known = shipKnownValues(deps);
        for (;;) {
          const st = await shipStatus(deps.sandboxes, { sandboxId, executionId, sha: info.sha, deploymentName, config: cfg, known });
          if (st.result) await recordDeploy(ctx, chef, { releaseId, config: cfg, result: st.result });
          if (st.status === "ok") {
            await verifyShip(ctx, chef, deps, { releaseId, config: cfg, result: st.result, siteUrl });
            return { done: true };
          }
          if (st.status === "failed") throw await shipFailed(ctx, chef, { releaseId, status: st });
          if (Date.now() > deadline) throw new Terminal("The ship script took too long");
          if (Date.now() + pollMs >= until) return { done: false };
          await sleep(pollMs);
        }
      }
      case "shipLive": {
        const went = await goLiveShip(ctx, chef, deps, { releaseId: need(a.releaseId, "releaseId"), config: await shipConfig(ctx) });
        return went ? { following: true, outcome: went.reason } : {};
      }
      case "shipFinish": {
        const cfg = await shipConfig(ctx);
        const siteUrl = a.siteUrl ?? liveSiteUrl(deps, cfg);
        const r = await finishShip(ctx, chef, deps, { releaseId: need(a.releaseId, "releaseId"), config: cfg, siteUrl });
        return { emailId: r.emailId, siteUrl };
      }
      case "shipFail": {
        let cfg: ShipConfig;
        try {
          cfg = await shipConfig(ctx);
        } catch {
          cfg = { gitHost: "", repoUrl: "", snapshot: "" }; // a missing setup step: no email
        }
        const r = await failShip(ctx, chef, deps, {
          releaseId: need(a.releaseId, "releaseId"),
          config: cfg,
          error: need(a.error, "error"),
        });
        return { outcome: r.outcome };
      }
      case "warmBuild": {
        // Scheduled by chef-cloud's warm.request, once per key; never part of a run.
        const r = await buildWarmSnapshot(ctx, chef, deps, {
          key: need(a.key, "key"),
          settings: warmSettings(options.runnerPath ?? options.deployPath ?? options.shipPath),
        });
        return { state: r.state };
      }
      case "shipCleanup": {
        let cfg: ShipConfig;
        try {
          cfg = await shipConfig(ctx);
        } catch {
          cfg = { gitHost: "", repoUrl: "", snapshot: "" };
        }
        const r = await cleanupShip(ctx, chef, deps, { releaseId: need(a.releaseId, "releaseId"), config: cfg });
        return { sandboxes: r.sandboxes.length };
      }
    }
  };

  /** The CLI's admin identity in Chef, for the functions that act as an admin. */
  const operatorAdmin = async (ctx: MutationCtx | ActionCtx): Promise<string> => {
    await ctx.runMutation(feedback.users.setRole, { userId: OPERATOR_USER, role: "admin" });
    return OPERATOR_USER;
  };

  /** An admin to act as: the one given (checked by the component), else the CLI's. */
  const actingAdmin = async (ctx: MutationCtx | ActionCtx, adminUserId: string | undefined) =>
    adminUserId ?? (await operatorAdmin(ctx));

  /** Unrevoked Chef agent keys of one kind ("cloud" turns cloud builds on; "worker" is for `npx chef work`). */
  const liveKeys = async (ctx: MutationCtx | ActionCtx, adminUserId: string, kind: "cloud" | "worker") =>
    (await ctx.runQuery(feedback.chefAgentKeys.list, { viewer: adminUserId })).filter(
      (k: { revokedAt?: number; kind: string }) => k.revokedAt === undefined && k.kind === kind,
    );

  /** One audit row in the feedback component's log, for something done here on Chef's behalf. */
  const audit = async (
    ctx: MutationCtx | ActionCtx,
    e: {
      actor?: string;
      action: string;
      outcome: "ok" | "refused" | "error";
      target?: string;
      reason?: string;
      detail?: Record<string, string | number | boolean | null>;
    },
  ) => {
    const { actor, ...rest } = e;
    await ctx.runMutation(feedback.chefAudit.record, { actor: actor ?? `operator:${operator}`, ...rest });
  };

  /** Our own messages, cut short, for the audit log. */
  const reasonOf = (e: unknown) => (e instanceof Error ? e.message : String(e)).slice(0, 300);

  /**
   * What GET /chef-agent/run hands any runner: the repo URL chef-cloud
   * recorded and this code's gates, frontend and local env, in the feedback
   * component (chefRunnerConfig). Writes only when something changed.
   */
  const syncRunnerConfig = async (ctx: MutationCtx | ActionCtx) => {
    const repo = await ctx.runQuery(cloud.orchestration.config, {});
    await ctx.runMutation(feedback.chefRunnerConfig.set, {
      ...(repo.repoUrl ? { repoUrl: repo.repoUrl } : {}),
      gates,
      frontend,
      localEnv,
      fixRounds: fixRounds ?? 3,
      // The build's screenshots sign in with the same function previews use.
      ...(options.previewLoginFunction !== undefined ? { loginFunction: options.previewLoginFunction } : {}),
    });
  };

  /** A handle to one of this module's own functions, or a message saying which export is missing. */
  const handleTo = async (ref: Parameters<typeof createFunctionHandle>[0], name: string) => {
    try {
      return await createFunctionHandle(ref);
    } catch {
      throw new ConvexError(
        `No function ${module}:${name}: export ${name} from convex/${module}.ts (\`npx chef init --write\` adds it), ` +
          "or pass chefCloud's `module` option",
      );
    }
  };

  /**
   * Check the feedback component's contract, register `<module>:chefStep` as
   * chef-cloud's executor, and register this module's chefRunStart,
   * chefReconcile and chefShipStart with the feedback component as its
   * orchestrator, reconciler and shipper; then the runner settings. Safe to
   * repeat.
   */
  /**
   * The cleanup once each run finishes (chefCleanup), in place of an hourly
   * cron. Optional like the applier: without it, `npx chef cleanup` (or
   * chefCleanup by hand) is the only sweep. Setup registers it, and so does
   * each run's start, so an app upgraded from chefCrons gets it on its next
   * build without running setup again. A no-op when it's already the one.
   */
  const registerCleaner = async (ctx: MutationCtx | ActionCtx): Promise<boolean> => {
    try {
      await ctx.runMutation(feedback.chefEffects.setCleaner, { handle: await createFunctionHandle(cleanupRef) });
      return true;
    } catch {
      return false;
    }
  };

  /**
   * The batch planner (chefPlanBatches), or none with `batching: false`.
   * Like the cleanup: setup registers it, and so does each run's start, so
   * an upgraded app batches from its next build on; an app that hasn't
   * exported chefPlanBatches yet builds each request alone. A no-op when
   * it's already the one.
   */
  const registerPlanner = async (ctx: MutationCtx | ActionCtx): Promise<boolean> => {
    try {
      const handle = options.batching === false ? null : await createFunctionHandle(planRef);
      await ctx.runMutation(feedback.chefBatches.setPlanner, { handle });
      return true;
    } catch {
      return false;
    }
  };

  const register = async (ctx: MutationCtx | ActionCtx) => {
    await checkFeedbackContract(ctx, feedback);
    const executor = await handleTo(stepRef, "chefStep");
    const orchestrator = await handleTo(runStartRef, "chefRunStart");
    const reconciler = await handleTo(reconcileRef, "chefReconcile");
    const shipper = await handleTo(shipStartRef, "chefShipStart");
    await ctx.runMutation(cloud.orchestration.register, { executor, appName: safeAppName });
    await ctx.runMutation(feedback.chefEffects.setOrchestrator, { handle: orchestrator });
    await ctx.runMutation(feedback.chefEffects.setReconciler, { handle: reconciler });
    await ctx.runMutation(feedback.chefShip.setShipper, { handle: shipper });
    // Repair commits' Apply (chefRepairApply): optional, so a host that
    // hasn't exported it yet still sets up; Apply then says what to add.
    try {
      await ctx.runMutation(feedback.chefRepairs.setApplier, { handle: await createFunctionHandle(repairApplyRef) });
    } catch {
      await audit(ctx, { action: "cloud.repairApplier", outcome: "refused", reason: `export chefRepairApply from convex/${module}.ts to apply repairs` });
    }
    if (!(await registerCleaner(ctx))) {
      await audit(ctx, { action: "cloud.cleaner", outcome: "refused", reason: `export chefCleanup from convex/${module}.ts to clean up after each run` });
    }
    if (!(await registerPlanner(ctx))) {
      await audit(ctx, { action: "cloud.planner", outcome: "refused", reason: `export chefPlanBatches from convex/${module}.ts to build related requests together` });
    }
    // A run or ship that was live before deadline checks existed gets its one.
    await ctx.runMutation(feedback.chefWatchdog.check, {});
    await syncRunnerConfig(ctx);
    await audit(ctx, { action: "cloud.registered", outcome: "ok", detail: { appName: safeAppName } });
  };

  const vRepoResult = v.object({ repo: v.string(), remoteUrl: v.string(), created: v.boolean() });

  const repoSetup = async (ctx: ActionCtx) => {
    await register(ctx);
    let r: { repo: string; repoUrl: string; created: boolean };
    try {
      r = await ctx.runAction(cloud.repo.setup, { name: repoName });
    } catch (e) {
      await audit(ctx, { action: "repo.setup", outcome: "error", target: repoName, reason: reasonOf(e) });
      throw e;
    }
    await audit(ctx, { action: "repo.setup", outcome: "ok", target: repoName, detail: { created: r.created, repoUrl: r.repoUrl } });
    await syncRunnerConfig(ctx);
    return { repo: r.repo, remoteUrl: r.repoUrl, created: r.created };
  };

  const vStatus = v.object({
    executor: v.boolean(),
    appName: v.union(v.string(), v.null()),
    repo: v.union(v.string(), v.null()),
    remoteUrl: v.union(v.string(), v.null()),
    snapshot: v.string(),
    runner: v.union(v.literal("delivered"), v.literal("baked")),
    runnerVersion: v.string(),
    // The feedback component's contract version, checked against this package's.
    contract: v.number(),
    previewKeyPrefix: v.union(v.string(), v.null()),
    previewKeyEnv: v.boolean(),
    deployKeyPrefix: v.union(v.string(), v.null()),
    deployKeyEnv: v.boolean(),
    siteUrl: v.boolean(),
    email: v.boolean(),
    autoBuild: v.union(v.boolean(), v.null()),
    // Cloud builds on: a live "cloud" Chef agent key. `enabled` is the same
    // value, kept for older CLIs.
    cloudEnabled: v.boolean(),
    enabled: v.boolean(),
    // Live "worker" keys: how many `npx chef work` machines may enroll.
    workerKeys: v.number(),
    adminUserId: v.union(v.string(), v.null()),
    // Warm snapshots on, and how many at most (docs, "Warm snapshots").
    warmSnapshots: v.union(v.literal(false), v.number()),
    // The beta channel, when chefCloud's `beta` is set: its key's env var and whether it's set.
    beta: v.optional(v.union(v.null(), v.object({ keyEnv: v.string(), keySet: v.boolean(), mode: v.string() }))),
  });

  const status = async (ctx: ActionCtx) => {
    const contract = await checkFeedbackContract(ctx, feedback);
    const repo = await ctx.runQuery(cloud.orchestration.config, {});
    const admins: string[] = await ctx.runQuery(feedback.users.listAdmins, {});
    const operatorIsAdmin = admins.includes(OPERATOR_USER);
    const viewer = operatorIsAdmin ? OPERATOR_USER : (admins[0] ?? null);
    const settings = viewer ? await ctx.runQuery(feedback.chefSettings.get, { viewer }) : null;
    const cloudKeys = viewer ? await liveKeys(ctx, viewer, "cloud") : [];
    const workerKeys = viewer ? await liveKeys(ctx, viewer, "worker") : [];
    return {
      executor: repo.executor,
      appName: repo.appName,
      repo: repo.repoName,
      remoteUrl: repo.repoUrl,
      snapshot: snapshot(),
      runner: options.runnerPath !== undefined ? ("baked" as const) : ("delivered" as const),
      runnerVersion: RUNNER_VERSION,
      contract,
      previewKeyPrefix: settings?.previewKeyPrefix ?? null,
      previewKeyEnv: !!readEnv("CHEF_PREVIEW_DEPLOY_KEY"),
      deployKeyPrefix: settings?.deployKeyPrefix ?? null,
      deployKeyEnv: !!readEnv("CHEF_DEPLOY_KEY"),
      siteUrl: !!readEnv("CONVEX_SITE_URL"),
      email: emailOn(),
      autoBuild: settings?.cloudAutoBuild ?? null,
      cloudEnabled: cloudKeys.length > 0,
      enabled: cloudKeys.length > 0,
      workerKeys: workerKeys.length,
      // The app's own admin (chefSetAdmin), not the CLI's identity.
      adminUserId: admins.find((a) => !a.startsWith("operator:")) ?? null,
      warmSnapshots: warmSettings(options.runnerPath)?.keep ?? (false as const),
      beta: options.beta
        ? {
            keyEnv: options.beta.deployKeyEnv ?? DEFAULT_BETA_KEY_ENV,
            keySet: !!readEnv(options.beta.deployKeyEnv ?? DEFAULT_BETA_KEY_ENV),
            mode: options.beta.mode ?? "also",
          }
        : null,
    };
  };

  const enable = async (ctx: MutationCtx, args: { autoBuild?: boolean; adminUserId?: string }) => {
    const repo = await ctx.runQuery(cloud.orchestration.config, {});
    if (!repo.repoUrl) throw new ConvexError("The app has no repo yet: run chefRepoSetup (or chefSetup) first");
    // Someone has to approve builds, and it can't be whoever signs in first.
    if (!(await ctx.runQuery(feedback.users.hasAppAdmin, {}))) throw new ConvexError(NO_ADMIN);
    await register(ctx);
    const adminUserId = await actingAdmin(ctx, args.adminUserId);
    const autoBuild = args.autoBuild ?? true;
    await ctx.runMutation(feedback.chefSettings.set, { adminUserId, cloudAutoBuild: autoBuild });
    const live = await liveKeys(ctx, adminUserId, "cloud");
    if (live.length > 0) return { prefix: live[0].prefix, alreadyOn: true, autoBuild };
    const { prefix } = await ctx.runMutation(feedback.chefAgentKeys.create, {
      name: `${appName} cloud builds`.slice(0, 100),
      adminUserId,
      kind: "cloud",
    });
    return { prefix, alreadyOn: false, autoBuild };
  };

  return {
    /**
     * By hand only (`npx chef cleanup`; no cron calls it any more): claim the
     * next approved build, if any, and the watchdog over every live run and
     * open ship, arming a deadline check for any that has none.
     */
    chefSweep: internalMutationGeneric({
      args: {},
      returns: v.null(),
      handler: async (ctx) => {
        await ctx.runMutation(feedback.chefRuns.sweep, {});
        // The watchdog: runs stuck reconciling, ships that stopped answering.
        await ctx.runMutation(feedback.chefWatchdog.check, {});
        return null;
      },
    }),

    /**
     * The cleanup sweep on chef-cloud's pool, once cloud builds have run. The
     * feedback component schedules it once each time a run finishes (setup
     * registers it), and `npx chef cleanup` runs it by hand; no cron.
     */
    chefCleanup: internalMutationGeneric({
      args: {},
      returns: v.null(),
      handler: async (ctx) => {
        // Nothing of Chef's can exist before its first run.
        if (await ctx.runQuery(feedback.chefRuns.hasRuns, {})) {
          await ctx.runMutation(cloud.orchestration.queueCleanup, {});
        }
        // Rejected-attempt and repeated-refusal counts older than 30 days (chefRejected.ts).
        await ctx.runMutation(feedback.chefRejected.prune, {});
        return null;
      },
    }),

    /**
     * The batch planner (registered by setup and each run's start): the
     * feedback component schedules it when a claim finds more than one
     * approved request waiting. One model call through the AI gateway; it
     * answers with chefBatches.applyPlan, which makes the claim.
     */
    chefPlanBatches: internalActionGeneric({
      args: vPlanArgs,
      returns: v.null(),
      handler: async (ctx, args) => {
        await planBatches(ctx, feedback, args, options.batching === false ? {} : (options.batching ?? {}));
        return null;
      },
    }),

    /** The executor: the run's and the ship's workflows call it for every step. Registered by setup. */
    chefStep: internalActionGeneric({
      args: vStepArgs,
      returns: vStepResult,
      handler: async (ctx, args) => {
        try {
          return await runStep(ctx, args);
        } catch (e) {
          // What a retry can't change (a deadline, a failed self-test, a run
          // that isn't active): reported, not thrown, so the workflow fails
          // the run at once instead of retrying the step (orchestration.ts).
          if (e instanceof Terminal || e instanceof RunNotActive) return { terminal: e.message };
          throw e;
        }
      },
    }),

    /**
     * The feedback component's orchestrator (registered by setup): it hands
     * each claimed cloud run here once, and this starts its workflow.
     */
    chefRunStart: internalMutationGeneric({
      args: { runId: v.string() },
      returns: v.null(),
      handler: async (ctx, { runId }) => {
        await registerCleaner(ctx);
        await registerPlanner(ctx);
        const workflowId = await ctx.runMutation(cloud.orchestration.start, { runId });
        await audit(ctx, {
          actor: "system:orchestrator",
          action: "cloud.workflowStarted",
          outcome: "ok",
          target: runId,
          detail: { workflowId },
        });
        return null;
      },
    }),

    /**
     * The feedback component's shipper (registered by setup): "Ship to live"
     * hands each approved cloud release here, and this starts its workflow.
     */
    chefShipStart: internalMutationGeneric({
      args: { releaseId: v.string() },
      returns: v.null(),
      handler: async (ctx, { releaseId }) => {
        const workflowId = await ctx.runMutation(cloud.orchestration.startShip, { releaseId });
        await audit(ctx, {
          actor: "system:orchestrator",
          action: "cloud.shipWorkflowStarted",
          outcome: "ok",
          target: releaseId,
          detail: { workflowId },
        });
        return null;
      },
    }),

    /**
     * The feedback component's reconciler (registered by setup): a stale,
     * cancelled or revoked run's cleanup (secrets dead, sandboxes and
     * secrets deleted, refs read back), and only then the run finishes.
     */
    chefReconcile: internalActionGeneric({
      args: { runId: v.string() },
      returns: v.object({ finished: v.boolean(), pushedToChef: v.boolean() }),
      handler: async (ctx, { runId }) => await reconcileRun(ctx, chef, depsFor(ctx), runId),
    }),

    /**
     * A repair commit an admin applied (chefRepairs.apply schedules it,
     * registered by setup): main moves to it (compare-and-swap) and the
     * request builds again (packages/chef-cloud/src/client/chefRepair.ts).
     */
    /**
     * iOS CI, one step (chefIosCi.ts): push a built build's commit to GitHub
     * for Xcode Cloud, or read Xcode Cloud's result; schedules itself again
     * while it waits. "finish" schedules the first. A no-op without `iosCi`.
     */
    chefCiCheck: internalActionGeneric({
      args: { runId: v.string() },
      returns: v.null(),
      handler: async (ctx, { runId }) => {
        if (!options.iosCi) return null;
        const r = await iosCiStep(ctx, chef, depsFor(ctx), { runId, config: options.iosCi, operator: `chef-cloud:${operator}` });
        if (r.again !== null) await ctx.scheduler.runAfter(r.again, ciCheckRef, { runId });
        return null;
      },
    }),

    chefRepairApply: internalActionGeneric({
      args: { repairId: v.string() },
      returns: v.null(),
      handler: async (ctx, { repairId }) => {
        await applyRepair(ctx, chef, depsFor(ctx), { repairId, operator: `chef-cloud:${operator}` });
        return null;
      },
    }),

    /**
     * All of setup in one go, safe to repeat: check the feedback component's
     * contract version, register the executor (and the orchestrator,
     * reconciler and shipper), create or adopt the app's repo on Code
     * Storage, and record the preview deploy key's and the deploy key's
     * prefixes if CHEF_PREVIEW_DEPLOY_KEY and CHEF_DEPLOY_KEY are set. Then
     * push the app to the repo's `main` and run chefEnableCloudBuilds.
     *
     *   npx convex run chef:chefSetup
     */
    chefSetup: internalActionGeneric({
      args: {},
      returns: v.object({
        repo: vRepoResult,
        previewKeyPrefix: v.union(v.string(), v.null()),
        deployKeyPrefix: v.union(v.string(), v.null()),
        status: vStatus,
      }),
      handler: async (ctx) => {
        const repo = await repoSetup(ctx);
        let previewKeyPrefix: string | null = null;
        if (readEnv("CHEF_PREVIEW_DEPLOY_KEY")) {
          const adminUserId = await operatorAdmin(ctx);
          previewKeyPrefix = (await setPreviewDeployKey(ctx, chef, { adminUserId }, depsFor(ctx))).prefix;
        }
        let deployKeyPrefix: string | null = null;
        if (readEnv("CHEF_DEPLOY_KEY")) {
          const adminUserId = await operatorAdmin(ctx);
          deployKeyPrefix = (await setDeployKey(ctx, chef, { adminUserId }, depsFor(ctx))).prefix;
        }
        return { repo, previewKeyPrefix, deployKeyPrefix, status: await status(ctx) };
      },
    }),

    // chefSetAdmin and chefMigrateAgentKeys, as @convex-dev/feedback's chefAdmin has them.
    ...chefAdmin(feedback),

    /**
     * Names and switches only: what is set up for cloud builds here. Refuses,
     * saying what to do, if the feedback component's contract isn't this
     * package's.
     */
    chefSetupStatus: internalActionGeneric({
      args: {},
      returns: vStatus,
      handler: async (ctx) => await status(ctx),
    }),

    /**
     * Turn cloud builds on, once the repo exists: registers the executor
     * again (cheap, and it keeps the handle current), turns auto-build on
     * (default) so each approved request builds, and creates a "cloud" Chef
     * agent key, whose existence is what allows cloud builds. chefCloud
     * itself uses no key, so it is never shown. Worker keys
     * (chefCreateWorkerKey) don't turn cloud builds on. Acts as
     * `adminUserId` if given (it must be an admin), else as the CLI's
     * operator identity. Refused until an app admin exists (chefSetAdmin).
     */
    chefEnableCloudBuilds: internalMutationGeneric({
      args: { autoBuild: v.optional(v.boolean()), adminUserId: v.optional(v.string()) },
      returns: v.object({ prefix: v.string(), alreadyOn: v.boolean(), autoBuild: v.boolean() }),
      handler: async (ctx, args) => await enable(ctx, args),
    }),

    /**
     * Turn cloud builds off: every "cloud" Chef agent key revoked; a cloud
     * run in flight is reconciled. Worker keys stay, so `npx chef work`
     * keeps building (worker-only mode), unless `workers: true` revokes them
     * too, which stops everything.
     */
    chefDisableCloudBuilds: internalMutationGeneric({
      args: {
        reason: v.optional(v.string()),
        adminUserId: v.optional(v.string()),
        workers: v.optional(v.boolean()),
      },
      returns: v.object({ revoked: v.number(), workerKeys: v.number() }),
      handler: async (ctx, args) => {
        const adminUserId = await actingAdmin(ctx, args.adminUserId);
        const cloudKeys = await liveKeys(ctx, adminUserId, "cloud");
        const workers = await liveKeys(ctx, adminUserId, "worker");
        const revoke = args.workers ? [...cloudKeys, ...workers] : cloudKeys;
        for (const k of revoke) {
          await ctx.runMutation(feedback.chefAgentKeys.revoke, {
            id: k._id,
            adminUserId,
            reason: args.reason ?? (args.workers ? "Chef builds turned off" : "cloud builds turned off"),
          });
        }
        return { revoked: revoke.length, workerKeys: args.workers ? 0 : workers.length };
      },
    }),

    /**
     * A "worker" Chef agent key for `npx chef work`, returned once and
     * never stored in the clear. It lets a worker enroll and claim approved
     * requests; it never turns cloud builds on. Pipe it straight into the
     * key file, never into a terminal or a chat:
     *
     *   npx chef work --setup
     *   # or: npx convex run chef:chefCreateWorkerKey | npx chef work --save-key
     *
     * Refused until an app admin exists (chefSetAdmin), like enabling cloud
     * builds: a worker builds what an admin approved.
     */
    chefCreateWorkerKey: internalMutationGeneric({
      args: { name: v.optional(v.string()), adminUserId: v.optional(v.string()) },
      returns: v.string(),
      handler: async (ctx, args) => {
        if (!(await ctx.runQuery(feedback.users.hasAppAdmin, {}))) throw new ConvexError(NO_ADMIN);
        const adminUserId = await actingAdmin(ctx, args.adminUserId);
        const name = (args.name?.trim() || "chef work").slice(0, 100);
        const { key } = await ctx.runMutation(feedback.chefAgentKeys.create, { name, adminUserId, kind: "worker" });
        return key;
      },
    }),

    /**
     * Check the preview deploy key in CHEF_PREVIEW_DEPLOY_KEY and record its
     * `preview:<team>:<project>` prefix. The key stays in the env var: the
     * launcher hands it only to the deploy script's one command. Rotating is
     * setting the env var and running this again. As `adminUserId` if given,
     * else as the CLI's operator identity.
     */
    chefSetPreviewDeployKey: internalActionGeneric({
      args: { adminUserId: v.optional(v.string()) },
      returns: v.object({ prefix: v.string() }),
      handler: async (ctx, args) =>
        await setPreviewDeployKey(ctx, chef, { adminUserId: await actingAdmin(ctx, args.adminUserId) }, depsFor(ctx)),
    }),

    /**
     * "Ship it"'s key: check CHEF_DEPLOY_KEY (a prod: or dev: deploy key for
     * this very deployment) and record its prefix. The key stays in the env
     * var: the ship hands it only to the ship script's one command. As
     * `adminUserId` if given, else as the CLI's operator identity.
     *
     *   npx convex env set CHEF_DEPLOY_KEY "$(cat key)" && npx convex run chef:chefSetDeployKey
     */
    chefSetDeployKey: internalActionGeneric({
      args: { adminUserId: v.optional(v.string()) },
      returns: v.object({ prefix: v.string() }),
      handler: async (ctx, args) =>
        await setDeployKey(ctx, chef, { adminUserId: await actingAdmin(ctx, args.adminUserId) }, depsFor(ctx)),
    }),

    /** Cancel a run: it reconciles (secrets dead, sandboxes deleted, refs read back) before its slot frees. */
    chefCancelRun: internalMutationGeneric({
      args: { runId: v.string(), reason: v.optional(v.string()), force: v.optional(v.boolean()) },
      returns: v.object({ finished: v.boolean(), reconciling: v.boolean() }),
      handler: async (ctx, { runId, reason, force }) => {
        const adminUserId = await operatorAdmin(ctx);
        return await ctx.runMutation(feedback.chefRuns.cancel, {
          runId,
          adminUserId,
          ...(reason ? { reason } : {}),
          ...(force ? { force } : {}),
        });
      },
    }),

    /**
     * `npx chef ios <runId|itemId>` on the developer's Mac: without `report`,
     * the build to fetch (its branch and commit, the preview's or beta's
     * Convex URL); with it, what the Mac found (compiled, installed), shown
     * on the Ship card's iOS flag. Audited.
     */
    chefIos: internalMutationGeneric({
      args: {
        ref: v.string(),
        report: v.optional(
          v.object({
            compiled: v.boolean(),
            installed: v.boolean(),
            device: v.optional(v.string()),
            error: v.optional(v.string()),
          }),
        ),
      },
      returns: v.any(),
      handler: async (ctx, { ref, report }) => {
        const info = await ctx.runQuery(feedback.chefIos.info, { ref });
        if (!info) return null;
        if (report) {
          await ctx.runMutation(feedback.chefIos.report, { operator, runId: info.runId, commitSha: info.commitSha, ...report });
        }
        return { ...info, runId: String(info.runId) };
      },
    }),

    // ------------------------------------------------------------ the repo
    //
    // For the developer's CLI (`npx chef init`, `chef sync`, the `chef` git
    // remote's credential helper, `npx chef work`). Each call is audited in
    // the feedback component's log as `operator:<operator>`.

    /**
     * Create (or adopt) the app's repo on Code Storage and record its URL;
     * registers the executor too. Safe to repeat. `remoteUrl` holds no
     * credentials.
     */
    chefRepoSetup: internalActionGeneric({
      args: {},
      returns: vRepoResult,
      handler: async (ctx) => await repoSetup(ctx),
    }),

    /** Where to upload a git pack (`git pack-objects`) for chefRepoPushPack. */
    chefRepoUploadUrl: internalMutationGeneric({
      args: {},
      returns: v.string(),
      handler: async (ctx) => {
        const url = await ctx.runMutation(cloud.repo.uploadUrl, {});
        await audit(ctx, { action: "repo.uploadUrl", outcome: "ok" });
        return url;
      },
    }),

    /**
     * Push the uploaded pack: `ref` (a branch name like "main") to `newSha`,
     * only if it is at `oldSha` now (omit it for a new branch). Never a
     * force. The token never leaves Convex; the upload is deleted.
     */
    chefRepoPushPack: internalActionGeneric({
      args: {
        storageId: v.string(),
        ref: v.string(),
        oldSha: v.optional(v.union(v.string(), v.null())),
        newSha: v.string(),
      },
      returns: v.object({ ref: v.string(), before: v.union(v.string(), v.null()), after: v.string(), updated: v.boolean() }),
      handler: async (ctx, args) => {
        const target = /^refs\//.test(args.ref) ? args.ref : `refs/heads/${args.ref}`;
        let r: { ref: string; before: string | null; after: string; updated: boolean; bytes: number };
        try {
          r = await ctx.runAction(cloud.repo.pushPack, {
            storageId: args.storageId,
            ref: args.ref,
            ...(args.oldSha !== undefined ? { oldSha: args.oldSha } : {}),
            newSha: args.newSha,
          });
        } catch (e) {
          await audit(ctx, { action: "repo.push", outcome: "refused", target: target.slice(0, 200), reason: reasonOf(e) });
          throw e;
        }
        await audit(ctx, {
          action: "repo.push",
          outcome: "ok",
          target: r.ref,
          detail: { before: r.before, after: r.after, updated: r.updated, bytes: r.bytes },
        });
        return { ref: r.ref, before: r.before, after: r.after, updated: r.updated };
      },
    }),

    /**
     * A 10-minute git credential for the developer's credential helper:
     * `{ remoteUrl, username, password, expiresAt }`. Read-only unless
     * `write`. Audited without the token.
     */
    chefGitCredential: internalActionGeneric({
      args: { write: v.boolean() },
      returns: v.object({ remoteUrl: v.string(), username: v.string(), password: v.string(), expiresAt: v.number() }),
      handler: async (ctx, args) => {
        const r = await ctx.runAction(cloud.repo.gitCredential, { write: args.write });
        await audit(ctx, {
          action: "repo.credential",
          outcome: "ok",
          target: r.repo,
          detail: { write: args.write, expiresAt: r.expiresAt },
        });
        return { remoteUrl: r.remoteUrl, username: r.username, password: r.password, expiresAt: r.expiresAt };
      },
    }),

    /** Every branch on the app's repo and its sha, by short name: `{ main: "<sha>", chef: "<sha>", ... }`. */
    chefRepoRefs: internalActionGeneric({
      args: {},
      returns: v.record(v.string(), v.string()),
      handler: async (ctx) => {
        const r = await ctx.runAction(cloud.repo.refs, {});
        await audit(ctx, { action: "repo.refs", outcome: "ok", detail: { count: r.refs.length } });
        return Object.fromEntries(
          r.refs.map((x: { ref: string; sha: string }) => [x.ref.replace(/^refs\/heads\//, ""), x.sha]),
        );
      },
    }),
  };
}

/**
 * @deprecated Chef has no crons any more; this registers nothing. Remove
 * `chefCrons(crons)` from convex/crons.ts (and the file, if that was all it
 * had) whenever convenient: an app that still calls it pushes fine, and its
 * old "chef sweep" and "chef cleanup" crons go away at that push.
 *
 * What the crons did now happens when it is due: a build is claimed on
 * approval, when the build before it finishes (built, failed, cancelled or
 * reconciled) and when cloud builds or auto-build turn on; a run, a
 * reconciliation and a ship each get one deadline check, scheduled when
 * they start; the cleanup sweep runs once when a run or a ship ends, and
 * once more when the oldest request branch reaches 14 days; old refusal
 * counts are pruned as new ones are written. `npx chef cleanup` runs the
 * sweep and the checks by hand.
 */
export function chefCrons(_crons: Crons, module = "chef"): void {
  if (!/^[A-Za-z0-9_/]+$/.test(module)) throw new Error("module must be a path under convex/, like chef");
}

export { vFrontend as vChefCloudFrontend };
