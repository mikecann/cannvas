/**
 * The batch planner (docs/chef-pipeline.md, "Batching"): the feedback
 * component schedules it, by the handle chefCloud registers
 * (chefBatches.setPlanner), when a claim finds more than one approved request
 * waiting. One model call, through the same Convex AI gateway the build
 * agents' inference goes to (`https://ai-gateway.convex.dev/v1/messages`,
 * with the deployment's own `getServiceToken("ai-gateway")`, so no provider
 * key anywhere), on a cheap model (Haiku), forced to answer with one tool
 * call: groups of request numbers with a title and a reason. Whatever
 * happens, it answers the component exactly once with applyPlan: the groups,
 * or `batches: null` and why, and every request builds alone.
 */
import { getServiceToken } from "convex/server";
import type { GenericActionCtx } from "convex/server";
import { v } from "convex/values";
import {
  PLANNER_MODEL,
  parsePlannerReply,
  plannerRequestBody,
  type PlanRequest,
} from "@convex-dev/feedback/chef/batching.js";
import { estimateCostUsd, usageFromJson } from "@convex-dev/feedback/chef/ai.js";
import type { FeedbackComponentApi } from "./apis.js";

const AI_UPSTREAM = "https://ai-gateway.convex.dev";
/** The call is small; past this it is given up (the component's own timeout is longer). */
const PLAN_FETCH_MS = 60_000;

export type PlannerOptions = {
  /** The model. Default anthropic/claude-haiku-4.5. */
  model?: string;
  /** Tests: the gateway's address, its token and fetch. Defaults are the real ones. */
  upstream?: string;
  serviceToken?: () => Promise<string>;
  fetch?: (url: string, init: RequestInit) => Promise<Response>;
};

export const vPlanArgs = {
  planId: v.string(),
  requests: v.array(
    v.object({
      number: v.number(),
      title: v.string(),
      description: v.string(),
      screen: v.union(v.string(), v.null()),
      ref: v.union(v.string(), v.null()),
      votes: v.number(),
      screenshots: v.number(),
    }),
  ),
  maxBatch: v.number(),
};

/** Plan, then answer the component with applyPlan (once, whatever happened). */
export async function planBatches(
  ctx: GenericActionCtx<any>,
  feedback: FeedbackComponentApi,
  args: { planId: string; requests: PlanRequest[]; maxBatch: number },
  opts: PlannerOptions = {},
): Promise<void> {
  const model = opts.model ?? PLANNER_MODEL;
  let batches: Array<{ numbers: number[]; title: string; reason: string }> | null = null;
  let error: string | undefined;
  let costUsd: number | undefined;
  try {
    const body = plannerRequestBody(args.requests, { maxBatch: args.maxBatch, model });
    const token = await (opts.serviceToken ?? (() => getServiceToken("ai-gateway")))();
    const doFetch = opts.fetch ?? ((url: string, init: RequestInit) => fetch(url, init));
    const upstream = (opts.upstream ?? AI_UPSTREAM).replace(/\/$/, "");
    const abort = new AbortController();
    const timer = setTimeout(() => abort.abort(), PLAN_FETCH_MS);
    let text: string;
    let status: number;
    try {
      const res = await doFetch(`${upstream}/v1/messages`, {
        method: "POST",
        headers: {
          "content-type": "application/json",
          "anthropic-version": "2023-06-01",
          authorization: `Bearer ${token}`,
        },
        body: JSON.stringify(body),
        signal: abort.signal,
      });
      status = res.status;
      text = await res.text();
    } finally {
      clearTimeout(timer);
    }
    const usage = usageFromJson(text);
    costUsd = usage.costUsd ?? estimateCostUsd(model, usage);
    if (status < 200 || status >= 300) throw new Error(`the AI gateway answered ${status}`);
    let message: unknown;
    try {
      message = JSON.parse(text);
    } catch {
      throw new Error("the AI gateway's answer isn't JSON");
    }
    batches = parsePlannerReply(
      message,
      args.requests.map((r) => r.number),
      { maxBatch: args.maxBatch },
    );
  } catch (e) {
    // Never the token or the request text: our own short messages.
    const msg = e instanceof Error ? e.message : String(e);
    error = /abort/i.test(msg) ? "the planner timed out" : msg.slice(0, 300);
    batches = null;
  }
  await ctx.runMutation(feedback.chefBatches.applyPlan, {
    planId: args.planId,
    batches,
    model,
    ...(costUsd !== undefined && Number.isFinite(costUsd) ? { costUsd } : {}),
    ...(error !== undefined ? { error } : {}),
  });
}
