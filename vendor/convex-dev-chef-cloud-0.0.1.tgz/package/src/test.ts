/// <reference types="vite/client" />
// For hosts' convex-test suites, next to @convex-dev/feedback's:
//
//   import feedbackTest from "@convex-dev/feedback/test";
//   import chefCloudTest from "@convex-dev/chef-cloud/test";
//   const t = convexTest(schema, modules);
//   feedbackTest.register(t);   // "feedback"
//   chefCloudTest.register(t);  // "chefCloud", or register(t, "<name in convex.config.ts>")
//
// This registers the component's own children too (convex.config.ts): the
// workflow and the cleanup pool, and the vendored Daytona, Code Storage and
// Resend components that cloud builds use.
import type { TestConvex } from "convex-test";
import type { GenericSchema, SchemaDefinition } from "convex/server";
import workflow from "@convex-dev/workflow/test";
import workpool from "@convex-dev/workpool/test";
import rateLimiter from "@convex-dev/rate-limiter/test";
import schema from "./component/schema.js";
import daytonaSchema from "../vendor/marketplace/daytona/dist/component/schema.js";
import codestorageSchema from "../vendor/marketplace/codestorage/dist/component/schema.js";
import resendSchema from "../vendor/marketplace/resend/dist/component/schema.js";
const modules = import.meta.glob("./component/**/*.ts");
const daytonaModules = import.meta.glob("../vendor/marketplace/daytona/dist/component/**/*.js");
const codestorageModules = import.meta.glob("../vendor/marketplace/codestorage/dist/component/**/*.js");
const resendModules = import.meta.glob("../vendor/marketplace/resend/dist/component/**/*.js");

type AnyTest = TestConvex<SchemaDefinition<GenericSchema, boolean>>;

/**
 * Register the component's children under `prefix` (`"chefCloud/"` when it
 * is installed as "chefCloud"; `""` when the component is the test's root app).
 */
export function registerChildren(t: AnyTest, prefix: string) {
  workflow.register(t, `${prefix}workflow`);
  workpool.register(t, `${prefix}chefCleanup`);
  t.registerComponent(`${prefix}daytona`, daytonaSchema, daytonaModules);
  t.registerComponent(`${prefix}codestorage`, codestorageSchema, codestorageModules);
  t.registerComponent(`${prefix}resend`, resendSchema, resendModules);
  rateLimiter.register(t, `${prefix}resend/rateLimiter`);
  workpool.register(t, `${prefix}resend/emailWorkpool`);
  workpool.register(t, `${prefix}resend/callbackWorkpool`);
}

/**
 * Register the component and its children with the test convex instance.
 * @param t - The test convex instance, e.g. from calling `convexTest`.
 * @param name - The name of the component, as registered in convex.config.ts.
 */
export function register<Schema extends SchemaDefinition<GenericSchema, boolean>>(
  t: TestConvex<Schema>,
  name: string = "chefCloud",
) {
  t.registerComponent(name, schema, modules);
  registerChildren(t as unknown as AnyTest, `${name}/`);
}
export default { register, registerChildren, schema, modules };
