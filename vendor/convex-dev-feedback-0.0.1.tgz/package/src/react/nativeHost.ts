/**
 * The panel inside a native app's web view (an iOS `WKWebView`, e.g. ChefKit's
 * `ChefWebPanel`), signed in as the app rather than with a web sign-in.
 *
 * The app shows a page of your site that renders `<ChefPanelMount nativeHost … />`,
 * and before the page loads it:
 *   - adds a script message handler with a reply (`WKScriptMessageHandlerWithReply`)
 *     named `tokenHandler` (default "chefToken"). The panel posts `{ force: boolean }`
 *     and the app replies with its own Convex access token (refreshed when `force`).
 *   - optionally injects `window[configGlobal] = { convexUrl }` (default global
 *     "chefHost") when the app talks to a different deployment than the site's build
 *     (a preview build, a staging app).
 *
 * In a browser there is no such handler, the panel is not "native", and
 * ChefPanelMount uses its `token` / `getToken` as usual.
 */
import type { ChefAuthTokenFetcher } from "../../panel/chef-panel.browser.js";

export type ChefNativeHostOptions = {
  /** `window.webkit.messageHandlers[tokenHandler]` answers `{ force }` with the app's token. Default "chefToken". */
  tokenHandler?: string;
  /** `window[configGlobal].convexUrl`, injected by the app, overrides `convexUrl`. Default "chefHost". */
  configGlobal?: string;
};

export type ChefNativeHost = {
  /** The deployment the app uses, when it injected one. */
  convexUrl?: string;
  /** Asks the app for its token (ChefPanelMount hands this to the panel). */
  getToken: ChefAuthTokenFetcher;
};

export const DEFAULT_NATIVE_TOKEN_HANDLER = "chefToken";
export const DEFAULT_NATIVE_CONFIG_GLOBAL = "chefHost";

type MessageHandler = { postMessage(m: unknown): unknown };

/**
 * The native app hosting this page, or null in a plain browser (or on the server).
 * `win` is for tests; it defaults to `window`.
 */
export function chefNativeHost(
  options: ChefNativeHostOptions = {},
  win: unknown = typeof window === "undefined" ? undefined : window,
): ChefNativeHost | null {
  const tokenHandler = options.tokenHandler ?? DEFAULT_NATIVE_TOKEN_HANDLER;
  const configGlobal = options.configGlobal ?? DEFAULT_NATIVE_CONFIG_GLOBAL;
  const w = win as Record<string, unknown> & { webkit?: { messageHandlers?: Record<string, MessageHandler | undefined> } } | undefined;
  const handler = w?.webkit?.messageHandlers?.[tokenHandler];
  if (!handler || typeof handler.postMessage !== "function") return null;
  const config = w?.[configGlobal] as { convexUrl?: unknown } | undefined;
  const url = config?.convexUrl;
  return {
    convexUrl: typeof url === "string" && url ? url : undefined,
    getToken: async ({ forceRefreshToken }) => {
      // A handler without a reply (plain WKScriptMessageHandler) returns undefined, and a
      // refusal (the app's origin check) rejects: either way, signed out.
      try {
        const token = await handler.postMessage({ force: forceRefreshToken });
        return typeof token === "string" && token ? token : null;
      } catch {
        return null;
      }
    },
  };
}
