/**
 * The plain-language Ship card (docs/chef-pipeline.md, "The Ship card"):
 * what a build changed and what to try, in the owner's words, the
 * screenshots, the preview, and the risk flags, in one narrow column that
 * reads on a phone. The raw diff is not here: "Ship it" folds it under
 * "Details".
 *
 * Everything the agent wrote (the bullets) is shown as text: never markup,
 * never a link. The flags come from the diff by fixed rules
 * (src/chef/card.ts); the agent can't add or remove one.
 */
import * as React from "react";

/** What exposeChefApi's `buildCard` returns. */
export type BuildCardData = {
  runId: string;
  seq: number;
  status: string;
  phase: string;
  commitSha: string | null;
  finishedAt: number | null;
  previewUrl: string | null;
  previewLoginUrl: string | null;
  /** The preview has a copy of the admin's own data ("admin-copy"). */
  previewHasYourData?: boolean;
  requests: {
    runId: string;
    itemId: string;
    number: number | null;
    title: string;
    whatChanged: string[];
    whatToTry: string[];
    wroteSummary: boolean;
    /** A batch build: the other requests built together with this one (absent from older hosts). */
    builtWith?: number[];
  }[];
  screenshots: { name: string; path: string; url: string | null; width: number; height: number }[];
  flags: { kind: string; label: string; files: string[]; count: number }[];
  flagsFrom: "diff" | "paths";
  details: {
    diffHash: string;
    chunkCount: number;
    bytes: number;
    files: number;
    filesTruncated: boolean;
    depsChanged: boolean;
    redactions: number;
  } | null;
  filesChanged: number;
  videos?: { viewport: "phone" | "desktop"; url: string | null; durationMs: number; failed: { step: number; what: string; reason: string } | null }[];
  demoNote?: string | null;
  /** Why there is no preview: the change is only the phone or Mac app, tests or docs. */
  previewNote?: string | null;
  /** `npx chef ios` on the developer's Mac (shown on the iOS flag). Absent or null until it ran. */
  iosCheck?: { compiled: boolean; installed: boolean; at: number; device: string | null; error: string | null } | null;
  /** The beta channel: where it is, and whether this build is on it. Absent or null without one. */
  beta?: { siteUrl: string; onBeta: boolean; deployedAt: number | null; status: "deploying" | "deployed" | "failed" | null; note: string | null } | null;
};

const C = { ink: "#1f2937", muted: "#6b7280", brand: "#9a3412", accent: "#ea580c", line: "#fed7aa", warn: "#b45309", warnBg: "#fffbeb" };
const h: React.CSSProperties = { fontSize: 12, fontWeight: 700, color: C.brand, margin: "0 0 4px" };
const linkBtn: React.CSSProperties = {
  padding: "8px 12px",
  borderRadius: 8,
  fontSize: 13,
  fontWeight: 600,
  textDecoration: "none",
  border: `1px solid ${C.line}`,
  color: C.brand,
  background: "white",
  display: "inline-block",
};

/** Only http(s) links are ever rendered. */
function safeUrl(u: string | null | undefined): string | null {
  if (!u) return null;
  try {
    const x = new URL(u);
    return x.protocol === "https:" || x.protocol === "http:" ? x.href : null;
  } catch {
    return null;
  }
}

/** The iOS flag's line: what `npx chef ios` found, or how to try it. */
function iosText(card: Pick<BuildCardData, "runId" | "iosCheck">): string {
  const c = card.iosCheck;
  if (!c) return `Not tried on an iPhone yet: npx chef ios ${card.runId}`;
  const mark = (ok: boolean) => (ok ? "✓" : "✗");
  return `On ${c.device ?? "an iPhone"}: compiled ${mark(c.compiled)} installed ${mark(c.installed)}${c.error ? ` (${c.error})` : ""}`;
}

export function BuildCard({ card, loginUsed, onLoginUsed }: { card: BuildCardData; loginUsed?: boolean; onLoginUsed?: () => void }) {
  const preview = safeUrl(card.previewUrl);
  const login = safeUrl(card.previewLoginUrl);
  const shots = card.screenshots.filter((s) => safeUrl(s.url));
  const many = card.requests.length > 1;
  const said = card.requests.some((r) => r.wroteSummary);
  const video = (card.videos ?? []).find((x) => x.viewport === "phone" && safeUrl(x.url)) ?? (card.videos ?? []).find((x) => safeUrl(x.url));
  const others = (card.videos ?? []).filter((x) => x !== video && safeUrl(x.url));
  return (
    <section className="chef-card" style={{ display: "grid", gap: 12, fontSize: 14, color: C.ink, maxWidth: "100%", overflowWrap: "anywhere" }}>
      {video && (
        <div className="chef-card-video">
          <video
            src={safeUrl(video.url)!}
            controls
            playsInline
            muted
            preload="metadata"
            style={{ width: "100%", maxHeight: 520, borderRadius: 8, background: "#000", display: "block" }}
          />
          <div style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>
            The feature being used on the preview ({video.viewport}, {Math.round(video.durationMs / 1000)} s)
            {others.map((o) => (
              <React.Fragment key={o.viewport}>
                {" · "}
                <a href={safeUrl(o.url)!} target="_blank" rel="noreferrer">
                  {o.viewport} video
                </a>
              </React.Fragment>
            ))}
          </div>
        </div>
      )}
      {card.beta && (card.beta.onBeta || card.beta.status) && (
        <div className="chef-card-beta" style={{ fontSize: 12, color: C.muted }}>
          {card.beta.onBeta ? (
            <>
              On the beta
              {safeUrl(card.beta.siteUrl) && (
                <>
                  {": "}
                  <a href={safeUrl(card.beta.siteUrl)!} target="_blank" rel="noreferrer">
                    open it
                  </a>
                </>
              )}
              . Promote it to everyone when it's ready.
            </>
          ) : card.beta.status === "deploying" ? (
            "Deploying to the beta…"
          ) : (
            card.beta.note ?? "Not on the beta."
          )}
        </div>
      )}
      {card.demoNote && <div className="chef-card-demonote" style={{ fontSize: 12, color: C.muted }}>{card.demoNote}</div>}
      {card.previewNote && <div className="chef-card-previewnote" style={{ fontSize: 12, color: C.muted }}>{card.previewNote}</div>}
      <div>
        <div style={h}>What changed</div>
        {!said && (
          <p style={{ margin: 0, fontSize: 13, color: C.muted }}>
            The agent didn't describe this build in plain words. Open the preview, or read the details.
          </p>
        )}
        {card.requests.map((r) => (
          <div key={r.itemId} className="chef-card-request" style={{ marginBottom: many ? 8 : 0 }}>
            {many && (
              <div style={{ fontSize: 13, fontWeight: 600 }}>
                {r.number !== null && <span style={{ color: C.muted }}>#{r.number} </span>}
                {r.title}
                {(r.builtWith ?? []).length > 0 && (
                  <span style={{ color: C.muted, fontWeight: 400 }}> (built together with {r.builtWith!.map((n) => `#${n}`).join(", ")})</span>
                )}
              </div>
            )}
            {r.whatChanged.length > 0 && (
              <ul className="chef-card-changed" style={{ margin: "2px 0 0", paddingLeft: 20, display: "grid", gap: 2 }}>
                {r.whatChanged.map((t, i) => (
                  <li key={i}>{t}</li>
                ))}
              </ul>
            )}
          </div>
        ))}
      </div>
      {card.requests.some((r) => r.whatToTry.length > 0) && (
        <div>
          <div style={h}>What to try</div>
          <ol className="chef-card-try" style={{ margin: 0, paddingLeft: 20, display: "grid", gap: 2 }}>
            {card.requests.flatMap((r) => r.whatToTry.map((t, i) => <li key={`${r.itemId}:${i}`}>{t}</li>))}
          </ol>
        </div>
      )}
      {card.previewHasYourData && (
        <div className="chef-card-yours" style={{ fontSize: 12, color: C.muted }}>
          This preview has a copy of your own data.
        </div>
      )}
      {(preview || login) && (
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          {login && !loginUsed && (
            <a href={login} target="_blank" rel="noreferrer" style={{ ...linkBtn, background: C.accent, color: "white", border: 0 }} onClick={onLoginUsed}>
              Try it, signed in
            </a>
          )}
          {preview && (
            <a href={preview} target="_blank" rel="noreferrer" style={linkBtn}>
              Open the preview
            </a>
          )}
        </div>
      )}
      {shots.length > 0 && (
        <div>
          <div style={h}>After</div>
          <div className="chef-card-shots" style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 6 }}>
            {shots.map((s) => (
              <a key={s.name} href={safeUrl(s.url)!} target="_blank" rel="noreferrer" title={`${s.name} (${s.path})`}>
                <img src={safeUrl(s.url)!} alt={s.name} loading="lazy" style={{ width: "100%", height: "auto", borderRadius: 6, border: `1px solid ${C.line}`, display: "block" }} />
              </a>
            ))}
          </div>
        </div>
      )}
      <div>
        <div style={h}>Worth a look</div>
        {card.flags.length === 0 ? (
          <p className="chef-card-noflags" style={{ margin: 0, fontSize: 13, color: C.muted }}>
            Nothing in the {card.flagsFrom === "diff" ? "change" : "changed files' names"} touches sign-in, data, payments, secrets, sharing,
            dependencies or iOS.
          </p>
        ) : (
          <ul className="chef-card-flags" style={{ listStyle: "none", margin: 0, padding: 0, display: "grid", gap: 6 }}>
            {card.flags.map((f) => (
              <li key={f.kind} data-kind={f.kind} style={{ background: C.warnBg, border: "1px solid #fde68a", borderRadius: 8, padding: "6px 8px" }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: C.warn }}>⚠ {f.label}</div>
                <div style={{ fontSize: 11, color: C.muted, fontFamily: "ui-monospace, SFMono-Regular, Menlo, monospace" }}>
                  {f.files.join(", ")}
                  {f.count > f.files.length ? `, and ${f.count - f.files.length} more` : ""}
                </div>
                {f.kind === "ios" && (
                  <div className="chef-card-ios" style={{ fontSize: 12, color: C.ink, marginTop: 2 }}>
                    {iosText(card)}
                  </div>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  );
}
