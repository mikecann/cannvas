/**
 * The admin's view of a Chef cloud build, for the panel: where the run is in
 * its phase list, status, spend, model calls, heartbeat, the preview (and its
 * one-time sign-in link), screenshots of the built app, what the agent said
 * about its skills, the paid steps it asked for (Approve or Decline), and
 * the run log, collapsed until asked for.
 *
 * Talks to exposeChefApi's admin queries (`runStatus`, `recentRuns`,
 * `runScreenshots`, `skillFeedback`, `approvalRequests`, `runLogs`) and
 * mutations (`approveApprovalRequest`, `declineApprovalRequest`). They return
 * nothing to members, so a member never sees any of this.
 */
import * as React from "react";
import { BuildCard, type BuildCardData } from "./BuildCard.js";
import { useMutation, useQuery } from "convex/react";
import { makeFunctionReference, type FunctionReference } from "convex/server";

type Q<Args extends Record<string, any>, R> = FunctionReference<"query", "public", Args, R>;
type M<Args extends Record<string, any>, R = any> = FunctionReference<"mutation", "public", Args, R>;
type Paged<T> = { page: T[]; isDone: boolean; continueCursor: string };
type PageOpts = { paginationOpts: { numItems: number; cursor: string | null } };

export type RunPhaseStep = { phase: string; label: string; state: "done" | "now" | "stopped" | "todo" };

/** What `runStatus` (exposeChefApi) returns. */
export type CloudRunStatus = {
  runId: string;
  itemId: string;
  seq: number;
  status: "active" | "reconciling" | "built" | "failed" | "cancelled";
  phase: string;
  statusText: string;
  phases: RunPhaseStep[];
  createdAt: number;
  heartbeatAt: number;
  finishedAt: number | null;
  spendUsd: number;
  aiRequests: number;
  aiInFlight: number;
  previewUrl: string | null;
  /** One-time sign-in link to the preview. Works once. */
  previewLoginUrl: string | null;
  branch: string | null;
  commitSha: string | null;
  filesChanged: string[];
  error: string | null;
  /** The machine's name when `npx chef work` built it there; null (or absent) for the cloud. */
  builtLocallyOn?: string | null;
  /** A failed run's one-line reason and what to do (src/chef/failures.ts). */
  failure?: { code: string; kind: "transient" | "deterministic" | "environmental"; reason: string; action: string } | null;
  /** When Chef tries a transient failure again on its own. */
  retryAt?: number | null;
  attempt?: number;
  /** "Try again" applies: the request's newest run failed or was cancelled. */
  canRetry?: boolean;
  /** The checks against the base and after the agent. */
  gates?: {
    command: string;
    baseline: "pass" | "fail" | "none";
    baselineCached: boolean;
    result: "pass" | "fail" | null;
    preexisting: boolean;
    blocking: boolean;
    /** "main already fails `npm run lint` in X; not blocking this build", or what is new. */
    note?: string | null;
  }[];
  fixRound?: number;
  fixRounds?: number;
  phaseMs?: Record<string, number>;
  convexPlugin?: string | null;
  /** "Try again": how the earlier attempt's work was used (same base, rebased, or fresh and why). */
  earlierAttempt?: string | null;
  /** Each fix round: what failed in verification, when, and the spend when it started. */
  rounds?: { round: number; reason: string; at: number; spendUsd: number }[];
  /** What the agent tried (its summary and the diff stat), even when the run failed. Untrusted text. */
  summary?: string | null;
  diffStat?: string | null;
  /** What Chef did about a failure (src/chef/recovery.ts): its class and action. */
  recovery?: { class: string; action: string } | null;
  /** A repair commit for the repo problem it failed on ("Chef can fix this"). */
  repair?: {
    repairId: string;
    kind: string;
    status: string;
    summary: string | null;
    files: { path: string; how: string }[];
    sha: string | null;
    error: string | null;
  } | null;
};

/** One line on what Chef is doing about a failure, or null (src/chef/recovery.ts). */
export function recoveryLine(r: { class: string; action: string } | null | undefined): string | null {
  if (!r) return null;
  if (r.action === "stop") return "Stopped for safety: Chef won't retry or repair this on its own.";
  if (r.action === "fixRound") return "Chef is building it once more, told why the preview failed.";
  if (r.action === "repair") return "Chef can fix this in the repo; see the repair below.";
  return null;
}

/** What `retryRun` (exposeChefApi) returns. */
export type RetryResult =
  | { outcome: "started"; claim: string; snapshotId: string }
  | { outcome: "needsApproval"; snapshotId: string; contentHash: string }
  | { outcome: "refused"; reason: string };

/** One entry of `appLearnings`. */
export type AppLearning = {
  id: string;
  source: "runner" | "agent" | "failure";
  topic: string;
  text: string;
  firstRunSeq: number;
  lastRunSeq: number;
  seenCount: number;
  expired: boolean;
  updatedAt: number;
};

/** One row of `buildCosts`. */
export type BuildCost = {
  runId: string;
  seq: number;
  status: string;
  createdAt: number;
  wallMs: number | null;
  spendUsd: number;
  aiRequests: number;
  inputTokens: number;
  outputTokens: number;
  phaseMs: Record<string, number>;
  attempt: number;
  fixRounds: number;
  failure: string | null;
  /** Whether the install came from a warm snapshot (phaseMs.installWarm); null if it was never timed. */
  warm?: boolean | null;
};

export type CloudRunSummary = {
  runId: string;
  itemId: string;
  title: string;
  seq: number;
  status: CloudRunStatus["status"];
  phase: string;
  statusText: string;
  createdAt: number;
  finishedAt: number | null;
  builtLocallyOn?: string | null;
  failureReason?: string | null;
};

export type RunScreenshot = { name: string; path: string; url: string | null; width: number; height: number; createdAt: number };

export type SkillNote = {
  id: string;
  skill: string;
  kind: "wrong" | "missing" | "outdated" | "deviation";
  message: string;
  suggestion: string | null;
  createdAt: number;
};

export type SpendApproval = {
  id: string;
  action: string;
  skill: string | null;
  estimatedCostUsd: number | null;
  why: string;
  commandOrSteps: string;
  status: "pending" | "approved" | "declined";
  decidedAt: number | null;
  decisionNote: string | null;
  createdAt: number;
};

export type RunLogPage = { page: { seq: number; at: number; lines: string[] }[]; nextCursor: number | null };

/** exposeChefApi's functions the build view uses. */
export type CloudBuildApi = {
  runStatus: Q<{ runId?: string; itemId?: string }, CloudRunStatus | null>;
  /** Only needed for the list of builds (`CloudBuilds`). */
  recentRuns?: Q<{ limit?: number }, CloudRunSummary[]>;
  runScreenshots: Q<{ runId: string }, RunScreenshot[]>;
  skillFeedback: Q<{ runId?: string } & PageOpts, Paged<SkillNote>>;
  approvalRequests: Q<{ runId?: string } & PageOpts, Paged<SpendApproval>>;
  approveApprovalRequest: M<{ id: string; note?: string }>;
  declineApprovalRequest: M<{ id: string; note?: string }>;
  runLogs: Q<{ runId: string; cursor?: number | null; limit?: number }, RunLogPage>;
  /** "Try again" on a failed build; without it the button isn't shown. */
  retryRun?: M<{ itemId: string }, RetryResult>;
  /** "Chef can fix this: ... [Apply]"; without it the offer shows no button. */
  applyRepair?: M<{ repairId: string; sha: string }, { applying: boolean; reason?: string }>;
  /** The plain-language card (src/react/BuildCard.tsx), shown first once the build is built. */
  buildCard?: Q<{ runId?: string }, BuildCardData | null>;
  /** "Preview data" (exposeChefApi's previewDataMode and setPreviewData); without them the toggle doesn't show. */
  previewDataMode?: Q<Record<string, never>, { mode: "demo" | "admin-copy"; mine: boolean } | null>;
  setPreviewData?: M<{ mode: "demo" | "admin-copy" }, { mode: "demo" | "admin-copy" }>;
};

/** exposeChefApi's `appLearnings`, `forgetLearning` and `buildCosts`, for `AppLearnings`. */
export type AppLearningsApi = {
  appLearnings: Q<Record<string, never>, { entries: AppLearning[]; brief: string }>;
  forgetLearning: M<{ id: string }, boolean>;
  buildCosts?: Q<{ limit?: number }, BuildCost[]>;
};

const C = {
  ink: "#1f2937",
  muted: "#6b7280",
  brand: "#9a3412",
  accent: "#ea580c",
  line: "#fed7aa",
  ok: "#15803d",
  bad: "#b91c1c",
};
const mono = "ui-monospace, SFMono-Regular, Menlo, monospace";
const label: React.CSSProperties = {
  fontSize: 11,
  fontWeight: 700,
  textTransform: "uppercase",
  letterSpacing: 0.6,
  color: C.brand,
  margin: "0 0 6px",
};
const btn: React.CSSProperties = {
  padding: "6px 10px",
  borderRadius: 6,
  fontSize: 12,
  fontWeight: 600,
  cursor: "pointer",
  border: `1px solid ${C.line}`,
  background: "white",
  color: C.brand,
};
const primary: React.CSSProperties = { ...btn, background: C.accent, color: "white", border: 0 };

function ago(now: number, at: number) {
  const s = Math.max(0, Math.round((now - at) / 1000));
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  return `${Math.round(s / 3600)}h ago`;
}
const time = (at: number) => new Date(at).toLocaleTimeString();
const cost = (usd: number | null) => (usd === null ? "cost unknown" : `about $${usd.toFixed(2)}`);
const errText = (e: any) => String(e?.data?.message ?? e?.message ?? e);

function useNow(ms: number) {
  const [now, setNow] = React.useState(() => Date.now());
  React.useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return now;
}

const PHASE_STYLE: Record<RunPhaseStep["state"], { glyph: string; color: string }> = {
  done: { glyph: "✓", color: C.ok },
  now: { glyph: "●", color: C.accent },
  stopped: { glyph: "■", color: C.bad },
  todo: { glyph: "○", color: "#9ca3af" },
};

/** The preview's one-time sign-in link: shown until it is opened, then gone. */
function PreviewLinks({ run }: { run: CloudRunStatus }) {
  const [used, setUsed] = React.useState(false);
  if (!run.previewUrl && !run.previewLoginUrl) return null;
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
      {run.previewLoginUrl && !used && (
        <a
          className="chef-preview-login"
          href={run.previewLoginUrl}
          target="_blank"
          rel="noreferrer"
          onClick={() => setUsed(true)}
          style={{ ...primary, textDecoration: "none" }}
          title="A one-time sign-in link: it works once"
        >
          Open the preview, signed in
        </a>
      )}
      {run.previewUrl && (
        <a href={run.previewUrl} target="_blank" rel="noreferrer" style={{ ...btn, textDecoration: "none" }}>
          Open the preview
        </a>
      )}
      {run.previewLoginUrl && (
        <span style={{ fontSize: 11, color: C.muted }}>
          {used ? "Sign-in link used. It works once." : "The sign-in link works once."}
        </span>
      )}
    </div>
  );
}

function SpendApprovals({
  items,
  onDecide,
}: {
  items: SpendApproval[];
  onDecide: (id: string, decision: "approve" | "decline") => Promise<unknown>;
}) {
  const [busy, setBusy] = React.useState<string | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const pending = items.filter((a) => a.status === "pending").length;
  const decide = async (id: string, decision: "approve" | "decline") => {
    setError(null);
    setBusy(id);
    try {
      await onDecide(id, decision);
    } catch (e) {
      setError(errText(e));
    } finally {
      setBusy(null);
    }
  };
  return (
    <section>
      <div style={label}>{pending > 0 ? `Waiting for you (${pending})` : "Approval requests"}</div>
      <p style={{ fontSize: 12, color: C.muted, margin: "0 0 6px" }}>
        The build may not spend money or act for you on its own, so it asked. Approving records your answer;
        nothing runs it yet.
      </p>
      {error && (
        <div role="alert" style={{ fontSize: 12, color: C.bad }}>
          {error}
        </div>
      )}
      <div style={{ display: "grid", gap: 6 }}>
        {items.map((a) => (
          <div key={a.id} className="chef-spend-approval" style={{ padding: 10, borderRadius: 8, border: `1px solid ${C.line}`, background: "white" }}>
            <div style={{ fontWeight: 600, fontSize: 13, color: C.ink }}>{a.action}</div>
            <div style={{ fontSize: 12, color: C.muted, whiteSpace: "pre-wrap" }}>{a.why}</div>
            <pre style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", overflowWrap: "anywhere", margin: "6px 0" }}>
              {a.commandOrSteps}
            </pre>
            <div style={{ fontSize: 11, color: C.muted }}>
              {cost(a.estimatedCostUsd)}
              {a.skill !== null && ` · from the ${a.skill} skill`}
            </div>
            {a.status === "pending" ? (
              <div style={{ display: "flex", gap: 8, marginTop: 8 }}>
                <button type="button" style={primary} disabled={busy !== null} onClick={() => void decide(a.id, "approve")}>
                  Approve
                </button>
                <button type="button" style={btn} disabled={busy !== null} onClick={() => void decide(a.id, "decline")}>
                  Decline
                </button>
              </div>
            ) : (
              <div style={{ fontSize: 12, fontWeight: 600, marginTop: 6, color: a.status === "approved" ? C.ok : C.muted }}>
                {a.status === "approved" ? "Approved" : "Declined"}
                {a.decidedAt !== null && ` ${time(a.decidedAt)}`}
                {a.decisionNote !== null && ` · ${a.decisionNote}`}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}

/**
 * One run, in full. Pure rendering: the data and the decide callback come in
 * as props (CloudBuildView wires them to Convex).
 */
/** A failed run: what went wrong, what to do, "Try again", and the raw error folded away. */
function RepairOffer({ repair, onApply }: { repair: NonNullable<CloudRunStatus["repair"]>; onApply?: (r: { repairId: string; sha: string }) => Promise<{ applying: boolean; reason?: string }> }) {
  const [busy, setBusy] = React.useState(false);
  const [note, setNote] = React.useState<string | null>(null);
  const box: React.CSSProperties = { border: "1px solid #bbf7d0", background: "#f0fdf4", borderRadius: 8, padding: 8, fontSize: 12, color: "#14532d" };
  if (repair.status === "making") return <div className="chef-repair" style={box}>Chef is preparing a fix for this…</div>;
  if (repair.status === "applying") return <div className="chef-repair" style={box}>Applying the fix…</div>;
  if (repair.status === "applied") return <div className="chef-repair" style={box}>Fix applied to main; building it again.</div>;
  if (repair.status === "failed") return <div className="chef-repair" style={box}>Chef couldn't make a fix: {repair.error}</div>;
  if (repair.status !== "offered") return null;
  return (
    <div className="chef-repair" style={{ ...box, display: "grid", gap: 4 }}>
      <div>
        <b>Chef can fix this:</b> {repair.summary}
      </div>
      {repair.files.length > 0 && (
        <ul style={{ margin: 0, paddingLeft: 18 }}>
          {repair.files.map((f) => (
            <li key={f.path}>
              <code>{f.path}</code> {f.how}
            </li>
          ))}
        </ul>
      )}
      {onApply && repair.sha && (
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button
            type="button"
            style={primary}
            disabled={busy}
            onClick={() => {
              setBusy(true);
              onApply({ repairId: repair.repairId, sha: repair.sha! })
                .then((r) => setNote(r.applying ? "Applying, then building again." : (r.reason ?? "Refused")))
                .catch((e) => setNote(errText(e)))
                .finally(() => setBusy(false));
            }}
          >
            Apply
          </button>
          <span style={{ color: C.muted }}>{note ?? `Moves main to the fix (${repair.sha.slice(0, 12)}), then builds again.`}</span>
        </div>
      )}
    </div>
  );
}

function FailureBox({
  run,
  now,
  onRetry,
  onApplyRepair,
}: {
  run: CloudRunStatus;
  now: number;
  onRetry?: () => Promise<RetryResult>;
  onApplyRepair?: (r: { repairId: string; sha: string }) => Promise<{ applying: boolean; reason?: string }>;
}) {
  const [busy, setBusy] = React.useState(false);
  const [note, setNote] = React.useState<string | null>(null);
  const f = run.failure;
  if (!f && !run.error) return null;
  const retry = async () => {
    if (!onRetry) return;
    setBusy(true);
    setNote(null);
    try {
      const r = await onRetry();
      setNote(
        r.outcome === "started"
          ? r.claim === "claimed"
            ? "Started again."
            : "Queued: it starts when the current build finishes."
          : r.outcome === "needsApproval"
            ? "The request changed since you approved it: open it under Approvals and approve the new text."
            : r.reason,
      );
    } catch (e) {
      setNote(errText(e));
    } finally {
      setBusy(false);
    }
  };
  return (
    <div className="chef-failure" role="alert" style={{ display: "grid", gap: 6, padding: 10, borderRadius: 8, border: `1px solid ${C.bad}`, background: "#fef2f2" }}>
      {f && (
        <>
          <div className="chef-failure-reason" style={{ fontWeight: 700, color: C.bad }}>{f.reason}</div>
          <div className="chef-failure-action" style={{ fontSize: 12, color: C.ink }}>
            {run.retryAt ? `Chef tries again on its own ${run.retryAt > now ? `in ${Math.max(1, Math.round((run.retryAt - now) / 60_000))} min` : "now"}.` : f.action}
          </div>
          {recoveryLine(run.recovery) && (
            <div className="chef-failure-recovery" style={{ fontSize: 12, color: C.muted }}>
              {recoveryLine(run.recovery)}
            </div>
          )}
        </>
      )}
      {run.repair && <RepairOffer repair={run.repair} {...(onApplyRepair ? { onApply: onApplyRepair } : {})} />}
      {run.canRetry && onRetry && (
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button type="button" className="chef-try-again" style={primary} disabled={busy} onClick={() => void retry()}>
            {busy ? "Starting…" : "Try again"}
          </button>
          {note && <span style={{ fontSize: 12, color: C.muted }}>{note}</span>}
        </div>
      )}
      {run.error && (
        <details>
          <summary style={{ fontSize: 11, color: C.muted, cursor: "pointer" }}>Details</summary>
          <pre style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", color: C.bad, margin: 0 }}>{run.error}</pre>
        </details>
      )}
    </div>
  );
}

const GATE_GLYPH = { pass: "✓", fail: "✗", none: "–" } as const;

/** The checks: how each did before the build and after it. */
function GatesTable({ run }: { run: CloudRunStatus }) {
  const gates = run.gates ?? [];
  if (gates.length === 0) return null;
  return (
    <section>
      <div style={label}>Checks</div>
      <table className="chef-gates" style={{ fontSize: 12, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ color: C.muted, textAlign: "left" }}>
            <th style={{ paddingRight: 10, fontWeight: 600 }}>Check</th>
            <th style={{ paddingRight: 10, fontWeight: 600 }}>Before</th>
            <th style={{ fontWeight: 600 }}>After</th>
          </tr>
        </thead>
        <tbody>
          {gates.map((g) => (
            <tr key={g.command} data-blocking={g.blocking ? "true" : "false"}>
              <td style={{ fontFamily: mono, paddingRight: 10 }}>{g.command}</td>
              <td style={{ paddingRight: 10, color: g.baseline === "fail" ? C.bad : g.baseline === "pass" ? C.ok : C.muted }}>
                {GATE_GLYPH[g.baseline]} {g.baseline === "fail" ? "failing before this build" : g.baseline === "pass" ? "passed" : "not run"}
                {g.baselineCached ? " (cached)" : ""}
              </td>
              <td style={{ color: g.result === "fail" ? (g.blocking ? C.bad : C.muted) : g.result === "pass" ? C.ok : C.muted }}>
                {g.result === null ? "–" : `${GATE_GLYPH[g.result]} ${g.result === "pass" ? "passes" : g.blocking ? "fails" : "still fails (didn't block)"}`}
                {g.note && <div style={{ fontSize: 11, color: C.muted }}>{g.note}</div>}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      {(run.rounds ?? []).length > 0 && (
        <ol className="chef-rounds" style={{ margin: "6px 0 0", paddingLeft: 18, fontSize: 11, color: C.ink }}>
          {(run.rounds ?? []).map((r) => (
            <li key={r.round}>
              Fix round {r.round} of {run.fixRounds ?? r.round}: {r.reason}
              <span style={{ color: C.muted }}> · started at ${r.spendUsd.toFixed(2)}</span>
            </li>
          ))}
        </ol>
      )}
    </section>
  );
}

/** What the agent tried: its own summary and the diff stat, folded away. Untrusted text, shown as text. */
function AttemptBox({ run }: { run: CloudRunStatus }) {
  if (!run.summary && !run.diffStat) return null;
  return (
    <details className="chef-attempt">
      <summary style={{ fontSize: 12, color: C.muted, cursor: "pointer" }}>What the agent tried</summary>
      {run.summary && <p style={{ fontSize: 12, whiteSpace: "pre-wrap", margin: "6px 0" }}>{run.summary}</p>}
      {run.diffStat && (
        <pre style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", overflowWrap: "anywhere", margin: 0 }}>{run.diffStat}</pre>
      )}
    </details>
  );
}

export function CloudBuildDetails({
  run,
  screenshots,
  skillNotes,
  approvals,
  onDecide,
  now,
  log,
  onRetry,
  onApplyRepair,
  card,
}: {
  run: CloudRunStatus;
  screenshots: RunScreenshot[];
  skillNotes: SkillNote[];
  approvals: SpendApproval[];
  onDecide: (id: string, decision: "approve" | "decline") => Promise<unknown>;
  /** ms since epoch, for "started 3m ago" and the heartbeat. */
  now: number;
  /** The run log, rendered last (CloudBuildView passes RunLog). */
  log?: React.ReactNode;
  /** "Try again" (exposeChefApi's retryRun for this run's request). */
  onRetry?: () => Promise<RetryResult>;
  /** "Chef can fix this: ... [Apply]" (exposeChefApi's applyRepair). */
  onApplyRepair?: (r: { repairId: string; sha: string }) => Promise<{ applying: boolean; reason?: string }>;
  /** The plain-language card for this run, shown first when it built. */
  card?: BuildCardData | null;
}) {
  const finished = run.status !== "active" && run.status !== "reconciling";
  const fact = (k: string, v: React.ReactNode) => (
    <div style={{ display: "contents" }}>
      <dt style={{ color: C.muted }}>{k}</dt>
      <dd style={{ margin: 0, color: C.ink }}>{v}</dd>
    </div>
  );
  return (
    <div className="chef-cloud-build" style={{ display: "grid", gap: 12, fontSize: 13 }}>
      <div>
        <div style={{ fontSize: 11, color: C.muted }}>
          Build #{run.seq} · started {ago(now, run.createdAt)}
          {run.builtLocallyOn ? <span className="chef-built-locally"> · built locally on {run.builtLocallyOn}</span> : null}
        </div>
        <div
          className="chef-run-status"
          style={{ fontWeight: 700, color: run.status === "failed" ? C.bad : run.status === "built" ? C.ok : C.accent }}
        >
          {run.statusText}
        </div>
      </div>
      {card && run.status === "built" && card.runId === run.runId ? <BuildCard card={card} /> : <PreviewLinks run={run} />}
      {(run.status === "failed" || run.status === "cancelled") && <FailureBox run={run} now={now} {...(onRetry ? { onRetry } : {})} {...(onApplyRepair ? { onApplyRepair } : {})} />}
      <ol className="chef-phases" style={{ listStyle: "none", margin: 0, padding: 0, display: "grid", gap: 2 }}>
        {run.phases.map((p) => (
          <li
            key={p.phase}
            data-state={p.state}
            style={{ display: "flex", gap: 8, fontSize: 12, color: p.state === "todo" ? "#9ca3af" : C.ink, fontWeight: p.state === "now" ? 700 : 400 }}
          >
            <span aria-hidden="true" style={{ width: 14, color: PHASE_STYLE[p.state].color }}>
              {PHASE_STYLE[p.state].glyph}
            </span>
            {p.label}
          </li>
        ))}
      </ol>
      <dl style={{ display: "grid", gridTemplateColumns: "auto 1fr", gap: "2px 10px", margin: 0, fontSize: 12 }}>
        {fact("Spend so far", `$${run.spendUsd.toFixed(2)}`)}
        {fact("Model calls", `${run.aiRequests}${run.aiInFlight > 0 ? ` (${run.aiInFlight} running)` : ""}`)}
        {fact("Last heartbeat", finished ? "-" : ago(now, run.heartbeatAt))}
        {run.branch && fact("Branch", <span style={{ fontFamily: mono }}>{run.branch}</span>)}
        {run.commitSha && fact("Commit", <span style={{ fontFamily: mono }}>{run.commitSha.slice(0, 12)}</span>)}
        {run.filesChanged.length > 0 && fact("Files changed", run.filesChanged.length)}
        {(run.attempt ?? 1) > 1 && fact("Attempt", `${run.attempt} (Chef retried a platform failure)`)}
        {run.convexPlugin && fact("Convex plugin", run.convexPlugin)}
        {run.earlierAttempt && fact("Earlier attempt", run.earlierAttempt)}
      </dl>
      <GatesTable run={run} />
      <AttemptBox run={run} />
      {screenshots.length > 0 && (
        <section>
          <div style={label}>Screenshots</div>
          <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
            {screenshots.map((s) =>
              s.url ? (
                <a key={s.name} href={s.url} target="_blank" rel="noreferrer" title={`${s.name} (${s.path})`}>
                  <img
                    src={s.url}
                    alt={s.name}
                    style={{ width: 110, height: 70, objectFit: "cover", borderRadius: 6, border: `1px solid ${C.line}` }}
                  />
                </a>
              ) : (
                <span key={s.name} style={{ fontSize: 11, color: C.muted }}>
                  {s.name} (unavailable)
                </span>
              ),
            )}
          </div>
        </section>
      )}
      {approvals.length > 0 && <SpendApprovals items={approvals} onDecide={onDecide} />}
      {skillNotes.length > 0 && (
        <section>
          <div style={label}>Notes on its skills</div>
          <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "grid", gap: 4 }}>
            {skillNotes.map((f) => (
              <li key={f.id} className="chef-skill-note" style={{ fontSize: 12 }}>
                <span style={{ fontFamily: mono }}>{f.skill}</span> <span style={{ color: C.muted }}>{f.kind}</span>{" "}
                {f.message}
                {f.suggestion !== null && <span style={{ color: C.muted }}> Suggests: {f.suggestion}</span>}
              </li>
            ))}
          </ul>
        </section>
      )}
      {log}
    </div>
  );
}

function RunLogPageView({
  api,
  runId,
  cursor,
  last,
  onMore,
}: {
  api: CloudBuildApi;
  runId: string;
  cursor: number | null;
  last: boolean;
  onMore: (next: number) => void;
}) {
  const r = useQuery(api.runLogs, { runId, cursor });
  if (r === undefined) return <div style={{ fontSize: 11, color: C.muted }}>Loading…</div>;
  return (
    <>
      {r.page.map((b) =>
        b.lines.map((line, i) => (
          <div key={`${b.seq}:${i}`} className="chef-log-line">
            {line}
          </div>
        )),
      )}
      {last && r.nextCursor !== null && (
        <button type="button" style={{ ...btn, marginTop: 6 }} onClick={() => onMore(r.nextCursor!)}>
          Load more
        </button>
      )}
    </>
  );
}

/** The run log, collapsed by default, a page at a time. */
export function RunLog({ api, runId }: { api: CloudBuildApi; runId: string }) {
  const [open, setOpen] = React.useState(false);
  const [cursors, setCursors] = React.useState<(number | null)[]>([null]);
  return (
    <section>
      <button type="button" style={btn} aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {open ? "Hide the run log" : "Show the run log"}
      </button>
      {open && (
        <div
          className="chef-run-log"
          style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", overflowWrap: "anywhere", maxHeight: 260, overflowY: "auto", marginTop: 6 }}
        >
          {cursors.map((c, i) => (
            <RunLogPageView
              key={String(c)}
              api={api}
              runId={runId}
              cursor={c}
              last={i === cursors.length - 1}
              onMore={(next) => setCursors((cs) => [...cs, next])}
            />
          ))}
        </div>
      )}
    </section>
  );
}

const FIRST_50 = { numItems: 50, cursor: null };

/** One cloud run, live: pass `runId`, or `itemId` for that request's newest run. */
export function CloudBuildView({ api, runId, itemId }: { api: CloudBuildApi; runId?: string; itemId?: string }) {
  const run = useQuery(api.runStatus, runId !== undefined ? { runId } : itemId !== undefined ? { itemId } : "skip");
  const id = run?.runId;
  const shots = useQuery(api.runScreenshots, id ? { runId: id } : "skip");
  const notes = useQuery(api.skillFeedback, id ? { runId: id, paginationOpts: FIRST_50 } : "skip");
  const asks = useQuery(api.approvalRequests, id ? { runId: id, paginationOpts: FIRST_50 } : "skip");
  const approve = useMutation(api.approveApprovalRequest);
  const decline = useMutation(api.declineApprovalRequest);
  const retry = useOptionalMutation(api.retryRun);
  const applyRepair = useOptionalMutation(api.applyRepair);
  const card = useQuery(api.buildCard ?? (api.runStatus as unknown as NonNullable<CloudBuildApi["buildCard"]>), api.buildCard && id ? { runId: id } : "skip");
  const now = useNow(5000);
  if (run === undefined) return <div style={{ fontSize: 12, color: C.muted }}>Loading the build…</div>;
  if (run === null) return <div style={{ fontSize: 12, color: C.muted }}>No cloud build yet.</div>;
  return (
    <CloudBuildDetails
      run={run}
      screenshots={shots ?? []}
      skillNotes={notes?.page ?? []}
      approvals={asks?.page ?? []}
      onDecide={(rid, d) => (d === "approve" ? approve({ id: rid }) : decline({ id: rid }))}
      now={now}
      log={<RunLog api={api} runId={run.runId} />}
      card={card ?? null}
      {...(retry ? { onRetry: () => retry({ itemId: run.itemId }) as Promise<RetryResult> } : {})}
      {...(applyRepair ? { onApplyRepair: (r: { repairId: string; sha: string }) => applyRepair(r) as Promise<{ applying: boolean; reason?: string }> } : {})}
    />
  );
}

/** useMutation for an optional function: the hook is always called, with a stand-in when absent. */
const NO_MUTATION = makeFunctionReference<"mutation">("chef:__noMutation") as unknown as M<Record<string, never>>;
function useOptionalMutation<Args extends Record<string, any>, R>(fn: M<Args, R> | undefined): ((args: Args) => Promise<R>) | null {
  const m = useMutation((fn ?? NO_MUTATION) as M<Args, R>);
  return fn ? (m as unknown as (args: Args) => Promise<R>) : null;
}

const SOURCE_LABEL: Record<AppLearning["source"], string> = {
  runner: "Seen by the runner",
  failure: "Earlier failures",
  agent: "Notes from build agents",
};

/**
 * "What Chef knows about this app": the runner's facts, recurring failures
 * and the build agents' notes, each deletable, the brief the next build's
 * agent gets, and (with `buildCosts`) what recent builds cost. Admins only:
 * the queries return nothing to anyone else.
 */
export function AppLearnings({ api }: { api: AppLearningsApi }) {
  const data = useQuery(api.appLearnings, {});
  const costs = useQuery(api.buildCosts ?? (NO_QUERY as Q<{ limit?: number }, BuildCost[]>), api.buildCosts ? { limit: 20 } : "skip");
  const forget = useMutation(api.forgetLearning);
  const [open, setOpen] = React.useState(false);
  const [showBrief, setShowBrief] = React.useState(false);
  if (!data || (data.entries.length === 0 && (!costs || costs.length === 0))) return null;
  const groups = (["runner", "failure", "agent"] as const).map((src) => ({ src, rows: data.entries.filter((e) => e.source === src) }));
  return (
    <section className="chef-learnings" style={{ display: "grid", gap: 6 }}>
      <button type="button" style={{ ...btn, justifySelf: "start" }} aria-expanded={open} onClick={() => setOpen((o) => !o)}>
        {open ? "Hide what Chef knows about this app" : `What Chef knows about this app (${data.entries.length})`}
      </button>
      {open && (
        <div style={{ display: "grid", gap: 10 }}>
          <p style={{ fontSize: 12, color: C.muted, margin: 0 }}>
            Each build starts with this, so it explores less. Agents' notes are only ever read as notes, never as settings.
            Delete anything wrong.
          </p>
          {groups.map(
            (g) =>
              g.rows.length > 0 && (
                <div key={g.src}>
                  <div style={label}>{SOURCE_LABEL[g.src]}</div>
                  <ul style={{ listStyle: "none", margin: 0, padding: 0, display: "grid", gap: 4 }}>
                    {g.rows.map((e) => (
                      <li key={e.id} className="chef-learning" style={{ display: "flex", gap: 8, fontSize: 12, opacity: e.expired ? 0.5 : 1 }}>
                        <span style={{ flex: 1 }}>
                          {g.src === "agent" && <span style={{ color: C.muted }}>{e.topic}: </span>}
                          {e.text}
                          <span style={{ color: C.muted }}>
                            {" "}
                            · build #{e.lastRunSeq}
                            {e.seenCount > 1 ? `, seen ${e.seenCount}×` : ""}
                            {e.expired ? ", expired" : ""}
                          </span>
                        </span>
                        <button type="button" style={btn} onClick={() => void forget({ id: e.id })} aria-label={`Forget: ${e.text}`}>
                          Forget
                        </button>
                      </li>
                    ))}
                  </ul>
                </div>
              ),
          )}
          {data.brief && (
            <div>
              <button type="button" style={btn} aria-expanded={showBrief} onClick={() => setShowBrief((b) => !b)}>
                {showBrief ? "Hide the next build's brief" : "Show the next build's brief"}
              </button>
              {showBrief && (
                <pre style={{ fontFamily: mono, fontSize: 11, whiteSpace: "pre-wrap", overflowWrap: "anywhere", maxHeight: 260, overflowY: "auto" }}>
                  {data.brief}
                </pre>
              )}
            </div>
          )}
          {costs && costs.length > 0 && <BuildCostTrend costs={costs} />}
        </div>
      )}
    </section>
  );
}

const NO_QUERY = makeFunctionReference<"query">("chef:__noQuery") as unknown as Q<Record<string, never>, unknown>;

/** What recent builds cost, oldest first: a bar per build, spend and time. */
export function BuildCostTrend({ costs }: { costs: BuildCost[] }) {
  const max = Math.max(0.01, ...costs.map((c) => c.spendUsd));
  const avg = (xs: BuildCost[]) => (xs.length ? xs.reduce((n, c) => n + c.spendUsd, 0) / xs.length : 0);
  const half = Math.floor(costs.length / 2);
  const before = avg(costs.slice(0, half));
  const after = avg(costs.slice(half));
  const mins = (ms: number | null) => (ms === null ? "–" : `${Math.round(ms / 60_000)} min`);
  const secs = (ms: number) => `${Math.round(ms / 1000)} s`;
  // Warm snapshots (docs, "Warm snapshots"): how many recent installs came from one.
  const timed = costs.filter((c) => c.warm === true || c.warm === false);
  const warmHits = timed.filter((c) => c.warm === true).length;
  const install = (c: BuildCost) =>
    typeof c.phaseMs.installWarm === "number"
      ? `${secs(c.phaseMs.installWarm)} (warm)`
      : typeof c.phaseMs.install === "number"
        ? secs(c.phaseMs.install)
        : "–";
  return (
    <div className="chef-cost-trend">
      <div style={label}>What builds cost</div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 3, height: 48 }} aria-hidden="true">
        {costs.map((c) => (
          <div
            key={c.runId}
            title={`#${c.seq}: $${c.spendUsd.toFixed(2)}, ${mins(c.wallMs)}, ${c.status}`}
            style={{
              width: 10,
              height: Math.max(2, Math.round((c.spendUsd / max) * 48)),
              background: c.status === "failed" ? C.bad : c.status === "built" ? C.ok : C.accent,
              borderRadius: 2,
            }}
          />
        ))}
      </div>
      {half > 0 && (
        <div style={{ fontSize: 11, color: C.muted, marginTop: 4 }}>
          Average ${before.toFixed(2)} for the older half, ${after.toFixed(2)} for the newer half.
        </div>
      )}
      {timed.length > 0 && (
        <div className="chef-warm-rate" style={{ fontSize: 11, color: C.muted, marginTop: 2 }}>
          Warm installs: {warmHits} of {timed.length} recent build{timed.length === 1 ? "" : "s"} ({Math.round((warmHits / timed.length) * 100)}%).
        </div>
      )}
      <table style={{ fontSize: 11, marginTop: 6, borderCollapse: "collapse" }}>
        <thead>
          <tr style={{ color: C.muted, textAlign: "left" }}>
            <th style={{ paddingRight: 8 }}>Build</th>
            <th style={{ paddingRight: 8 }}>Spend</th>
            <th style={{ paddingRight: 8 }}>Tokens</th>
            <th style={{ paddingRight: 8 }}>Time</th>
            <th style={{ paddingRight: 8 }}>Install</th>
            <th>Agent / checks</th>
          </tr>
        </thead>
        <tbody>
          {costs
            .slice()
            .reverse()
            .map((c) => (
              <tr key={c.runId}>
                <td style={{ paddingRight: 8 }}>#{c.seq}</td>
                <td style={{ paddingRight: 8 }}>${c.spendUsd.toFixed(2)}</td>
                <td style={{ paddingRight: 8 }}>{Math.round((c.inputTokens + c.outputTokens) / 1000)}k</td>
                <td style={{ paddingRight: 8 }}>{mins(c.wallMs)}</td>
                <td style={{ paddingRight: 8 }}>{install(c)}</td>
                <td>
                  {mins(c.phaseMs.agent ?? null)} / {mins((c.phaseMs.gates ?? 0) + (c.phaseMs.baseline ?? 0) || null)}
                  {c.fixRounds > 0 ? `, ${c.fixRounds} fix round${c.fixRounds === 1 ? "" : "s"}` : ""}
                </td>
              </tr>
            ))}
        </tbody>
      </table>
    </div>
  );
}

/** The newest cloud builds; open one to watch it. Needs `api.recentRuns`. */
/**
 * "Previews use a copy of my own data": off (the app's demo data) by
 * default. On, each preview gets a copy of this admin's rows only, when the
 * app opted in (chefCloud's `previewData`). Admins only.
 */
export function PreviewDataToggle({
  api,
}: {
  api: { previewDataMode: NonNullable<CloudBuildApi["previewDataMode"]>; setPreviewData: NonNullable<CloudBuildApi["setPreviewData"]> };
}) {
  const p = useQuery(api.previewDataMode, {});
  const set = useMutation(api.setPreviewData);
  const [busy, setBusy] = React.useState(false);
  if (!p) return null;
  const on = p.mode === "admin-copy";
  return (
    <div className="chef-preview-data" style={{ display: "grid", gap: 2, fontSize: 12 }}>
      <label style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <input
          type="checkbox"
          checked={on && p.mine}
          disabled={busy}
          onChange={(e) => {
            setBusy(true);
            void set({ mode: e.target.checked ? "admin-copy" : "demo" }).finally(() => setBusy(false));
          }}
        />
        Previews use a copy of my own data{on && !p.mine ? " (another admin's: turning it on again makes it yours)" : ""}
      </label>
      <span style={{ color: C.muted }}>
        Off: previews get the app's demo data. On: each preview gets a copy of your rows only, never anyone else's; the build's code can read them.
      </span>
    </div>
  );
}

export function CloudBuilds({ api, limit = 5 }: { api: CloudBuildApi & { recentRuns: NonNullable<CloudBuildApi["recentRuns"]> }; limit?: number }) {
  const runs = useQuery(api.recentRuns, { limit });
  const [open, setOpen] = React.useState<string | null>(null);
  if (!runs || runs.length === 0) return null;
  return (
    <section style={{ display: "grid", gap: 6 }}>
      <div style={label}>Cloud builds</div>
      {api.previewDataMode && api.setPreviewData && (
        <PreviewDataToggle api={{ previewDataMode: api.previewDataMode, setPreviewData: api.setPreviewData }} />
      )}
      {runs.map((r) => (
        <div key={r.runId} style={{ padding: 10, borderRadius: 8, border: `1px solid ${C.line}`, background: "white" }}>
          <button
            type="button"
            onClick={() => setOpen(open === r.runId ? null : r.runId)}
            aria-expanded={open === r.runId}
            style={{ all: "unset", cursor: "pointer", display: "flex", gap: 8, width: "100%" }}
          >
            <span style={{ flex: 1, minWidth: 0, fontWeight: 600, fontSize: 13, color: C.ink, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {r.title || `Build #${r.seq}`}
            </span>
            {r.builtLocallyOn ? <span style={{ fontSize: 11, color: C.muted }}>built locally</span> : null}
            <span style={{ fontSize: 11, fontWeight: 600, color: r.status === "failed" ? C.bad : r.status === "built" ? C.ok : C.accent }}>
              {r.statusText}
            </span>
          </button>
          {r.failureReason && open !== r.runId && (
            <div className="chef-run-failure" style={{ fontSize: 11, color: C.bad, marginTop: 4 }}>
              {r.failureReason}
            </div>
          )}
          {open === r.runId && (
            <div style={{ marginTop: 10 }}>
              <CloudBuildView api={api} runId={r.runId} />
            </div>
          )}
        </div>
      ))}
    </section>
  );
}
