/**
 * Make hidden characters visible, so an approval shows every byte the build
 * will see (docs/chef-pipeline.md, "Approval binds an immutable snapshot").
 *
 * Zero-width characters, bidi controls (which can reorder what you read),
 * tag characters, variation selectors, other format and control characters
 * and lone surrogates each become a visible `<U+XXXX>` marker. Newlines and
 * tabs are kept. Pure functions, no React.
 */

/** Whether a code point renders as nothing (or changes how its neighbours render). */
export function isInvisibleCodePoint(cp: number): boolean {
  if (cp < 0x20) return cp !== 0x0a && cp !== 0x09; // C0 controls, \r included
  return (
    (cp >= 0x7f && cp <= 0x9f) || // DEL, C1 controls
    cp === 0x00ad || // soft hyphen
    cp === 0x034f || // combining grapheme joiner
    cp === 0x061c || // Arabic letter mark
    cp === 0x115f || cp === 0x1160 || cp === 0x3164 || cp === 0xffa0 || // Hangul fillers
    cp === 0x17b4 || cp === 0x17b5 || // Khmer inherent vowels
    (cp >= 0x180b && cp <= 0x180f) || // Mongolian selectors and vowel separator
    (cp >= 0x200b && cp <= 0x200f) || // zero-width space, joiners, LRM, RLM
    (cp >= 0x2028 && cp <= 0x202e) || // line and paragraph separators, bidi embeddings and overrides
    (cp >= 0x2060 && cp <= 0x206f) || // word joiner, invisible operators, bidi isolates, deprecated formats
    (cp >= 0xfe00 && cp <= 0xfe0f) || // variation selectors
    cp === 0xfeff || // zero-width no-break space (BOM)
    (cp >= 0xfff0 && cp <= 0xfffb) || // specials, interlinear annotation
    (cp >= 0x1d173 && cp <= 0x1d17a) || // musical formatting
    (cp >= 0xe0000 && cp <= 0xe0fff) || // tag characters, variation selectors supplement
    (cp >= 0xd800 && cp <= 0xdfff) // lone surrogates
  );
}

/** `<U+202E>`: at least four uppercase hex digits. */
export function markerFor(cp: number): string {
  return `<U+${cp.toString(16).toUpperCase().padStart(4, "0")}>`;
}

export type TextSegment = { text: string; hidden: boolean; codePoint?: number };

/**
 * Split text into visible runs and one segment per hidden character, whose
 * `text` is its marker. Joining every segment's text equals revealInvisible.
 */
export function segmentInvisible(text: string): TextSegment[] {
  const out: TextSegment[] = [];
  let run = "";
  // for...of walks code points, and yields a lone surrogate on its own.
  for (const ch of text) {
    const cp = ch.codePointAt(0)!;
    if (isInvisibleCodePoint(cp)) {
      if (run) out.push({ text: run, hidden: false });
      run = "";
      out.push({ text: markerFor(cp), hidden: true, codePoint: cp });
    } else {
      run += ch;
    }
  }
  if (run) out.push({ text: run, hidden: false });
  return out;
}

/** The text with every hidden character replaced by its `<U+XXXX>` marker. */
export function revealInvisible(text: string): string {
  return segmentInvisible(text)
    .map((s) => s.text)
    .join("");
}

/** How many hidden characters the text holds. */
export function countInvisible(text: string): number {
  let n = 0;
  for (const ch of text) if (isInvisibleCodePoint(ch.codePointAt(0)!)) n++;
  return n;
}
