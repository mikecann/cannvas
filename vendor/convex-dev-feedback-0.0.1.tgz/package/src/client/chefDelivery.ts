/**
 * Runner delivery: the launcher (@convex-dev/chef-cloud, which imports this
 * as `@convex-dev/feedback/delivery`) writes the exact runner the host's
 * @convex-dev/feedback has into each sandbox, so the sandbox image (the
 * shared `chef-base` snapshot) needs no Chef or app code, and the runner
 * always speaks the /chef-agent routes of the feedback component installed.
 *
 * scripts/build-runner.mjs bundles runner/*.ts into one file and puts it,
 * the screenshot helper, the start script and the deploy sandbox's scripts
 * in src/client/runnerBundle.generated.ts as strings with their sha256.
 * Here, for one sandbox:
 *
 * 1. every file, and a sha256 manifest of them (`<sha256>  <path>` lines,
 *    as `sha256sum -c` reads), is written through Daytona's file API to
 *    `/tmp/chef-delivery-<sha256>`, as the toolbox user;
 * 2. the one command the launcher starts installs the manifest into a fresh
 *    root-owned dir (/opt/chef/runner or /opt/chef/deploy) through sudo,
 *    checks it against the manifest's sha256 written into the command,
 *    installs every file it lists root-owned, and checks every installed
 *    file against it before anything runs. Nothing is run from /tmp, and
 *    whatever the toolbox user could change after the writes is caught.
 *
 * The command is deterministic for a given runner and config, so a launch
 * retried after a lost start response finds and adopts it (startOnce).
 */
import { RUNNER_ENV_NAMES } from "../chef/runnerEnv.js";
import { DEMO_FILES, DEPLOY_FILES, REPAIR_FILES, RUNNER_FILES, RUNNER_VERSION, SHIP_FILES, type DeliveredFile } from "./runnerBundle.generated.js";

export { RUNNER_VERSION };
export type { DeliveredFile };

/** The one sandbox call delivery needs: chef-cloud's SandboxApi has it. */
export type SandboxFiles = {
  /** Write a text file into the sandbox, as the toolbox user. */
  writeFile(id: string, path: string, content: string): Promise<void>;
};

/** Where the build sandbox's runner is installed, root-owned. */
export const RUNNER_DIR = "/opt/chef/runner";
/** Where the deploy sandbox's script and helpers are installed, root-owned. */
export const DEPLOY_DIR = "/opt/chef/deploy";
/** Where "Ship it"'s script and helpers are installed, root-owned. */
export const SHIP_DIR = "/opt/chef/ship";
/** Where a repair sandbox's script and helpers are installed, root-owned. */
export const REPAIR_DIR = "/opt/chef/repair";
/** Where a demo sandbox's recorder is installed, root-owned. */
export const DEMO_DIR = "/opt/chef/demo";
/** Where the toolbox writes the files first, each under its own sha256. */
export const STAGING_PREFIX = "/tmp/chef-delivery-";

/** The shared base image every team can start sandboxes from (marketplace packages/daytona/images/chef-base). */
export const DEFAULT_BASE_SNAPSHOT = "shared:chef-base-1";

export type Delivery = {
  /** Root-owned install dir. */
  dir: string;
  files: DeliveredFile[];
  /** `sha256sum -c` lines for every file. */
  manifest: string;
  manifestSha256: string;
};

/**
 * The runner's config (runner/main.ts's file config) for the `chef-base`
 * image, with the delivered paths. The run's gates, frontend build and local
 * env command come from GET /chef-agent/run instead, so they can follow the
 * host's code without a new config.
 */
export function defaultRunnerJson(opts: { skills: boolean }): Record<string, unknown> {
  return {
    agentUser: "chefagent",
    stateDir: "/opt/chef/state",
    gitDir: "/opt/chef/work/repo.git",
    workDir: "/home/chefagent/app",
    chefDir: "/home/chefagent/chef",
    settingsPath: "/opt/chef/claude-settings.json",
    skillsDir: opts.skills ? `${RUNNER_DIR}/skills` : false,
    pluginDir: "/opt/chef-agent/plugin",
    claudeConfigDir: "/opt/chef-agent/claude",
    claudeBin: "/usr/local/bin/claude",
    // The app's own dependencies, from the registry (the clone phase's egress
    // allows it), never its install scripts: npm or pnpm by the lockfile
    // (runner/chef-install.mjs).
    install: "auto",
    prepare: [],
    screenshots: {
      helper: `${RUNNER_DIR}/chef-screenshot.mjs`,
      playwrightBin: "/opt/chef/bin/playwright",
      browsersPath: "/opt/chef/ms-playwright",
      outDir: "/opt/chef-agent/screenshots",
    },
  };
}

const SKILL_NAME = /^[a-z0-9][a-z0-9-]{0,62}$/;
const REL_PATH = /^[A-Za-z0-9._-]+(\/[A-Za-z0-9._-]+)*$/;
/** The skills' total, a cap on what goes through the file API. */
const MAX_SKILLS_BYTES = 2 * 1024 * 1024;

async function sha256Hex(text: string): Promise<string> {
  const d = new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(text)));
  return Array.from(d, (b) => b.toString(16).padStart(2, "0")).join("");
}

async function delivery(dir: string, files: DeliveredFile[]): Promise<Delivery> {
  const seen = new Set<string>();
  for (const f of files) {
    if (!REL_PATH.test(f.path) || f.path.split("/").includes("..") || seen.has(f.path)) {
      throw new Error(`bad delivered path ${f.path}`);
    }
    seen.add(f.path);
    if ((await sha256Hex(f.content)) !== f.sha256) throw new Error(`${f.path} doesn't match its sha256`);
  }
  const manifest = files.map((f) => `${f.sha256}  ${f.path}\n`).join("");
  return { dir, files, manifest, manifestSha256: await sha256Hex(manifest) };
}

/** What the build sandbox gets: the runner, its config, the start script, the screenshot helper, any skills. */
export async function runnerDelivery(args: {
  runnerJson?: Record<string, unknown>;
  skills?: Record<string, string>;
}): Promise<Delivery> {
  const skills = Object.entries(args.skills ?? {});
  let total = 0;
  const skillFiles: DeliveredFile[] = [];
  for (const [name, content] of skills.sort(([a], [b]) => a.localeCompare(b))) {
    if (!SKILL_NAME.test(name)) throw new Error(`bad skill name ${name}`);
    total += content.length;
    if (total > MAX_SKILLS_BYTES) throw new Error("the skills are over 2 MB");
    skillFiles.push({ path: `skills/${name}/SKILL.md`, content, sha256: await sha256Hex(content) });
  }
  const json = JSON.stringify(args.runnerJson ?? defaultRunnerJson({ skills: skillFiles.length > 0 }), null, 2) + "\n";
  return await delivery(RUNNER_DIR, [
    ...RUNNER_FILES,
    { path: "runner.json", content: json, sha256: await sha256Hex(json) },
    ...skillFiles,
  ]);
}

/** What the deploy sandbox gets: chef-preview-deploy.sh with its unpacker and uploader next to it. */
export async function deployDelivery(): Promise<Delivery> {
  return await delivery(DEPLOY_DIR, [...DEPLOY_FILES]);
}

/** What the ship sandbox gets: chef-ship-deploy.sh with its unpacker and uploader next to it. */
export async function shipDelivery(): Promise<Delivery> {
  return await delivery(SHIP_DIR, [...SHIP_FILES]);
}

/** What a repair sandbox gets: chef-repair.sh and chef-repair.mjs with the installer next to them. */
export async function repairDelivery(): Promise<Delivery> {
  return await delivery(REPAIR_DIR, [...REPAIR_FILES]);
}

/** What a demo sandbox gets: chef-demo.sh and the bundled recorder. */
export async function demoDelivery(): Promise<Delivery> {
  return await delivery(DEMO_DIR, [...DEMO_FILES]);
}

export const stagingPath = (sha256: string) => `${STAGING_PREFIX}${sha256}`;

/** Step 1: every file and the manifest into the sandbox, as the toolbox user. */
export async function writeDelivery(sandboxes: SandboxFiles, sandboxId: string, d: Delivery): Promise<void> {
  const written = new Set<string>();
  for (const f of d.files) {
    if (written.has(f.sha256)) continue; // the same bytes twice (two identical skills)
    await sandboxes.writeFile(sandboxId, stagingPath(f.sha256), f.content);
    written.add(f.sha256);
  }
  await sandboxes.writeFile(sandboxId, stagingPath(d.manifestSha256), d.manifest);
}

/**
 * Step 2, as shell for `sh -c '...'` run as root: install the manifest and
 * the files root-owned into a fresh `d.dir`, and check them all. No single
 * quotes inside; every interpolated value is a fixed path or a hex sha256.
 */
export function installScript(d: Pick<Delivery, "dir" | "manifestSha256">): string {
  if (!/^\/opt\/chef\/[a-z]+$/.test(d.dir)) throw new Error("bad install dir");
  if (!/^[0-9a-f]{64}$/.test(d.manifestSha256)) throw new Error("bad manifest sha256");
  const s = STAGING_PREFIX;
  return [
    "set -eu",
    `d=${d.dir}`,
    `rm -rf "$d"`,
    `install -d -o root -g root -m 0755 "$d"`,
    `install -o root -g root -m 0644 ${s}${d.manifestSha256} "$d/MANIFEST"`,
    `cd "$d"`,
    `echo "${d.manifestSha256}  MANIFEST" | sha256sum -c --quiet -`,
    `while read -r h f; do mkdir -p "$(dirname "$d/$f")"; install -o root -g root -m 0644 "${s}$h" "$d/$f"; done < MANIFEST`,
    `sha256sum -c --quiet MANIFEST`,
  ].join("; ");
}

/**
 * The build sandbox's start command: install and check as root, then the
 * start script, keeping exactly the variables the runner reads through sudo.
 */
export function deliveredRunnerCommand(d: Delivery): string {
  if (d.dir !== RUNNER_DIR) throw new Error("not a runner delivery");
  return `sudo -n --preserve-env=${RUNNER_ENV_NAMES.join(",")} /bin/sh -c '${installScript(d)}; exec /bin/sh ${RUNNER_DIR}/chef-runner-start.sh'`;
}

/**
 * A deploy or ship sandbox's command: install and check as root, then the
 * script as the toolbox user, as before, with the envs the launcher gives
 * this one command (the deploy key among them). No `exec`: Daytona runs it
 * in a session shell that must outlive it.
 */
export function deliveredScriptCommand(d: Delivery, script: string, sha: string): string {
  if (d.dir !== DEPLOY_DIR && d.dir !== SHIP_DIR && d.dir !== REPAIR_DIR && d.dir !== DEMO_DIR) throw new Error("not a deploy, ship, repair or demo delivery");
  if (!d.files.some((f) => f.path === script) || !/^[a-z-]+\.sh$/.test(script)) throw new Error("no such delivered script");
  if (!/^[0-9a-f]{40}$/.test(sha)) throw new Error("bad sha");
  return `sudo -n /bin/sh -c '${installScript(d)}' && /bin/bash ${d.dir}/${script} ${sha}`;
}

/** The deploy sandbox's command (deliveredScriptCommand for chef-preview-deploy.sh). */
export function deliveredDeployCommand(d: Delivery, sha: string): string {
  if (d.dir !== DEPLOY_DIR) throw new Error("not a deploy delivery");
  return deliveredScriptCommand(d, "chef-preview-deploy.sh", sha);
}
