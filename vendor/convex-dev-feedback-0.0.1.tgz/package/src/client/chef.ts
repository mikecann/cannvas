import type { ComponentApi } from "../component/_generated/component.js";
import {
  mutationGeneric,
  paginationOptsValidator,
  queryGeneric,
  type GenericMutationCtx,
  type GenericQueryCtx,
} from "convex/server";
import { ConvexError, v } from "convex/values";
import { Feedback, type ItemState } from "./index.js";
import { phaseSteps, RUN_PHASES, runStatusText } from "../chef/runPhases.js";
import { classifyFailure } from "../chef/failures.js";
import { clampFixRounds, gateBlocks, gateNote } from "../chef/gates.js";

/**
 * `exposeChefApi` — the whole public surface the Chef clients (the `<chef-panel>`
 * web component in `panel/` and the iOS ChefKit package) talk to, as ready-made
 * Convex functions. The host writes ONE file:
 *
 *   // convex/chef.ts
 *   import { exposeChefApi } from "@convex-dev/feedback";
 *   import { components } from "./_generated/api";
 *   import { getAuthUserId } from "@convex-dev/auth/server";
 *   export const {
 *     agentState, listPublicItems, submitRequest, upvoteRequest, answerRefinement, skipRefinement,
 *     generateUploadUrl, submitRequestWithMedia, listAttachments,
 *     mine, amAdmin, whoAmI, awaitingApproval, review, myNotifications, markNotificationsRead,
 *     approvalSnapshot, prepareApproval, approveSnapshot, runLogs, skillFeedback,
 *     approvalRequests, approveApprovalRequest, declineApprovalRequest, runScreenshots,
 *     runStatus, recentRuns, buildState, buildInCloud, shipCandidate, shipDiffChunk, shipApprove,
 *     retryRun, appLearnings, forgetLearning, buildCosts, applyRepair, buildCard,
 *     previewDataMode, setPreviewData, splitFromBatch, fixRequest, removeRequest,
 *   } = exposeChefApi(components.feedback, { getUserId: getAuthUserId });
 *
 * Clients address the functions by module name (`chef:submitRequest`, …) — the
 * panel's `prefix` attribute / ChefKit's `prefix` — so the host may pick any name.
 *
 * Trust model (same as the rest of the component): identity always comes from
 * `getUserId(ctx)` (i.e. the caller's auth token), never from arguments. Writes
 * require a signed-in user (`ConvexError({ code: "UNAUTHENTICATED" })`);
 * queries return empty / false for signed-out callers. Admin-only surfaces
 * (approvals, build status, refinement answers) use the component's roles
 * (`users` table: signing in makes a member; the operator names admins with
 * chefCloud's `chefSetAdmin` / `npx chef init --admin <userId>`, or the host
 * promotes with `feedback.users.setRole`).
 */

/** Anything with `auth` — a query or mutation ctx (mutation ctx is a superset). */
type AnyCtx = GenericQueryCtx<any>;

/** What `onSubmitted` receives after a request is filed. */
export type ChefSubmission = {
  itemId: string;
  userId: string;
  title: string;
  /** What the user typed (or dictated), without the context footer. */
  description: string;
  /** Voice-note transcript (client-side speech recognition), when there was one. */
  transcript?: string;
  /**
   * The item's resulting state: "requested" when an admin filed it (straight to
   * the build queue), "submitted" when it awaits an admin's approval.
   */
  state: ItemState;
  screenshotCount: number;
  hasAudio: boolean;
};

/** What `onRequestApproved` receives when an admin approves someone's request. */
export type ChefApprovedRequest = {
  itemId: string;
  number: number | null;
  title: string;
  /** The requester. */
  userId: string;
  /** The admin who approved it. */
  approvedBy: string;
};

export type ChefApiOptions = {
  /**
   * Who is calling: the host's authenticated user id, or null when signed out.
   * `getAuthUserId` from `@convex-dev/auth/server` (2.0 alpha: `/core`) fits as-is; any
   * `(ctx) => Promise<string | null>` works (e.g. `ctx.auth.getUserIdentity()`'s subject).
   */
  getUserId: (ctx: AnyCtx) => Promise<string | null | undefined>;
  /**
   * Optional agent key (e.g. `() => process.env.FEEDBACK_AGENT_KEY`). Only ever
   * forwarded on behalf of a caller already verified to be an admin; never
   * grants anything to ordinary users.
   */
  agentKey?: () => string | undefined;
  /**
   * Called (inside the submitting mutation) after a request is created and its
   * attachments are stored. Typical use: email admins when
   * `state === "submitted"` (a request waiting for approval). Throwing rolls
   * the whole submission back, so schedule slow work with `ctx.scheduler`.
   */
  onSubmitted?: (
    ctx: GenericMutationCtx<any>,
    submission: ChefSubmission,
  ) => Promise<void> | void;
  /**
   * Called (inside the approving mutation) when an admin approves a request
   * that was waiting for approval: once per request, never for a
   * re-approval or "Try again", nor for an admin's own request. Typical use:
   * email the requester. A throw is logged and the approval stands; schedule
   * slow work with `ctx.scheduler`.
   */
  onRequestApproved?: (ctx: GenericMutationCtx<any>, request: ChefApprovedRequest) => Promise<void> | void;
  /**
   * Optional display name for "from" in the approvals list (e.g. a username
   * lookup). Defaults to null (clients show "Someone").
   */
  getUserName?: (ctx: AnyCtx, userId: string) => Promise<string | null>;
  /**
   * Show pre-triage ("submitted") requests on the public list and make their
   * media readable like the board (community/dedup board). Default false: only
   * approved requests are public; requesters always see their own.
   */
  includeCommunity?: boolean;
  /**
   * Register signed-in callers with the component on their first write
   * (`users.ensure`, which only ever makes members). Default true. Turn
   * off if your app calls `feedback.users.ensure` itself after sign-in.
   */
  autoRegister?: boolean;
};

const MAX_SCREENSHOTS = 4;
const MAX_TITLE = 200;
const MAX_TEXT = 8000;
const MAX_NOTIFICATIONS = 10;

const vAttachmentKind = v.union(v.literal("screenshot"), v.literal("audio"));
const vItemState = v.union(
  v.literal("submitted"),
  v.literal("requested"),
  v.literal("planned"),
  v.literal("inProgress"),
  v.literal("rejected"),
  v.literal("completed"),
);

/** `buildCard`'s answer (the Ship card). Ids are strings; everything else is plain data. */
export const vBuildCard = v.object({
  runId: v.string(),
  seq: v.number(),
  status: v.string(),
  phase: v.string(),
  commitSha: v.union(v.string(), v.null()),
  finishedAt: v.union(v.number(), v.null()),
  previewUrl: v.union(v.string(), v.null()),
  // A one-time sign-in link for the preview (admins only, like runStatus).
  previewLoginUrl: v.union(v.string(), v.null()),
  previewHasYourData: v.boolean(),
  // Why a built run has no preview (only the phone or Mac app, tests or docs changed).
  previewNote: v.union(v.string(), v.null()),
  requests: v.array(
    v.object({
      runId: v.string(),
      itemId: v.string(),
      number: v.union(v.number(), v.null()),
      title: v.string(),
      whatChanged: v.array(v.string()),
      whatToTry: v.array(v.string()),
      wroteSummary: v.boolean(),
      // A batch build: the other requests it built together with this one.
      builtWith: v.array(v.number()),
    }),
  ),
  screenshots: v.array(
    v.object({ name: v.string(), path: v.string(), url: v.union(v.string(), v.null()), width: v.number(), height: v.number() }),
  ),
  flags: v.array(v.object({ kind: v.string(), label: v.string(), files: v.array(v.string()), count: v.number() })),
  flagsFrom: v.union(v.literal("diff"), v.literal("paths")),
  details: v.union(
    v.null(),
    v.object({
      diffHash: v.string(),
      chunkCount: v.number(),
      bytes: v.number(),
      files: v.number(),
      filesTruncated: v.boolean(),
      depsChanged: v.boolean(),
      redactions: v.number(),
    }),
  ),
  filesChanged: v.number(),
  // The demo videos of the feature being used, on the preview (a link for ChefKit).
  videos: v.array(
    v.object({
      viewport: v.union(v.literal("phone"), v.literal("desktop")),
      url: v.union(v.string(), v.null()),
      durationMs: v.number(),
      failed: v.union(v.null(), v.object({ step: v.number(), what: v.string(), reason: v.string() })),
    }),
  ),
  demoNote: v.union(v.string(), v.null()),
  // `npx chef ios`: the developer's Mac compiled and installed this build.
  iosCheck: v.union(
    v.null(),
    v.object({ compiled: v.boolean(), installed: v.boolean(), at: v.number(), device: v.union(v.string(), v.null()), error: v.union(v.string(), v.null()) }),
  ),
  // Xcode Cloud's build of this commit, when it went to CI (chef-cloud's iosCi).
  ciCheck: v.optional(v.union(
      v.null(),
      v.object({
        status: v.union(v.literal("pending"), v.literal("passed"), v.literal("failed"), v.literal("none"), v.literal("error")),
        at: v.number(),
        url: v.union(v.string(), v.null()),
        detail: v.union(v.string(), v.null()),
      }),
    )),
  // The beta channel: where it is, and whether this build is on it ("Promote to everyone").
  beta: v.union(
    v.null(),
    v.object({
      siteUrl: v.string(),
      onBeta: v.boolean(),
      deployedAt: v.union(v.number(), v.null()),
      status: v.union(v.literal("deploying"), v.literal("deployed"), v.literal("failed"), v.null()),
      note: v.union(v.string(), v.null()),
    }),
  ),
});

/** A batch in buildState (docs/chef-pipeline.md, "Batching"). Ids are strings; the title and reason are the planner's words (plain text). */
const vBatch = v.object({
  batchId: v.string(),
  status: v.string(),
  title: v.string(),
  reason: v.string(),
  failures: v.number(),
  runId: v.union(v.string(), v.null()),
  items: v.array(v.object({ itemId: v.string(), number: v.number(), title: v.string(), state: v.string() })),
});

function batchOut(b: {
  batchId: string;
  status: string;
  title: string;
  reason: string;
  failures: number;
  runId: string | null;
  items: Array<{ itemId: string; number: number; title: string; state: string }>;
}) {
  return {
    batchId: String(b.batchId),
    status: b.status,
    title: b.title,
    reason: b.reason,
    failures: b.failures,
    runId: b.runId === null ? null : String(b.runId),
    items: b.items.map((i) => ({ itemId: String(i.itemId), number: i.number, title: i.title, state: i.state })),
  };
}

// The public board shows a coarse status; the panel speaks raw states.
const STATE_FOR_PUBLIC_STATUS: Record<string, ItemState> = {
  community: "submitted",
  planned: "requested",
  building: "inProgress",
  shipped: "completed",
};

function unauthenticated(): never {
  throw new ConvexError({ code: "UNAUTHENTICATED", message: "Not signed in: sign in to use Chef" });
}
function badRequest(message: string): never {
  throw new ConvexError({ code: "BAD_REQUEST", message });
}
function forbidden(message: string): never {
  throw new ConvexError({ code: "FORBIDDEN", message });
}

// Component errors are plain Errors ("Uncaught Error: At most 4 screenshots…" plus a
// stack); surface their first line as a clean, client-readable message.
function cleanMessage(e: unknown): string {
  return String((e as Error)?.message ?? e)
    .replace(/^[\s\S]*?Uncaught Error: /, "")
    .split("\n")[0];
}

/**
 * Build the Chef public API on top of the feedback component. Destructure the
 * result into named exports of one Convex module (see the file comment).
 */
export function exposeChefApi(component: ComponentApi, options: ChefApiOptions) {
  const feedback = new Feedback(component);
  const agentKey = () => options.agentKey?.();
  const includeCommunity = options.includeCommunity ?? false;

  const userIdOf = async (ctx: AnyCtx): Promise<string | null> =>
    (await options.getUserId(ctx)) ?? null;

  const requireUser = async (ctx: GenericMutationCtx<any>): Promise<string> => {
    const userId = await userIdOf(ctx);
    if (!userId) unauthenticated();
    if (options.autoRegister ?? true) await feedback.users.ensure(ctx, { userId });
    return userId;
  };

  const isAdmin = async (ctx: AnyCtx, userId: string | null) => {
    if (!userId) return false;
    const u = await feedback.users.get(ctx, { userId });
    return u?.role === "admin";
  };

  // Refinement answers are build chrome: the same audience that sees build
  // status (admins, or anyone while nobody has registered yet).
  const requireBuildAudience = async (ctx: GenericMutationCtx<any>, userId: string | null) => {
    if (await isAdmin(ctx, userId)) return;
    if (!(await feedback.users.hasAppUsers(ctx))) return;
    forbidden("Only the app's admins can answer Chef's questions");
  };

  // The requester hears their request was approved. Not the admin's own
  // request, and the approval stands whatever the host's hook does.
  const requestApproved = async (ctx: GenericMutationCtx<any>, request: ChefApprovedRequest) => {
    if (!options.onRequestApproved || request.userId === request.approvedBy) return;
    try {
      await options.onRequestApproved(ctx, request);
    } catch (e) {
      console.error(`Chef: onRequestApproved failed for request ${request.itemId}: ${cleanMessage(e)}`);
    }
  };

  const requireRefinement = async (ctx: AnyCtx, id: string) => {
    let item: any = null;
    try {
      item = await feedback.items.get(ctx, { itemId: id as any });
    } catch {
      // malformed id
    }
    if (!item || item.kind !== "refinement") badRequest("Unknown question");
    return item;
  };

  /** Create the item, attach media, then tell the host. Shared by both submit paths. */
  const fileRequest = async (
    ctx: GenericMutationCtx<any>,
    userId: string,
    a: {
      title: string;
      description?: string;
      transcript?: string;
      screenshotStorageIds?: string[];
      audioStorageId?: string;
      context?: { screen?: string; ref?: string };
    },
  ): Promise<{ itemId: string; state: ItemState }> => {
    const title = a.title.trim().slice(0, MAX_TITLE);
    if (!title) badRequest("A title is required");
    const shots = a.screenshotStorageIds ?? [];
    if (shots.length > MAX_SCREENSHOTS) badRequest(`At most ${MAX_SCREENSHOTS} screenshots`);
    if (new Set(shots).size !== shots.length) badRequest("Duplicate screenshot");
    if (a.audioStorageId && shots.includes(a.audioStorageId)) badRequest("Duplicate upload");

    const typed = (a.description ?? "").trim().slice(0, MAX_TEXT);
    const transcript = a.transcript?.trim().slice(0, MAX_TEXT) || undefined;
    // Where the user was when they asked, as a footer the build agent can read.
    const bits = [
      a.context?.screen?.trim() ? `screen: ${a.context.screen.trim().slice(0, 120)}` : null,
      a.context?.ref?.trim() ? `ref: ${a.context.ref.trim().slice(0, 200)}` : null,
    ].filter(Boolean);
    const description = (bits.length ? `${typed}\n\n_${bits.join(" · ")}_` : typed).trim();

    // autoApprove only takes effect for component admins (enforced by the
    // component); everyone else's request lands in "submitted" for approval.
    const itemId = String(
      await feedback.items.create(ctx, { userId, title, description, transcript, autoApprove: true }),
    );
    try {
      for (const storageId of shots) {
        await feedback.attachments.add(ctx, { itemId, kind: "screenshot", storageId, userId });
      }
      if (a.audioStorageId) {
        await feedback.attachments.add(ctx, { itemId, kind: "audio", storageId: a.audioStorageId, userId });
      }
    } catch (e) {
      // The whole mutation (including the item insert) rolls back.
      badRequest(cleanMessage(e));
    }
    const item: any = await feedback.items.get(ctx, { itemId: itemId as any });
    const state: ItemState = item?.state ?? "submitted";
    // An admin's own request goes straight to "requested": snapshot it now,
    // approved by its author, so it can be built in the cloud like any other.
    if (state === "requested") {
      await feedback.chefSnapshots.snapshotOwnRequest(ctx, { itemId, adminUserId: userId });
    }
    if (options.onSubmitted) {
      await options.onSubmitted(ctx, {
        itemId,
        userId,
        title,
        description: typed,
        transcript,
        state,
        screenshotCount: shots.length,
        hasAudio: !!a.audioStorageId,
      });
    }
    return { itemId, state };
  };

  // ------------------------------------------------------------------ queries

  /** Build status for the panel: todos, progress feed, open questions (admins only once users exist). */
  const agentState = queryGeneric({
    args: {},
    returns: v.object({
      todos: v.array(v.any()),
      progress: v.array(v.any()),
      refinements: v.array(v.any()),
    }),
    handler: async (ctx) => {
      const viewer = await userIdOf(ctx);
      const s: any = await feedback.agentState.snapshot(ctx, { viewer });
      return { todos: s.todos, progress: s.progress, refinements: s.refinements };
    },
  });

  /** The public board (approved requests, plus pre-triage ones with `includeCommunity`). */
  const listPublicItems = queryGeneric({
    args: { limit: v.optional(v.number()) },
    returns: v.array(
      v.object({
        _id: v.string(),
        number: v.number(),
        title: v.string(),
        description: v.string(),
        state: vItemState,
        voteCount: v.number(),
      }),
    ),
    handler: async (ctx, a) => {
      const r: any = await feedback.items.listPublic(ctx, { limit: a.limit ?? 20, includeCommunity });
      return (r.page ?? []).map((i: any) => ({
        _id: String(i._id),
        number: i.number,
        title: i.title,
        description: i.description,
        state: STATE_FOR_PUBLIC_STATUS[i.publicStatus] ?? "requested",
        voteCount: i.voteCount ?? 0,
      }));
    },
  });

  /** Screenshots / voice notes of up to 50 items, filtered by each item's read rules. */
  const listAttachments = queryGeneric({
    args: { itemId: v.optional(v.string()), itemIds: v.optional(v.array(v.string())) },
    returns: v.array(
      v.object({
        itemId: v.string(),
        attachments: v.array(
          v.object({ kind: vAttachmentKind, url: v.union(v.string(), v.null()), mimeType: v.string() }),
        ),
      }),
    ),
    handler: async (ctx, a) => {
      const ids = [...(a.itemId ? [a.itemId] : []), ...(a.itemIds ?? [])].slice(0, 50);
      if (!ids.length) return [];
      const viewer = await userIdOf(ctx);
      let rows;
      try {
        rows = await feedback.attachments.listForItems(ctx, { itemIds: ids, viewer, includeCommunity });
      } catch {
        badRequest("Unknown request id");
      }
      return rows.map((r) => ({
        itemId: String(r.itemId),
        attachments: r.attachments.map((x) => ({ kind: x.kind, url: x.url, mimeType: x.mimeType })),
      }));
    },
  });

  /** The caller's own requests, newest first (≤50). [] when signed out. */
  const mine = queryGeneric({
    args: {},
    returns: v.array(
      v.object({
        _id: v.string(),
        title: v.string(),
        state: vItemState,
        _creationTime: v.number(),
        hasAudio: v.boolean(),
        screenshotCount: v.number(),
      }),
    ),
    handler: async (ctx) => {
      const userId = await userIdOf(ctx);
      if (!userId) return [];
      const rows = await feedback.items.listByCreator(ctx, { userId, limit: 50 });
      return rows.map((r) => ({
        _id: String(r._id),
        title: r.title,
        state: r.state,
        _creationTime: r._creationTime,
        hasAudio: r.hasAudio,
        screenshotCount: r.screenshotCount,
      }));
    },
  });

  /**
   * The caller's Chef user id (what getUserId returns) and whether they're an
   * admin; null when signed out. The panel shows the id to a signed-in user
   * who isn't an admin, so the app's owner can name themselves admin with
   * `npx chef init --admin <id>`.
   */
  const whoAmI = queryGeneric({
    args: {},
    returns: v.union(v.object({ userId: v.string(), admin: v.boolean() }), v.null()),
    handler: async (ctx) => {
      const userId = await userIdOf(ctx);
      if (!userId) return null;
      return { userId, admin: await isAdmin(ctx, userId) };
    },
  });

  /**
   * The caller's unread notifications (their request approved, shipped, ...),
   * newest first, for the panel's popup. [] when signed out.
   */
  const myNotifications = queryGeneric({
    args: {},
    returns: v.array(
      v.object({
        id: v.string(),
        itemId: v.string(),
        type: v.string(),
        message: v.string(),
        stamp: v.number(),
        title: v.union(v.string(), v.null()),
        number: v.union(v.number(), v.null()),
      }),
    ),
    handler: async (ctx) => {
      const userId = await userIdOf(ctx);
      if (!userId) return [];
      const rows = await feedback.notifications.listForUser(ctx, { userId, limit: MAX_NOTIFICATIONS, unreadOnly: true });
      return await Promise.all(
        rows.map(async (n: any) => {
          const item: any = await feedback.items.get(ctx, { itemId: n.itemId });
          return {
            id: String(n._id),
            itemId: String(n.itemId),
            type: n.type,
            message: n.message,
            stamp: n.stamp,
            title: item?.title ?? null,
            number: item?.number ?? null,
          };
        }),
      );
    },
  });

  /** Whether the caller is a component admin (sees approvals + build status). */
  const amAdmin = queryGeneric({
    args: {},
    returns: v.boolean(),
    handler: async (ctx) => await isAdmin(ctx, await userIdOf(ctx)),
  });

  /** Requests from non-admins waiting for an admin, with media. [] for non-admins. */
  const awaitingApproval = queryGeneric({
    args: {},
    returns: v.array(
      v.object({
        id: v.string(),
        title: v.string(),
        description: v.string(),
        from: v.union(v.string(), v.null()),
        at: v.number(),
        attachments: v.array(v.object({ kind: vAttachmentKind, url: v.union(v.string(), v.null()) })),
      }),
    ),
    handler: async (ctx) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return [];
      const page: any[] = await feedback.items.listAwaitingApproval(ctx, { viewer: me, limit: 50 });
      const media = page.length
        ? await feedback.attachments.listForItems(ctx, {
            itemIds: page.map((i) => i._id),
            viewer: me,
            agentKey: agentKey(),
          })
        : [];
      const byItem = new Map(media.map((m) => [String(m.itemId), m.attachments]));
      return await Promise.all(
        page.map(async (i) => ({
          id: String(i._id),
          title: String(i.title ?? ""),
          description: String(i.description ?? "").slice(0, 2000),
          from: i.createdBy && options.getUserName ? await options.getUserName(ctx, String(i.createdBy)) : null,
          at: Number(i._creationTime),
          attachments: (byItem.get(String(i._id)) ?? []).map((x) => ({ kind: x.kind, url: x.url ?? null })),
        })),
      );
    },
  });

  /**
   * One approval snapshot, in full: every character of the title, description
   * and transcript, and every attachment. The approvals view renders this, not
   * the item. null for non-admins.
   */
  const approvalSnapshot = queryGeneric({
    args: { snapshotId: v.string() },
    returns: v.union(
      v.null(),
      v.object({
        snapshotId: v.string(),
        itemId: v.string(),
        title: v.string(),
        description: v.string(),
        transcript: v.union(v.string(), v.null()),
        contentHash: v.string(),
        approved: v.boolean(),
        attachments: v.array(
          v.object({
            kind: vAttachmentKind,
            url: v.union(v.string(), v.null()),
            contentType: v.string(),
            size: v.number(),
            sha256: v.string(),
          }),
        ),
      }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      let r: any = null;
      try {
        r = await feedback.chefSnapshots.get(ctx, { snapshotId: a.snapshotId, viewer: me });
      } catch {
        badRequest("Unknown snapshot");
      }
      if (!r) return null;
      const s = r.snapshot;
      return {
        snapshotId: String(s._id),
        itemId: String(s.itemId),
        title: s.title,
        description: s.description,
        transcript: s.transcript,
        contentHash: s.contentHash,
        approved: s.approvedAt !== undefined,
        attachments: s.attachments.map((x: any, i: number) => ({
          kind: x.kind,
          url: r.attachmentUrls[i] ?? null,
          contentType: x.contentType,
          size: x.size,
          sha256: x.sha256,
        })),
      };
    },
  });

  /**
   * A Chef run's log lines, oldest first, a page of numbered batches at a
   * time (pass the previous `nextCursor` as `cursor`; null means the last
   * page). The lines were scrubbed when the runner's batch was stored.
   * Admins only: everyone else gets an empty last page.
   */
  const runLogs = queryGeneric({
    args: {
      runId: v.string(),
      cursor: v.optional(v.union(v.number(), v.null())),
      limit: v.optional(v.number()),
    },
    returns: v.object({
      page: v.array(v.object({ seq: v.number(), at: v.number(), lines: v.array(v.string()) })),
      nextCursor: v.union(v.number(), v.null()),
    }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return { page: [], nextCursor: null };
      return await ctx.runQuery(component.chefRuns.listLogs, {
        viewer: me,
        runId: a.runId,
        cursor: a.cursor ?? null,
        ...(a.limit === undefined ? {} : { limit: a.limit }),
      });
    },
  });

  /**
   * What build agents said about the image's skills: wrong, missing,
   * outdated, or deviated from. One run's in the order written, or all of it
   * (optionally for one skill), newest first, a page at a time. Admins only:
   * everyone else gets an empty last page.
   */
  const skillFeedback = queryGeneric({
    args: { runId: v.optional(v.string()), skill: v.optional(v.string()), paginationOpts: paginationOptsValidator },
    returns: v.object({
      page: v.array(
        v.object({
          id: v.string(),
          runId: v.string(),
          itemId: v.string(),
          skill: v.string(),
          kind: v.union(v.literal("wrong"), v.literal("missing"), v.literal("outdated"), v.literal("deviation")),
          message: v.string(),
          suggestion: v.union(v.string(), v.null()),
          createdAt: v.number(),
        }),
      ),
      isDone: v.boolean(),
      continueCursor: v.string(),
    }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return { page: [], isDone: true, continueCursor: "" };
      return await ctx.runQuery(component.chefFeedback.listSkillFeedback, {
        viewer: me,
        paginationOpts: a.paginationOpts,
        ...(a.runId !== undefined ? { runId: a.runId } : {}),
        ...(a.skill !== undefined ? { skill: a.skill } : {}),
      });
    },
  });

  /**
   * A run's screenshots of the built app, taken by the runner after the
   * guards, in the order taken: name, page path, the file's storage URL,
   * size in pixels. Admins only: everyone else gets [].
   */
  const runScreenshots = queryGeneric({
    args: { runId: v.string() },
    returns: v.array(
      v.object({
        name: v.string(),
        path: v.string(),
        url: v.union(v.string(), v.null()),
        width: v.number(),
        height: v.number(),
        createdAt: v.number(),
      }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return [];
      const rows = await ctx.runQuery(component.chefScreenshots.listRunScreenshots, { viewer: me, runId: a.runId });
      return rows.map((r) => ({ name: r.name, path: r.path, url: r.url, width: r.width, height: r.height, createdAt: r.createdAt }));
    },
  });

  const vRunStatus = v.union(
    v.literal("active"),
    v.literal("reconciling"),
    v.literal("built"),
    v.literal("failed"),
    v.literal("cancelled"),
  );
  const vPhase = v.union(...RUN_PHASES.map(([p]) => v.literal(p)));
  /** The host's name for a run `npx chef work` built (provenance runner "local"), else null. */
  const builtLocallyOn = (r: { provenance?: { runner?: string; host?: string } }) =>
    r.provenance?.runner === "local" ? (r.provenance.host ?? "a developer's machine") : null;

  /**
   * A cloud run as the panel's build view shows it: where it is in the phase
   * list, spend, model calls, heartbeat, the preview, and how it ended. Pass
   * `runId`, or `itemId` for that request's newest run. `previewLoginUrl` is
   * a one-time sign-in link to the preview: open it once. Admins only:
   * everyone else, and an unknown run, gets null.
   */
  const runStatus = queryGeneric({
    args: { runId: v.optional(v.string()), itemId: v.optional(v.string()) },
    returns: v.union(
      v.null(),
      v.object({
        runId: v.string(),
        itemId: v.string(),
        seq: v.number(),
        status: vRunStatus,
        phase: vPhase,
        statusText: v.string(),
        phases: v.array(
          v.object({
            phase: vPhase,
            label: v.string(),
            state: v.union(v.literal("done"), v.literal("now"), v.literal("stopped"), v.literal("todo")),
          }),
        ),
        createdAt: v.number(),
        heartbeatAt: v.number(),
        finishedAt: v.union(v.number(), v.null()),
        spendUsd: v.number(),
        aiRequests: v.number(),
        aiInFlight: v.number(),
        previewUrl: v.union(v.string(), v.null()),
        previewLoginUrl: v.union(v.string(), v.null()),
        branch: v.union(v.string(), v.null()),
        commitSha: v.union(v.string(), v.null()),
        filesChanged: v.array(v.string()),
        error: v.union(v.string(), v.null()),
        // The machine's name when `npx chef work` built it there; null for the cloud.
        builtLocallyOn: v.union(v.string(), v.null()),
        // A failed run, for people: one line of what went wrong and one of
        // what to do (src/chef/failures.ts). Show these, not `error`.
        failure: v.union(
          v.null(),
          v.object({
            code: v.string(),
            kind: v.union(v.literal("transient"), v.literal("deterministic"), v.literal("environmental")),
            reason: v.string(),
            action: v.string(),
          }),
        ),
        // When Chef will try a transient failure again on its own; null for none.
        retryAt: v.union(v.number(), v.null()),
        // Chef's try of this approval: 1, or 2 and 3 for its own retries.
        attempt: v.number(),
        // Whether "Try again" applies: the request's newest run failed or was cancelled.
        canRetry: v.boolean(),
        // An admin's fix or removal (fixRequest, removeRequest): which, and their words.
        followUp: v.optional(v.union(v.null(), v.object({ kind: v.union(v.literal("fix"), v.literal("remove")), note: v.union(v.string(), v.null()) }))),
        // The checks against the base and after the agent (src/chef/gates.ts).
        gates: v.array(
          v.object({
            command: v.string(),
            baseline: v.union(v.literal("pass"), v.literal("fail"), v.literal("none")),
            baselineCached: v.boolean(),
            result: v.union(v.literal("pass"), v.literal("fail"), v.null()),
            // Failed before this build too, so it didn't block.
            preexisting: v.boolean(),
            // Passed before and fails now, or has new problems: what fails the build.
            blocking: v.boolean(),
            // "main already fails `npm run lint` in X; not blocking this build", or what is new.
            note: v.optional(v.union(v.string(), v.null())),
            // A merge's baseline is main's own tree.
            baselineOn: v.optional(v.union(v.literal("main"), v.null())),
          }),
        ),
        fixRound: v.number(),
        fixRounds: v.number(),
        // Milliseconds per phase, from the runner.
        phaseMs: v.record(v.string(), v.number()),
        convexPlugin: v.union(v.string(), v.null()),
        // "Try again": how the earlier attempt's work was used (same base, rebased, or fresh and why).
        earlierAttempt: v.union(v.string(), v.null()),
        // Each fix round: what failed in verification, when, and the spend when it started.
        rounds: v.array(v.object({ round: v.number(), reason: v.string(), at: v.number(), spendUsd: v.number() })),
        // What the agent tried (its summary, the diff stat), even when the run failed. Untrusted text.
        summary: v.union(v.string(), v.null()),
        diffStat: v.union(v.string(), v.null()),
        // What Chef did about a failure (src/chef/recovery.ts): its class and action.
        recovery: v.union(v.null(), v.object({ class: v.string(), action: v.string() })),
        // A batch build (docs/chef-pipeline.md, "Batching"): every request it
        // builds, this one first, and the planner's title; null for a single build.
        batch: v.union(
          v.null(),
          v.object({
            title: v.string(),
            reason: v.string(),
            requests: v.array(v.object({ itemId: v.string(), number: v.number(), title: v.string() })),
          }),
        ),
        // A repair commit for the repo problem it failed on ("Chef can fix this", applyRepair).
        repair: v.union(
          v.null(),
          v.object({
            repairId: v.string(),
            kind: v.string(),
            status: v.string(),
            summary: v.union(v.string(), v.null()),
            files: v.array(v.object({ path: v.string(), how: v.string() })),
            sha: v.union(v.string(), v.null()),
            error: v.union(v.string(), v.null()),
          }),
        ),
      }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      if (a.runId === undefined && a.itemId === undefined) return null;
      const r = await ctx.runQuery(component.chefRuns.lookup, {
        viewer: me,
        ...(a.runId !== undefined ? { runId: a.runId } : { itemId: a.itemId }),
      });
      if (!r) return null;
      const fixRounds = clampFixRounds((await ctx.runQuery(component.chefRunnerConfig.get, {})).fixRounds);
      const newest = await ctx.runQuery(component.chefRuns.lookup, { viewer: me, itemId: String(r.itemId) });
      // A built run Ship it couldn't ship as it is (main moved) can be tried again too.
      const finishedBad = r.status === "failed" || r.status === "cancelled" || (r.status === "built" && r.shipBlocked !== undefined);
      return {
        runId: String(r._id),
        itemId: String(r.itemId),
        seq: r.seq,
        status: r.status,
        // A finished run: where it stopped (its phase is "done" or "ended").
        phase: (r.endedPhase ?? r.phase) as Exclude<typeof r.phase, "ended">,
        statusText: runStatusText(r.status, r.endedPhase ?? r.phase, { round: r.fixRound, rounds: fixRounds }),
        phases: phaseSteps(r.status, r.endedPhase ?? r.phase),
        createdAt: r.createdAt,
        heartbeatAt: r.heartbeatAt,
        finishedAt: r.finishedAt ?? null,
        spendUsd: r.spendUsd ?? 0,
        aiRequests: r.aiRequests ?? 0,
        aiInFlight: r.aiInFlight ?? 0,
        previewUrl: r.previewUrl ?? null,
        previewLoginUrl: r.previewLoginUrl ?? null,
        branch: r.branch ?? null,
        commitSha: r.commitSha ?? null,
        filesChanged: r.filesChanged ?? [],
        error: r.error ?? null,
        builtLocallyOn: builtLocallyOn(r),
        failure: r.failure ?? (r.status === "failed" ? classifyFailure(r.error) : null),
        retryAt: r.retryAt ?? null,
        attempt: r.attempt ?? 1,
        canRetry: finishedBad && newest !== null && String(newest._id) === String(r._id),
        followUp: r.followUp?.kind ? { kind: r.followUp.kind, note: r.followUp.note ?? null } : null,
        gates: (r.gateResults ?? []).map((g) => ({
          command: g.command,
          baseline: g.baseline,
          baselineCached: g.baselineCached ?? false,
          result: g.result ?? null,
          preexisting: g.baseline === "fail",
          blocking: gateBlocks(g),
          note: gateNote(g),
          baselineOn: g.baselineOn ?? null,
        })),
        fixRound: r.fixRound ?? 0,
        fixRounds,
        phaseMs: r.phaseMs ?? {},
        convexPlugin: r.provenance?.convexPlugin ?? null,
        earlierAttempt: r.provenance?.earlierAttempt ?? null,
        rounds: (r.roundLog ?? []).map((x) => ({ round: x.round, reason: x.reason, at: x.at, spendUsd: x.spendUsd })),
        summary: r.summary ?? null,
        diffStat: r.diffStat ?? null,
        recovery: r.recovery ? { class: r.recovery.class, action: r.recovery.action } : null,
        batch: await (async () => {
          if (!r.batch) return null;
          const all = await ctx.runQuery(component.chefBatches.list, { viewer: me });
          const b = all?.batches.find((x) => String(x.batchId) === String(r.batch!.batchId));
          const requests = [];
          for (const m of r.batch.items) {
            const item: any = await feedback.items.get(ctx, { itemId: m.itemId as any }).catch(() => null);
            if (item) requests.push({ itemId: String(m.itemId), number: Number(item.number), title: String(item.title) });
          }
          return { title: b?.title ?? requests.map((x) => x.title).join(" + "), reason: b?.reason ?? "", requests };
        })(),
        repair: await (async () => {
          const x = await ctx.runQuery(component.chefRepairs.forRun, { viewer: me, runId: String(r._id) });
          return x
            ? { repairId: String(x.repairId), kind: x.kind, status: x.status, summary: x.summary, files: x.files, sha: x.sha, error: x.error }
            : null;
        })(),
      };
    },
  });

  /**
   * The newest cloud runs (at most `limit`, default 10, up to 50), with each
   * request's title, for the panel's list of builds. Admins only: everyone
   * else gets [].
   */
  const recentRuns = queryGeneric({
    args: { limit: v.optional(v.number()) },
    returns: v.array(
      v.object({
        runId: v.string(),
        itemId: v.string(),
        title: v.string(),
        seq: v.number(),
        status: vRunStatus,
        phase: vPhase,
        statusText: v.string(),
        createdAt: v.number(),
        finishedAt: v.union(v.number(), v.null()),
        builtLocallyOn: v.union(v.string(), v.null()),
        // A failed run's one-line reason (src/chef/failures.ts); null otherwise.
        failureReason: v.union(v.string(), v.null()),
        // How many requests it built: more than 1 for a batch.
        requests: v.number(),
        // An admin's fix or removal of the request (#`number`); null for a build.
        followUp: v.optional(v.union(v.null(), v.literal("fix"), v.literal("remove"))),
        number: v.optional(v.union(v.number(), v.null())),
      }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return [];
      const limit = Math.min(50, Math.max(1, Math.floor(a.limit ?? 10) || 10));
      const runs = await ctx.runQuery(component.chefRuns.list, { viewer: me, limit });
      return await Promise.all(
        runs.map(async (r) => {
          const item: any = await feedback.items.get(ctx, { itemId: r.itemId as any }).catch(() => null);
          return {
            runId: String(r._id),
            itemId: String(r.itemId),
            title: String(item?.title ?? ""),
            seq: r.seq,
            status: r.status,
            phase: (r.endedPhase ?? r.phase) as Exclude<typeof r.phase, "ended">,
            statusText: runStatusText(r.status, r.endedPhase ?? r.phase, { round: r.fixRound }),
            createdAt: r.createdAt,
            finishedAt: r.finishedAt ?? null,
            builtLocallyOn: builtLocallyOn(r),
            failureReason:
              r.status === "failed" ? (r.failure ?? classifyFailure(r.error)).reason : null,
            requests: r.batch ? r.batch.items.length : 1,
            followUp: r.followUp?.kind ?? null,
            number: typeof item?.number === "number" ? item.number : null,
          };
        }),
      );
    },
  });

  /**
   * What the panel needs for "Build in cloud": `{ cloudEnabled, workerKeys,
   * autoBuild, queued, busy, upNext }`, `upNext` being what builds next, in
   * order. The panel shows the button only with `cloudEnabled`. Admins only;
   * null for everyone else.
   */
  const buildState = queryGeneric({
    args: {},
    returns: v.union(
      v.null(),
      v.object({
        cloudEnabled: v.boolean(),
        workerKeys: v.number(),
        autoBuild: v.boolean(),
        queued: v.boolean(),
        busy: v.boolean(),
        // A batched request carries its batch's id (`batches`).
        upNext: v.array(v.object({ itemId: v.string(), number: v.number(), title: v.string(), batchId: v.union(v.string(), v.null()) })),
        // Batching (docs/chef-pipeline.md, "Batching"): whether it is on (a
        // planner registered, the setting on), whether the planner is grouping
        // the queue now, and the batches waiting ("planned": splitFromBatch
        // takes a request out), building, or built and not shipped.
        batching: v.boolean(),
        planning: v.boolean(),
        batches: v.array(vBatch),
        // The requests "Fix…" and "Remove…" apply to now (fixRequest,
        // removeRequest): built and waiting for Ship it, or shipped; each with
        // its newest run, the one whose card shows them.
        followUps: v.array(v.object({ itemId: v.string(), number: v.number(), runId: v.string() })),
      }),
    ),
    handler: async (ctx) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      const b = await ctx.runQuery(component.chefRuns.buildState, { viewer: me });
      if (!b) return null;
      return {
        ...b,
        upNext: b.upNext.map((n) => ({ itemId: String(n.itemId), number: n.number, title: n.title, batchId: n.batchId ? String(n.batchId) : null })),
        batches: b.batches.map(batchOut),
        followUps: b.followUps.map((f) => ({ itemId: String(f.itemId), number: f.number, runId: String(f.runId) })),
      };
    },
  });

  /**
   * Split a request out of a batch that hasn't started building (Chef
   * builds it on its own, where it was in the queue). `{ remaining }`: how
   * many requests the batch still has (0 when it was left with one, which
   * then builds alone too). Admins only; audited.
   */
  const splitFromBatch = mutationGeneric({
    args: { itemId: v.string() },
    returns: v.object({ remaining: v.number() }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can change a batch");
      try {
        const r = await ctx.runMutation(component.chefBatches.split, { adminUserId: me, itemId: a.itemId as any });
        return { remaining: r.remaining };
      } catch (e) {
        badRequest(cleanMessage(e));
      }
    },
  });

  /**
   * "Build in cloud": claim the oldest approved request for a cloud build now,
   * with auto-build off. `{ outcome }`: "claimed", "busy", "reconciling",
   * "empty", or "disabled" with cloud builds off. Admins only.
   */
  const buildInCloud = mutationGeneric({
    args: {},
    returns: v.object({ outcome: v.string(), reason: v.union(v.string(), v.null()) }),
    handler: async (ctx) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can start a cloud build");
      const r = await ctx.runMutation(component.chefRuns.buildNow, { adminUserId: me });
      return { outcome: r.outcome, reason: r.outcome === "disabled" ? r.reason : null };
    },
  });

  /**
   * "Try again" on a request whose last cloud build failed or was cancelled,
   * in one step: re-snapshot the request and, if it is exactly what was
   * approved last time (the same content hash), approve that and start a
   * build (with auto-build off too). If it changed, nothing is approved:
   * `{ outcome: "needsApproval", snapshotId, contentHash }`, and the panel
   * opens the normal approval (approvalSnapshot, approveSnapshot) so the
   * admin reads the new text first. `{ outcome: "started", claim }` when it
   * went (claim "claimed", or "busy" when it is queued behind another
   * build), `{ outcome: "refused", reason }` when there is nothing to try
   * again. Audited. Admins only.
   */
  const retryRun = mutationGeneric({
    args: { itemId: v.string() },
    returns: v.union(
      v.object({ outcome: v.literal("started"), claim: v.string(), snapshotId: v.string() }),
      v.object({ outcome: v.literal("needsApproval"), snapshotId: v.string(), contentHash: v.string() }),
      v.object({ outcome: v.literal("refused"), reason: v.string() }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can start a cloud build");
      let itemId: string;
      try {
        itemId = String((await feedback.items.get(ctx, { itemId: a.itemId as any }))?._id ?? "");
      } catch {
        itemId = "";
      }
      if (!itemId) badRequest("Unknown request");
      return await ctx.runMutation(component.chefSnapshots.retry, { itemId, adminUserId: me });
    },
  });

  /**
   * "Fix…" and "Remove…" on a request Chef built (waiting for Ship it, or
   * shipped; buildState's `followUps` lists them): a follow-up build on top
   * of the earlier work, a normal build with checks, a preview and the Ship
   * card. fixRequest tells the agent what is wrong (`note`, the admin's
   * words, required); removeRequest takes the request's change out of the
   * app (`note`, why, optional). `{ started: true, claim }` when it went
   * (claim "claimed", or "busy" when it is queued behind another build),
   * `{ started: false, reason }` when it can't now (it is building or
   * queued, or Chef never built it). Audited. Admins only.
   */
  const followUpRequest = (kind: "fix" | "remove") =>
    mutationGeneric({
      args: { itemId: v.string(), note: kind === "fix" ? v.string() : v.optional(v.string()) },
      returns: v.union(
        v.object({ started: v.literal(true), claim: v.string() }),
        v.object({ started: v.literal(false), reason: v.string() }),
      ),
      handler: async (ctx, a) => {
        const me = await userIdOf(ctx);
        if (!me) unauthenticated();
        if (!(await isAdmin(ctx, me))) forbidden("Only admins can ask Chef to change a build");
        let itemId: string;
        try {
          itemId = String((await feedback.items.get(ctx, { itemId: a.itemId as any }))?._id ?? "");
        } catch {
          itemId = "";
        }
        if (!itemId) badRequest("Unknown request");
        try {
          const r = await ctx.runMutation(component.chefSnapshots.adminFollowUp, {
            itemId,
            kind,
            ...(a.note !== undefined ? { note: a.note } : {}),
            adminUserId: me,
          });
          return r.outcome === "started" ? { started: true as const, claim: r.claim } : { started: false as const, reason: r.reason };
        } catch (e) {
          badRequest(cleanMessage(e));
        }
      },
    });
  const fixRequest = followUpRequest("fix");
  const removeRequest = followUpRequest("remove");

  /**
   * What Chef knows about this app (chefLearnings): the runner's facts,
   * recurring failures and earlier agents' notes, each with the build that
   * last confirmed it, and the brief the next build's agent gets. Admins
   * only: everyone else gets nothing.
   */
  const appLearnings = queryGeneric({
    args: {},
    returns: v.object({
      entries: v.array(
        v.object({
          id: v.string(),
          source: v.union(v.literal("runner"), v.literal("agent"), v.literal("failure")),
          topic: v.string(),
          text: v.string(),
          firstRunSeq: v.number(),
          lastRunSeq: v.number(),
          seenCount: v.number(),
          expired: v.boolean(),
          updatedAt: v.number(),
        }),
      ),
      brief: v.string(),
    }),
    handler: async (ctx) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return { entries: [], brief: "" };
      const r = await ctx.runQuery(component.chefLearnings.list, { viewer: me });
      return { entries: r.entries.map((e) => ({ ...e, id: String(e.id) })), brief: r.brief };
    },
  });

  /** Delete one thing Chef learned (a wrong note, a stale fact). Audited. Admins only. */
  const forgetLearning = mutationGeneric({
    args: { id: v.string() },
    returns: v.boolean(),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can change what Chef knows");
      return await ctx.runMutation(component.chefLearnings.forget, { id: a.id, adminUserId: me });
    },
  });

  /**
   * What recent builds cost, oldest first, for the trend: spend, tokens,
   * model calls, wall time, per-phase times, attempt and fix rounds. Admins
   * only: everyone else gets [].
   */
  const buildCosts = queryGeneric({
    args: { limit: v.optional(v.number()) },
    returns: v.array(
      v.object({
        runId: v.string(),
        seq: v.number(),
        status: v.string(),
        createdAt: v.number(),
        wallMs: v.union(v.number(), v.null()),
        spendUsd: v.number(),
        aiRequests: v.number(),
        inputTokens: v.number(),
        outputTokens: v.number(),
        phaseMs: v.record(v.string(), v.number()),
        attempt: v.number(),
        fixRounds: v.number(),
        failure: v.union(v.string(), v.null()),
        warm: v.union(v.boolean(), v.null()),
      }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return [];
      const rows = await ctx.runQuery(component.chefRuns.costs, { viewer: me, ...(a.limit !== undefined ? { limit: a.limit } : {}) });
      return rows.map((r) => ({ ...r, runId: String(r.runId) }));
    },
  });

  // ------------------------------------------------------------ Ship it

  const vShipRelease = v.object({
    releaseId: v.string(),
    seq: v.number(),
    state: v.string(),
    open: v.boolean(),
    sha: v.string(),
    shipRunId: v.union(v.string(), v.null()),
    approvedDiffHash: v.union(v.string(), v.null()),
    error: v.union(v.string(), v.null()),
    siteUrl: v.union(v.string(), v.null()),
    mainSha: v.union(v.string(), v.null()),
    updatedAt: v.number(),
  });

  /**
   * What "Ship it" would ship to the live app: the newest built run (its
   * commit is chef's tip), the facts of its release diff (main..chef) with
   * the hash to approve, the requests it covers, the newest cloud release
   * (how the last ship went), and `blocked`, why it can't ship now. Admins
   * only: everyone else gets null.
   */
  const shipCandidate = queryGeneric({
    args: {},
    returns: v.union(
      v.null(),
      v.object({
        run: v.union(
          v.null(),
          v.object({
            runId: v.string(),
            seq: v.number(),
            commitSha: v.union(v.string(), v.null()),
            baseSha: v.union(v.string(), v.null()),
            hasFrontend: v.boolean(),
            finishedAt: v.union(v.number(), v.null()),
            // Main moved before Ship it and Chef merged it in (a merge-only build):
            // what main brought, and whether the merged change is the one approved.
            mergedMain: v.union(v.null(), v.object({ count: v.number(), subjects: v.array(v.string()) })),
            refresh: v.union(v.null(), v.object({ releaseSeq: v.number(), sameDiff: v.boolean() })),
            // Merging main in failed: Try again (retryRun) on this request.
            retryItemId: v.union(v.string(), v.null()),
            refreshing: v.optional(v.union(v.literal("queued"), v.literal("merging"), v.null())),
            // A release paused while it follows main: approving this build ships it in that release's place.
            replaces: v.optional(v.union(v.number(), v.null())),
            diff: v.union(
              v.null(),
              v.object({
                diffHash: v.string(),
                chunkCount: v.number(),
                bytes: v.number(),
                filesChanged: v.array(v.string()),
                filesTruncated: v.boolean(),
                depsChanged: v.boolean(),
                redactions: v.number(),
              }),
            ),
          }),
        ),
        requests: v.array(v.object({ runId: v.string(), itemId: v.string(), number: v.union(v.number(), v.null()), title: v.string() })),
        // Requests whose own build failed after pushing to chef: their code is
        // under this build and ships with it. Show them before approving.
        alsoShips: v.optional(
          v.array(v.object({ runId: v.string(), itemId: v.string(), number: v.union(v.number(), v.null()), title: v.string(), seq: v.number() })),
        ),
        release: v.union(v.null(), vShipRelease),
        blocked: v.union(v.string(), v.null()),
        // The open release following main (docs/chef-pipeline.md, "When main
        // moves under Ship it"): `text` says where it is ("Merged main in",
        // "Resolving a conflict", "Needs you: conflict in X"). needsApproval:
        // shipApprove with `runId` and `diffHash` approves the merge, whose
        // `resolution` is all that needs reading. failed, stalled: shipApprove
        // with `shipRunId` and `approvedDiffHash` tries again.
        follow: v.optional(
          v.union(
            v.null(),
            v.object({
              releaseSeq: v.number(),
              status: v.string(),
              mainSha: v.string(),
              attempts: v.number(),
              text: v.string(),
              reason: v.union(v.string(), v.null()),
              files: v.array(v.string()),
              conflicts: v.array(v.string()),
              repaired: v.boolean(),
              runId: v.union(v.string(), v.null()),
              diffHash: v.union(v.string(), v.null()),
              depsChanged: v.boolean(),
              resolution: v.union(v.string(), v.null()),
              resolutionTruncated: v.boolean(),
              shipRunId: v.union(v.string(), v.null()),
              approvedDiffHash: v.union(v.string(), v.null()),
            }),
          ),
        ),
      }),
    ),
    handler: async (ctx) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      const c = await ctx.runQuery(component.chefShip.candidate, { viewer: me });
      if (!c) return null;
      return {
        run: c.run ? { ...c.run, runId: String(c.run.runId), retryItemId: c.run.retryItemId === null ? null : String(c.run.retryItemId) } : null,
        requests: c.requests.map((r) => ({ runId: String(r.runId), itemId: String(r.itemId), number: r.number, title: r.title })),
        alsoShips: (c.alsoShips ?? []).map((r) => ({ runId: String(r.runId), itemId: String(r.itemId), number: r.number, title: r.title, seq: r.seq })),
        release: c.release
          ? { ...c.release, releaseId: String(c.release.releaseId), shipRunId: c.release.shipRunId === null ? null : String(c.release.shipRunId) }
          : null,
        blocked: c.blocked,
        follow: c.follow
          ? {
              ...c.follow,
              runId: c.follow.runId === null ? null : String(c.follow.runId),
              shipRunId: c.follow.shipRunId === null ? null : String(c.follow.shipRunId),
            }
          : null,
      };
    },
  });

  /**
   * "Chef can fix this: ... [Apply]": apply a repair commit (an out-of-date
   * lockfile, tracked symlinks or env files) by the sha shown. Main moves to
   * it and the request builds again. Admins only; audited.
   */
  const applyRepair = mutationGeneric({
    args: { repairId: v.string(), sha: v.string() },
    returns: v.object({ applying: v.boolean(), reason: v.optional(v.string()) }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can apply a repair");
      try {
        return await ctx.runMutation(component.chefRepairs.apply, { adminUserId: me, repairId: a.repairId as any, sha: a.sha });
      } catch (e) {
        badRequest(cleanMessage(e));
      }
    },
  });

  /**
   * The plain-language Ship card (docs/chef-pipeline.md, "The Ship card"):
   * for one build (`runId`), or without one for what "Ship it" would ship.
   * "What changed" and "What to try" per request (the agents' summaries,
   * scrubbed, untrusted: show as text), the screenshots, the preview links,
   * the risk flags (from the diff by fixed rules, never from the agent),
   * and the diff's facts for "Details". Plain strings, numbers and URLs, so
   * ChefKit can decode it as is. Admins only: null for everyone else.
   */
  const buildCard = queryGeneric({
    args: { runId: v.optional(v.string()) },
    returns: v.union(v.null(), vBuildCard),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      const c = await ctx.runQuery(component.chefCards.card, { viewer: me, ...(a.runId !== undefined ? { runId: a.runId } : {}) });
      if (!c) return null;
      return {
        ...c,
        runId: String(c.runId),
        requests: c.requests.map((r) => ({ ...r, runId: String(r.runId), itemId: String(r.itemId) })),
        screenshots: c.screenshots.map((x) => ({ name: x.name, path: x.path, url: x.url, width: x.width, height: x.height })),
      };
    },
  });

  /**
   * Preview data (docs/chef-pipeline.md, "Preview data"): "demo" (the
   * default: previews get the app's demo data) or "admin-copy" (previews get
   * a copy of the signed-in admin's own rows, never anyone else's, when the
   * app opted in with chefCloud's `previewData`). Admins only: null for
   * everyone else. `available` says whether the app opted in.
   */
  const previewDataMode = queryGeneric({
    args: {},
    returns: v.union(
      v.null(),
      v.object({ mode: v.union(v.literal("demo"), v.literal("admin-copy")), mine: v.boolean() }),
    ),
    handler: async (ctx) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      const m = await ctx.runQuery(component.chefPreviewData.mode, { viewer: me });
      if (!m) return null;
      return { mode: m.mode, mine: m.userId === me };
    },
  });

  /** Turn "admin-copy" on (copying the caller's own data) or back to "demo". App admins only; audited. */
  const setPreviewData = mutationGeneric({
    args: { mode: v.union(v.literal("demo"), v.literal("admin-copy")) },
    returns: v.object({ mode: v.union(v.literal("demo"), v.literal("admin-copy")) }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can choose the preview's data");
      try {
        return await ctx.runMutation(component.chefPreviewData.setMode, { adminUserId: me, mode: a.mode });
      } catch (e) {
        badRequest(cleanMessage(e));
      }
    },
  });

  /** One chunk of a built run's release diff (scrubbed), for "Ship it". Admins only: null for everyone else. */
  const shipDiffChunk = queryGeneric({
    args: { runId: v.string(), index: v.number() },
    returns: v.union(
      v.null(),
      v.object({ index: v.number(), count: v.number(), text: v.string(), sha256: v.string(), redactions: v.number() }),
    ),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return null;
      return await ctx.runQuery(component.chefShip.diffChunk, { viewer: me, runId: a.runId, index: a.index });
    },
  });

  /**
   * "Ship to live": ship that run's commit to the live app, approving the
   * release diff by the hash the admin was shown (`depsAcknowledged` too
   * when it changes dependencies). The host's shipper does the rest. The
   * same call for a release that failed after its backend deploy tries it
   * again. Admins only.
   */
  const shipApprove = mutationGeneric({
    args: { runId: v.string(), diffHash: v.string(), depsAcknowledged: v.optional(v.boolean()) },
    returns: v.object({
      approved: v.boolean(),
      reason: v.optional(v.string()),
      releaseId: v.optional(v.string()),
      seq: v.optional(v.number()),
      started: v.optional(v.boolean()),
    }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can ship");
      try {
        const r = await ctx.runMutation(component.chefShip.approve, { adminUserId: me, ...a });
        return { ...r, ...(r.releaseId !== undefined ? { releaseId: String(r.releaseId) } : {}) };
      } catch (e) {
        badRequest(cleanMessage(e));
      }
    },
  });

  const vApprovalStatus = v.union(v.literal("pending"), v.literal("approved"), v.literal("declined"));

  /**
   * Steps builds needed that cost money or reach outside the app (a domain,
   * real email, a paid API), which the agent wrote down instead of taking.
   * One run's in the order written, or all of them (optionally one `status`,
   * such as "pending"), newest first, a page at a time. Admins only:
   * everyone else gets an empty last page.
   */
  const approvalRequests = queryGeneric({
    args: { runId: v.optional(v.string()), status: v.optional(vApprovalStatus), paginationOpts: paginationOptsValidator },
    returns: v.object({
      page: v.array(
        v.object({
          id: v.string(),
          runId: v.string(),
          itemId: v.string(),
          action: v.string(),
          skill: v.union(v.string(), v.null()),
          estimatedCostUsd: v.union(v.number(), v.null()),
          why: v.string(),
          commandOrSteps: v.string(),
          status: vApprovalStatus,
          decidedBy: v.union(v.string(), v.null()),
          decidedAt: v.union(v.number(), v.null()),
          decisionNote: v.union(v.string(), v.null()),
          createdAt: v.number(),
        }),
      ),
      isDone: v.boolean(),
      continueCursor: v.string(),
    }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me || !(await isAdmin(ctx, me))) return { page: [], isDone: true, continueCursor: "" };
      return await ctx.runQuery(component.chefFeedback.listApprovalRequests, {
        viewer: me,
        paginationOpts: a.paginationOpts,
        ...(a.runId !== undefined ? { runId: a.runId } : {}),
        ...(a.status !== undefined ? { status: a.status } : {}),
      });
    },
  });

  // ---------------------------------------------------------------- mutations

  const decide = (decision: "approved" | "declined") =>
    mutationGeneric({
      args: { id: v.string(), note: v.optional(v.string()) },
      returns: v.object({ status: vApprovalStatus, decidedAt: v.number(), changed: v.boolean() }),
      handler: async (ctx, a) => {
        const me = await userIdOf(ctx);
        if (!me) unauthenticated();
        if (!(await isAdmin(ctx, me))) forbidden("Only admins can decide approval requests");
        try {
          return await ctx.runMutation(component.chefFeedback.decideApprovalRequest, {
            adminUserId: me,
            requestId: a.id,
            decision,
            ...(a.note !== undefined ? { note: a.note } : {}),
          });
        } catch (e) {
          badRequest(cleanMessage(e));
        }
      },
    });

  /**
   * Admin: approve a pending approval request. This records the decision
   * (audited); nothing carries out the step yet. Approving again is a no-op;
   * approving a declined request is refused.
   */
  const approveApprovalRequest = decide("approved");

  /** Admin: decline a pending approval request. Same rules as approving. */
  const declineApprovalRequest = decide("declined");

  /** Admin opened a request for approval: snapshot exactly what they'll approve. */
  const prepareApproval = mutationGeneric({
    args: { id: v.string() },
    returns: v.object({ snapshotId: v.string(), contentHash: v.string() }),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can approve requests");
      try {
        return await feedback.chefSnapshots.prepareApproval(ctx, { itemId: a.id, adminUserId: me });
      } catch (e) {
        badRequest(cleanMessage(e));
      }
    },
  });

  /**
   * Approve the snapshot the admin was shown. The only approval that can lead
   * to a cloud build; refused if the hash is wrong or the request changed.
   */
  const approveSnapshot = mutationGeneric({
    args: { snapshotId: v.string(), contentHash: v.string() },
    returns: v.null(),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can approve requests");
      let r: Awaited<ReturnType<typeof feedback.chefSnapshots.approve>>;
      try {
        r = await feedback.chefSnapshots.approve(ctx, { ...a, adminUserId: me });
      } catch (e) {
        badRequest(cleanMessage(e));
      }
      if (r.submitted) {
        const { number, title, createdBy } = r.submitted;
        await requestApproved(ctx, { itemId: r.itemId, number, title, userId: createdBy, approvedBy: me });
      }
      return null;
    },
  });

  /** Mark the caller's own notifications read (the popup's "Got it"). Anyone else's ids are skipped. */
  const markNotificationsRead = mutationGeneric({
    args: { ids: v.array(v.string()) },
    returns: v.null(),
    handler: async (ctx, a) => {
      const userId = await userIdOf(ctx);
      if (!userId) unauthenticated();
      for (const id of a.ids.slice(0, MAX_NOTIFICATIONS * 5)) {
        try {
          await feedback.notifications.markRead(ctx, { id: id as any, userId });
        } catch {
          // Not theirs, or not an id: nothing to mark.
        }
      }
      return null;
    },
  });

  /** Upload URL (component storage) for one screenshot or voice note. Signed-in only. */
  const generateUploadUrl = mutationGeneric({
    args: {},
    returns: v.string(),
    handler: async (ctx) => {
      await requireUser(ctx);
      return await feedback.attachments.generateUploadUrl(ctx);
    },
  });

  /** File a text-only request. */
  const submitRequest = mutationGeneric({
    args: { title: v.string(), description: v.optional(v.string()) },
    returns: v.null(),
    handler: async (ctx, a) => {
      const userId = await requireUser(ctx);
      await fileRequest(ctx, userId, a);
      return null;
    },
  });

  /**
   * File a request with up to 4 screenshots and/or one voice note (uploaded via
   * generateUploadUrl first). `transcript` is the client's speech-to-text.
   */
  const submitRequestWithMedia = mutationGeneric({
    args: {
      title: v.string(),
      description: v.optional(v.string()),
      transcript: v.optional(v.string()),
      screenshotStorageIds: v.array(v.string()),
      audioStorageId: v.optional(v.string()),
      context: v.optional(v.object({ screen: v.optional(v.string()), ref: v.optional(v.string()) })),
    },
    returns: v.object({ itemId: v.string() }),
    handler: async (ctx, a) => {
      const userId = await requireUser(ctx);
      const { itemId } = await fileRequest(ctx, userId, a);
      return { itemId };
    },
  });

  /** +1 a request on the public board (one vote per user; repeat calls are no-ops). */
  const upvoteRequest = mutationGeneric({
    args: { id: v.string() },
    returns: v.null(),
    handler: async (ctx, a) => {
      const userId = await requireUser(ctx);
      try {
        await feedback.bids.place(ctx, { userId, itemId: a.id as any, amount: 1 });
      } catch (e) {
        badRequest(cleanMessage(e));
      }
      return null;
    },
  });

  /** Answer one of Chef's clarifying questions (admins, or anyone before the first user). */
  const answerRefinement = mutationGeneric({
    args: { id: v.string(), answer: v.string() },
    returns: v.null(),
    handler: async (ctx, a) => {
      const userId = await userIdOf(ctx);
      await requireBuildAudience(ctx, userId);
      const answer = a.answer.trim().slice(0, MAX_TEXT);
      if (!answer) badRequest("An answer is required");
      const q = await requireRefinement(ctx, a.id);
      await feedback.devLogs.post(ctx, { itemId: q._id, authorId: userId ?? "owner", message: answer });
      return null;
    },
  });

  /** Skip one of Chef's clarifying questions. Same audience as answerRefinement. */
  const skipRefinement = mutationGeneric({
    args: { id: v.string() },
    returns: v.null(),
    handler: async (ctx, a) => {
      await requireBuildAudience(ctx, await userIdOf(ctx));
      const q = await requireRefinement(ctx, a.id);
      await feedback.items.transitionState(ctx, { itemId: q._id, state: "rejected" });
      return null;
    },
  });

  /** Admin: approve (→ build queue) or reject a request awaiting approval. */
  /**
   * Release notes: what shipped after `since` (ms epoch), newest first (≤50).
   * Public — only the admin-written changelog line and ship time are returned.
   * Ship with a line via `feedback.items.complete(ctx, { itemId, changelog })`.
   */
  const whatsNew = queryGeneric({
    args: { since: v.number() },
    returns: v.array(v.object({ id: v.string(), text: v.string(), at: v.number() })),
    handler: async (ctx, a) => {
      const since = Number.isFinite(a.since) ? a.since : 0;
      const rows = await feedback.items.listShippedSince(ctx, { since, limit: 50 });
      return rows.map((r) => ({ id: String(r._id), text: r.changelog, at: r.completedAt }));
    },
  });

  const review = mutationGeneric({
    args: { id: v.string(), approve: v.boolean() },
    returns: v.null(),
    handler: async (ctx, a) => {
      const me = await userIdOf(ctx);
      if (!me) unauthenticated();
      if (!(await isAdmin(ctx, me))) forbidden("Only admins can approve or reject requests");
      let before: any;
      try {
        before = await feedback.items.get(ctx, { itemId: a.id as any });
        await feedback.items.review(ctx, { itemId: a.id as any, approve: a.approve, reviewerId: me });
      } catch (e) {
        badRequest(cleanMessage(e));
      }
      if (a.approve && before?.state === "submitted") {
        await requestApproved(ctx, {
          itemId: String(before._id),
          number: before.number ?? null,
          title: before.title,
          userId: before.createdBy,
          approvedBy: me,
        });
      }
      return null;
    },
  });

  return {
    agentState,
    listPublicItems,
    submitRequest,
    upvoteRequest,
    answerRefinement,
    skipRefinement,
    generateUploadUrl,
    submitRequestWithMedia,
    listAttachments,
    mine,
    amAdmin,
    whoAmI,
    awaitingApproval,
    review,
    whatsNew,
    myNotifications,
    markNotificationsRead,
    approvalSnapshot,
    prepareApproval,
    approveSnapshot,
    runLogs,
    skillFeedback,
    approvalRequests,
    approveApprovalRequest,
    declineApprovalRequest,
    runScreenshots,
    runStatus,
    recentRuns,
    buildState,
    splitFromBatch,
    buildInCloud,
    shipCandidate,
    shipDiffChunk,
    shipApprove,
    applyRepair,
    buildCard,
    previewDataMode,
    setPreviewData,
    retryRun,
    fixRequest,
    removeRequest,
    appLearnings,
    forgetLearning,
    buildCosts,
  };
}
