// The host's half of the release state machine: internal functions that
// `chef-release` reaches with `npx convex run --prod <module>:<name>` and the
// operator's CLI login. Internal, so no browser and no app user can call
// them; approving a release's diff is not among them (that is the panel's,
// through an admin user).
//
//   // convex/chefPipeline.ts
//   import { exposeChefRelease } from "@convex-dev/feedback";
//   import { components } from "./_generated/api";
//   export const {
//     releasePrepare, releaseDiffChunk, releaseStep, releaseTarget, releaseAbandon,
//     releaseRollback, releaseStatus, releaseBuiltRuns, releaseItemRuns, releaseDrop,
//   } = exposeChefRelease(components.feedback);
import type { ComponentApi } from "../component/_generated/component.js";
import { internalMutationGeneric, internalQueryGeneric } from "convex/server";
import { v } from "convex/values";

const vStepTo = v.union(
  v.literal("merged"),
  v.literal("sourcePushed"),
  v.literal("gatesPassed"),
  v.literal("backendDeployed"),
  v.literal("frontendPublished"),
  v.literal("verified"),
  v.literal("live"),
  v.literal("done"),
);

/** The function names the CLI calls, under the host module (default `chefPipeline`). */
export const RELEASE_FUNCTIONS = [
  "releasePrepare",
  "releaseDiffChunk",
  "releaseStep",
  "releaseTarget",
  "releaseAbandon",
  "releaseRollback",
  "releaseStatus",
  "releaseBuiltRuns",
  "releaseItemRuns",
  "releaseDrop",
] as const;

export function exposeChefRelease(component: ComponentApi) {
  const c = component.chefReleases;
  return {
    releasePrepare: internalMutationGeneric({
      args: {
        operator: v.string(),
        sha: v.string(),
        baseSha: v.string(),
        runIds: v.array(v.string()),
        cliVersion: v.optional(v.string()),
      },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runMutation(c.prepare, args),
    }),
    releaseDiffChunk: internalMutationGeneric({
      args: {
        operator: v.string(),
        releaseId: v.string(),
        diffHash: v.string(),
        index: v.number(),
        count: v.number(),
        text: v.string(),
      },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runMutation(c.uploadDiffChunk, args),
    }),
    releaseStep: internalMutationGeneric({
      args: {
        operator: v.string(),
        releaseId: v.string(),
        phase: v.union(v.literal("begin"), v.literal("complete")),
        to: vStepTo,
        mergeSha: v.optional(v.string()),
        diffHash: v.optional(v.string()),
        releaseBranch: v.optional(v.string()),
        artifactDigest: v.optional(v.string()),
        gates: v.optional(v.array(v.string())),
        pushId: v.optional(v.string()),
        checks: v.optional(v.array(v.object({ name: v.string(), ok: v.boolean() }))),
        mainSha: v.optional(v.string()),
      },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runMutation(c.step, args),
    }),
    releaseTarget: internalMutationGeneric({
      args: {
        operator: v.string(),
        releaseId: v.string(),
        target: v.union(v.literal("convexApp"), v.literal("staticHosting")),
        digest: v.string(),
        detail: v.optional(v.string()),
      },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runMutation(c.recordTarget, args),
    }),
    releaseAbandon: internalMutationGeneric({
      args: { operator: v.string(), releaseId: v.string(), reason: v.string() },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runMutation(c.abandon, args),
    }),
    releaseRollback: internalMutationGeneric({
      args: { operator: v.string(), seq: v.number(), mainSha: v.string(), reason: v.string() },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runMutation(c.rollback, args),
    }),
    releaseStatus: internalQueryGeneric({
      args: { seq: v.optional(v.number()) },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runQuery(c.status, args),
    }),
    releaseBuiltRuns: internalQueryGeneric({
      args: { limit: v.optional(v.number()) },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runQuery(c.builtRuns, args),
    }),
    releaseItemRuns: internalQueryGeneric({
      args: { itemNumber: v.number() },
      returns: v.any(),
      handler: async (ctx, args) => await ctx.runQuery(c.itemRuns, args),
    }),
    releaseDrop: internalMutationGeneric({
      args: {
        operator: v.string(),
        itemNumber: v.number(),
        revertSha: v.union(v.string(), v.null()),
        reverted: v.array(v.string()),
        reason: v.optional(v.string()),
      },
      returns: v.null(),
      handler: async (ctx, args) => {
        await ctx.runMutation(c.recordDrop, args);
        return null;
      },
    }),
  };
}
