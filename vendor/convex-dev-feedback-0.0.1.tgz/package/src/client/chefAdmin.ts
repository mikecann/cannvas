/**
 * The functions `npx chef` runs through `npx convex run` in an app with
 * just the feedback board: name the app's admin, and the upgrade step for
 * /agent/* keys from before they were hashed. Internal, so only the
 * deployment's own functions and its CLI can call them.
 *
 *   // convex/chef.ts, next to exposeChefApi
 *   import { chefAdmin, exposeChefApi } from "@convex-dev/feedback";
 *   export const { chefSetAdmin, chefMigrateAgentKeys } = chefAdmin(components.feedback);
 *
 * An app with cloud builds gets the same two from @convex-dev/chef-cloud's
 * chefCloud(...) instead, with the rest of its functions.
 */
import { internalActionGeneric, internalMutationGeneric } from "convex/server";
import { ConvexError, v } from "convex/values";
import type { ComponentApi } from "../component/_generated/component.js";

/** The CLI's admin identity in Chef, for setup steps run with `npx convex run`. No app user has this id. */
export const OPERATOR_USER = "operator:cli";

/** Why cloud builds and "Ship it" refuse before an app admin exists. */
export const NO_ADMIN =
  "No app admin yet. Name one first: npx chef init --admin <userId> (or npx convex run chef:chefSetAdmin '{\"userId\":\"<id>\"}'). " +
  'A signed-in user sees their id in the Chef panel as "your Chef user id".';

export type ChefAdminOptions = Record<string, never>;

export function chefAdmin(component: ComponentApi, _options: ChefAdminOptions = {}) {
  return {
    /**
     * Make an app user an admin: the person who approves requests (and, with
     * cloud builds, builds and ships). Nobody becomes one by signing in, so
     * the operator names them here (`npx chef init --admin <userId>` runs
     * this). The id is what the host's getUserId returns for them; the Chef
     * panel shows it to a signed-in user as "your Chef user id". Safe to
     * repeat.
     *
     *   npx convex run chef:chefSetAdmin '{"userId":"<id>"}'
     */
    chefSetAdmin: internalMutationGeneric({
      args: { userId: v.string() },
      returns: v.object({ userId: v.string(), wasAdmin: v.boolean() }),
      handler: async (ctx, { userId }) => {
        const id = userId.trim();
        if (!id) throw new ConvexError("userId is empty");
        if (id.startsWith("operator:")) throw new ConvexError("operator: ids are the CLI's own, not an app user's");
        const u = await ctx.runQuery(component.users.get, { userId: id });
        if (u?.role !== "admin") await ctx.runMutation(component.users.setRole, { userId: id, role: "admin" });
        return { userId: id, wasAdmin: u?.role === "admin" };
      },
    }),

    /**
     * Rewrite every /agent/* key still stored in plaintext (from before keys
     * were hashed) to hash plus prefix, batch by batch until none is left,
     * then check that none is. The keys keep working. `npx chef init` and
     * `npx chef upgrade` run it; any key it migrated sat in the database in
     * the clear and may have been read, so rotate those.
     *
     *   npx convex run chef:chefMigrateAgentKeys
     */
    chefMigrateAgentKeys: internalActionGeneric({
      args: {},
      // `prefixes`: the first 100 migrated keys' prefixes (ship_xxxxxxxx), to rotate.
      returns: v.object({ migrated: v.number(), legacyRemaining: v.boolean(), prefixes: v.array(v.string()) }),
      handler: async (ctx) => {
        let migrated = 0;
        const prefixes: string[] = [];
        // 100 rows a batch; the cap only stops a loop that makes no progress.
        for (let i = 0; i < 10_000; i++) {
          const r = await ctx.runMutation(component.agentKeys.migrateToHashes, {});
          migrated += r.migrated;
          prefixes.push(...r.prefixes.slice(0, Math.max(0, 100 - prefixes.length)));
          if (!r.remaining || r.migrated === 0) break;
        }
        const legacyRemaining = await ctx.runQuery(component.agentKeys.hasLegacy, {});
        return { migrated, legacyRemaining, prefixes };
      },
    }),
  };
}
