// Chef runs: the atomic claim (docs/chef-pipeline.md, "One build at a time").
//
// Convex mutations are serializable, so there is no lock. claimNextBuild does
// the whole decision in one transaction around the singleton chefState row:
// two claims at once conflict on it, Convex retries one, and the retry sees the
// active run and does nothing. Every trigger calls it: the approval hook, the
// "Build in cloud" button, POST /chef-agent/enroll, cloud builds or
// auto-build turning on, and Chef's own retries. finishRun is the other half
// and, with auto-build on, claims the next build in the same transaction, so
// every path that frees the slot (built, failed, cancelled, reconciled, the
// watchdog giving up) claims the next one. Nothing polls: a run that stops
// answering is caught by its own deadline check (chefWatchdog.ts).
import { v } from "convex/values";
import { internalMutation, mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { internal } from "./_generated/api.js";
import { chefRunFields, vBatchView, vClaimResult, vRunVia } from "./schema.js";
import { isAdminUser, requireAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { cloudBuildsEnabled, hasActiveAgentKey, liveKeyCounts } from "./chefAgentKeys.js";
import { readChefSettings } from "./chefSettings.js";
import { revokeRunCredentials } from "./chefAgent.js";
import type { FunctionHandle } from "convex/server";
import { classifyFailure, type FailureInfo } from "../chef/failures.js";
import { previewSkip } from "../chef/preview.js";
import { recover, type RecoveryDecision } from "../chef/recovery.js";
import { recordFailureLearning } from "./chefLearnings.js";
import { installWasWarm } from "../chef/learnings.js";
import { armRunCheck } from "./chefWatchdog.js";
import { dissolveBatch, gatherBatch, liveBatches, maybeStartPlanning, planningHolds } from "./chefBatches.js";
import { batchFailurePolicy, numberList } from "../chef/batching.js";

export const RUN_DEADLINE_MS = 90 * 60_000;
export const HEARTBEAT_STALE_MS = 15 * 60_000;
// Bounds the claim's scan past queue entries that are no longer buildable.
const MAX_SKIPS = 25;
// How many buildable members' requests an admin-only claim looks past.
const MAX_PASSED_OVER = 50;

export const vRun = v.object({
  _id: v.id("chefRuns"),
  _creationTime: v.number(),
  ...chefRunFields,
});

// "cron" is the old every-minute sweep's (chefRuns.sweep, kept for hosts that still call it).
export type RunVia = "approval" | "button" | "cron" | "enroll" | "enable" | "finish" | "retry";

export type ClaimResult =
  | { outcome: "claimed"; runId: Id<"chefRuns"> }
  | { outcome: "busy"; runId: Id<"chefRuns"> }
  | { outcome: "reconciling"; runId: Id<"chefRuns"> }
  | { outcome: "empty"; memberRequests?: number }
  | { outcome: "disabled"; reason: string }
  | { outcome: "planning" };


export const runActor = (runId: Id<"chefRuns">) => `run:${runId}`;

async function getState(ctx: MutationCtx): Promise<Doc<"chefState">> {
  const row = await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
  if (row) return row;
  const id = await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1 });
  return (await ctx.db.get("chefState", id))!;
}

export function isStale(run: Doc<"chefRuns">, now: number): boolean {
  return now - run.heartbeatAt > HEARTBEAT_STALE_MS || now > run.deadline;
}

/** A queued item's approved snapshot, if a claim would build it; null for an entry it would clear. */
export async function buildableSnapshot(ctx: QueryCtx, item: Doc<"items">): Promise<Doc<"chefSnapshots"> | null> {
  if (item.state !== "requested" || item.mergedInto || !item.snapshotId) return null;
  const snapshot = await ctx.db.get("chefSnapshots", item.snapshotId);
  if (!snapshot || snapshot.itemId !== item._id || snapshot.approvedAt === undefined) return null;
  const alreadyRun = await ctx.db
    .query("chefRuns")
    .withIndex("by_snapshotId", (q) => q.eq("snapshotId", snapshot._id))
    .first();
  return alreadyRun ? null : snapshot;
}

/** Every request a run builds: its own, then a batch's others (chefBatches.ts). */
export function runItemIds(run: Doc<"chefRuns">): Id<"items">[] {
  if (!run.batch) return [run.itemId];
  return [run.itemId, ...run.batch.items.map((m) => m.itemId).filter((id) => id !== run.itemId)];
}

/** The approved snapshot a run builds `itemId` from (a batch's member's own), or null. */
export function runSnapshotFor(run: Doc<"chefRuns">, itemId: Id<"items">): Id<"chefSnapshots"> | null {
  if (itemId === run.itemId) return run.snapshotId;
  return run.batch?.items.find((m) => m.itemId === itemId)?.snapshotId ?? null;
}

/**
 * An item's newest run: one built for it alone (by_itemId), or a batch run
 * it was part of (chefRunItems), whichever is newer.
 */
export async function newestRunOf(ctx: QueryCtx, itemId: Id<"items">): Promise<Doc<"chefRuns"> | null> {
  const own = await ctx.db
    .query("chefRuns")
    .withIndex("by_itemId", (q) => q.eq("itemId", itemId))
    .order("desc")
    .first();
  const link = await ctx.db
    .query("chefRunItems")
    .withIndex("by_itemId", (q) => q.eq("itemId", itemId))
    .order("desc")
    .first();
  const batched = link ? await ctx.db.get("chefRuns", link.runId) : null;
  if (!own) return batched;
  if (!batched) return own;
  return batched.seq > own.seq ? batched : own;
}

/**
 * Whether an admin may ask for a fix or a removal of `item` now
 * (chefSnapshots.adminFollowUp): Chef built it (its newest run built,
 * shipped or not) or it shipped, and nothing of it is queued or running.
 * `last` is its newest run; otherwise why not.
 */
export async function followUpCheck(
  ctx: QueryCtx,
  item: Doc<"items">,
): Promise<{ ok: true; last: Doc<"chefRuns"> } | { ok: false; reason: string }> {
  if (item.mergedInto || item.kind === "refinement") return { ok: false, reason: "this isn't a request Chef builds" };
  const last = await newestRunOf(ctx, item._id);
  if (!last) return { ok: false, reason: "Chef never built this request" };
  if (last.status === "active" || last.status === "reconciling") return { ok: false, reason: "Chef is building it now" };
  if (item.cloudQueuedAt) return { ok: false, reason: "it is already waiting for a build" };
  if (item.state === "completed") return { ok: true, last };
  if (item.state !== "inProgress") return { ok: false, reason: `the request is ${item.state}` };
  if (last.status !== "built") return { ok: false, reason: `its last build ${last.status === "failed" ? "failed" : "was cancelled"}: try it again instead` };
  return { ok: true, last };
}

/**
 * Whether Chef is merging the newest main into `run` (a built run "Ship it"
 * found main had moved under, chefShip.followMain): "queued" while the
 * merge-only build waits for the slot, "merging" while it runs, else null.
 */
export async function refreshState(ctx: QueryCtx, run: Doc<"chefRuns">): Promise<"queued" | "merging" | null> {
  const newest = await ctx.db
    .query("chefRuns")
    .withIndex("by_itemId", (q) => q.eq("itemId", run.itemId))
    .order("desc")
    .first();
  if (newest && newest._id !== run._id && newest.refresh?.ofRunId === run._id && (newest.status === "active" || newest.status === "reconciling")) {
    return "merging";
  }
  const item = await ctx.db.get("items", run.itemId);
  if (!item || !item.cloudQueuedAt || !item.snapshotId) return null;
  const snapshot = await ctx.db.get("chefSnapshots", item.snapshotId);
  if (snapshot?.refresh?.ofRunId !== run._id) return null;
  return (await buildableSnapshot(ctx, item)) ? "queued" : null;
}

/**
 * What claims will build, in order (read-only: the entries a claim would
 * clear are just left out). At most `limit`.
 */
async function buildQueue(
  ctx: QueryCtx,
  limit: number,
): Promise<Array<{ itemId: Id<"items">; number: number; title: string; batchId?: Id<"chefBatches"> }>> {
  const out: Array<{ itemId: Id<"items">; number: number; title: string; batchId?: Id<"chefBatches"> }> = [];
  const queued = await ctx.db
    .query("items")
    .withIndex("by_cloudQueuedAt", (q) => q.gt("cloudQueuedAt", 0))
    .take(MAX_SKIPS + MAX_PASSED_OVER);
  for (const item of queued) {
    if (out.length >= limit) break;
    if (await buildableSnapshot(ctx, item)) {
      out.push({ itemId: item._id, number: item.number, title: item.title, ...(item.batchId ? { batchId: item.batchId } : {}) });
    }
  }
  return out;
}

/**
 * The oldest queued item that can still be built, clearing entries that can't.
 * With `adminRequestsOnly`, items a non-admin wrote are passed over (and left
 * queued for a cloud build) and counted in `memberRequests`.
 */
async function nextBuildable(
  ctx: MutationCtx,
  opts: { adminRequestsOnly?: boolean } = {},
): Promise<{ next: { item: Doc<"items">; snapshot: Doc<"chefSnapshots"> } | null; memberRequests: number }> {
  let memberRequests = 0;
  let cleared = 0;
  const queued = await ctx.db
    .query("items")
    .withIndex("by_cloudQueuedAt", (q) => q.gt("cloudQueuedAt", 0))
    .take(MAX_SKIPS + MAX_PASSED_OVER);
  for (const item of queued) {
    const snapshot = await buildableSnapshot(ctx, item);
    if (snapshot) {
      if (opts.adminRequestsOnly && !(await isAdminUser(ctx, item.createdBy))) {
        memberRequests++;
        continue;
      }
      return { next: { item, snapshot }, memberRequests };
    }
    await ctx.db.patch("items", item._id, { cloudQueuedAt: undefined });
    if (++cleared >= MAX_SKIPS) break;
  }
  return { next: null, memberRequests };
}

/** Whether a release merge (chefShip.followMain) is first in the queue. */
async function releaseMergeQueued(ctx: QueryCtx): Promise<boolean> {
  const first = await ctx.db
    .query("items")
    .withIndex("by_cloudQueuedAt", (q) => q.gt("cloudQueuedAt", 0))
    .first();
  if (!first?.snapshotId) return false;
  const snapshot = await ctx.db.get("chefSnapshots", first.snapshotId);
  return snapshot?.refresh?.releaseId !== undefined;
}

/**
 * The one claim every trigger goes through. Either it creates the run, takes
 * the slot, moves the item to inProgress and schedules the run's start, or
 * none of that happens.
 */
export async function claimNextBuild(
  ctx: MutationCtx,
  opts: {
    via: RunVia;
    actor: string;
    startedBy?: string;
    agentKeyId?: Id<"chefAgentKeys">;
    /**
     * Only claim a request an admin wrote (a local worker's default: its agent
     * holds the developer's reusable login, so a member's text must not reach it).
     */
    adminRequestsOnly?: boolean;
  },
): Promise<ClaimResult> {
  const now = Date.now();
  const state = await getState(ctx);

  if (state.activeRunId) {
    const active = await ctx.db.get("chefRuns", state.activeRunId);
    if (active && active.status === "reconciling") {
      // A run from before deadline checks existed gets its one now.
      if (active.watchdogDueAt === undefined) await armRunCheck(ctx, active, now);
      return { outcome: "reconciling", runId: active._id };
    }
    if (active && active.status === "active") {
      if (!(await reconcileIfStale(ctx, active, now, opts.actor))) {
        if (active.watchdogDueAt === undefined) await armRunCheck(ctx, active, now);
        return { outcome: "busy", runId: active._id };
      }
      return { outcome: "reconciling", runId: active._id };
    }
    // A finished run still in the slot shouldn't happen; free it.
    await ctx.db.patch("chefState", state._id, { activeRunId: undefined });
  }

  // An enroll presents its own live key, of either kind: a worker key builds
  // on the worker's machine, never in the cloud. Every other trigger starts
  // a cloud build, so it needs cloud builds on (a live "cloud" key), and
  // approvals, turning things on, the sweep and finish need auto-build too.
  if (opts.via === "enroll") {
    if (!(await hasActiveAgentKey(ctx))) {
      return { outcome: "disabled", reason: "no active Chef agent key" };
    }
  } else {
    // A retry Chef schedules itself (retryTransient) goes with auto-build off
    // too: the admin already started this build.
    if (opts.via === "approval" || opts.via === "cron" || opts.via === "enable" || opts.via === "finish") {
      if (!(await readChefSettings(ctx)).cloudAutoBuild) {
        return { outcome: "disabled", reason: "cloudAutoBuild is off" };
      }
    }
    if (!(await cloudBuildsEnabled(ctx))) {
      return { outcome: "disabled", reason: "cloud builds are off (no cloud Chef agent key)" };
    }
  }

  // Batching (chefBatches.ts): a planning call in flight holds the claim
  // until it answers (or its timeout check gives up on it); with more than
  // one approved request waiting, this claim may start one.
  if (planningHolds(state, now)) return { outcome: "planning" };
  if (state.planning) await ctx.db.patch("chefState", state._id, { planning: undefined });
  const planning = await maybeStartPlanning(ctx, state, opts, now);
  if (planning) return planning;

  const { next, memberRequests } = await nextBuildable(ctx, { adminRequestsOnly: opts.adminRequestsOnly });
  if (!next) return memberRequests > 0 ? { outcome: "empty", memberRequests } : { outcome: "empty" };
  const requestedBy = (await isAdminUser(ctx, next.item.createdBy)) ? ("admin" as const) : ("member" as const);
  // A planned batch builds whole: this request and the others still waiting.
  const batched = await gatherBatch(ctx, next.item, { adminRequestsOnly: opts.adminRequestsOnly });
  const members = batched?.members ?? [];
  const numbers = [next.item.number, ...members.map((m) => m.item.number)];

  const runId = await ctx.db.insert("chefRuns", {
    seq: state.nextSeq,
    itemId: next.item._id,
    snapshotId: next.snapshot._id,
    status: "active",
    phase: "launched",
    startedVia: opts.via,
    requestedBy,
    ...(opts.startedBy !== undefined ? { startedBy: opts.startedBy } : {}),
    ...(opts.agentKeyId !== undefined ? { agentKeyId: opts.agentKeyId } : {}),
    heartbeatAt: now,
    deadline: now + RUN_DEADLINE_MS,
    createdAt: now,
    // A retry of a transient failure carries its attempt and the spend so
    // far: the spend ceiling covers every attempt of one approval.
    attempt: next.snapshot.retry?.attempt ?? 1,
    ...(next.snapshot.retry
      ? { retryOf: next.snapshot.retry.ofRunId, priorSpendUsd: next.snapshot.retry.priorSpendUsd }
      : {}),
    ...(next.item.continueFrom ? { continueFrom: next.item.continueFrom } : {}),
    // Main moved before Ship it: this build merges it in, with no agent.
    ...(next.snapshot.refresh ? { mode: "merge" as const, refresh: next.snapshot.refresh } : {}),
    // A follow-up build: the agent is told why the last one's preview failed.
    ...(next.snapshot.followUp ? { followUp: next.snapshot.followUp } : {}),
    ...(batched
      ? {
          batch: {
            batchId: batched.batch._id,
            items: [next, ...members].map((m) => ({ itemId: m.item._id, snapshotId: m.snapshot._id })),
          },
        }
      : {}),
  });
  await ctx.db.patch("chefState", state._id, {
    activeRunId: runId,
    nextSeq: state.nextSeq + 1,
  });
  // A release merge: its release shows which build is merging main in.
  const followOf = next.snapshot.refresh?.releaseId ? await ctx.db.get("chefReleases", next.snapshot.refresh.releaseId) : null;
  if (followOf?.open && followOf.follow?.status === "merging" && followOf.follow.attempts === next.snapshot.refresh?.attempt) {
    await ctx.db.patch("chefReleases", followOf._id, { follow: { ...followOf.follow, runId } });
  }
  await ctx.db.patch("items", next.item._id, {
    state: "inProgress",
    cloudQueuedAt: undefined,
    continueFrom: undefined,
  });
  for (const m of members) {
    await ctx.db.patch("items", m.item._id, { state: "inProgress", cloudQueuedAt: undefined, continueFrom: undefined });
    await ctx.db.insert("chefRunItems", { runId, itemId: m.item._id });
  }
  if (batched) {
    await ctx.db.patch("chefBatches", batched.batch._id, {
      status: "building",
      runIds: [...batched.batch.runIds, runId],
      updatedAt: now,
    });
  }
  // Its one deadline check: no heartbeat for 15 minutes, or past its deadline.
  await armRunCheck(ctx, (await ctx.db.get("chefRuns", runId))!, now);
  // The run's orchestration starts in this same transaction: startRun is
  // scheduled with the claim, and hands the run to the host's chefRunStart,
  // which starts chef-cloud's build workflow (@convex-dev/workflow,
  // packages/chef-cloud/src/component/orchestration.ts). This component
  // doesn't depend on chef-cloud, so it reaches the workflow through the host.
  const workflowId = await ctx.scheduler.runAfter(0, internal.chefOrchestrator.startRun, { runId });
  await ctx.db.patch("chefRuns", runId, { workflowId });
  const startedLine = next.snapshot.refresh
    ? `Cloud build #${state.nextSeq} started: main moved under release #${next.snapshot.refresh.releaseSeq}, so Chef merges it in and checks again.`
    : next.snapshot.retry
      ? `Cloud build #${state.nextSeq} started (Chef's try ${next.snapshot.retry.attempt} after ${
          next.snapshot.createdBy === "system:batch" ? "its batch failed" : "a transient failure"
        }).`
      : `Cloud build #${state.nextSeq} started.`;
  for (const it of [next.item, ...members.map((m) => m.item)]) {
    const others = numbers.filter((n) => n !== it.number);
    await ctx.db.insert("devLogs", {
      itemId: it._id,
      authorId: "chef",
      message: others.length ? `${startedLine} Built together with ${numberList(others)}.` : startedLine,
      stamp: now,
    });
  }
  await writeAudit(ctx, {
    actor: opts.actor,
    action: "run.claimed",
    runId,
    target: next.item._id,
    outcome: "ok",
    detail: {
      via: opts.via,
      seq: state.nextSeq,
      snapshotId: next.snapshot._id,
      ...(batched ? { batchId: batched.batch._id, requests: numbers.length } : {}),
    },
  });
  return { outcome: "claimed", runId };
}

/**
 * A stale active run (no heartbeat for HEARTBEAT_STALE_MS, or past its
 * deadline) goes to reconciliation, keeping the slot until that finishes,
 * since the run may still have a live sandbox or a push in flight. Returns
 * whether it did. Shared by the claim and the run's deadline check.
 */
export async function reconcileIfStale(ctx: MutationCtx, run: Doc<"chefRuns">, now: number, actor: string): Promise<boolean> {
  if (run.status !== "active" || !isStale(run, now)) return false;
  const why = now > run.deadline ? "past deadline" : "no heartbeat";
  await writeAudit(ctx, { actor, action: "run.stale", runId: run._id, outcome: "ok", reason: why });
  await beginReconcile(ctx, run._id, { outcome: "failed", error: `stale: ${why}`, actor });
  return true;
}

/**
 * Stop a run without freeing its slot: revoke its credentials, mark it
 * reconciling with the outcome to record later, and schedule reconciliation.
 * The reconciler (the host's, registered with chefEffects.setReconciler)
 * sets the run's secrets dead, deletes its sandboxes and secrets, reads the
 * pushed refs back, and only then calls chefEffects.finishReconciled, which
 * frees the slot. Used for stale runs, cancel and key revocation. Returns
 * false for a run that already finished.
 */
export async function beginReconcile(
  ctx: MutationCtx,
  runId: Id<"chefRuns">,
  opts: { outcome: "failed" | "cancelled"; error: string; actor: string },
): Promise<boolean> {
  const run = await ctx.db.get("chefRuns", runId);
  if (!run) throw new Error("Run not found");
  if (run.status !== "active" && run.status !== "reconciling") return false;
  const now = Date.now();
  if (run.status === "active") {
    await ctx.db.patch("chefRuns", runId, {
      status: "reconciling",
      pendingOutcome: opts.outcome,
      pendingError: opts.error.slice(0, 2000),
      reconcileStartedAt: now,
    });
    // Its one check now: the reconciler again after 20 minutes, give up after 2 hours.
    await armRunCheck(ctx, (await ctx.db.get("chefRuns", runId))!, now);
  } else if (opts.outcome === "cancelled") {
    // An admin cancelling a run that was already reconciling: record it as
    // cancelled when it finishes.
    await ctx.db.patch("chefRuns", runId, {
      pendingOutcome: "cancelled",
      pendingError: opts.error.slice(0, 2000),
    });
  }
  // Nothing the runner or the agent holds works from here on.
  const revoked = await revokeRunCredentials(ctx, runId, { for: "reconcile" });
  const state = await getState(ctx);
  if (state.reconcilerHandle) {
    await ctx.scheduler.runAfter(0, state.reconcilerHandle as FunctionHandle<"action">, { runId });
  } else {
    await ctx.scheduler.runAfter(0, internal.chefOrchestrator.reconcileRun, { runId });
  }
  await writeAudit(ctx, {
    actor: opts.actor,
    action: "run.reconciling",
    runId,
    outcome: "ok",
    reason: opts.error.slice(0, 500),
    detail: {
      pendingOutcome: opts.outcome,
      revokedTokens: revoked,
      reconciler: state.reconcilerHandle ? "host" : "none",
    },
  });
  return true;
}

export type RunOutcome = "built" | "failed" | "cancelled";
const vRunOutcome = v.union(v.literal("built"), v.literal("failed"), v.literal("cancelled"));

/**
 * Delete a run's built frontend and release diff (chefArtifact.ts): the
 * storage file, the diff's chunk rows and both fields. Safe to repeat.
 */
export async function dropBuildOutputs(ctx: MutationCtx, run: Doc<"chefRuns">): Promise<void> {
  if (run.frontendArtifact) await ctx.storage.delete(run.frontendArtifact.storageId).catch(() => {});
  const chunks = await ctx.db
    .query("chefRunDiffChunks")
    .withIndex("by_runId_and_index", (q) => q.eq("runId", run._id))
    .take(64);
  for (const c of chunks) await ctx.db.delete("chefRunDiffChunks", c._id);
  if (run.frontendArtifact || run.releaseDiff) {
    await ctx.db.patch("chefRuns", run._id, { frontendArtifact: undefined, releaseDiff: undefined });
  }
}

/** Delete a run's release diff only (its chunks and the field); its frontend stays. */
export async function dropReleaseDiff(ctx: MutationCtx, run: Doc<"chefRuns">): Promise<void> {
  const chunks = await ctx.db
    .query("chefRunDiffChunks")
    .withIndex("by_runId_and_index", (q) => q.eq("runId", run._id))
    .take(64);
  for (const c of chunks) await ctx.db.delete("chefRunDiffChunks", c._id);
  if (run.releaseDiff) await ctx.db.patch("chefRuns", run._id, { releaseDiff: undefined });
}

/** The run whose frontend is live: the newest release that finished, if a build shipped it. */
export async function liveReleaseRunId(ctx: QueryCtx): Promise<Id<"chefRuns"> | null> {
  const recent = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").take(20);
  return recent.find((r) => r.state === "done")?.shipRunId ?? null;
}

/**
 * A newer build supersedes the older built runs' frontends and diffs, except
 * one an open cloud release is shipping, and the live release's frontend
 * (what Chef rolls back to).
 */
async function dropSupersededBuildOutputs(ctx: MutationCtx, keep: Id<"chefRuns">): Promise<void> {
  const open = await ctx.db
    .query("chefReleases")
    .withIndex("by_open", (q) => q.eq("open", true))
    .first();
  const live = await liveReleaseRunId(ctx);
  const older = await ctx.db
    .query("chefRuns")
    .withIndex("by_status", (q) => q.eq("status", "built"))
    .order("desc")
    .take(20);
  for (const r of older) {
    if (r._id === keep || r._id === open?.shipRunId || r._id === open?.follow?.runId) continue;
    if (r._id === live) {
      if (r.releaseDiff) await dropReleaseDiff(ctx, r);
      continue;
    }
    if (r.frontendArtifact || r.releaseDiff) await dropBuildOutputs(ctx, r);
  }
}

/**
 * Record a run's outcome, revoke its credentials, free the slot and, with
 * auto-build on, claim the next build, all in one transaction. Repeating it
 * for a finished run is a no-op.
 */
export async function finishRun(
  ctx: MutationCtx,
  runId: Id<"chefRuns">,
  outcome: RunOutcome,
  opts: { actor: string; error?: string },
): Promise<{ finished: boolean; next: ClaimResult | null }> {
  const run = await ctx.db.get("chefRuns", runId);
  if (!run) throw new Error("Run not found");
  if (run.status !== "active" && run.status !== "reconciling") {
    return { finished: false, next: null };
  }
  const now = Date.now();
  // A built run keeps its frontend and release diff: "Ship it" ships them
  // while it is the newest built run. Any older built run's are superseded.
  // A run that didn't build never ships, so its go now.
  // A release merge (chefShip.followMain) supersedes nothing: it isn't on
  // chef, and newer builds there keep what they will ship with.
  const releaseMerge = run.refresh?.releaseId !== undefined;
  if (outcome === "built") {
    if (!releaseMerge) await dropSupersededBuildOutputs(ctx, runId);
  } else await dropBuildOutputs(ctx, run);
  // An admin's export for the preview never outlives the run (chefPreviewData.ts).
  if (run.previewExport) {
    await ctx.storage.delete(run.previewExport.storageId).catch(() => {});
    await ctx.db.patch("chefRuns", run._id, { previewExport: undefined });
  }
  // A failure's reason and what to do (src/chef/failures.ts), and what Chef
  // does about it (src/chef/recovery.ts, one table): try a transient one
  // again (a cloud build that pushed nothing, at most MAX_AUTO_RETRIES times
  // per approval), give a preview that failed on the build's own code one
  // follow-up build, offer a repair for the repo, stop for security, or
  // leave it to a person with the exact action.
  let failure: FailureInfo | null = null;
  let retryInMs: number | null = null;
  let decision: RecoveryDecision | null = null;
  if (outcome === "failed") {
    const errorText = opts.error ?? run.error ?? "";
    failure = classifyFailure(errorText);
    const pushed = run.phase === "pushed" || run.phase === "previewing" || run.phase === "done" || run.chefAfter !== undefined;
    decision = recover(failure, {
      source: pushed ? "preview" : "build",
      errorText,
      attempt: run.attempt ?? 1,
      pushed,
      // An admin's fix or removal still gets Chef's one follow-up.
      followedUp: run.followUp?.reason !== undefined,
      enrolled: run.startedVia === "enroll",
    });
    if (decision.action === "retry") retryInMs = decision.inMs;
  }
  // A release merge is tried again by its release (chefShip.afterFollow),
  // within the release's bound on merges, not by the build's own retries.
  const mergeTransient = releaseMerge && decision?.action === "retry";
  if (releaseMerge) retryInMs = null;
  await ctx.db.patch("chefRuns", runId, {
    status: outcome,
    finishedAt: now,
    // A terminal phase, consistent with finishedAt: a run that ended in
    // `gates` must not read as still checking. Where it stopped is kept.
    phase: outcome === "built" ? "done" : "ended",
    endedPhase: run.phase,
    // Its pending deadline check, if any, finds no match and does nothing.
    watchdogDueAt: undefined,
    ...(opts.error !== undefined ? { error: opts.error.slice(0, 2000) } : {}),
    ...(failure ? { failure } : {}),
    ...(retryInMs !== null ? { retryAt: now + retryInMs } : {}),
    ...(decision
      ? { recovery: { class: decision.class, action: decision.action, ...(decision.action === "repair" ? { repair: decision.repair } : {}) } }
      : {}),
  });
  // A batch's failure goes by the batch's own policy (src/chef/batching.ts),
  // not the single build's retry and follow-up, which build one request.
  const batchNext =
    run.batch && outcome !== "built"
      ? batchFailurePolicy({
          outcome,
          code: failure?.code ?? null,
          decision,
          failures: (await ctx.db.get("chefBatches", run.batch.batchId))?.failures ?? 0,
          pushed: run.phase === "pushed" || run.phase === "previewing" || run.phase === "done" || run.chefAfter !== undefined,
        })
      : null;
  if (run.batch) {
    retryInMs = batchNext?.action === "retryBatch" && batchNext.inMs > 0 ? batchNext.inMs : null;
    await ctx.db.patch("chefRuns", runId, { retryAt: retryInMs !== null ? now + retryInMs : undefined });
  }
  if (decision?.action === "fixRound" && !run.batch && !releaseMerge) await ctx.scheduler.runAfter(0, internal.chefRuns.followUp, { runId });
  if (decision?.action === "stop") {
    await writeAudit(ctx, {
      actor: opts.actor,
      action: "run.securityStop",
      runId,
      outcome: "ok",
      reason: failure?.reason ?? "stopped",
      detail: { code: failure?.code ?? null },
    });
  }
  if (failure) await recordFailureLearning(ctx, run.seq, failure);
  // A release merge (main moved under Ship it, chefShip.followMain): its
  // release goes on, asks once, or says why it stopped (afterFollow).
  if (releaseMerge) {
    await ctx.scheduler.runAfter(0, internal.chefShip.afterFollow, { runId, outcome, ...(mergeTransient ? { transient: true } : {}) });
  } else if (run.refresh) {
    // A merge-only build from before contract 13: its build waits for Try again.
    if (outcome !== "built") {
      const of = await ctx.db.get("chefRuns", run.refresh.ofRunId);
      if (of) {
        const why = failure?.reason ?? opts.error ?? outcome;
        await ctx.db.patch("chefRuns", of._id, {
          shipBlocked: { reason: `Main moved since this build, and merging it failed: ${why.slice(0, 300)}`, at: now },
        });
      }
    }
  }
  if (retryInMs !== null && !run.batch) await ctx.scheduler.runAfter(retryInMs, internal.chefRuns.retryTransient, { runId });
  if (run.batch) {
    const batch = await ctx.db.get("chefBatches", run.batch.batchId);
    if (batch && outcome === "built") {
      // Its requests are built; the row keeps what was built together.
      await dissolveBatch(ctx, batch._id, "built");
    } else if (batch) {
      await ctx.db.patch("chefBatches", batch._id, { failures: batch.failures + (outcome === "failed" ? 1 : 0), updatedAt: now });
      if (batchNext?.action === "retryBatch" || batchNext?.action === "split") {
        // The requests wait, out of the queue, until it runs.
        await ctx.db.patch("chefBatches", batch._id, { status: "dissolved" });
        await ctx.scheduler.runAfter(batchNext.action === "retryBatch" ? batchNext.inMs : 0, internal.chefBatches.requeueAfterFailure, {
          runId,
          mode: batchNext.action,
        });
      } else {
        await dissolveBatch(ctx, batch._id);
      }
    }
  }
  const tokens = await ctx.db
    .query("chefRunTokens")
    .withIndex("by_runId", (q) => q.eq("runId", runId))
    .take(20);
  for (const tk of tokens) {
    if (tk.revokedAt === undefined) {
      await ctx.db.patch("chefRunTokens", tk._id, { revokedAt: now });
    }
  }
  // A build whose change the web preview can't show (only the phone or Mac
  // app, tests, docs) had none: its history says why (src/chef/preview.ts).
  const noPreview = outcome === "built" && !releaseMerge && !run.previewUrl ? previewSkip(run.filesChanged) : null;
  const numbers: number[] = [];
  const runItems: Doc<"items">[] = [];
  for (const id of runItemIds(run)) {
    const it = await ctx.db.get("items", id);
    if (it) {
      runItems.push(it);
      numbers.push(it.number);
    }
  }
  const batchLine =
    batchNext?.action === "retryBatch"
      ? ` Chef builds the batch once more${retryInMs !== null ? ` in ${Math.round(retryInMs / 60_000)} min` : ""}.`
      : batchNext?.action === "split"
        ? " Chef builds each request of the batch on its own next."
        : run.batch && outcome !== "built"
          ? " Its batch is over: approve it again to build it."
          : "";
  for (const item of runItems) {
    if (item.state !== "inProgress") continue;
    if (outcome !== "built" && releaseMerge && run.refresh) {
      // The request is still built and approved for its release: back to
      // the build that release ships, not to the queue.
      const of = await ctx.db.get("chefRuns", run.refresh.ofRunId);
      if (of) await ctx.db.patch("items", item._id, { snapshotId: of.snapshotId });
    } else if (outcome !== "built") {
      // Back to the queue it came from, but not re-queued for the cloud: an
      // admin re-approves to try again (or Chef's retry re-queues it).
      await ctx.db.patch("items", item._id, { state: "requested" });
    }
    const others = numbers.filter((n) => n !== item.number);
    const together = others.length ? ` (built together with ${numberList(others)})` : "";
    await ctx.db.insert("devLogs", {
      itemId: item._id,
      authorId: "chef",
      message:
        outcome === "built"
          ? `Cloud build #${run.seq} built${together}.${noPreview ? ` ${noPreview.note}` : ""}`
          : failure
            ? `Cloud build #${run.seq}${together} failed: ${failure.reason} ${
                run.batch ? batchLine.trim() || failure.action : retryInMs !== null ? `Chef tries again in ${Math.round(retryInMs / 60_000)} min.` : failure.action
              }`
            : `Cloud build #${run.seq}${together} ${outcome}${opts.error ? `: ${opts.error.slice(0, 500)}` : "."}${batchLine}`,
      stamp: now,
    });
  }
  const state = await getState(ctx);
  if (state.activeRunId === runId) {
    await ctx.db.patch("chefState", state._id, { activeRunId: undefined });
  }
  // The host's one-shot cleanup (chefCloud's chefCleanup, chefEffects
  // .setCleaner): whatever this run left (sandboxes, secrets), on the host's
  // pool with retries, and the next request branch expiry. In place of an
  // hourly sweep.
  if (state.cleanerHandle) {
    await ctx.scheduler.runAfter(0, state.cleanerHandle as FunctionHandle<"mutation">, {});
  }
  await writeAudit(ctx, {
    actor: opts.actor,
    action: "run.finished",
    runId,
    outcome: "ok",
    ...(opts.error !== undefined ? { reason: opts.error.slice(0, 500) } : {}),
    detail: {
      outcome,
      revokedTokens: tokens.length,
      ...(failure ? { failure: failure.code, failureKind: failure.kind } : {}),
      ...(retryInMs !== null ? { retryInMs } : {}),
    },
  });
  // A release merge waiting for the slot goes next even with auto-build
  // off: an admin already approved what it ships (chefShip.followMain).
  const via = (await releaseMergeQueued(ctx)) ? ("retry" as const) : ("finish" as const);
  const next = await claimNextBuild(ctx, { via, actor: "system:finish" });
  return { finished: true, next };
}

// ------------------------------------------------------------- entry points

/** The "Build in cloud" button. Works with auto-build off. */
export const buildNow = mutation({
  args: { adminUserId: v.string() },
  returns: vClaimResult,
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    return await claimNextBuild(ctx, {
      via: "button",
      actor: userActor(args.adminUserId),
      startedBy: args.adminUserId,
    });
  },
});

/**
 * Claim the next approved build, if any (with auto-build off, nothing).
 * Nothing calls it on a timer any more: claims happen on approval, when a
 * run finishes, and when cloud builds or auto-build turn on. Kept for hosts
 * that still call it (chefCloud's chefSweep, a hand-wired cron), and as a
 * manual nudge (`npx chef cleanup`).
 */
export const sweep = mutation({
  args: {},
  returns: vClaimResult,
  handler: async (ctx) => await claimNextBuild(ctx, { via: "cron", actor: "system:cron" }),
});

/**
 * An admin stops a run. It goes through reconciliation like a stale run: the
 * slot stays taken until the run's secrets are dead, its sandboxes deleted and
 * its refs read back. `force` finishes a run stuck in reconciling at once,
 * without that cleanup confirmed; it is audited as such.
 */
export const cancel = mutation({
  args: {
    runId: v.id("chefRuns"),
    adminUserId: v.string(),
    reason: v.optional(v.string()),
    force: v.optional(v.boolean()),
  },
  returns: v.object({ finished: v.boolean(), reconciling: v.boolean() }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const actor = userActor(args.adminUserId);
    const error = (args.reason ?? "cancelled by an admin").slice(0, 2000);
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (args.force && run.status === "reconciling") {
      await writeAudit(ctx, {
        actor,
        action: "run.forceFinished",
        runId: run._id,
        outcome: "ok",
        reason: "cancelled while reconciling; cleanup not confirmed",
      });
      const { finished } = await finishRun(ctx, run._id, "cancelled", {
        actor,
        error: `${error} (forced; cleanup not confirmed)`,
      });
      return { finished, reconciling: false };
    }
    const started = await beginReconcile(ctx, run._id, { outcome: "cancelled", error, actor });
    return { finished: false, reconciling: started };
  },
});

/** For the orchestration (workflow onComplete, reconciliation). */
export const finish = internalMutation({
  args: {
    runId: v.id("chefRuns"),
    outcome: vRunOutcome,
    error: v.optional(v.string()),
    actor: v.optional(v.string()),
  },
  returns: v.object({ finished: v.boolean(), next: v.union(vClaimResult, v.null()) }),
  handler: async (ctx, args) =>
    await finishRun(ctx, args.runId, args.outcome, {
      actor: args.actor ?? "system:workflow",
      ...(args.error !== undefined ? { error: args.error } : {}),
    }),
});

/**
 * Try a transient failure again (finishRun scheduled this after a backoff):
 * a copy of the failed run's snapshot (the same bytes, hash and approval,
 * marked `retry`), queued and claimed. Nothing happens if the request moved
 * on since: an admin edited, re-approved, dropped or built it, or cloud
 * builds are off. Audited either way.
 */
export const retryTransient = internalMutation({
  args: { runId: v.id("chefRuns") },
  returns: v.union(vClaimResult, v.null()),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) return null;
    const skip = async (reason: string) => {
      await writeAudit(ctx, { actor: "system:retry", action: "run.autoRetry", runId: run._id, outcome: "refused", reason });
      if (run.retryAt !== undefined) await ctx.db.patch("chefRuns", run._id, { retryAt: undefined });
      return null;
    };
    if (run.status !== "failed" || run.retryAt === undefined) return await skip("the run isn't waiting for a retry");
    const item = await ctx.db.get("items", run.itemId);
    const snapshot = await ctx.db.get("chefSnapshots", run.snapshotId);
    if (!item || !snapshot || snapshot.approvedAt === undefined || snapshot.approvedBy === undefined) {
      return await skip("the request or its approval is gone");
    }
    if (item.state !== "requested" || item.mergedInto || item.snapshotId !== run.snapshotId) {
      return await skip("the request changed since the failure");
    }
    if (run.batch) return await skip("a batch's retry goes through chefBatches.requeueAfterFailure");
    const newer = await newestRunOf(ctx, item._id);
    if (newer && newer._id !== run._id) return await skip("the request was built again since");
    if (!(await cloudBuildsEnabled(ctx))) return await skip("cloud builds are off");
    const attempt = (run.attempt ?? 1) + 1;
    const copyId = await ctx.db.insert("chefSnapshots", {
      itemId: snapshot.itemId,
      title: snapshot.title,
      description: snapshot.description,
      transcript: snapshot.transcript,
      attachments: snapshot.attachments,
      contentHash: snapshot.contentHash,
      itemUpdatedAt: snapshot.itemUpdatedAt,
      createdBy: "system:retry",
      createdAt: Date.now(),
      approvedBy: snapshot.approvedBy,
      approvedAt: snapshot.approvedAt,
      retry: {
        ofRunId: run._id,
        attempt,
        priorSpendUsd: (run.priorSpendUsd ?? 0) + (run.spendUsd ?? 0),
      },
      // A merge-only build, or a follow-up, tried again is still one.
      ...(snapshot.refresh ? { refresh: snapshot.refresh } : {}),
      ...(snapshot.followUp ? { followUp: snapshot.followUp } : {}),
    });
    // At the front of the queue (claims take the oldest cloudQueuedAt): this
    // build was already under way when the platform failed it.
    await ctx.db.patch("items", item._id, { snapshotId: copyId, cloudQueuedAt: 1 });
    await ctx.db.patch("chefRuns", run._id, { retryAt: undefined });
    const claim = await claimNextBuild(ctx, { via: "retry", actor: "system:retry" });
    await writeAudit(ctx, {
      actor: "system:retry",
      action: "run.autoRetry",
      runId: run._id,
      target: copyId,
      outcome: "ok",
      reason: run.failure?.reason ?? "transient failure",
      detail: { attempt, contentHash: snapshot.contentHash, claim: claim.outcome },
    });
    return claim;
  },
});

/**
 * One follow-up build for a run whose preview deploy failed on the build's
 * own code (src/chef/recovery.ts, agentFixable): a copy of its snapshot
 * (the same bytes and approval) marked `followUp` with why, queued first
 * and claimed. The runner tells the agent why (previous-failure.md); the
 * failed build's work is already on chef, so it starts from it. Once per
 * failure: a follow-up's own failure is left to a person.
 */
export const followUp = internalMutation({
  args: { runId: v.id("chefRuns") },
  returns: v.union(vClaimResult, v.null()),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "failed" || run.recovery?.action !== "fixRound" || run.followUp?.reason !== undefined) return null;
    const skip = async (reason: string) => {
      await writeAudit(ctx, { actor: "system:recovery", action: "run.followUp", runId: run._id, outcome: "refused", reason });
      return null;
    };
    const item = await ctx.db.get("items", run.itemId);
    const snapshot = await ctx.db.get("chefSnapshots", run.snapshotId);
    if (!item || !snapshot || snapshot.approvedAt === undefined || snapshot.approvedBy === undefined) {
      return await skip("the request or its approval is gone");
    }
    if (item.state !== "requested" || item.mergedInto || item.snapshotId !== run.snapshotId) return await skip("the request changed since");
    if (run.batch) return await skip("a batch's follow-up goes through chefBatches.requeueAfterFailure");
    const newer = await newestRunOf(ctx, item._id);
    if (newer && newer._id !== run._id) return await skip("the request was built again since");
    if (!(await cloudBuildsEnabled(ctx))) return await skip("cloud builds are off");
    const reason = (run.failure?.reason ?? run.error ?? "the preview deploy failed").slice(0, 2000);
    const copyId = await ctx.db.insert("chefSnapshots", {
      itemId: snapshot.itemId,
      title: snapshot.title,
      description: snapshot.description,
      transcript: snapshot.transcript,
      attachments: snapshot.attachments,
      contentHash: snapshot.contentHash,
      itemUpdatedAt: snapshot.itemUpdatedAt,
      createdBy: "system:recovery",
      createdAt: Date.now(),
      approvedBy: snapshot.approvedBy,
      approvedAt: snapshot.approvedAt,
      // An admin's fix or removal stays one, told why too. Its revert is in
      // the failed build's work, on chef already.
      followUp: {
        ofRunId: run._id,
        reason,
        ...(snapshot.followUp?.kind ? { kind: snapshot.followUp.kind } : {}),
        ...(snapshot.followUp?.note ? { note: snapshot.followUp.note } : {}),
      },
    });
    await ctx.db.patch("items", item._id, { snapshotId: copyId, cloudQueuedAt: 1 });
    const claim = await claimNextBuild(ctx, { via: "retry", actor: "system:recovery" });
    await writeAudit(ctx, {
      actor: "system:recovery",
      action: "run.followUp",
      runId: run._id,
      target: copyId,
      outcome: "ok",
      reason,
      detail: { claim: claim.outcome },
    });
    return claim;
  },
});

/** Internal entry for a claim from another trigger (tests, future hooks). */
export const claim = internalMutation({
  args: { via: vRunVia, actor: v.string() },
  returns: vClaimResult,
  handler: async (ctx, args) => await claimNextBuild(ctx, args),
});

// ------------------------------------------------------------------- reads

/**
 * What the panel needs to offer "Build in cloud": whether cloud builds are on
 * (a live "cloud" key), how many worker keys are live, auto-build, whether an
 * approved request is waiting (and which, in order: `upNext`) and whether a
 * build holds the slot. Admins only; null for everyone else.
 */
export const buildState = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(
    v.null(),
    v.object({
      cloudEnabled: v.boolean(),
      workerKeys: v.number(),
      autoBuild: v.boolean(),
      queued: v.boolean(),
      busy: v.boolean(),
      // What claims will build next, in order (the first few). A batched
      // request carries its batch: the claim builds the batch whole.
      upNext: v.array(
        v.object({
          itemId: v.id("items"),
          number: v.number(),
          title: v.string(),
          batchId: v.optional(v.id("chefBatches")),
        }),
      ),
      // Batching (chefBatches.ts): whether the planner is grouping the
      // queue right now, and the batches waiting, building, or built and
      // not shipped yet.
      planning: v.boolean(),
      batching: v.boolean(),
      batches: v.array(vBatchView),
      // The requests an admin may ask Chef to fix or remove now (followUpCheck),
      // from the newest built runs: built and waiting for Ship it, or shipped.
      followUps: v.array(v.object({ itemId: v.id("items"), number: v.number(), runId: v.id("chefRuns") })),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const counts = await liveKeyCounts(ctx);
    const upNext = await buildQueue(ctx, 5);
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const settings = await readChefSettings(ctx);
    return {
      cloudEnabled: counts.cloud > 0,
      workerKeys: counts.worker,
      autoBuild: settings.cloudAutoBuild,
      queued: upNext.length > 0,
      busy: !!state?.activeRunId,
      upNext,
      planning: !!state && planningHolds(state, Date.now()),
      batching: settings.cloudBatching && !!state?.plannerHandle,
      batches: await liveBatches(ctx),
      followUps: await followUpTargets(ctx),
    };
  },
});

/** The requests followUpCheck allows, from the newest built runs (at most 30). */
async function followUpTargets(ctx: QueryCtx) {
  const runs = await ctx.db
    .query("chefRuns")
    .withIndex("by_status", (q) => q.eq("status", "built"))
    .order("desc")
    .take(30);
  const seen = new Set<string>();
  const out: Array<{ itemId: Id<"items">; number: number; runId: Id<"chefRuns"> }> = [];
  for (const run of runs) {
    for (const itemId of runItemIds(run)) {
      if (seen.has(itemId)) continue;
      seen.add(itemId);
      const item = await ctx.db.get("items", itemId);
      const check = item ? await followUpCheck(ctx, item) : null;
      if (item && check?.ok && check.last._id === run._id) out.push({ itemId, number: item.number, runId: run._id });
    }
  }
  return out;
}

/** Whether Chef has ever run here (the cleanup skips an app where it hasn't). Host-only. */
export const hasRuns = query({
  args: {},
  returns: v.boolean(),
  handler: async (ctx) => (await ctx.db.query("chefRuns").first()) !== null,
});

/** Runs, newest first. Admins only; [] for members and signed-out callers. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), limit: v.optional(v.number()) },
  returns: v.array(vRun),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(100, Math.max(1, Math.floor(args.limit ?? 20) || 20));
    return await ctx.db.query("chefRuns").order("desc").take(limit);
  },
});

/** One run. Admins only; null for everyone else. */
export const get = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), runId: v.id("chefRuns") },
  returns: v.union(vRun, v.null()),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    return await ctx.db.get("chefRuns", args.runId);
  },
});

/**
 * One run by id, or an item's newest run. Ids are strings so a malformed one
 * is null, not a validation error. Admins only; null for everyone else.
 */
export const lookup = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    runId: v.optional(v.string()),
    itemId: v.optional(v.string()),
  },
  returns: v.union(vRun, v.null()),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    if (args.runId !== undefined) {
      const runId = ctx.db.normalizeId("chefRuns", args.runId);
      return runId === null ? null : await ctx.db.get("chefRuns", runId);
    }
    if (args.itemId !== undefined) {
      const itemId = ctx.db.normalizeId("items", args.itemId);
      if (itemId === null) return null;
      return await newestRunOf(ctx, itemId);
    }
    return null;
  },
});

// Log pages are bounded by rows and by characters: a stored batch holds up
// to 200 lines of up to 4,000 characters each, so a row count alone could
// return tens of megabytes.
const MAX_LOG_PAGE_ROWS = 50;
const LOG_PAGE_CHARS = 1_000_000;

const vLogBatch = v.object({ seq: v.number(), at: v.number(), lines: v.array(v.string()) });

/**
 * One run's log lines, oldest first, as the runner sent them in numbered
 * batches. The lines were scrubbed when they were stored (chefAgent.log).
 * `cursor` is the last `seq` of the previous page (null or absent on the
 * first call); `nextCursor` is null on the last page. A page always holds at
 * least one batch when there is one, and stops early past ~1M characters.
 * Admins only; an empty last page for members, signed-out callers and an
 * unknown run.
 */
export const listLogs = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    runId: v.string(),
    cursor: v.optional(v.union(v.number(), v.null())),
    limit: v.optional(v.number()),
  },
  returns: v.object({ page: v.array(vLogBatch), nextCursor: v.union(v.number(), v.null()) }),
  handler: async (ctx, args) => {
    const empty = { page: [], nextCursor: null };
    if (!(await isAdminUser(ctx, args.viewer))) return empty;
    const runId = ctx.db.normalizeId("chefRuns", args.runId);
    if (runId === null) return empty;
    const limit = Math.min(MAX_LOG_PAGE_ROWS, Math.max(1, Math.floor(args.limit ?? 20) || 20));
    const cursor = args.cursor ?? null;
    if (cursor !== null && !Number.isFinite(cursor)) return empty;
    const rows = await ctx.db
      .query("chefRunLogs")
      .withIndex("by_runId_and_seq", (q) =>
        cursor === null ? q.eq("runId", runId) : q.eq("runId", runId).gt("seq", cursor),
      )
      .take(limit + 1);
    const page: Array<{ seq: number; at: number; lines: string[] }> = [];
    let chars = 0;
    for (const row of rows.slice(0, limit)) {
      const size = row.lines.reduce((n, l) => n + l.length, 0);
      if (page.length > 0 && chars + size > LOG_PAGE_CHARS) break;
      page.push({ seq: row.seq, at: row.at, lines: row.lines });
      chars += size;
    }
    const more = rows.length > page.length;
    return { page, nextCursor: more ? page[page.length - 1].seq : null };
  },
});

/**
 * What each recent build cost, oldest first, for the trend: spend, tokens,
 * model calls, wall time and the runner's per-phase times, the attempt and
 * fix rounds, and how it ended. Admins only; [] for everyone else.
 */
export const costs = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), limit: v.optional(v.number()) },
  returns: v.array(
    v.object({
      runId: v.id("chefRuns"),
      seq: v.number(),
      status: v.string(),
      createdAt: v.number(),
      wallMs: v.union(v.number(), v.null()),
      spendUsd: v.number(),
      aiRequests: v.number(),
      inputTokens: v.number(),
      outputTokens: v.number(),
      phaseMs: v.record(v.string(), v.number()),
      attempt: v.number(),
      fixRounds: v.number(),
      failure: v.union(v.string(), v.null()),
      // Whether the install came from a warm snapshot (phaseMs.installWarm), or null if never timed.
      warm: v.union(v.boolean(), v.null()),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(50, Math.max(1, Math.floor(args.limit ?? 20) || 20));
    const runs = await ctx.db.query("chefRuns").order("desc").take(limit);
    return runs.reverse().map((r) => ({
      runId: r._id,
      seq: r.seq,
      status: r.status,
      createdAt: r.createdAt,
      wallMs: r.finishedAt !== undefined ? r.finishedAt - r.createdAt : null,
      spendUsd: r.spendUsd ?? 0,
      aiRequests: r.aiRequests ?? 0,
      inputTokens: r.aiInputTokens ?? 0,
      outputTokens: r.aiOutputTokens ?? 0,
      phaseMs: r.phaseMs ?? {},
      attempt: r.attempt ?? 1,
      fixRounds: r.fixRound ?? 0,
      failure: r.failure?.code ?? null,
      warm: installWasWarm(r.phaseMs),
    }));
  },
});
