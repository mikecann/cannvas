// Chef settings: auto-build and the per-run spend ceiling. Admin-only and
// audited, unlike the board settings in settings.ts.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import { isAdminUser, requireAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { DEFAULT_AI_MAX_REQUESTS, DEFAULT_AI_MAX_TOKENS } from "../chef/ai.js";
import { isPreviewKeyPrefix } from "../chef/previewKey.js";
import { isDeployKeyPrefix } from "../chef/deployKey.js";
import { claimNextBuild } from "./chefRuns.js";

/** Where the host keeps the preview deploy key: an env var on the host deployment. */
export const PREVIEW_KEY_ENV_NAME = "CHEF_PREVIEW_DEPLOY_KEY";
/** Where the host keeps its own deploy key, for "Ship it". */
export const DEPLOY_KEY_ENV_NAME = "CHEF_DEPLOY_KEY";

export const DEFAULT_SPEND_CEILING_USD = 20;
// No request needs more than this; Claude Code asks for 64000.
const AI_MAX_TOKENS_LIMIT = 128_000;
const AI_MAX_REQUESTS_LIMIT = 10_000;

export async function readChefSettings(ctx: QueryCtx) {
  const row = await ctx.db
    .query("settings")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
  return {
    cloudAutoBuild: row?.cloudAutoBuild ?? false,
    // Batching (chefBatches.ts): on unless turned off; it plans only with a
    // planner registered (chef-cloud registers one).
    cloudBatching: row?.cloudBatching ?? true,
    spendCeilingUsd: row?.spendCeilingUsd ?? DEFAULT_SPEND_CEILING_USD,
    aiMaxTokens: row?.aiMaxTokens ?? DEFAULT_AI_MAX_TOKENS,
    aiMaxRequests: row?.aiMaxRequests ?? DEFAULT_AI_MAX_REQUESTS,
    previewKeyPrefix: row?.previewKeyPrefix ?? null,
    deployKeyPrefix: row?.deployKeyPrefix ?? null,
  };
}

const vChefSettings = v.object({
  cloudAutoBuild: v.boolean(),
  cloudBatching: v.boolean(),
  spendCeilingUsd: v.number(),
  aiMaxTokens: v.number(),
  aiMaxRequests: v.number(),
  // `preview:<team>:<project>`, the non-secret part of the preview deploy
  // key; null until setPreviewDeployKey has run.
  previewKeyPrefix: v.union(v.string(), v.null()),
  // `prod:<deployment>` (or `dev:`), the non-secret part of CHEF_DEPLOY_KEY,
  // the host's own deploy key for "Ship it"; null until setDeployKey has run.
  deployKeyPrefix: v.union(v.string(), v.null()),
});

function isIntIn(x: number, lo: number, hi: number) {
  return Number.isInteger(x) && x >= lo && x <= hi;
}

/** Admins only; null for everyone else. */
export const get = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(vChefSettings, v.null()),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    return await readChefSettings(ctx);
  },
});

export const set = mutation({
  args: {
    adminUserId: v.string(),
    cloudAutoBuild: v.optional(v.boolean()),
    cloudBatching: v.optional(v.boolean()),
    spendCeilingUsd: v.optional(v.number()),
    aiMaxTokens: v.optional(v.number()),
    aiMaxRequests: v.optional(v.number()),
  },
  returns: vChefSettings,
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    if (
      args.spendCeilingUsd !== undefined &&
      !(Number.isFinite(args.spendCeilingUsd) && args.spendCeilingUsd > 0 && args.spendCeilingUsd <= 1000)
    ) {
      throw new Error("spendCeilingUsd must be a number between 0 and 1000");
    }
    if (args.aiMaxTokens !== undefined && !isIntIn(args.aiMaxTokens, 1, AI_MAX_TOKENS_LIMIT)) {
      throw new Error(`aiMaxTokens must be an integer from 1 to ${AI_MAX_TOKENS_LIMIT}`);
    }
    if (args.aiMaxRequests !== undefined && !isIntIn(args.aiMaxRequests, 1, AI_MAX_REQUESTS_LIMIT)) {
      throw new Error(`aiMaxRequests must be an integer from 1 to ${AI_MAX_REQUESTS_LIMIT}`);
    }
    const row = await ctx.db
      .query("settings")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const wasAutoBuild = row?.cloudAutoBuild ?? false;
    const patch = {
      ...(args.cloudAutoBuild !== undefined ? { cloudAutoBuild: args.cloudAutoBuild } : {}),
      ...(args.cloudBatching !== undefined ? { cloudBatching: args.cloudBatching } : {}),
      ...(args.spendCeilingUsd !== undefined ? { spendCeilingUsd: args.spendCeilingUsd } : {}),
      ...(args.aiMaxTokens !== undefined ? { aiMaxTokens: args.aiMaxTokens } : {}),
      ...(args.aiMaxRequests !== undefined ? { aiMaxRequests: args.aiMaxRequests } : {}),
    };
    if (row) {
      await ctx.db.patch("settings", row._id, patch);
    } else {
      await ctx.db.insert("settings", {
        key: "singleton",
        communityBoardVisible: true,
        runMode: "local",
        ...patch,
      });
    }
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "settings.changed",
      outcome: "ok",
      detail: patch,
    });
    // Auto-build just turned on: what was approved meanwhile starts now (the
    // claim does nothing with cloud builds off or a build in the slot).
    if (args.cloudAutoBuild === true && !wasAutoBuild) {
      await claimNextBuild(ctx, { via: "enable", actor: userActor(args.adminUserId) });
    }
    return await readChefSettings(ctx);
  },
});

/**
 * The host's setPreviewDeployKey action: record the preview deploy key's
 * prefix (`preview:<team>:<project>`, not secret). The key itself never
 * comes here; it stays in the host's CHEF_PREVIEW_DEPLOY_KEY env var.
 */
export const setPreviewKeyPrefix = mutation({
  args: { adminUserId: v.string(), prefix: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    // Only the prefix shape is accepted, so nothing else (a whole key, a
    // prod key) can be stored here by mistake.
    if (!isPreviewKeyPrefix(args.prefix)) throw new Error("Not a preview deploy key prefix");
    const row = await ctx.db
      .query("settings")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    if (row) {
      await ctx.db.patch("settings", row._id, { previewKeyPrefix: args.prefix });
    } else {
      await ctx.db.insert("settings", {
        key: "singleton",
        communityBoardVisible: true,
        runMode: "local",
        previewKeyPrefix: args.prefix,
      });
    }
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "settings.changed",
      outcome: "ok",
      detail: { previewKeyPrefix: args.prefix },
    });
    return null;
  },
});

/** Audit the setup (or its failure), by the env var's name only. */
export const recordPreviewDeployKey = mutation({
  args: {
    adminUserId: v.string(),
    outcome: v.union(v.literal("ok"), v.literal("error")),
    created: v.optional(v.boolean()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "secrets.previewDeployKey",
      target: `env:${PREVIEW_KEY_ENV_NAME}`,
      outcome: args.outcome,
      ...(args.created !== undefined ? { detail: { rotated: !args.created } } : {}),
    });
    return null;
  },
});

/**
 * The host's setDeployKey action: record CHEF_DEPLOY_KEY's prefix
 * (`prod:<deployment>` or `dev:<deployment>`, not secret), after it checked
 * the key is for the host's own deployment. The key never comes here.
 */
export const setDeployKeyPrefix = mutation({
  args: { adminUserId: v.string(), prefix: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    if (!isDeployKeyPrefix(args.prefix)) throw new Error("Not a deploy key prefix");
    const row = await ctx.db
      .query("settings")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    if (row) {
      await ctx.db.patch("settings", row._id, { deployKeyPrefix: args.prefix });
    } else {
      await ctx.db.insert("settings", {
        key: "singleton",
        communityBoardVisible: true,
        runMode: "local",
        deployKeyPrefix: args.prefix,
      });
    }
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "settings.changed",
      outcome: "ok",
      detail: { deployKeyPrefix: args.prefix },
    });
    return null;
  },
});

/** Audit the deploy key's setup (or its failure), by the env var's name only. */
export const recordDeployKey = mutation({
  args: {
    adminUserId: v.string(),
    outcome: v.union(v.literal("ok"), v.literal("error")),
    reason: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "secrets.deployKey",
      target: `env:${DEPLOY_KEY_ENV_NAME}`,
      outcome: args.outcome,
      ...(args.reason !== undefined ? { reason: args.reason.slice(0, 300) } : {}),
    });
    return null;
  },
});
