import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";

export const listForUser = query({
  args: {
    userId: v.string(),
    limit: v.optional(v.number()),
    unreadOnly: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const limit = Math.min(100, Math.max(1, args.limit ?? 50));
    const q = args.unreadOnly
      ? ctx.db
          .query("notifications")
          .withIndex("by_user_and_read", (q) =>
            q.eq("userId", args.userId).eq("isRead", false),
          )
      : ctx.db
          .query("notifications")
          .withIndex("by_user", (q) => q.eq("userId", args.userId));
    const rows = await q.order("desc").take(limit);
    return rows;
  },
});

/** Unread counts stop here: a badge shows "99+" past it, and the read stays small. */
export const UNREAD_CAP = 100;
/** markAllRead marks at most this many per call. */
export const MARK_BATCH = 500;

/** Unread notifications for `userId`, up to UNREAD_CAP (UNREAD_CAP means that many or more). */
export const unreadCount = query({
  args: { userId: v.string() },
  returns: v.number(),
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("notifications")
      .withIndex("by_user_and_read", (q) =>
        q.eq("userId", args.userId).eq("isRead", false),
      )
      .take(UNREAD_CAP);
    return rows.length;
  },
});

export const markRead = mutation({
  args: { id: v.id("notifications"), userId: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    const n = await ctx.db.get("notifications", args.id);
    if (!n) return null;
    if (n.userId !== args.userId) throw new Error("Not your notification");
    await ctx.db.patch("notifications", args.id, { isRead: true });
    return null;
  },
});

/**
 * Mark up to MARK_BATCH of `userId`'s unread notifications read. Returns how
 * many it marked; call again while that is MARK_BATCH.
 */
export const markAllRead = mutation({
  args: { userId: v.string() },
  returns: v.number(),
  handler: async (ctx, args) => {
    const rows = await ctx.db
      .query("notifications")
      .withIndex("by_user_and_read", (q) =>
        q.eq("userId", args.userId).eq("isRead", false),
      )
      .take(MARK_BATCH);
    for (const n of rows) {
      await ctx.db.patch("notifications", n._id, { isRead: true });
    }
    return rows.length;
  },
});
