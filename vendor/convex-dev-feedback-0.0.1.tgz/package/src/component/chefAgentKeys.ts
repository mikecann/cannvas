// The Chef agent key: enrollment only (docs/chef-pipeline.md, Part 2).
//
// A root secret, created by an admin and shown once. Convex keeps
// sha256(key), a short prefix, its kind, the creator and the time. An
// external runner presents it to POST /chef-agent/enroll. No other route
// accepts it, and it is a different credential from the /agent/* keys in
// agentKeys.ts.
//
// Two kinds:
// - "cloud": a live one is the switch that turns cloud builds on. Approvals
//   (with auto-build), creating one (with auto-build: what was approved
//   meanwhile) and the "Build in cloud" button claim only while one exists,
//   and their runs go to the host's orchestrator.
// - "worker": only for `npx chef work`. It enrolls and claims like a cloud
//   key, but never turns cloud builds on, so on its own (worker-only mode)
//   nothing but a worker ever builds and nothing is spent on the cloud.
// Both can exist at once: whoever claims first builds. With cloud builds on
// and auto-build on, approvals claim in their own transaction, so the cloud
// takes nearly everything and a worker only gets what is left queued.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import type { Doc } from "./_generated/dataModel.js";
import { hasAppAdminUser, isAdminUser, requireAdminUser } from "./access.js";
import { randomSecret, sha256Hex } from "./chefShared.js";
import { auditRepeatedRefusal, noteRejected } from "./chefRejected.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { claimNextBuild, beginReconcile } from "./chefRuns.js";
import { issueRunCredential } from "./chefAgent.js";
import { vClaimResult } from "./schema.js";

export const keyActor = (k: { prefix: string }) => `chefKey:${k.prefix}`;

export const CHEF_KEY_PREFIX = "chefk";
const PREFIX_LENGTH = CHEF_KEY_PREFIX.length + 1 + 8;

export type AgentKeyKind = "cloud" | "worker";
export const vAgentKeyKind = v.union(v.literal("cloud"), v.literal("worker"));

/** A key's kind; keys from before kinds existed are "cloud". */
export const kindOf = (k: { kind?: AgentKeyKind }): AgentKeyKind => k.kind ?? "cloud";

const vKeyOut = v.object({
  _id: v.id("chefAgentKeys"),
  name: v.string(),
  prefix: v.string(),
  kind: vAgentKeyKind,
  createdBy: v.string(),
  createdAt: v.number(),
  revokedAt: v.optional(v.number()),
});

// Live keys are few (one per app and one per worker); this bounds the scan.
const MAX_LIVE_KEYS = 200;

async function liveKeys(ctx: QueryCtx): Promise<Doc<"chefAgentKeys">[]> {
  return await ctx.db
    .query("chefAgentKeys")
    .withIndex("by_revokedAt", (q) => q.eq("revokedAt", undefined))
    .take(MAX_LIVE_KEYS);
}

/** Whether any unrevoked Chef agent key exists, of either kind. */
export async function hasActiveAgentKey(ctx: QueryCtx): Promise<boolean> {
  return (await liveKeys(ctx)).length > 0;
}

/** Whether cloud builds are on: an unrevoked "cloud" key exists. */
export async function cloudBuildsEnabled(ctx: QueryCtx): Promise<boolean> {
  return (await liveKeys(ctx)).some((k) => kindOf(k) === "cloud");
}

/** How many unrevoked keys of each kind exist. */
export async function liveKeyCounts(ctx: QueryCtx): Promise<{ cloud: number; worker: number }> {
  const keys = await liveKeys(ctx);
  const worker = keys.filter((k) => kindOf(k) === "worker").length;
  return { cloud: keys.length - worker, worker };
}

/** Look a presented key up by its hash. Never logs or stores the key. */
export async function findAgentKey(
  ctx: QueryCtx,
  key: string,
): Promise<Doc<"chefAgentKeys"> | null> {
  if (!key.startsWith(`${CHEF_KEY_PREFIX}_`)) return null;
  const hash = await sha256Hex(key);
  return await ctx.db
    .query("chefAgentKeys")
    .withIndex("by_hash", (q) => q.eq("hash", hash))
    .unique();
}

/**
 * Create a key. The plaintext is in this return value and nowhere else, ever.
 * `kind` defaults to "cloud", which turns cloud builds on; a key for
 * `npx chef work` alone is "worker".
 */
export const create = mutation({
  args: { name: v.string(), adminUserId: v.string(), kind: v.optional(vAgentKeyKind) },
  returns: v.object({
    id: v.id("chefAgentKeys"),
    key: v.string(),
    prefix: v.string(),
    kind: vAgentKeyKind,
  }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    // Either kind lets a runner build approved requests; with no app admin
    // (only the CLI's operator: identity) nobody could have approved them.
    if (!(await hasAppAdminUser(ctx))) {
      throw new Error("No app admin yet: name one (chefSetAdmin) before creating a Chef agent key.");
    }
    const name = args.name.trim().slice(0, 100);
    if (!name) throw new Error("A key needs a name");
    const kind = args.kind ?? "cloud";
    const key = randomSecret(CHEF_KEY_PREFIX);
    const prefix = key.slice(0, PREFIX_LENGTH);
    const id = await ctx.db.insert("chefAgentKeys", {
      name,
      hash: await sha256Hex(key),
      prefix,
      kind,
      createdBy: args.adminUserId,
      createdAt: Date.now(),
    });
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "agentKey.created",
      target: prefix,
      outcome: "ok",
      detail: { name, kind },
    });
    // A cloud key turns cloud builds on: with auto-build on, what was
    // approved meanwhile starts now.
    if (kind === "cloud") await claimNextBuild(ctx, { via: "enable", actor: userActor(args.adminUserId) });
    return { id, key, prefix, kind };
  },
});

/** Keys for the panel: names and prefixes, never hashes. Admins only; [] otherwise. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.array(vKeyOut),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const rows = await ctx.db.query("chefAgentKeys").order("desc").take(100);
    return rows.map((k) => ({
      _id: k._id,
      name: k.name,
      prefix: k.prefix,
      kind: kindOf(k),
      createdBy: k.createdBy,
      createdAt: k.createdAt,
      ...(k.revokedAt !== undefined ? { revokedAt: k.revokedAt } : {}),
    }));
  },
});

/** Revoke a key. Repeating it is a no-op. */
export const revoke = mutation({
  args: {
    id: v.id("chefAgentKeys"),
    adminUserId: v.string(),
    reason: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const k = await ctx.db.get("chefAgentKeys", args.id);
    if (!k) throw new Error("Key not found");
    if (k.revokedAt !== undefined) return null;
    await ctx.db.patch("chefAgentKeys", k._id, {
      revokedAt: Date.now(),
      revokedBy: args.adminUserId,
    });
    await writeAudit(ctx, {
      actor: userActor(args.adminUserId),
      action: "agentKey.revoked",
      target: k.prefix,
      outcome: "ok",
      ...(args.reason ? { reason: args.reason } : {}),
    });
    // Credentials of runs this key enrolled stop working at once (authorize
    // also checks the key). The active run fails if this key enrolled it, or
    // if it is a cloud run and no cloud key is left, since a cloud key's
    // existence is what allows cloud builds.
    // It goes through reconciliation: its credentials are revoked now, and
    // the slot frees only after its secrets are dead, its sandboxes deleted
    // and its refs read back.
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const active = state?.activeRunId ? await ctx.db.get("chefRuns", state.activeRunId) : null;
    if (
      active &&
      (active.status === "active" || active.status === "reconciling") &&
      (active.agentKeyId === k._id ||
        (active.startedVia !== "enroll" && !(await cloudBuildsEnabled(ctx))))
    ) {
      await beginReconcile(ctx, active._id, {
        outcome: "failed",
        error: "Chef agent key revoked",
        actor: userActor(args.adminUserId),
      });
    }
    return null;
  },
});

/**
 * POST /chef-agent/enroll: an external runner presents the key once. The only
 * place the key is accepted. Returns a refusal rather than throwing, so the
 * attempt can be recorded.
 */
export const enroll = mutation({
  args: {
    key: v.string(),
    // "admin": claim only requests an admin wrote, leaving members' for a
    // cloud build. "any": every approved request (cloud keys' default). A
    // worker key always gets "admin", whatever it asks for: a local worker's
    // agent holds the developer's reusable login and a member's text could
    // steal it, so members' requests are built only in the cloud.
    requests: v.optional(v.union(v.literal("admin"), v.literal("any"))),
  },
  returns: v.union(
    v.object({ ok: v.literal(false), error: v.string(), status: v.optional(v.number()) }),
    v.object({
      ok: v.literal(true),
      claim: vClaimResult,
      // The run-bound runner credential when this call claimed a run, or
      // replaced it on a retry; shown once. Use it as the bearer for every
      // other /chef-agent route.
      credential: v.union(v.string(), v.null()),
      // True when this was a retry for this key's own run that hadn't started
      // yet: the earlier credential is revoked and this one replaces it.
      rotated: v.boolean(),
      // Who wrote the run's request, when there is a credential.
      requestedBy: v.optional(v.union(v.literal("admin"), v.literal("member"))),
    }),
  ),
  handler: async (ctx, args) => {
    const k = await findAgentKey(ctx, args.key);
    if (!k) {
      // A key nobody holds: counted per minute, not audited per request
      // (chefRejected.ts). Never any part of it: it could be a mistyped real one.
      const { limited } = await noteRejected(ctx, "agentKey.enroll");
      return limited
        ? { ok: false as const, error: "Too many attempts with unknown keys; try again in a minute", status: 429 }
        : { ok: false as const, error: "Invalid or revoked Chef agent key" };
    }
    if (k.revokedAt !== undefined) {
      // Whoever holds a revoked key can keep sending it: the first refusal
      // is audited, the rest counted per minute (chefRejected.ts).
      await auditRepeatedRefusal(ctx, { actor: keyActor(k), action: "agentKey.enroll", outcome: "refused", reason: "revoked" });
      return { ok: false as const, error: "Invalid or revoked Chef agent key" };
    }
    await writeAudit(ctx, { actor: keyActor(k), action: "agentKey.enroll", outcome: "ok" });
    // No opt-in for worker keys: there is no safe local path for members'
    // requests until the login is out of the agent's reach.
    const adminRequestsOnly = kindOf(k) === "worker" || args.requests === "admin";
    // The same claim as every other trigger.
    const claim = await claimNextBuild(ctx, {
      via: "enroll",
      actor: keyActor(k),
      startedBy: k._id,
      agentKeyId: k._id,
      adminRequestsOnly,
    });
    let credential: string | null = null;
    let rotated = false;
    let requestedBy: "admin" | "member" | undefined;
    if (claim.outcome === "claimed") {
      const run = (await ctx.db.get("chefRuns", claim.runId))!;
      credential = await issueRunCredential(ctx, run, "runner", keyActor(k));
      requestedBy = run.requestedBy;
    } else if (claim.outcome === "busy") {
      // A retry after a lost response: the run this key enrolled is active,
      // but only its hash was kept, so the credential can't be sent again.
      // Replace it. Only while the run is still "launched" with no report, so
      // a second runner polling with the same key can't take over a run
      // that is already under way.
      const run = await ctx.db.get("chefRuns", claim.runId);
      if (
        run &&
        run.status === "active" &&
        run.startedVia === "enroll" &&
        run.agentKeyId === k._id &&
        run.phase === "launched" &&
        run.lastReport === undefined &&
        (!adminRequestsOnly || run.requestedBy === "admin")
      ) {
        credential = await issueRunCredential(ctx, run, "runner", keyActor(k));
        rotated = true;
        requestedBy = run.requestedBy;
        await writeAudit(ctx, {
          actor: keyActor(k),
          action: "credential.rotated",
          runId: run._id,
          outcome: "ok",
          reason: "enroll retried for this key's run; the earlier runner credential is revoked",
          detail: { kind: "runner" },
        });
      }
    }
    return { ok: true as const, claim, credential, rotated, ...(requestedBy ? { requestedBy } : {}) };
  },
});
