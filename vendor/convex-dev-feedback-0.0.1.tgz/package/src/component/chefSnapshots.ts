// Approval binds an immutable snapshot (docs/chef-pipeline.md, Part 2).
//
// The admin approves exactly the bytes the build will see, not the mutable
// item: prepareApproval copies the item's full text, transcript and each
// attachment's hash into a chefSnapshots row, the panel renders that row, and
// approve() only accepts the snapshot's contentHash while the item is still
// what the snapshot says it is. Snapshots are never patched, except the
// one-time approval stamp.
//
// Like the rest of the component, these trust the userId the host forwards
// (the authenticated caller) and check its role here.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { requireAdminUser, isAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { claimNextBuild, followUpCheck, newestRunOf, refreshState, runSnapshotFor } from "./chefRuns.js";
import { leaveBatch } from "./chefBatches.js";
import { vFollowUp, vRefresh } from "./schema.js";
import {
  itemUpdatedAt,
  readSnapshotContent,
  snapshotContentHash,
} from "./chefShared.js";

const vSnapshotAttachment = v.object({
  kind: v.union(v.literal("screenshot"), v.literal("audio")),
  storageId: v.id("_storage"),
  sha256: v.string(),
  size: v.number(),
  contentType: v.string(),
});

export const vSnapshot = v.object({
  _id: v.id("chefSnapshots"),
  _creationTime: v.number(),
  itemId: v.id("items"),
  title: v.string(),
  description: v.string(),
  transcript: v.union(v.string(), v.null()),
  attachments: v.array(vSnapshotAttachment),
  contentHash: v.string(),
  itemUpdatedAt: v.number(),
  createdBy: v.string(),
  createdAt: v.number(),
  approvedBy: v.optional(v.string()),
  approvedAt: v.optional(v.number()),
  retry: v.optional(v.object({ ofRunId: v.id("chefRuns"), attempt: v.number(), priorSpendUsd: v.number() })),
  refresh: v.optional(vRefresh),
  followUp: v.optional(vFollowUp),
});

/** Items an admin may approve for a cloud build. */
function approvable(item: Doc<"items">): boolean {
  if (item.mergedInto || item.kind === "refinement") return false;
  return item.state === "submitted" || item.state === "requested";
}

/**
 * Snapshot the item as it is now. Reuses the newest unapproved snapshot when
 * nothing changed, so opening the same request twice writes one row.
 */
export async function takeSnapshot(
  ctx: MutationCtx,
  item: Doc<"items">,
  createdBy: string,
  // Try again on an admin's fix or removal: the new snapshot carries what was asked.
  followUp?: Doc<"chefSnapshots">["followUp"],
): Promise<{ snapshotId: Id<"chefSnapshots">; contentHash: string; reused: boolean }> {
  const content = await readSnapshotContent(ctx, item);
  const contentHash = await snapshotContentHash(content);
  const updatedAt = itemUpdatedAt(item);
  const latest = await ctx.db
    .query("chefSnapshots")
    .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
    .order("desc")
    .first();
  if (
    !followUp &&
    latest &&
    latest.approvedAt === undefined &&
    latest.contentHash === contentHash &&
    latest.itemUpdatedAt === updatedAt
  ) {
    return { snapshotId: latest._id, contentHash, reused: true };
  }
  const snapshotId = await ctx.db.insert("chefSnapshots", {
    itemId: item._id,
    title: content.title,
    description: content.description,
    transcript: content.transcript,
    attachments: content.attachments,
    contentHash,
    itemUpdatedAt: updatedAt,
    createdBy,
    createdAt: Date.now(),
    ...(followUp ? { followUp } : {}),
  });
  await writeAudit(ctx, {
    actor: userActor(createdBy),
    action: "snapshot.prepared",
    target: snapshotId,
    outcome: "ok",
    detail: { itemId: item._id, contentHash },
  });
  return { snapshotId, contentHash, reused: false };
}

/**
 * Check the snapshot still describes the item and stamp the approval. Shared
 * by approve() and an admin's own request at submit time.
 */
export async function approveSnapshot(
  ctx: MutationCtx,
  snapshot: Doc<"chefSnapshots">,
  contentHash: string,
  approverId: string,
): Promise<Doc<"items">> {
  if (contentHash !== snapshot.contentHash) {
    throw new Error("Approval refused: the content hash doesn't match the snapshot.");
  }
  const item = await ctx.db.get("items", snapshot.itemId);
  if (!item) throw new Error("Item not found");
  if (!approvable(item)) {
    throw new Error(`Approval refused: the request is ${item.state}.`);
  }
  if (itemUpdatedAt(item) !== snapshot.itemUpdatedAt) {
    throw new Error("Approval refused: the request changed after the snapshot. Open it again.");
  }
  const current = await snapshotContentHash(await readSnapshotContent(ctx, item));
  if (current !== snapshot.contentHash) {
    throw new Error("Approval refused: the request changed after the snapshot. Open it again.");
  }
  await ctx.db.patch("chefSnapshots", snapshot._id, {
    approvedBy: approverId,
    approvedAt: Date.now(),
  });
  // Approved again: it leaves a batch still waiting (the planner may group
  // it again, with what it says now), and one it was split out of.
  if (item.batchId) await leaveBatch(ctx, item._id, { alone: false });
  await ctx.db.patch("items", item._id, {
    state: "requested",
    snapshotId: snapshot._id,
    cloudQueuedAt: Date.now(),
    batchAlone: undefined,
  });
  await writeAudit(ctx, {
    actor: userActor(approverId),
    action: "snapshot.approved",
    target: snapshot._id,
    outcome: "ok",
    detail: { itemId: item._id, contentHash: snapshot.contentHash },
  });
  return item;
}

/**
 * An admin opened a request in the approvals view: snapshot it. Returns the
 * snapshot id and hash the panel passes back to `approve`.
 */
export const prepareApproval = mutation({
  args: { itemId: v.id("items"), adminUserId: v.string() },
  returns: v.object({
    snapshotId: v.id("chefSnapshots"),
    contentHash: v.string(),
  }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    if (!approvable(item)) {
      throw new Error(`Only submitted or requested items can be approved (this one is ${item.state}).`);
    }
    const { snapshotId, contentHash } = await takeSnapshot(ctx, item, args.adminUserId);
    return { snapshotId, contentHash };
  },
});

/**
 * The approval that can lead to a cloud build. Refuses a wrong hash, an item
 * edited after the snapshot, or a snapshot that was already approved.
 */
export const approve = mutation({
  args: {
    snapshotId: v.id("chefSnapshots"),
    contentHash: v.string(),
    adminUserId: v.string(),
  },
  // `submitted`: the request was waiting for its first approval (not a
  // re-approval), so the host can tell its requester (exposeChefApi's onRequestApproved).
  returns: v.object({
    itemId: v.id("items"),
    submitted: v.optional(v.object({ number: v.number(), title: v.string(), createdBy: v.string() })),
  }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const snapshot = await ctx.db.get("chefSnapshots", args.snapshotId);
    if (!snapshot) throw new Error("Snapshot not found");
    if (snapshot.approvedAt !== undefined) {
      throw new Error("Approval refused: this snapshot was already approved.");
    }
    const before = await approveSnapshot(ctx, snapshot, args.contentHash, args.adminUserId);
    if (before.state === "submitted") {
      await ctx.db.insert("notifications", {
        userId: before.createdBy,
        itemId: before._id,
        type: "approved",
        message: `“${before.title}” was approved`,
        isRead: false,
        stamp: Date.now(),
      });
    }
    // The approval hook: with auto-build on, claim a build in this same
    // transaction (claimNextBuild does nothing when it's off).
    await claimNextBuild(ctx, { via: "approval", actor: userActor(args.adminUserId) });
    if (before.state !== "submitted") return { itemId: before._id };
    return { itemId: before._id, submitted: { number: before.number, title: before.title, createdBy: before.createdBy } };
  },
});

/**
 * An admin's own request lands in "requested" at submit time; it gets a
 * snapshot approved by its author, since they wrote it. Called by the host
 * (exposeChefApi) after the request's attachments are stored.
 */
export const snapshotOwnRequest = mutation({
  args: { itemId: v.id("items"), adminUserId: v.string() },
  returns: v.union(v.id("chefSnapshots"), v.null()),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    // Only the author, and only while they are an admin and it's queued.
    if (item.createdBy !== args.adminUserId) return null;
    if (!(await isAdminUser(ctx, args.adminUserId))) return null;
    if (item.state !== "requested" || item.snapshotId) return null;
    const { snapshotId, contentHash } = await takeSnapshot(ctx, item, args.adminUserId);
    const snapshot = (await ctx.db.get("chefSnapshots", snapshotId))!;
    await approveSnapshot(ctx, snapshot, contentHash, args.adminUserId);
    await claimNextBuild(ctx, { via: "approval", actor: userActor(args.adminUserId) });
    return snapshotId;
  },
});

/**
 * "Try again" on a request whose last build failed or was cancelled: one
 * step instead of prepareApproval, the snapshot, approve. It snapshots the
 * request as it is now and, only if that is exactly what the admin
 * approved for the last build (the same contentHash), approves the new
 * snapshot and claims a cloud build (with auto-build off too, like the
 * button). If the request changed, nothing is approved: the answer is
 * `needsApproval` with the new snapshot, for the normal approval flow,
 * which shows the admin the new text first. Audited either way.
 */
export const retry = mutation({
  args: { itemId: v.id("items"), adminUserId: v.string() },
  returns: v.union(
    v.object({ outcome: v.literal("started"), claim: v.string(), snapshotId: v.id("chefSnapshots") }),
    v.object({ outcome: v.literal("needsApproval"), snapshotId: v.id("chefSnapshots"), contentHash: v.string() }),
    // Returned, not thrown, so its audit row stays.
    v.object({ outcome: v.literal("refused"), reason: v.string() }),
  ),
  handler: async (ctx, args) => await retryRequest(ctx, args),
});

/**
 * "Try again" for one request, as `adminUserId`: the body of `retry`, for
 * the component's own callers too (a repair applied, chefRepairs.applied).
 */
export async function retryRequest(ctx: MutationCtx, args: { itemId: Id<"items">; adminUserId: string }) {
  {
    await requireAdminUser(ctx, args.adminUserId);
    const actor = userActor(args.adminUserId);
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    const last = await newestRunOf(ctx, item._id);
    const refuse = async (reason: string) => {
      await writeAudit(ctx, { actor, action: "run.retry", target: item._id, outcome: "refused", reason });
      return { outcome: "refused" as const, reason };
    };
    if (!last) return await refuse("Nothing to try again: this request was never built");
    // A built run Ship it couldn't ship as it is (main moved; shipBlocked)
    // can be tried again too: a fresh build of it on the new main.
    if (last.status !== "failed" && last.status !== "cancelled" && !(last.status === "built" && last.shipBlocked)) {
      return await refuse(`Nothing to try again: its last build is ${last.status}`);
    }
    if (!approvable(item)) return await refuse(`Nothing to try again: the request is ${item.state}`);
    // A new snapshot would replace the approved merge-only build Chef queued
    // when main moved before Ship it, and drop it from the queue.
    if (last.status === "built" && last.shipBlocked && (await refreshState(ctx, last))) {
      return await refuse("Chef is already merging the newest main into this build; it ships on its own if the change is the same");
    }
    // A batch run's member was built from its own snapshot.
    const lastSnapshotId = runSnapshotFor(last, item._id) ?? last.snapshotId;
    const approved = await ctx.db.get("chefSnapshots", lastSnapshotId);
    if (!approved || approved.approvedAt === undefined) return await refuse("The last build's approval is gone");
    // Trying an admin's fix or removal again tries that again, not the request.
    const asked = approved.followUp?.kind ? approved.followUp : undefined;
    const { snapshotId, contentHash } = await takeSnapshot(
      ctx,
      item,
      args.adminUserId,
      asked && {
        ofRunId: asked.ofRunId,
        kind: asked.kind,
        ...(asked.note ? { note: asked.note } : {}),
        ...(asked.revertShas ? { revertShas: asked.revertShas } : {}),
      },
    );
    if (contentHash !== approved.contentHash) {
      await writeAudit(ctx, {
        actor,
        action: "run.retry",
        target: item._id,
        outcome: "refused",
        reason: "the request changed since its last approval: approve it again",
        detail: { runId: last._id, snapshotId, contentHash, approvedHash: approved.contentHash },
      });
      return { outcome: "needsApproval" as const, snapshotId, contentHash };
    }
    const snapshot = (await ctx.db.get("chefSnapshots", snapshotId))!;
    await approveSnapshot(ctx, snapshot, contentHash, args.adminUserId);
    // A retry Chef had scheduled for the failed run is superseded.
    if (last.retryAt !== undefined) await ctx.db.patch("chefRuns", last._id, { retryAt: undefined });
    // The failed run's work, if it left any (chefAttempts): the next build
    // starts from it rather than from scratch.
    const attempt = await ctx.db
      .query("chefAttempts")
      .withIndex("by_runId", (q) => q.eq("runId", last._id))
      .first();
    // Not a batch's: its work holds the other requests' changes too.
    if (attempt && !last.batch) await ctx.db.patch("items", item._id, { continueFrom: last._id });
    const claim = await claimNextBuild(ctx, { via: "button", actor, startedBy: args.adminUserId });
    await writeAudit(ctx, {
      actor,
      action: "run.retry",
      target: item._id,
      runId: last._id,
      outcome: "ok",
      detail: { snapshotId, contentHash, claim: claim.outcome, continues: attempt !== null },
    });
    return { outcome: "started" as const, claim: claim.outcome, snapshotId };
  }
}

/** The longest note an admin's fix or removal carries to the build. */
export const MAX_FOLLOW_UP_NOTE = 4000;
/** At most this many of a request's commits a removal reverts (chef-release drop's bound too). */
const MAX_REVERTS = 20;

/**
 * "Fix…" and "Remove…" on a request Chef built (waiting for Ship it, or
 * shipped): a follow-up build on top of the earlier work. "fix" tells the
 * agent what the admin says is wrong (`note`, required); "remove" takes the
 * request's change out of the app, starting from a revert of its builds'
 * commits. Either is a normal build: checks, a preview and the Ship card,
 * and nothing reaches the live app until the admin ships it.
 *
 * It copies the request's approved snapshot (the same bytes and contentHash;
 * the note goes in `followUp`, never the description), puts the request
 * back in `requested`, queues it first and claims, like Chef's own
 * follow-up. Refused, with an audit row, while it is queued or building,
 * or when Chef never built it.
 */
export const adminFollowUp = mutation({
  args: {
    itemId: v.id("items"),
    kind: v.union(v.literal("fix"), v.literal("remove")),
    note: v.optional(v.string()),
    adminUserId: v.string(),
  },
  returns: v.union(
    v.object({ outcome: v.literal("started"), claim: v.string(), snapshotId: v.id("chefSnapshots") }),
    v.object({ outcome: v.literal("refused"), reason: v.string() }),
  ),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const actor = userActor(args.adminUserId);
    const action = args.kind === "fix" ? "snapshot.fixRequested" : "snapshot.removeRequested";
    const note = (args.note ?? "").trim();
    if (args.kind === "fix" && !note) throw new Error("Say what's wrong, so Chef knows what to fix.");
    if (note.length > MAX_FOLLOW_UP_NOTE) throw new Error(`Keep it under ${MAX_FOLLOW_UP_NOTE} characters.`);
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    const refuse = async (reason: string) => {
      await writeAudit(ctx, { actor, action, target: item._id, outcome: "refused", reason });
      return { outcome: "refused" as const, reason };
    };
    const check = await followUpCheck(ctx, item);
    if (!check.ok) return await refuse(`Not now: ${check.reason}`);
    const last = check.last;
    // A batch run's member was built from its own snapshot.
    const approved = await ctx.db.get("chefSnapshots", runSnapshotFor(last, item._id) ?? last.snapshotId);
    if (!approved || approved.approvedAt === undefined || approved.approvedBy === undefined) {
      return await refuse("Its approval is gone: approve it again");
    }
    // What a removal reverts: the commits of the request's own builds,
    // oldest first. Not a batch's (it holds other requests' changes too),
    // nor a merge of main, nor an earlier removal; the agent handles those.
    const revertShas: string[] = [];
    if (args.kind === "remove") {
      const runs = await ctx.db
        .query("chefRuns")
        .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
        .order("desc")
        .take(50);
      for (const r of runs) {
        if (r.status !== "built" || !r.commitSha || r.batch || r.mode === "merge" || r.refresh || r.followUp?.kind === "remove") continue;
        revertShas.unshift(r.commitSha);
      }
      revertShas.splice(0, Math.max(0, revertShas.length - MAX_REVERTS));
    }
    const copyId = await ctx.db.insert("chefSnapshots", {
      itemId: approved.itemId,
      title: approved.title,
      description: approved.description,
      transcript: approved.transcript,
      attachments: approved.attachments,
      contentHash: approved.contentHash,
      itemUpdatedAt: approved.itemUpdatedAt,
      createdBy: args.adminUserId,
      createdAt: Date.now(),
      approvedBy: approved.approvedBy,
      approvedAt: approved.approvedAt,
      followUp: {
        ofRunId: last._id,
        kind: args.kind,
        ...(note ? { note } : {}),
        ...(args.kind === "remove" ? { revertShas } : {}),
      },
    });
    if (item.batchId) await leaveBatch(ctx, item._id, { alone: false });
    // Being worked on again, a shipped request too; at the front of the queue.
    await ctx.db.patch("items", item._id, { state: "requested", snapshotId: copyId, cloudQueuedAt: 1, continueFrom: undefined });
    await ctx.db.insert("devLogs", {
      itemId: item._id,
      authorId: args.adminUserId,
      message: args.kind === "fix" ? `Fix requested: ${note.slice(0, 500)}` : `Removal requested${note ? `: ${note.slice(0, 500)}` : "."}`,
      stamp: Date.now(),
    });
    const claim = await claimNextBuild(ctx, { via: "button", actor, startedBy: args.adminUserId });
    await writeAudit(ctx, {
      actor,
      action,
      target: copyId,
      runId: last._id,
      outcome: "ok",
      detail: { itemId: item._id, contentHash: approved.contentHash, reverts: revertShas.length, claim: claim.outcome },
    });
    return { outcome: "started" as const, claim: claim.outcome, snapshotId: copyId };
  },
});

/** One snapshot with inline attachment URLs for the approvals view. Admins only; null otherwise. */
export const get = query({
  args: { snapshotId: v.id("chefSnapshots"), viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(
    v.null(),
    v.object({
      snapshot: vSnapshot,
      attachmentUrls: v.array(v.union(v.string(), v.null())),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const snapshot = await ctx.db.get("chefSnapshots", args.snapshotId);
    if (!snapshot) return null;
    const attachmentUrls = await Promise.all(
      snapshot.attachments.map((a) => ctx.storage.getUrl(a.storageId)),
    );
    return { snapshot, attachmentUrls };
  },
});
