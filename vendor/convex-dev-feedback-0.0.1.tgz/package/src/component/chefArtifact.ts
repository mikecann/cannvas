// The frontend artifact (docs/chef-pipeline.md, "The preview"): the runner
// builds the app's frontend in the build sandbox with the Convex URL set to a
// placeholder, and uploads it here with its run credential through
// POST /chef-agent/artifact. The launcher later hands it to the deploy
// sandbox, which runs no repo code.
//
// One artifact per run, uploaded only in the `guards` phase (after the gates
// and the commit, before the push is asked for), at most MAX_ARTIFACT_BYTES,
// its sha256 checked against the bytes and against storage's own hash. Every
// call writes one audit row: the credential's prefix, the run, the sha256
// and size. Never the bytes.
import { changeFingerprint } from "../chef/follow.js";
import { v } from "convex/values";
import { action, internalMutation, mutation, query } from "./_generated/server.js";
import { api, internal } from "./_generated/api.js";
import { auditOk, authorize, refuseAuthorized, vRefusal } from "./chefAgent.js";
import { base64ToHex, sha256Hex } from "./chefShared.js";
import { MAX_ARTIFACT_BYTES, isCommitSha, isSha256Hex } from "../chef/frontend.js";
import {
  DIFF_MAX_CHUNKS,
  RELEASE_DIFF_MAX_BYTES,
  chunkDiff,
  diffHashFromChunkHashes,
  filesInDiff,
  isDependencyFile,
} from "../chef/release.js";
import { scrubWithReport } from "../chef/scrub.js";
import { riskFlags } from "../chef/card.js";


const NEED = { route: "artifact", scope: "run.report", phases: ["guards"] } as const;

/**
 * Before any bytes are stored: the credential, the phase and the declared
 * sha256, size and commit. `already` means this exact artifact is recorded
 * (a retry after a lost response), so nothing needs storing.
 */
export const admit = mutation({
  args: { token: v.string(), sha256: v.string(), size: v.number(), commitSha: v.string() },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), already: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { ...NEED, phases: [...NEED.phases] });
    if (!a.ok) return a;
    const refuse = (status: number, error: string) => refuseAuthorized(ctx, a, "artifact", status, error);
    if (!isSha256Hex(args.sha256)) return await refuse(400, "x-chef-sha256 must be 64 hex characters");
    if (!isCommitSha(args.commitSha)) return await refuse(400, "x-chef-commit must be a 40 character sha");
    if (!Number.isInteger(args.size) || args.size <= 0) return await refuse(400, "Empty artifact");
    if (args.size > MAX_ARTIFACT_BYTES) return await refuse(413, `Artifact over ${MAX_ARTIFACT_BYTES} bytes`);
    const prior = a.run.frontendArtifact;
    if (prior) {
      if (prior.sha256 === args.sha256 && prior.commitSha === args.commitSha) {
        return { ok: true as const, already: true };
      }
      return await refuse(409, "A different artifact was already uploaded for this run");
    }
    return { ok: true as const, already: false };
  },
});

/**
 * The upload itself, called by the HTTP route with the request's bytes.
 * Stores them in this component's storage only once admit passed and their
 * sha256 matches the declared one; `record` decides the rest.
 */
export const store = action({
  args: { token: v.string(), sha256: v.string(), commitSha: v.string(), bytes: v.bytes() },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.boolean(), sha256: v.string(), size: v.number() })),
  handler: async (ctx, args): Promise<
    { ok: false; status: number; error: string } | { ok: true; stored: boolean; sha256: string; size: number }
  > => {
    const size = args.bytes.byteLength;
    const admitted = await ctx.runMutation(api.chefArtifact.admit, {
      token: args.token,
      sha256: args.sha256,
      size,
      commitSha: args.commitSha,
    });
    if (!admitted.ok) return admitted;
    const bytesSha256 = await sha256Hex(args.bytes);
    let storageId = null;
    if (!admitted.already && bytesSha256 === args.sha256) {
      storageId = await ctx.storage.store(new Blob([args.bytes], { type: "application/gzip" }));
    }
    return await ctx.runMutation(internal.chefArtifact.record, {
      token: args.token,
      sha256: args.sha256,
      bytesSha256,
      size,
      commitSha: args.commitSha,
      storageId,
    });
  },
});

/** Records the stored artifact on the run, or refuses and deletes it. */
export const record = internalMutation({
  args: {
    token: v.string(),
    sha256: v.string(),
    bytesSha256: v.string(),
    size: v.number(),
    commitSha: v.string(),
    storageId: v.union(v.id("_storage"), v.null()),
  },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.boolean(), sha256: v.string(), size: v.number() })),
  handler: async (ctx, args) => {
    const drop = async () => {
      if (args.storageId) await ctx.storage.delete(args.storageId);
    };
    // Again, in this transaction: the run may have moved since admit.
    const a = await authorize(ctx, args.token, { ...NEED, phases: [...NEED.phases] });
    if (!a.ok) {
      await drop();
      return a;
    }
    const refuse = async (status: number, error: string) => {
      await drop();
      return await refuseAuthorized(ctx, a, "artifact", status, error, { sha256: args.sha256, size: args.size });
    };
    if (args.bytesSha256 !== args.sha256) return await refuse(400, "The bytes don't match x-chef-sha256");
    if (args.size > MAX_ARTIFACT_BYTES) return await refuse(413, `Artifact over ${MAX_ARTIFACT_BYTES} bytes`);
    const prior = a.run.frontendArtifact;
    if (prior) {
      await drop();
      if (prior.sha256 !== args.sha256 || prior.commitSha !== args.commitSha) {
        return await refuseAuthorized(ctx, a, "artifact", 409, "A different artifact was already uploaded for this run");
      }
      await auditOk(ctx, a, "artifact", { sha256: args.sha256, size: args.size, stored: false });
      return { ok: true as const, stored: false, sha256: args.sha256, size: args.size };
    }
    if (!args.storageId) return await refuse(500, "Nothing was stored");
    const file = await ctx.db.system.get("_storage", args.storageId);
    if (!file || base64ToHex(file.sha256) !== args.sha256 || file.size !== args.size) {
      return await refuse(409, "Stored bytes don't match");
    }
    await ctx.db.patch("chefRuns", a.run._id, {
      frontendArtifact: {
        storageId: args.storageId,
        sha256: args.sha256,
        size: args.size,
        commitSha: args.commitSha,
        at: Date.now(),
      },
    });
    await auditOk(ctx, a, "artifact", { sha256: args.sha256, size: args.size, commit: args.commitSha, stored: true });
    return { ok: true as const, stored: true, sha256: args.sha256, size: args.size };
  },
});

/**
 * For the host's launcher (packages/chef-cloud/src/client/chefLauncher.ts): where to fetch a
 * run's artifact and what it must hash to. Host-only; the storage URL never
 * reaches a sandbox.
 */
export const forRun = query({
  args: { runId: v.id("chefRuns") },
  returns: v.union(
    v.null(),
    v.object({ url: v.string(), sha256: v.string(), size: v.number(), commitSha: v.string() }),
  ),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    const art = run?.frontendArtifact;
    if (!art) return null;
    const url = await ctx.storage.getUrl(art.storageId);
    if (!url) return null;
    return { url, sha256: art.sha256, size: art.size, commitSha: art.commitSha };
  },
});

// ------------------------------------------------------------ release diff

const NEED_DIFF = { route: "releaseDiff", scope: "run.report", phases: ["guards"] } as const;
const MAX_DIFF_FILES = 500;

/**
 * The run's release diff, `git diff <main>..<commit>` with the release's
 * fixed options (src/chef/release.ts), uploaded by the runner next to the
 * frontend (POST /chef-agent/release-diff). "Ship it" shows it and binds the
 * approval to its hash, the same hash `chef-release` computes: chunked by
 * `chunkDiff`, each chunk's sha256 taken before scrubbing, the chunk hashes
 * hashed together. Stored scrubbed, one row per chunk. One per run: the same
 * diff again is a no-op, a different one is refused.
 */
export const recordReleaseDiff = mutation({
  args: {
    token: v.string(),
    baseSha: v.string(),
    commitSha: v.string(),
    sha256: v.string(),
    text: v.string(),
  },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.boolean(), diffHash: v.string() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { ...NEED_DIFF, phases: [...NEED_DIFF.phases] });
    if (!a.ok) return a;
    const refuse = (status: number, error: string) => refuseAuthorized(ctx, a, "releaseDiff", status, error);
    if (!isSha256Hex(args.sha256)) return await refuse(400, "x-chef-sha256 must be 64 hex characters");
    if (!isCommitSha(args.commitSha) || !isCommitSha(args.baseSha)) {
      return await refuse(400, "x-chef-commit and x-chef-base must be 40 character shas");
    }
    const bytes = new TextEncoder().encode(args.text).length;
    if (bytes === 0) return await refuse(400, "Empty diff");
    if (bytes > RELEASE_DIFF_MAX_BYTES) return await refuse(413, `Diff over ${RELEASE_DIFF_MAX_BYTES} bytes`);
    if ((await sha256Hex(args.text)) !== args.sha256) return await refuse(400, "The diff doesn't match x-chef-sha256");
    const prior = a.run.releaseDiff;
    if (prior) {
      if (prior.sha256 === args.sha256 && prior.commitSha === args.commitSha && prior.baseSha === args.baseSha) {
        await auditOk(ctx, a, "releaseDiff", { sha256: args.sha256, stored: false });
        return { ok: true as const, stored: false, diffHash: prior.diffHash };
      }
      return await refuse(409, "A different release diff was already uploaded for this run");
    }
    if (a.run.commitSha !== undefined && a.run.commitSha !== args.commitSha) {
      return await refuse(409, "The diff is for another commit");
    }
    const chunks = chunkDiff(args.text);
    if (chunks.length > DIFF_MAX_CHUNKS) return await refuse(413, "Diff too large");
    const hashes: string[] = [];
    let redactions = 0;
    const files = new Set<string>();
    for (let i = 0; i < chunks.length; i++) {
      const sha256 = await sha256Hex(chunks[i]);
      hashes.push(sha256);
      for (const f of filesInDiff(chunks[i])) files.add(f);
      const { text, counts } = scrubWithReport(chunks[i]);
      const n = Object.values(counts).reduce((x, y) => x + (y ?? 0), 0);
      redactions += n;
      await ctx.db.insert("chefRunDiffChunks", {
        runId: a.run._id,
        index: i,
        sha256,
        bytes: new TextEncoder().encode(chunks[i]).length,
        text,
        redactions: n,
      });
    }
    const diffHash = await diffHashFromChunkHashes(hashes);
    const all = [...files];
    // The Ship card's flags, from the whole diff as uploaded (before
    // scrubbing), by fixed rules (src/chef/card.ts).
    const flags = riskFlags({ diffText: args.text });
    // The build's own change, apart from main (src/chef/follow.ts): what an
    // approval binds to when Ship it merges a newer main in.
    const change = await changeFingerprint(args.text);
    await ctx.db.patch("chefRuns", a.run._id, {
      riskFlags: flags,
      releaseDiff: {
        baseSha: args.baseSha,
        commitSha: args.commitSha,
        sha256: args.sha256,
        diffHash,
        chunkCount: chunks.length,
        bytes,
        filesChanged: all.slice(0, MAX_DIFF_FILES),
        filesTruncated: all.length > MAX_DIFF_FILES,
        depsChanged: all.some(isDependencyFile),
        redactions,
        at: Date.now(),
        change,
      },
    });
    await auditOk(ctx, a, "releaseDiff", {
      sha256: args.sha256,
      diffHash,
      chunks: chunks.length,
      base: args.baseSha,
      commit: args.commitSha,
      stored: true,
    });
    return { ok: true as const, stored: true, diffHash };
  },
});
