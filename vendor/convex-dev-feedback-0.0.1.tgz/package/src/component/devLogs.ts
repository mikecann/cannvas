import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";

export const post = mutation({
  args: {
    itemId: v.id("items"),
    authorId: v.string(),
    message: v.string(),
  },
  returns: v.id("devLogs"),
  handler: async (ctx, args) => {
    return await ctx.db.insert("devLogs", {
      itemId: args.itemId,
      authorId: args.authorId,
      message: args.message,
      stamp: Date.now(),
    });
  },
});

/** An item's log lines are read up to this many, the newest. */
export const LIST_CAP = 500;

/** The item's newest LIST_CAP log lines, oldest first. */
export const listForItem = query({
  args: { itemId: v.id("items") },
  handler: async (ctx, args) => {
    const logs = await ctx.db
      .query("devLogs")
      .withIndex("by_item", (q) => q.eq("itemId", args.itemId))
      .order("desc")
      .take(LIST_CAP);
    logs.sort((a, b) => a.stamp - b.stamp);
    return logs;
  },
});
