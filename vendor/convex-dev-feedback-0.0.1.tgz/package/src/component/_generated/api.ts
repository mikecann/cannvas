/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as access from "../access.js";
import type * as agentKeys from "../agentKeys.js";
import type * as agentState from "../agentState.js";
import type * as attachments from "../attachments.js";
import type * as bids from "../bids.js";
import type * as chefAgent from "../chefAgent.js";
import type * as chefAgentKeys from "../chefAgentKeys.js";
import type * as chefArtifact from "../chefArtifact.js";
import type * as chefAttempts from "../chefAttempts.js";
import type * as chefAudit from "../chefAudit.js";
import type * as chefBatches from "../chefBatches.js";
import type * as chefBeta from "../chefBeta.js";
import type * as chefCards from "../chefCards.js";
import type * as chefDemo from "../chefDemo.js";
import type * as chefEffects from "../chefEffects.js";
import type * as chefFeedback from "../chefFeedback.js";
import type * as chefInference from "../chefInference.js";
import type * as chefIos from "../chefIos.js";
import type * as chefLearnings from "../chefLearnings.js";
import type * as chefOrchestrator from "../chefOrchestrator.js";
import type * as chefPreviewData from "../chefPreviewData.js";
import type * as chefRejected from "../chefRejected.js";
import type * as chefReleases from "../chefReleases.js";
import type * as chefRepairs from "../chefRepairs.js";
import type * as chefRunnerConfig from "../chefRunnerConfig.js";
import type * as chefRuns from "../chefRuns.js";
import type * as chefScreenshots from "../chefScreenshots.js";
import type * as chefSettings from "../chefSettings.js";
import type * as chefShared from "../chefShared.js";
import type * as chefShip from "../chefShip.js";
import type * as chefSnapshots from "../chefSnapshots.js";
import type * as chefWatchdog from "../chefWatchdog.js";
import type * as contract from "../contract.js";
import type * as devLogs from "../devLogs.js";
import type * as items from "../items.js";
import type * as notifications from "../notifications.js";
import type * as progress from "../progress.js";
import type * as settings from "../settings.js";
import type * as todos from "../todos.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";
import { anyApi, componentsGeneric } from "convex/server";

const fullApi: ApiFromModules<{
  access: typeof access;
  agentKeys: typeof agentKeys;
  agentState: typeof agentState;
  attachments: typeof attachments;
  bids: typeof bids;
  chefAgent: typeof chefAgent;
  chefAgentKeys: typeof chefAgentKeys;
  chefArtifact: typeof chefArtifact;
  chefAttempts: typeof chefAttempts;
  chefAudit: typeof chefAudit;
  chefBatches: typeof chefBatches;
  chefBeta: typeof chefBeta;
  chefCards: typeof chefCards;
  chefDemo: typeof chefDemo;
  chefEffects: typeof chefEffects;
  chefFeedback: typeof chefFeedback;
  chefInference: typeof chefInference;
  chefIos: typeof chefIos;
  chefLearnings: typeof chefLearnings;
  chefOrchestrator: typeof chefOrchestrator;
  chefPreviewData: typeof chefPreviewData;
  chefRejected: typeof chefRejected;
  chefReleases: typeof chefReleases;
  chefRepairs: typeof chefRepairs;
  chefRunnerConfig: typeof chefRunnerConfig;
  chefRuns: typeof chefRuns;
  chefScreenshots: typeof chefScreenshots;
  chefSettings: typeof chefSettings;
  chefShared: typeof chefShared;
  chefShip: typeof chefShip;
  chefSnapshots: typeof chefSnapshots;
  chefWatchdog: typeof chefWatchdog;
  contract: typeof contract;
  devLogs: typeof devLogs;
  items: typeof items;
  notifications: typeof notifications;
  progress: typeof progress;
  settings: typeof settings;
  todos: typeof todos;
  users: typeof users;
}> = anyApi as any;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
> = anyApi as any;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
> = anyApi as any;

export const components = componentsGeneric() as unknown as {};
