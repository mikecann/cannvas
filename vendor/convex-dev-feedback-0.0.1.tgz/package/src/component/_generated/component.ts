/* eslint-disable */
/**
 * Generated `ComponentApi` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type { FunctionReference } from "convex/server";

/**
 * A utility for referencing a Convex component's exposed API.
 *
 * Useful when expecting a parameter like `components.myComponent`.
 * Usage:
 * ```ts
 * async function myFunction(ctx: QueryCtx, component: ComponentApi) {
 *   return ctx.runQuery(component.someFile.someQuery, { ...args });
 * }
 * ```
 */
export type ComponentApi<Name extends string | undefined = string | undefined> =
  {
    agentKeys: {
      create: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          name: string;
          scopes?: Array<"build" | "triage">;
        },
        { id: string; key: string; prefix: string },
        Name
      >;
      hasLegacy: FunctionReference<"query", "internal", {}, boolean, Name>;
      list: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        Array<{
          _creationTime: number;
          _id: string;
          createdBy: string;
          lastUsedAt?: number;
          legacy: boolean;
          name: string;
          prefix: string;
          revoked: boolean;
          scopes: Array<"build" | "triage">;
        }>,
        Name
      >;
      migrateToHashes: FunctionReference<
        "mutation",
        "internal",
        {},
        { migrated: number; prefixes: Array<string>; remaining: boolean },
        Name
      >;
      revoke: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; id: string },
        null,
        Name
      >;
      touch: FunctionReference<
        "mutation",
        "internal",
        { id: string },
        null,
        Name
      >;
      verify: FunctionReference<
        "query",
        "internal",
        { key: string },
        null | { _id: string; name: string; scopes: Array<"build" | "triage"> },
        Name
      >;
    };
    agentState: {
      snapshot: FunctionReference<
        "query",
        "internal",
        {
          agentKey?: string;
          includeCompleted?: boolean;
          limit?: number;
          mode?: "all" | "chef" | "queue";
          viewer?: string | null;
        },
        {
          counts: {
            inProgress: number;
            openRefinements: number;
            openTodos: number;
            progress: number;
            requested: number;
            todos: number;
          };
          progress: Array<any>;
          refinements: Array<any>;
          requests: Array<any>;
          todos: Array<any>;
        },
        Name
      >;
    };
    attachments: {
      add: FunctionReference<
        "mutation",
        "internal",
        {
          agentKey?: string;
          itemId: string;
          kind: "screenshot" | "audio";
          storageId: string;
          userId: string;
        },
        string,
        Name
      >;
      generateUploadUrl: FunctionReference<
        "mutation",
        "internal",
        {},
        string,
        Name
      >;
      list: FunctionReference<
        "query",
        "internal",
        {
          agentKey?: string;
          includeCommunity?: boolean;
          itemId: string;
          viewer?: string | null;
        },
        Array<{
          _id: string;
          createdAt: number;
          kind: "screenshot" | "audio";
          mimeType: string;
          size: number;
          url: string | null;
        }>,
        Name
      >;
      listForItems: FunctionReference<
        "query",
        "internal",
        {
          agentKey?: string;
          includeCommunity?: boolean;
          itemIds: Array<string>;
          viewer?: string | null;
        },
        Array<{
          attachments: Array<{
            _id: string;
            createdAt: number;
            kind: "screenshot" | "audio";
            mimeType: string;
            size: number;
            url: string | null;
          }>;
          itemId: string;
        }>,
        Name
      >;
      remove: FunctionReference<
        "mutation",
        "internal",
        { agentKey?: string; attachmentId: string; userId: string },
        null,
        Name
      >;
    };
    bids: {
      backfillStats: FunctionReference<
        "mutation",
        "internal",
        {},
        number,
        Name
      >;
      getUserBid: FunctionReference<
        "query",
        "internal",
        { itemId: string; userId: string },
        { _id: string; amount: number } | null,
        Name
      >;
      itemStats: FunctionReference<
        "query",
        "internal",
        { itemId: string },
        { supporterCount: number; totalAmount: number },
        Name
      >;
      place: FunctionReference<
        "mutation",
        "internal",
        { amount: number; itemId: string; userId: string },
        { bidId: string; delta: number; previousAmount: number },
        Name
      >;
      remove: FunctionReference<
        "mutation",
        "internal",
        { itemId: string; userId: string },
        number,
        Name
      >;
    };
    chefAgent: {
      attachmentMismatch: FunctionReference<
        "mutation",
        "internal",
        { index: number; token: string },
        null,
        Name
      >;
      attachmentSource: FunctionReference<
        "mutation",
        "internal",
        { index: number; member?: number; token: string },
        | { error: string; ok: false; status: number }
        | {
            contentType: string;
            ok: true;
            sha256: string;
            size: number;
            url: string;
          },
        Name
      >;
      finish: FunctionReference<
        "mutation",
        "internal",
        {
          error?: string;
          handoff?: boolean;
          outcome: "built" | "failed";
          previewDeploymentName?: string;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | { finished: boolean; handedOff: boolean; ok: true },
        Name
      >;
      getRun: FunctionReference<
        "mutation",
        "internal",
        { token: string },
        | { error: string; ok: false; status: number }
        | {
            batch?: Array<{
              itemNumber: number;
              snapshot: {
                attachments: Array<{
                  contentType: string;
                  index: number;
                  kind: "screenshot" | "audio";
                  sha256: string;
                  size: number;
                  storageId: string;
                }>;
                contentHash: string;
                description: string;
                itemId: string;
                title: string;
                transcript: string | null;
              };
            }>;
            continues: boolean;
            deadline: number;
            followUp?: {
              kind?: "fix" | "remove";
              note?: string;
              reason?: string;
              revertShas?: Array<string>;
            };
            itemNumber: number;
            mode?: "merge";
            ok: true;
            phase:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
            release?: { fromSha: string; repair: boolean; seq: number };
            runId: string;
            seq: number;
            snapshot: {
              attachments: Array<{
                contentType: string;
                index: number;
                kind: "screenshot" | "audio";
                sha256: string;
                size: number;
                storageId: string;
              }>;
              contentHash: string;
              description: string;
              itemId: string;
              title: string;
              transcript: string | null;
            };
          },
        Name
      >;
      heartbeat: FunctionReference<
        "mutation",
        "internal",
        { token: string },
        | { error: string; ok: false; status: number }
        | {
            ok: true;
            phase:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
          },
        Name
      >;
      issueRunCredentials: FunctionReference<
        "mutation",
        "internal",
        { runId: string },
        { inference: string; runner: string },
        Name
      >;
      log: FunctionReference<
        "mutation",
        "internal",
        { lines: Array<string>; seq: number; token: string },
        | { error: string; ok: false; status: number }
        | { ok: true; stored: boolean },
        Name
      >;
      recordRoute: FunctionReference<
        "mutation",
        "internal",
        {
          index?: number;
          outcome: "ok" | "refused" | "error";
          reason?: string;
          route:
            | "enroll"
            | "run"
            | "attachments"
            | "report"
            | "log"
            | "heartbeat"
            | "ai"
            | "feedback"
            | "approvals"
            | "screenshot"
            | "artifact"
            | "releaseDiff"
            | "finish"
            | "learnings"
            | "attempt";
          status: number;
          token: string | null;
        },
        null,
        Name
      >;
      report: FunctionReference<
        "mutation",
        "internal",
        {
          facts?: {
            baseSha?: string;
            branch?: string;
            chefAfter?: string;
            chefBefore?: string;
            commitSha?: string;
            demoScript?: {
              steps: Array<
                | { do: "goto"; path: string }
                | { do: "click"; name?: string; role?: string; text?: string }
                | {
                    do: "fill";
                    label?: string;
                    placeholder?: string;
                    value: string;
                  }
                | { do: "press"; key: string }
                | { do: "waitFor"; text: string }
                | { do: "wait"; ms: number }
                | { do: "scroll"; y: number }
              >;
            };
            depsChanged?: boolean;
            diffHash?: string;
            error?: string;
            filesChanged?: Array<string>;
            fixReason?: string;
            fixRound?: number;
            gateResults?: Array<{
              baseline: "pass" | "fail" | "none";
              baselineCached?: boolean;
              baselineFiles?: Array<string>;
              baselineOn?: "main";
              command: string;
              newProblems?: Array<string>;
              result?: "pass" | "fail";
            }>;
            mergeRepair?: {
              conflicts: Array<string>;
              diff: string;
              files: Array<string>;
              gates: Array<string>;
              truncated: boolean;
            };
            mergedMain?: { count: number; subjects: Array<string> };
            provenance?: {
              claudeCodeVersion?: string;
              convexCliVersion?: string;
              convexPlugin?: string;
              daytonaSnapshot?: string;
              daytonaSnapshotId?: string;
              deployScriptSha256?: string;
              earlierAttempt?: string;
              feedbackSha?: string;
              host?: string;
              lockfileHash?: string;
              model?: string;
              nodeVersion?: string;
              npmVersion?: string;
              pluginUsage?: string;
              previewWarmKey?: string;
              previewWarmSnapshot?: string;
              runner?: string;
              runnerSha256?: string;
              warmInstall?: string;
              warmKey?: string;
              warmSnapshot?: string;
            };
          };
          fromPhase:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          toPhase:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          token: string;
        },
        | { error: string; ok: false; status: number }
        | {
            applied: boolean;
            ok: true;
            phase:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
          },
        Name
      >;
    };
    chefAgentKeys: {
      create: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; kind?: "cloud" | "worker"; name: string },
        { id: string; key: string; kind: "cloud" | "worker"; prefix: string },
        Name
      >;
      enroll: FunctionReference<
        "mutation",
        "internal",
        { key: string; requests?: "admin" | "any" },
        | { error: string; ok: false; status?: number }
        | {
            claim:
              | { outcome: "claimed"; runId: string }
              | { outcome: "busy"; runId: string }
              | { outcome: "reconciling"; runId: string }
              | { memberRequests?: number; outcome: "empty" }
              | { outcome: "disabled"; reason: string }
              | { outcome: "planning" };
            credential: string | null;
            ok: true;
            requestedBy?: "admin" | "member";
            rotated: boolean;
          },
        Name
      >;
      list: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        Array<{
          _id: string;
          createdAt: number;
          createdBy: string;
          kind: "cloud" | "worker";
          name: string;
          prefix: string;
          revokedAt?: number;
        }>,
        Name
      >;
      revoke: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; id: string; reason?: string },
        null,
        Name
      >;
    };
    chefArtifact: {
      admit: FunctionReference<
        "mutation",
        "internal",
        { commitSha: string; sha256: string; size: number; token: string },
        | { error: string; ok: false; status: number }
        | { already: boolean; ok: true },
        Name
      >;
      forRun: FunctionReference<
        "query",
        "internal",
        { runId: string },
        null | { commitSha: string; sha256: string; size: number; url: string },
        Name
      >;
      recordReleaseDiff: FunctionReference<
        "mutation",
        "internal",
        {
          baseSha: string;
          commitSha: string;
          sha256: string;
          text: string;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | { diffHash: string; ok: true; stored: boolean },
        Name
      >;
      store: FunctionReference<
        "action",
        "internal",
        {
          bytes: ArrayBuffer;
          commitSha: string;
          sha256: string;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | { ok: true; sha256: string; size: number; stored: boolean },
        Name
      >;
    };
    chefAttempts: {
      fetch: FunctionReference<
        "mutation",
        "internal",
        { token: string },
        | { error: string; ok: false; status: number }
        | {
            baseTree: string;
            diff: string;
            ok: true;
            reason: string;
            sha256: string;
            summary: string;
          },
        Name
      >;
      store: FunctionReference<
        "mutation",
        "internal",
        { baseTree: string; diff: string; token: string },
        | { error: string; ok: false; status: number }
        | { ok: true; stored: boolean },
        Name
      >;
    };
    chefAudit: {
      list: FunctionReference<
        "query",
        "internal",
        { limit?: number; runId?: string; viewer?: string | null },
        Array<{
          _creationTime: number;
          _id: string;
          action: string;
          actor: string;
          at: number;
          detail?: Record<string, string | number | boolean | null>;
          outcome: "ok" | "refused" | "error";
          reason?: string;
          runId?: string;
          target?: string;
        }>,
        Name
      >;
      record: FunctionReference<
        "mutation",
        "internal",
        {
          action: string;
          actor: string;
          detail?: Record<string, string | number | boolean | null>;
          outcome: "ok" | "refused" | "error";
          reason?: string;
          runId?: string;
          target?: string;
        },
        null,
        Name
      >;
    };
    chefBatches: {
      applyPlan: FunctionReference<
        "mutation",
        "internal",
        {
          batches: null | Array<{
            numbers: Array<number>;
            reason: string;
            title: string;
          }>;
          costUsd?: number;
          error?: string;
          model?: string;
          planId: string;
        },
        | { outcome: "claimed"; runId: string }
        | { outcome: "busy"; runId: string }
        | { outcome: "reconciling"; runId: string }
        | { memberRequests?: number; outcome: "empty" }
        | { outcome: "disabled"; reason: string }
        | { outcome: "planning" }
        | null,
        Name
      >;
      list: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        null | {
          batches: Array<{
            batchId: string;
            failures: number;
            items: Array<{
              itemId: string;
              number: number;
              state: string;
              title: string;
            }>;
            reason: string;
            runId: string | null;
            status: string;
            title: string;
          }>;
          planning: boolean;
        },
        Name
      >;
      setPlanner: FunctionReference<
        "mutation",
        "internal",
        { handle: string | null },
        null,
        Name
      >;
      split: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; itemId: string },
        { batchId: string; remaining: number },
        Name
      >;
    };
    chefBeta: {
      begin: FunctionReference<
        "mutation",
        "internal",
        { deploymentName: string; runId: string; siteUrl: string },
        | { status: "busy" }
        | { siteUrl: string; status: "done" }
        | { status: "inactive" }
        | { baseSha: string; seedWanted: boolean; sha: string; status: "go" },
        Name
      >;
      finish: FunctionReference<
        "mutation",
        "internal",
        {
          asPreview?: boolean;
          demoLoginUrl?: string;
          note?: string;
          ok: boolean;
          runId: string;
          seeded?: boolean;
        },
        null | { previewUrl: string | null },
        Name
      >;
      state: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        null | {
          deployedAt: number | null;
          deploying: boolean;
          deploymentName: string;
          runId: string | null;
          seeded: boolean;
          sha: string | null;
          siteUrl: string;
        },
        Name
      >;
    };
    chefCards: {
      card: FunctionReference<
        "query",
        "internal",
        { runId?: string; viewer?: string | null },
        null | {
          beta: null | {
            deployedAt: number | null;
            note: string | null;
            onBeta: boolean;
            siteUrl: string;
            status: "deploying" | "deployed" | "failed" | null;
          };
          ciCheck: null | {
            at: number;
            detail: string | null;
            status: "pending" | "passed" | "failed" | "none" | "error";
            url: string | null;
          };
          commitSha: string | null;
          demoNote: string | null;
          details: null | {
            bytes: number;
            chunkCount: number;
            depsChanged: boolean;
            diffHash: string;
            files: number;
            filesTruncated: boolean;
            redactions: number;
          };
          filesChanged: number;
          finishedAt: number | null;
          flags: Array<{
            count: number;
            files: Array<string>;
            kind: string;
            label: string;
          }>;
          flagsFrom: "diff" | "paths";
          iosCheck: null | {
            at: number;
            compiled: boolean;
            device: string | null;
            error: string | null;
            installed: boolean;
          };
          phase:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          previewHasYourData: boolean;
          previewLoginUrl: string | null;
          previewNote: string | null;
          previewUrl: string | null;
          requests: Array<{
            builtWith: Array<number>;
            itemId: string;
            number: number | null;
            runId: string;
            title: string;
            whatChanged: Array<string>;
            whatToTry: Array<string>;
            wroteSummary: boolean;
          }>;
          runId: string;
          screenshots: Array<{
            createdAt: number;
            height: number;
            name: string;
            path: string;
            size: number;
            url: string | null;
            width: number;
          }>;
          seq: number;
          status: "active" | "reconciling" | "built" | "failed" | "cancelled";
          videos: Array<{
            durationMs: number;
            failed: null | { reason: string; step: number; what: string };
            url: string | null;
            viewport: "phone" | "desktop";
          }>;
        },
        Name
      >;
    };
    chefDemo: {
      finish: FunctionReference<
        "mutation",
        "internal",
        { note?: string; runId: string },
        null,
        Name
      >;
      forHost: FunctionReference<
        "query",
        "internal",
        { runId: string },
        null | {
          commitSha: string | null;
          demoScript: null | {
            steps: Array<
              | { do: "goto"; path: string }
              | { do: "click"; name?: string; role?: string; text?: string }
              | {
                  do: "fill";
                  label?: string;
                  placeholder?: string;
                  value: string;
                }
              | { do: "press"; key: string }
              | { do: "waitFor"; text: string }
              | { do: "wait"; ms: number }
              | { do: "scroll"; y: number }
            >;
          };
          loginUrl: string | null;
          previewUrl: string | null;
          recorded: Array<"phone" | "desktop">;
          status: string;
        },
        Name
      >;
      forRun: FunctionReference<
        "query",
        "internal",
        { runId: string; viewer?: string | null },
        null | {
          note: string | null;
          videos: Array<{
            bytes: number;
            done: number;
            durationMs: number;
            failed: null | { reason: string; step: number; what: string };
            steps: number;
            timedOut: boolean;
            url: string | null;
            viewport: "phone" | "desktop";
          }>;
        },
        Name
      >;
      storeVideo: FunctionReference<
        "action",
        "internal",
        {
          bytes: ArrayBuffer;
          done: number;
          durationMs: number;
          failed?: { reason: string; step: number; what: string };
          runId: string;
          sha256: string;
          steps: number;
          timedOut?: boolean;
          viewport: "phone" | "desktop";
        },
        { reason?: string; stored: boolean },
        Name
      >;
    };
    chefEffects: {
      appendRunLog: FunctionReference<
        "mutation",
        "internal",
        { lines: Array<string>; runId: string },
        null,
        Name
      >;
      branchesToSweep: FunctionReference<
        "query",
        "internal",
        { limit?: number; now: number },
        Array<{ branch: string | null; runId: string }>,
        Name
      >;
      checkIntent: FunctionReference<
        "query",
        "internal",
        { key: string; runId: string },
        null,
        Name
      >;
      confirmPushFromRefs: FunctionReference<
        "mutation",
        "internal",
        {
          refs: {
            branch: string | null;
            chef: string | null;
            main: string | null;
          };
          runId: string;
        },
        { branchPushed: boolean; mainMoved: boolean; pushed: boolean },
        Name
      >;
      emailFailed: FunctionReference<
        "mutation",
        "internal",
        { error: string; key: string; runId: string },
        null,
        Name
      >;
      finishActive: FunctionReference<
        "mutation",
        "internal",
        { error?: string; outcome: "built" | "failed"; runId: string },
        { finished: boolean },
        Name
      >;
      finishReconciled: FunctionReference<
        "mutation",
        "internal",
        {
          cleanup: { sandboxesDeleted: number; secretsDeleted: number };
          pushedToChef: boolean;
          runId: string;
        },
        { finished: boolean },
        Name
      >;
      liveResources: FunctionReference<
        "query",
        "internal",
        {},
        {
          releaseIds: Array<string>;
          repairRunIds?: Array<string>;
          runIds: Array<string>;
          secretNames: Array<string>;
        },
        Name
      >;
      markBranchSwept: FunctionReference<
        "mutation",
        "internal",
        { deleted: boolean; runId: string },
        null,
        Name
      >;
      nextBranchExpiry: FunctionReference<
        "query",
        "internal",
        {},
        number | null,
        Name
      >;
      orchestratorHeartbeat: FunctionReference<
        "mutation",
        "internal",
        { runId: string },
        null,
        Name
      >;
      reconcileInfo: FunctionReference<
        "query",
        "internal",
        { runId: string },
        {
          branch: string | null;
          commitSha: string | null;
          pendingOutcome: "failed" | "cancelled" | null;
          phase: string;
          runId: string;
          sandboxIds: Array<string>;
          secretNames: Array<string>;
          status: string;
        } | null,
        Name
      >;
      recordEffect: FunctionReference<
        "mutation",
        "internal",
        { adopted?: boolean; key: string; result: string; runId: string },
        null,
        Name
      >;
      recordPreview: FunctionReference<
        "mutation",
        "internal",
        {
          demoLoginUrl?: string;
          deploymentName: string;
          loginUrl?: string;
          previewName: string;
          runId: string;
          sha: string;
        },
        { previewName: string; previewUrl: string },
        Name
      >;
      recordSecrets: FunctionReference<
        "mutation",
        "internal",
        {
          event: "created" | "adopted" | "live" | "dead" | "deleted";
          names: Array<string>;
          runId: string;
        },
        null,
        Name
      >;
      recordSweep: FunctionReference<
        "mutation",
        "internal",
        {
          branches: number;
          errors: number;
          sandboxes: Array<string>;
          secrets: Array<string>;
        },
        null,
        Name
      >;
      recordWarm: FunctionReference<
        "mutation",
        "internal",
        {
          key: string;
          role: "build" | "deploy";
          runId: string;
          snapshot: string;
        },
        null,
        Name
      >;
      runInfo: FunctionReference<
        "query",
        "internal",
        { runId: string },
        {
          baseSha: string | null;
          branch: string | null;
          ciCheck?: {
            at: number;
            detail?: string;
            ref: string;
            sha: string;
            status: "pending" | "passed" | "failed" | "none" | "error";
            url?: string;
          };
          commitSha: string | null;
          deadline: number;
          error: string | null;
          filesChanged: Array<string>;
          heartbeatAt: number;
          itemNumber: number | null;
          phase: string;
          previewKeyPrefix: string | null;
          previewLoginUrl: string | null;
          previewName: string | null;
          previewUrl: string | null;
          releaseMerge?: boolean;
          runId: string;
          seq: number;
          startedVia: string;
          status: string;
          title: string;
        } | null,
        Name
      >;
      setCleaner: FunctionReference<
        "mutation",
        "internal",
        { handle: string | null },
        null,
        Name
      >;
      setOrchestrator: FunctionReference<
        "mutation",
        "internal",
        { handle: string | null },
        null,
        Name
      >;
      setPhase: FunctionReference<
        "mutation",
        "internal",
        {
          from: "cloned" | "committed" | "pushed" | "previewing";
          runId: string;
          to: "agent" | "pushing" | "previewing" | "done";
        },
        { applied: boolean },
        Name
      >;
      setReconciler: FunctionReference<
        "mutation",
        "internal",
        { handle: string | null },
        null,
        Name
      >;
    };
    chefFeedback: {
      decideApprovalRequest: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          decision: "approved" | "declined";
          note?: string;
          requestId: string;
        },
        {
          changed: boolean;
          decidedAt: number;
          status: "pending" | "approved" | "declined";
        },
        Name
      >;
      listApprovalRequests: FunctionReference<
        "query",
        "internal",
        {
          paginationOpts: {
            cursor: string | null;
            endCursor?: string | null;
            id?: number;
            maximumBytesRead?: number;
            maximumRowsRead?: number;
            numItems: number;
          };
          runId?: string;
          status?: "pending" | "approved" | "declined";
          viewer?: string | null;
        },
        {
          continueCursor: string;
          isDone: boolean;
          page: Array<{
            action: string;
            commandOrSteps: string;
            createdAt: number;
            decidedAt: number | null;
            decidedBy: string | null;
            decisionNote: string | null;
            estimatedCostUsd: number | null;
            id: string;
            itemId: string;
            runId: string;
            skill: string | null;
            status: "pending" | "approved" | "declined";
            why: string;
          }>;
        },
        Name
      >;
      listSkillFeedback: FunctionReference<
        "query",
        "internal",
        {
          paginationOpts: {
            cursor: string | null;
            endCursor?: string | null;
            id?: number;
            maximumBytesRead?: number;
            maximumRowsRead?: number;
            numItems: number;
          };
          runId?: string;
          skill?: string;
          viewer?: string | null;
        },
        {
          continueCursor: string;
          isDone: boolean;
          page: Array<{
            createdAt: number;
            id: string;
            itemId: string;
            kind: "wrong" | "missing" | "outdated" | "deviation";
            message: string;
            runId: string;
            skill: string;
            suggestion: string | null;
          }>;
        },
        Name
      >;
      reportApprovalRequests: FunctionReference<
        "mutation",
        "internal",
        {
          entries: Array<{
            action: string;
            commandOrSteps: string;
            estimatedCostUsd?: number | null;
            skill?: string | null;
            why: string;
          }>;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | { applied: boolean; ok: true; stored: number },
        Name
      >;
      reportSkillFeedback: FunctionReference<
        "mutation",
        "internal",
        {
          entries: Array<{
            kind: string;
            message: string;
            skill: string | null;
            suggestion?: string | null;
          }>;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | { applied: boolean; ok: true; stored: number },
        Name
      >;
    };
    chefInference: {
      begin: FunctionReference<
        "mutation",
        "internal",
        {
          maxTokens: number | null;
          model: string;
          requestBytes: number;
          stream: boolean;
          token: string;
        },
        | { error: string; ok: false; retryAfter?: number; status: number }
        | {
            budgetKey: string;
            ceilingUsd: number;
            ok: true;
            requestId: string;
            worstCaseUsd: number;
          },
        Name
      >;
      end: FunctionReference<
        "mutation",
        "internal",
        {
          firstByteMs?: number;
          httpStatus: number;
          latencyMs: number;
          outcome: "ok" | "error" | "cancelled";
          reason?: string;
          requestId: string;
          usage: {
            cacheCreationInputTokens?: number;
            cacheReadInputTokens?: number;
            costUsd?: number;
            inputTokens?: number;
            outputTokens?: number;
          };
        },
        { costUsd: number; recorded: boolean },
        Name
      >;
      listForRun: FunctionReference<
        "query",
        "internal",
        { limit?: number; runId: string; viewer?: string | null },
        Array<{
          _creationTime: number;
          _id: string;
          cacheCreationInputTokens?: number;
          cacheReadInputTokens?: number;
          costSource?: "gateway" | "estimate" | "worstCase";
          costUsd?: number;
          firstByteMs?: number;
          httpStatus?: number;
          inputTokens?: number;
          latencyMs?: number;
          maxTokens?: number;
          model: string;
          outputTokens?: number;
          reason?: string;
          requestBytes?: number;
          runId: string;
          startedAt: number;
          status:
            "pending" | "ok" | "error" | "cancelled" | "refused" | "abandoned";
          stream: boolean;
        }>,
        Name
      >;
    };
    chefIos: {
      info: FunctionReference<
        "query",
        "internal",
        { ref: string },
        null | {
          betaConvexUrl: string | null;
          branch: string | null;
          commitSha: string;
          itemNumber: number | null;
          previewConvexUrl: string | null;
          runId: string;
          status: string;
          title: string;
        },
        Name
      >;
      recordCi: FunctionReference<
        "mutation",
        "internal",
        {
          check: {
            at: number;
            detail?: string;
            ref: string;
            sha: string;
            status: "pending" | "passed" | "failed" | "none" | "error";
            url?: string;
          };
          operator: string;
          runId: string;
        },
        null,
        Name
      >;
      report: FunctionReference<
        "mutation",
        "internal",
        {
          commitSha: string;
          compiled: boolean;
          device?: string;
          error?: string;
          installed: boolean;
          operator: string;
          runId: string;
        },
        null,
        Name
      >;
    };
    chefLearnings: {
      forget: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; id: string },
        boolean,
        Name
      >;
      forRun: FunctionReference<
        "query",
        "internal",
        {},
        {
          baselines: Array<{
            gates: Array<{ command: string; outcome: "pass" | "fail" }>;
            lockfileHash?: string;
            tree: string;
          }>;
          brief: string;
        },
        Name
      >;
      list: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        {
          brief: string;
          entries: Array<{
            expired: boolean;
            firstRunSeq: number;
            id: string;
            lastRunSeq: number;
            seenCount: number;
            source: "runner" | "agent" | "failure";
            text: string;
            topic: string;
            updatedAt: number;
          }>;
        },
        Name
      >;
      report: FunctionReference<
        "mutation",
        "internal",
        {
          attempt?: { diffStat: string; summary: string };
          notes: Array<{ note: string; topic: string }>;
          observed: {
            baseline?: {
              gates: Array<{ command: string; outcome: "pass" | "fail" }>;
              lockfileHash?: string;
              tree: string;
            };
            filesChanged?: Array<string>;
            fixRounds?: number;
            frontend?: string;
            gates?: Array<{
              baseline: "pass" | "fail" | "none";
              command: string;
              result?: "pass" | "fail";
            }>;
            install?: string;
            pluginUsage?: string;
            scripts?: Array<string>;
          };
          timings: Record<string, number>;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | { applied: boolean; notes: number; ok: true },
        Name
      >;
    };
    chefPreviewData: {
      dropExport: FunctionReference<
        "mutation",
        "internal",
        { runId: string; seeded?: boolean },
        null,
        Name
      >;
      exportUrl: FunctionReference<
        "query",
        "internal",
        { runId: string },
        null | { bytes: number; sha256: string; url: string; userId: string },
        Name
      >;
      mode: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        null | { mode: "demo" | "admin-copy"; userId: string | null },
        Name
      >;
      setMode: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; mode: "demo" | "admin-copy" },
        { mode: "demo" | "admin-copy" },
        Name
      >;
      settingsForHost: FunctionReference<
        "query",
        "internal",
        {},
        { mode: "demo" | "admin-copy"; userId: string | null },
        Name
      >;
      storeExport: FunctionReference<
        "action",
        "internal",
        { bytes: ArrayBuffer; runId: string; sha256: string; userId: string },
        { reason?: string; stored: boolean },
        Name
      >;
    };
    chefRejected: {
      list: FunctionReference<
        "query",
        "internal",
        { limit?: number; viewer?: string | null },
        Array<{ bucket: number; count: number; route: string }>,
        Name
      >;
      listRefusals: FunctionReference<
        "query",
        "internal",
        { limit?: number; viewer?: string | null },
        Array<{
          action: string;
          actor: string;
          bucket: number;
          count: number;
          lastAt: number;
          reason?: string;
          runId?: string;
        }>,
        Name
      >;
      prune: FunctionReference<"mutation", "internal", {}, number, Name>;
    };
    chefReleases: {
      abandon: FunctionReference<
        "mutation",
        "internal",
        { operator: string; reason: string; releaseId: string },
        {
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        },
        Name
      >;
      approve: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          depsAcknowledged?: boolean;
          diffHash: string;
          releaseId: string;
        },
        { approved: boolean; reason?: string },
        Name
      >;
      builtRuns: FunctionReference<
        "query",
        "internal",
        { limit?: number },
        Array<{
          chefAfter: string | null;
          chefBefore: string | null;
          commitSha: string | null;
          finishedAt: number | null;
          itemId: string;
          itemNumber: number | null;
          runId: string;
          seq: number;
        }>,
        Name
      >;
      diffChunk: FunctionReference<
        "query",
        "internal",
        { index: number; releaseId: string; viewer?: string | null },
        null | {
          count: number;
          index: number;
          redactions: number;
          sha256: string;
          text: string;
        },
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { releaseId: string; viewer?: string | null },
        {
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        } | null,
        Name
      >;
      itemRuns: FunctionReference<
        "query",
        "internal",
        { itemNumber: number },
        null | {
          itemId: string;
          runs: Array<{
            chefAfter: string | null;
            chefBefore: string | null;
            commitSha: string | null;
            finishedAt: number | null;
            itemId: string;
            itemNumber: number | null;
            runId: string;
            seq: number;
          }>;
          state: string;
          title: string;
        },
        Name
      >;
      list: FunctionReference<
        "query",
        "internal",
        { limit?: number; viewer?: string | null },
        Array<{
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        }>,
        Name
      >;
      prepare: FunctionReference<
        "mutation",
        "internal",
        {
          baseSha: string;
          cliVersion?: string;
          operator: string;
          runIds: Array<string>;
          sha: string;
        },
        { releaseId: string; resumed: boolean; seq: number; state: string },
        Name
      >;
      recordDrop: FunctionReference<
        "mutation",
        "internal",
        {
          itemNumber: number;
          operator: string;
          reason?: string;
          revertSha: string | null;
          reverted: Array<string>;
        },
        null,
        Name
      >;
      recordTarget: FunctionReference<
        "mutation",
        "internal",
        {
          detail?: string;
          digest: string;
          operator: string;
          releaseId: string;
          target: "convexApp" | "staticHosting";
        },
        {
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        },
        Name
      >;
      rollback: FunctionReference<
        "mutation",
        "internal",
        { mainSha: string; operator: string; reason: string; seq: number },
        {
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        },
        Name
      >;
      status: FunctionReference<
        "query",
        "internal",
        { seq?: number },
        {
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        } | null,
        Name
      >;
      step: FunctionReference<
        "mutation",
        "internal",
        {
          artifactDigest?: string;
          checks?: Array<{ name: string; ok: boolean }>;
          diffHash?: string;
          gates?: Array<string>;
          mainSha?: string;
          mergeSha?: string;
          operator: string;
          phase: "begin" | "complete";
          pushId?: string;
          releaseBranch?: string;
          releaseId: string;
          to:
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done";
        },
        {
          _creationTime: number;
          _id: string;
          approvedAt?: number;
          approvedBy?: string;
          approvedChange?: { blocks?: Array<string>; changeHash: string };
          approvedDiffHash?: string;
          artifactDigest?: string;
          backend?: {
            actor: string;
            at: number;
            mergeSha: string;
            pushId?: string;
          };
          baseSha: string;
          checkpoints: Array<{
            actor: string;
            at: number;
            note?: string;
            state:
              | "pinned"
              | "diffReady"
              | "approved"
              | "merged"
              | "sourcePushed"
              | "gatesPassed"
              | "backendDeployed"
              | "frontendPublished"
              | "verified"
              | "live"
              | "done"
              | "abandoned"
              | "rolledBack";
          }>;
          checks?: Array<{ name: string; ok: boolean }>;
          cliVersion?: string;
          createdAt: number;
          deployedSha?: string;
          depsAcknowledged?: boolean;
          depsChanged?: boolean;
          diffBytes?: number;
          diffChunkCount?: number;
          diffHash?: string;
          endReason?: string;
          filesChanged?: Array<string>;
          filesTruncated?: boolean;
          finishedAt?: number;
          follow?: {
            at: number;
            attempts: number;
            conflicts?: Array<string>;
            files?: Array<string>;
            mainSha: string;
            reason?: string;
            repaired?: boolean;
            runId?: string;
            status:
              "merging" | "needsApproval" | "failed" | "stalled" | "merged";
          };
          gates?: Array<string>;
          inFlight?: { actor: string; at: number; to: string };
          kind: "chef" | "cloud" | "rollback";
          mainSha?: string;
          mergeSha?: string;
          open: boolean;
          preparedBy: string;
          redactions?: number;
          releaseBranch?: string;
          restores?: number;
          rollbackOf?: number;
          rolledBackBy?: number;
          runIds: Array<string>;
          seq: number;
          sha: string;
          ship?: {
            attempts?: number;
            deploymentName?: string;
            emailId?: string;
            emailKeys?: Array<string>;
            error?: string;
            errorAt?: number;
            executionId?: string;
            mirror?: {
              at: number;
              error?: string;
              github: string;
              sha?: string;
              status: string;
              target?: string;
            };
            retryAt?: number;
            sandboxId?: string;
            sandboxIntentAt?: number;
            secretName?: string;
            siteUrl?: string;
            watchdogAt?: number;
          };
          shipRunId?: string;
          shipWatchdogDueAt?: number;
          state:
            | "pinned"
            | "diffReady"
            | "approved"
            | "merged"
            | "sourcePushed"
            | "gatesPassed"
            | "backendDeployed"
            | "frontendPublished"
            | "verified"
            | "live"
            | "done"
            | "abandoned"
            | "rolledBack";
          targets: {
            convexApp?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
            staticHosting?: {
              actor: string;
              at: number;
              detail?: string;
              digest: string;
            };
          };
          updatedAt: number;
        },
        Name
      >;
      uploadDiffChunk: FunctionReference<
        "mutation",
        "internal",
        {
          count: number;
          diffHash: string;
          index: number;
          operator: string;
          releaseId: string;
          text: string;
        },
        { received: number; state: string },
        Name
      >;
    };
    chefRepairs: {
      applied: FunctionReference<
        "mutation",
        "internal",
        { mainSha: string; operator: string; repairId: string },
        { retry: string },
        Name
      >;
      apply: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; repairId: string; sha: string },
        { applying: boolean; reason?: string },
        Name
      >;
      begin: FunctionReference<
        "mutation",
        "internal",
        { operator: string; runId: string },
        null | {
          created: boolean;
          kind: "lockfile" | "symlinks" | "envFiles";
          repairId: string;
          status:
            | "making"
            | "offered"
            | "applying"
            | "applied"
            | "failed"
            | "declined";
        },
        Name
      >;
      decline: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; repairId: string },
        null,
        Name
      >;
      fail: FunctionReference<
        "mutation",
        "internal",
        { error: string; operator: string; repairId: string },
        null,
        Name
      >;
      forRun: FunctionReference<
        "query",
        "internal",
        { runId: string; viewer?: string | null },
        null | {
          baseSha: string | null;
          branch: string | null;
          error: string | null;
          files: Array<{ how: string; path: string }>;
          itemId: string;
          kind: "lockfile" | "symlinks" | "envFiles";
          repairId: string;
          runId: string;
          sha: string | null;
          status:
            | "making"
            | "offered"
            | "applying"
            | "applied"
            | "failed"
            | "declined";
          summary: string | null;
          updatedAt: number;
        },
        Name
      >;
      info: FunctionReference<
        "query",
        "internal",
        { repairId: string },
        null | {
          baseSha: string | null;
          branch: string | null;
          error: string | null;
          files: Array<{ how: string; path: string }>;
          itemId: string;
          kind: "lockfile" | "symlinks" | "envFiles";
          repairId: string;
          runId: string;
          sha: string | null;
          status:
            | "making"
            | "offered"
            | "applying"
            | "applied"
            | "failed"
            | "declined";
          summary: string | null;
          updatedAt: number;
        },
        Name
      >;
      offer: FunctionReference<
        "mutation",
        "internal",
        {
          baseSha: string;
          branch: string;
          files: Array<{ how: string; path: string }>;
          operator: string;
          repairId: string;
          sha: string;
          summary: string;
        },
        null,
        Name
      >;
      setApplier: FunctionReference<
        "mutation",
        "internal",
        { handle: string | null },
        null,
        Name
      >;
    };
    chefRunnerConfig: {
      get: FunctionReference<
        "query",
        "internal",
        {},
        {
          fixRounds?: number;
          frontend?:
            | false
            | { command: Array<string>; distDir: string; urlEnvVar: string };
          gates?: "auto" | Array<Array<string>>;
          localEnv?: "auto" | false | Array<string>;
          loginFunction?: string;
          repoUrl?: string;
        },
        Name
      >;
      set: FunctionReference<
        "mutation",
        "internal",
        {
          fixRounds?: number;
          frontend?:
            | false
            | { command: Array<string>; distDir: string; urlEnvVar: string };
          gates?: "auto" | Array<Array<string>>;
          localEnv?: "auto" | false | Array<string>;
          loginFunction?: string;
          repoUrl?: string;
        },
        boolean,
        Name
      >;
    };
    chefRuns: {
      buildNow: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string },
        | { outcome: "claimed"; runId: string }
        | { outcome: "busy"; runId: string }
        | { outcome: "reconciling"; runId: string }
        | { memberRequests?: number; outcome: "empty" }
        | { outcome: "disabled"; reason: string }
        | { outcome: "planning" },
        Name
      >;
      buildState: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        null | {
          autoBuild: boolean;
          batches: Array<{
            batchId: string;
            failures: number;
            items: Array<{
              itemId: string;
              number: number;
              state: string;
              title: string;
            }>;
            reason: string;
            runId: string | null;
            status: string;
            title: string;
          }>;
          batching: boolean;
          busy: boolean;
          cloudEnabled: boolean;
          followUps: Array<{ itemId: string; number: number; runId: string }>;
          planning: boolean;
          queued: boolean;
          upNext: Array<{
            batchId?: string;
            itemId: string;
            number: number;
            title: string;
          }>;
          workerKeys: number;
        },
        Name
      >;
      cancel: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          force?: boolean;
          reason?: string;
          runId: string;
        },
        { finished: boolean; reconciling: boolean },
        Name
      >;
      costs: FunctionReference<
        "query",
        "internal",
        { limit?: number; viewer?: string | null },
        Array<{
          aiRequests: number;
          attempt: number;
          createdAt: number;
          failure: string | null;
          fixRounds: number;
          inputTokens: number;
          outputTokens: number;
          phaseMs: Record<string, number>;
          runId: string;
          seq: number;
          spendUsd: number;
          status: string;
          wallMs: number | null;
          warm: boolean | null;
        }>,
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { runId: string; viewer?: string | null },
        {
          _creationTime: number;
          _id: string;
          agentKeyId?: string;
          aiInFlight?: number;
          aiInputTokens?: number;
          aiOutputTokens?: number;
          aiRequests?: number;
          attempt?: number;
          baseSha?: string;
          batch?: {
            batchId: string;
            items: Array<{ itemId: string; snapshotId: string }>;
          };
          beta?: {
            at: number;
            deploymentName: string;
            note?: string;
            seeded?: boolean;
            status: "deploying" | "deployed" | "failed";
          };
          branch?: string;
          branchSweptAt?: number;
          buildSandboxId?: string;
          chefAfter?: string;
          chefBefore?: string;
          ciCheck?: {
            at: number;
            detail?: string;
            ref: string;
            sha: string;
            status: "pending" | "passed" | "failed" | "none" | "error";
            url?: string;
          };
          commitSha?: string;
          continueFrom?: string;
          createdAt: number;
          deadline: number;
          demoNote?: string;
          demoScript?: {
            steps: Array<
              | { do: "goto"; path: string }
              | { do: "click"; name?: string; role?: string; text?: string }
              | {
                  do: "fill";
                  label?: string;
                  placeholder?: string;
                  value: string;
                }
              | { do: "press"; key: string }
              | { do: "waitFor"; text: string }
              | { do: "wait"; ms: number }
              | { do: "scroll"; y: number }
            >;
          };
          demoVideos?: Array<{
            bytes: number;
            done: number;
            durationMs: number;
            failed?: { reason: string; step: number; what: string };
            sha256: string;
            steps: number;
            storageId: string;
            timedOut?: boolean;
            viewport: "phone" | "desktop";
          }>;
          deploySandboxId?: string;
          depsChanged?: boolean;
          diffFileId?: string;
          diffHash?: string;
          diffStat?: string;
          endedPhase?:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          error?: string;
          failure?: {
            action: string;
            code: string;
            kind: "transient" | "deterministic" | "environmental";
            reason: string;
          };
          filesChanged?: Array<string>;
          finishedAt?: number;
          fixRound?: number;
          followUp?: {
            kind?: "fix" | "remove";
            note?: string;
            ofRunId: string;
            reason?: string;
            revertShas?: Array<string>;
          };
          frontendArtifact?: {
            at: number;
            commitSha: string;
            sha256: string;
            size: number;
            storageId: string;
          };
          gateResults?: Array<{
            baseline: "pass" | "fail" | "none";
            baselineCached?: boolean;
            baselineFiles?: Array<string>;
            baselineOn?: "main";
            command: string;
            newProblems?: Array<string>;
            result?: "pass" | "fail";
          }>;
          heartbeatAt: number;
          iosCheck?: {
            at: number;
            compiled: boolean;
            device?: string;
            error?: string;
            installed: boolean;
          };
          itemId: string;
          lastReport?: {
            at: number;
            from:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
            hash?: string;
            to:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
          };
          learningsAt?: number;
          mergeRepair?: {
            conflicts: Array<string>;
            diff: string;
            files: Array<string>;
            gates: Array<string>;
            truncated: boolean;
          };
          mergedMain?: { count: number; subjects: Array<string> };
          mode?: "merge";
          orchestratedAt?: number;
          pendingError?: string;
          pendingOutcome?: "failed" | "cancelled";
          phase:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          phaseMs?: Record<string, number>;
          previewAdminCopy?: boolean;
          previewDemoLoginUrl?: string;
          previewExport?: {
            bytes: number;
            sha256: string;
            storageId: string;
            userId: string;
          };
          previewLoginUrl?: string;
          previewName?: string;
          previewUrl?: string;
          priorSpendUsd?: number;
          provenance?: {
            claudeCodeVersion?: string;
            convexCliVersion?: string;
            convexPlugin?: string;
            daytonaSnapshot?: string;
            daytonaSnapshotId?: string;
            deployScriptSha256?: string;
            earlierAttempt?: string;
            feedbackSha?: string;
            host?: string;
            lockfileHash?: string;
            model?: string;
            nodeVersion?: string;
            npmVersion?: string;
            pluginUsage?: string;
            previewWarmKey?: string;
            previewWarmSnapshot?: string;
            runner?: string;
            runnerSha256?: string;
            warmInstall?: string;
            warmKey?: string;
            warmSnapshot?: string;
          };
          reconcileRetriedAt?: number;
          reconcileStartedAt?: number;
          recovery?: { action: string; class: string; repair?: string };
          refresh?: {
            approvedBy: string;
            approvedDiffHash: string;
            attempt?: number;
            depsAcknowledged: boolean;
            fromSha?: string;
            mainSha: string;
            ofRunId: string;
            releaseId?: string;
            releaseSeq: number;
            repair?: boolean;
          };
          releaseDiff?: {
            at: number;
            baseSha: string;
            bytes: number;
            change?: { blocks?: Array<string>; changeHash: string };
            chunkCount: number;
            commitSha: string;
            depsChanged: boolean;
            diffHash: string;
            filesChanged: Array<string>;
            filesTruncated: boolean;
            redactions: number;
            sha256: string;
          };
          requestedBy?: "admin" | "member";
          retryAt?: number;
          retryOf?: string;
          riskFlags?: Array<{
            count: number;
            files: Array<string>;
            kind: string;
            label: string;
          }>;
          roundLog?: Array<{
            at: number;
            from: string;
            reason: string;
            round: number;
            spendUsd: number;
          }>;
          secretNames?: Array<string>;
          seq: number;
          shipBlocked?: { at: number; reason: string };
          snapshotId: string;
          spendUsd?: number;
          startedBy?: string;
          startedVia:
            | "approval"
            | "button"
            | "cron"
            | "enroll"
            | "finish"
            | "retry"
            | "enable";
          status: "active" | "reconciling" | "built" | "failed" | "cancelled";
          summary?: string;
          watchdogDueAt?: number;
          workflowId?: string;
        } | null,
        Name
      >;
      hasRuns: FunctionReference<"query", "internal", {}, boolean, Name>;
      list: FunctionReference<
        "query",
        "internal",
        { limit?: number; viewer?: string | null },
        Array<{
          _creationTime: number;
          _id: string;
          agentKeyId?: string;
          aiInFlight?: number;
          aiInputTokens?: number;
          aiOutputTokens?: number;
          aiRequests?: number;
          attempt?: number;
          baseSha?: string;
          batch?: {
            batchId: string;
            items: Array<{ itemId: string; snapshotId: string }>;
          };
          beta?: {
            at: number;
            deploymentName: string;
            note?: string;
            seeded?: boolean;
            status: "deploying" | "deployed" | "failed";
          };
          branch?: string;
          branchSweptAt?: number;
          buildSandboxId?: string;
          chefAfter?: string;
          chefBefore?: string;
          ciCheck?: {
            at: number;
            detail?: string;
            ref: string;
            sha: string;
            status: "pending" | "passed" | "failed" | "none" | "error";
            url?: string;
          };
          commitSha?: string;
          continueFrom?: string;
          createdAt: number;
          deadline: number;
          demoNote?: string;
          demoScript?: {
            steps: Array<
              | { do: "goto"; path: string }
              | { do: "click"; name?: string; role?: string; text?: string }
              | {
                  do: "fill";
                  label?: string;
                  placeholder?: string;
                  value: string;
                }
              | { do: "press"; key: string }
              | { do: "waitFor"; text: string }
              | { do: "wait"; ms: number }
              | { do: "scroll"; y: number }
            >;
          };
          demoVideos?: Array<{
            bytes: number;
            done: number;
            durationMs: number;
            failed?: { reason: string; step: number; what: string };
            sha256: string;
            steps: number;
            storageId: string;
            timedOut?: boolean;
            viewport: "phone" | "desktop";
          }>;
          deploySandboxId?: string;
          depsChanged?: boolean;
          diffFileId?: string;
          diffHash?: string;
          diffStat?: string;
          endedPhase?:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          error?: string;
          failure?: {
            action: string;
            code: string;
            kind: "transient" | "deterministic" | "environmental";
            reason: string;
          };
          filesChanged?: Array<string>;
          finishedAt?: number;
          fixRound?: number;
          followUp?: {
            kind?: "fix" | "remove";
            note?: string;
            ofRunId: string;
            reason?: string;
            revertShas?: Array<string>;
          };
          frontendArtifact?: {
            at: number;
            commitSha: string;
            sha256: string;
            size: number;
            storageId: string;
          };
          gateResults?: Array<{
            baseline: "pass" | "fail" | "none";
            baselineCached?: boolean;
            baselineFiles?: Array<string>;
            baselineOn?: "main";
            command: string;
            newProblems?: Array<string>;
            result?: "pass" | "fail";
          }>;
          heartbeatAt: number;
          iosCheck?: {
            at: number;
            compiled: boolean;
            device?: string;
            error?: string;
            installed: boolean;
          };
          itemId: string;
          lastReport?: {
            at: number;
            from:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
            hash?: string;
            to:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
          };
          learningsAt?: number;
          mergeRepair?: {
            conflicts: Array<string>;
            diff: string;
            files: Array<string>;
            gates: Array<string>;
            truncated: boolean;
          };
          mergedMain?: { count: number; subjects: Array<string> };
          mode?: "merge";
          orchestratedAt?: number;
          pendingError?: string;
          pendingOutcome?: "failed" | "cancelled";
          phase:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          phaseMs?: Record<string, number>;
          previewAdminCopy?: boolean;
          previewDemoLoginUrl?: string;
          previewExport?: {
            bytes: number;
            sha256: string;
            storageId: string;
            userId: string;
          };
          previewLoginUrl?: string;
          previewName?: string;
          previewUrl?: string;
          priorSpendUsd?: number;
          provenance?: {
            claudeCodeVersion?: string;
            convexCliVersion?: string;
            convexPlugin?: string;
            daytonaSnapshot?: string;
            daytonaSnapshotId?: string;
            deployScriptSha256?: string;
            earlierAttempt?: string;
            feedbackSha?: string;
            host?: string;
            lockfileHash?: string;
            model?: string;
            nodeVersion?: string;
            npmVersion?: string;
            pluginUsage?: string;
            previewWarmKey?: string;
            previewWarmSnapshot?: string;
            runner?: string;
            runnerSha256?: string;
            warmInstall?: string;
            warmKey?: string;
            warmSnapshot?: string;
          };
          reconcileRetriedAt?: number;
          reconcileStartedAt?: number;
          recovery?: { action: string; class: string; repair?: string };
          refresh?: {
            approvedBy: string;
            approvedDiffHash: string;
            attempt?: number;
            depsAcknowledged: boolean;
            fromSha?: string;
            mainSha: string;
            ofRunId: string;
            releaseId?: string;
            releaseSeq: number;
            repair?: boolean;
          };
          releaseDiff?: {
            at: number;
            baseSha: string;
            bytes: number;
            change?: { blocks?: Array<string>; changeHash: string };
            chunkCount: number;
            commitSha: string;
            depsChanged: boolean;
            diffHash: string;
            filesChanged: Array<string>;
            filesTruncated: boolean;
            redactions: number;
            sha256: string;
          };
          requestedBy?: "admin" | "member";
          retryAt?: number;
          retryOf?: string;
          riskFlags?: Array<{
            count: number;
            files: Array<string>;
            kind: string;
            label: string;
          }>;
          roundLog?: Array<{
            at: number;
            from: string;
            reason: string;
            round: number;
            spendUsd: number;
          }>;
          secretNames?: Array<string>;
          seq: number;
          shipBlocked?: { at: number; reason: string };
          snapshotId: string;
          spendUsd?: number;
          startedBy?: string;
          startedVia:
            | "approval"
            | "button"
            | "cron"
            | "enroll"
            | "finish"
            | "retry"
            | "enable";
          status: "active" | "reconciling" | "built" | "failed" | "cancelled";
          summary?: string;
          watchdogDueAt?: number;
          workflowId?: string;
        }>,
        Name
      >;
      listLogs: FunctionReference<
        "query",
        "internal",
        {
          cursor?: number | null;
          limit?: number;
          runId: string;
          viewer?: string | null;
        },
        {
          nextCursor: number | null;
          page: Array<{ at: number; lines: Array<string>; seq: number }>;
        },
        Name
      >;
      lookup: FunctionReference<
        "query",
        "internal",
        { itemId?: string; runId?: string; viewer?: string | null },
        {
          _creationTime: number;
          _id: string;
          agentKeyId?: string;
          aiInFlight?: number;
          aiInputTokens?: number;
          aiOutputTokens?: number;
          aiRequests?: number;
          attempt?: number;
          baseSha?: string;
          batch?: {
            batchId: string;
            items: Array<{ itemId: string; snapshotId: string }>;
          };
          beta?: {
            at: number;
            deploymentName: string;
            note?: string;
            seeded?: boolean;
            status: "deploying" | "deployed" | "failed";
          };
          branch?: string;
          branchSweptAt?: number;
          buildSandboxId?: string;
          chefAfter?: string;
          chefBefore?: string;
          ciCheck?: {
            at: number;
            detail?: string;
            ref: string;
            sha: string;
            status: "pending" | "passed" | "failed" | "none" | "error";
            url?: string;
          };
          commitSha?: string;
          continueFrom?: string;
          createdAt: number;
          deadline: number;
          demoNote?: string;
          demoScript?: {
            steps: Array<
              | { do: "goto"; path: string }
              | { do: "click"; name?: string; role?: string; text?: string }
              | {
                  do: "fill";
                  label?: string;
                  placeholder?: string;
                  value: string;
                }
              | { do: "press"; key: string }
              | { do: "waitFor"; text: string }
              | { do: "wait"; ms: number }
              | { do: "scroll"; y: number }
            >;
          };
          demoVideos?: Array<{
            bytes: number;
            done: number;
            durationMs: number;
            failed?: { reason: string; step: number; what: string };
            sha256: string;
            steps: number;
            storageId: string;
            timedOut?: boolean;
            viewport: "phone" | "desktop";
          }>;
          deploySandboxId?: string;
          depsChanged?: boolean;
          diffFileId?: string;
          diffHash?: string;
          diffStat?: string;
          endedPhase?:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          error?: string;
          failure?: {
            action: string;
            code: string;
            kind: "transient" | "deterministic" | "environmental";
            reason: string;
          };
          filesChanged?: Array<string>;
          finishedAt?: number;
          fixRound?: number;
          followUp?: {
            kind?: "fix" | "remove";
            note?: string;
            ofRunId: string;
            reason?: string;
            revertShas?: Array<string>;
          };
          frontendArtifact?: {
            at: number;
            commitSha: string;
            sha256: string;
            size: number;
            storageId: string;
          };
          gateResults?: Array<{
            baseline: "pass" | "fail" | "none";
            baselineCached?: boolean;
            baselineFiles?: Array<string>;
            baselineOn?: "main";
            command: string;
            newProblems?: Array<string>;
            result?: "pass" | "fail";
          }>;
          heartbeatAt: number;
          iosCheck?: {
            at: number;
            compiled: boolean;
            device?: string;
            error?: string;
            installed: boolean;
          };
          itemId: string;
          lastReport?: {
            at: number;
            from:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
            hash?: string;
            to:
              | "launched"
              | "ready"
              | "cloning"
              | "cloned"
              | "agent"
              | "gates"
              | "guards"
              | "committed"
              | "pushing"
              | "pushed"
              | "previewing"
              | "done"
              | "ended";
          };
          learningsAt?: number;
          mergeRepair?: {
            conflicts: Array<string>;
            diff: string;
            files: Array<string>;
            gates: Array<string>;
            truncated: boolean;
          };
          mergedMain?: { count: number; subjects: Array<string> };
          mode?: "merge";
          orchestratedAt?: number;
          pendingError?: string;
          pendingOutcome?: "failed" | "cancelled";
          phase:
            | "launched"
            | "ready"
            | "cloning"
            | "cloned"
            | "agent"
            | "gates"
            | "guards"
            | "committed"
            | "pushing"
            | "pushed"
            | "previewing"
            | "done"
            | "ended";
          phaseMs?: Record<string, number>;
          previewAdminCopy?: boolean;
          previewDemoLoginUrl?: string;
          previewExport?: {
            bytes: number;
            sha256: string;
            storageId: string;
            userId: string;
          };
          previewLoginUrl?: string;
          previewName?: string;
          previewUrl?: string;
          priorSpendUsd?: number;
          provenance?: {
            claudeCodeVersion?: string;
            convexCliVersion?: string;
            convexPlugin?: string;
            daytonaSnapshot?: string;
            daytonaSnapshotId?: string;
            deployScriptSha256?: string;
            earlierAttempt?: string;
            feedbackSha?: string;
            host?: string;
            lockfileHash?: string;
            model?: string;
            nodeVersion?: string;
            npmVersion?: string;
            pluginUsage?: string;
            previewWarmKey?: string;
            previewWarmSnapshot?: string;
            runner?: string;
            runnerSha256?: string;
            warmInstall?: string;
            warmKey?: string;
            warmSnapshot?: string;
          };
          reconcileRetriedAt?: number;
          reconcileStartedAt?: number;
          recovery?: { action: string; class: string; repair?: string };
          refresh?: {
            approvedBy: string;
            approvedDiffHash: string;
            attempt?: number;
            depsAcknowledged: boolean;
            fromSha?: string;
            mainSha: string;
            ofRunId: string;
            releaseId?: string;
            releaseSeq: number;
            repair?: boolean;
          };
          releaseDiff?: {
            at: number;
            baseSha: string;
            bytes: number;
            change?: { blocks?: Array<string>; changeHash: string };
            chunkCount: number;
            commitSha: string;
            depsChanged: boolean;
            diffHash: string;
            filesChanged: Array<string>;
            filesTruncated: boolean;
            redactions: number;
            sha256: string;
          };
          requestedBy?: "admin" | "member";
          retryAt?: number;
          retryOf?: string;
          riskFlags?: Array<{
            count: number;
            files: Array<string>;
            kind: string;
            label: string;
          }>;
          roundLog?: Array<{
            at: number;
            from: string;
            reason: string;
            round: number;
            spendUsd: number;
          }>;
          secretNames?: Array<string>;
          seq: number;
          shipBlocked?: { at: number; reason: string };
          snapshotId: string;
          spendUsd?: number;
          startedBy?: string;
          startedVia:
            | "approval"
            | "button"
            | "cron"
            | "enroll"
            | "finish"
            | "retry"
            | "enable";
          status: "active" | "reconciling" | "built" | "failed" | "cancelled";
          summary?: string;
          watchdogDueAt?: number;
          workflowId?: string;
        } | null,
        Name
      >;
      sweep: FunctionReference<
        "mutation",
        "internal",
        {},
        | { outcome: "claimed"; runId: string }
        | { outcome: "busy"; runId: string }
        | { outcome: "reconciling"; runId: string }
        | { memberRequests?: number; outcome: "empty" }
        | { outcome: "disabled"; reason: string }
        | { outcome: "planning" },
        Name
      >;
    };
    chefScreenshots: {
      listRunScreenshots: FunctionReference<
        "query",
        "internal",
        { runId: string; viewer?: string | null },
        Array<{
          createdAt: number;
          height: number;
          name: string;
          path: string;
          size: number;
          url: string | null;
          width: number;
        }>,
        Name
      >;
      runScreenshotsForHost: FunctionReference<
        "query",
        "internal",
        { runId: string },
        Array<{
          createdAt: number;
          height: number;
          name: string;
          path: string;
          size: number;
          url: string | null;
          width: number;
        }>,
        Name
      >;
      upload: FunctionReference<
        "action",
        "internal",
        {
          bytes: ArrayBuffer;
          name: string;
          path: string;
          sha256?: string;
          token: string;
        },
        | { error: string; ok: false; status: number }
        | {
            height: number;
            name: string;
            ok: true;
            sha256: string;
            stored: boolean;
            width: number;
          },
        Name
      >;
    };
    chefSettings: {
      get: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        {
          aiMaxRequests: number;
          aiMaxTokens: number;
          cloudAutoBuild: boolean;
          cloudBatching: boolean;
          deployKeyPrefix: string | null;
          previewKeyPrefix: string | null;
          spendCeilingUsd: number;
        } | null,
        Name
      >;
      recordDeployKey: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; outcome: "ok" | "error"; reason?: string },
        null,
        Name
      >;
      recordPreviewDeployKey: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; created?: boolean; outcome: "ok" | "error" },
        null,
        Name
      >;
      set: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          aiMaxRequests?: number;
          aiMaxTokens?: number;
          cloudAutoBuild?: boolean;
          cloudBatching?: boolean;
          spendCeilingUsd?: number;
        },
        {
          aiMaxRequests: number;
          aiMaxTokens: number;
          cloudAutoBuild: boolean;
          cloudBatching: boolean;
          deployKeyPrefix: string | null;
          previewKeyPrefix: string | null;
          spendCeilingUsd: number;
        },
        Name
      >;
      setDeployKeyPrefix: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; prefix: string },
        null,
        Name
      >;
      setPreviewKeyPrefix: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; prefix: string },
        null,
        Name
      >;
    };
    chefShip: {
      approve: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          depsAcknowledged?: boolean;
          diffHash: string;
          runId: string;
        },
        {
          approved: boolean;
          reason?: string;
          releaseId?: string;
          seq?: number;
          started?: boolean;
        },
        Name
      >;
      autoRollback: FunctionReference<
        "mutation",
        "internal",
        { operator: string; reason: string; releaseId: string },
        {
          reason?: string;
          restores?: number;
          rolledBack: boolean;
          seq?: number;
        },
        Name
      >;
      candidate: FunctionReference<
        "query",
        "internal",
        { viewer?: string | null },
        null | {
          alsoShips?: Array<{
            itemId: string;
            number: number | null;
            runId: string;
            seq: number;
            title: string;
          }>;
          blocked: string | null;
          follow?: null | {
            approvedDiffHash: string | null;
            attempts: number;
            conflicts: Array<string>;
            depsChanged: boolean;
            diffHash: string | null;
            files: Array<string>;
            mainSha: string;
            reason: string | null;
            releaseSeq: number;
            repaired: boolean;
            resolution: string | null;
            resolutionTruncated: boolean;
            runId: string | null;
            shipRunId: string | null;
            status: string;
            text: string;
          };
          release: null | {
            approvedDiffHash: string | null;
            error: string | null;
            mainSha: string | null;
            open: boolean;
            releaseId: string;
            seq: number;
            sha: string;
            shipRunId: string | null;
            siteUrl: string | null;
            state: string;
            updatedAt: number;
          };
          requests: Array<{
            itemId: string;
            number: number | null;
            runId: string;
            title: string;
          }>;
          run: null | {
            baseSha: string | null;
            commitSha: string | null;
            diff: null | {
              bytes: number;
              chunkCount: number;
              depsChanged: boolean;
              diffHash: string;
              filesChanged: Array<string>;
              filesTruncated: boolean;
              redactions: number;
            };
            finishedAt: number | null;
            hasFrontend: boolean;
            mergedMain: null | { count: number; subjects: Array<string> };
            refresh: null | { releaseSeq: number; sameDiff: boolean };
            refreshing?: "queued" | "merging" | null;
            replaces?: number | null;
            retryItemId: string | null;
            runId: string;
            seq: number;
          };
        },
        Name
      >;
      diffChunk: FunctionReference<
        "query",
        "internal",
        { index: number; runId: string; viewer?: string | null },
        null | {
          count: number;
          index: number;
          redactions: number;
          sha256: string;
          text: string;
        },
        Name
      >;
      followMain: FunctionReference<
        "mutation",
        "internal",
        { mainSha: string; operator: string; releaseId: string },
        { following: boolean; reason: string | null },
        Name
      >;
      info: FunctionReference<
        "query",
        "internal",
        { releaseId: string },
        null | {
          approvedDiffHash: string | null;
          artifactDigest: string | null;
          attempts: number;
          baseSha: string;
          deployKeyPrefix: string | null;
          deployedSha?: string | null;
          emailKeys: Array<string>;
          executionId: string | null;
          following?: boolean;
          kind: string;
          mainSha: string | null;
          open: boolean;
          releaseId: string;
          requests: Array<{
            createdBy: string;
            itemId: string;
            number: number | null;
            removed?: boolean;
            title: string;
          }>;
          restores?: number | null;
          rollbackOf?: number | null;
          sandboxId: string | null;
          sandboxIntent: boolean;
          seq: number;
          sha: string;
          shipRunId: string | null;
          state: string;
        },
        Name
      >;
      record: FunctionReference<
        "mutation",
        "internal",
        {
          adopted?: boolean;
          deploymentName?: string;
          emailId?: string;
          emailKey?: string;
          error?: string;
          event:
            | "attempt"
            | "sandboxIntent"
            | "sandbox"
            | "secret"
            | "exec"
            | "deployment"
            | "error"
            | "cleanup"
            | "email"
            | "emailFailed"
            | "mirror";
          executionId?: string;
          mirrorGithub?: string;
          mirrorSha?: string;
          mirrorStatus?: "pushed" | "current" | "ahead" | "diverged" | "failed";
          mirrorTarget?: string;
          operator: string;
          releaseId: string;
          sandboxId?: string;
          secretName?: string;
          siteUrl?: string;
        },
        null,
        Name
      >;
      retryLater: FunctionReference<
        "mutation",
        "internal",
        { inMs: number; operator: string; releaseId: string },
        boolean,
        Name
      >;
      setShipper: FunctionReference<
        "mutation",
        "internal",
        { handle: string | null },
        null,
        Name
      >;
    };
    chefSnapshots: {
      adminFollowUp: FunctionReference<
        "mutation",
        "internal",
        {
          adminUserId: string;
          itemId: string;
          kind: "fix" | "remove";
          note?: string;
        },
        | { claim: string; outcome: "started"; snapshotId: string }
        | { outcome: "refused"; reason: string },
        Name
      >;
      approve: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; contentHash: string; snapshotId: string },
        {
          itemId: string;
          submitted?: { createdBy: string; number: number; title: string };
        },
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { snapshotId: string; viewer?: string | null },
        null | {
          attachmentUrls: Array<string | null>;
          snapshot: {
            _creationTime: number;
            _id: string;
            approvedAt?: number;
            approvedBy?: string;
            attachments: Array<{
              contentType: string;
              kind: "screenshot" | "audio";
              sha256: string;
              size: number;
              storageId: string;
            }>;
            contentHash: string;
            createdAt: number;
            createdBy: string;
            description: string;
            followUp?: {
              kind?: "fix" | "remove";
              note?: string;
              ofRunId: string;
              reason?: string;
              revertShas?: Array<string>;
            };
            itemId: string;
            itemUpdatedAt: number;
            refresh?: {
              approvedBy: string;
              approvedDiffHash: string;
              attempt?: number;
              depsAcknowledged: boolean;
              fromSha?: string;
              mainSha: string;
              ofRunId: string;
              releaseId?: string;
              releaseSeq: number;
              repair?: boolean;
            };
            retry?: { attempt: number; ofRunId: string; priorSpendUsd: number };
            title: string;
            transcript: string | null;
          };
        },
        Name
      >;
      prepareApproval: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; itemId: string },
        { contentHash: string; snapshotId: string },
        Name
      >;
      retry: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; itemId: string },
        | { claim: string; outcome: "started"; snapshotId: string }
        | { contentHash: string; outcome: "needsApproval"; snapshotId: string }
        | { outcome: "refused"; reason: string },
        Name
      >;
      snapshotOwnRequest: FunctionReference<
        "mutation",
        "internal",
        { adminUserId: string; itemId: string },
        string | null,
        Name
      >;
    };
    chefWatchdog: {
      check: FunctionReference<
        "mutation",
        "internal",
        { now?: number },
        { finished: number; reconcilers: number; ships: number },
        Name
      >;
      workflowEnded: FunctionReference<
        "mutation",
        "internal",
        { error: string; runId: string },
        boolean,
        Name
      >;
    };
    contract: {
      version: FunctionReference<
        "query",
        "internal",
        {},
        { version: number },
        Name
      >;
    };
    devLogs: {
      listForItem: FunctionReference<
        "query",
        "internal",
        { itemId: string },
        any,
        Name
      >;
      post: FunctionReference<
        "mutation",
        "internal",
        { authorId: string; itemId: string; message: string },
        string,
        Name
      >;
    };
    items: {
      boost: FunctionReference<
        "mutation",
        "internal",
        { amount: number; grantedBy: string; itemId: string; reason?: string },
        number,
        Name
      >;
      complete: FunctionReference<
        "mutation",
        "internal",
        { changelog?: string; itemId: string },
        null,
        Name
      >;
      countByState: FunctionReference<
        "query",
        "internal",
        {
          state:
            | "submitted"
            | "requested"
            | "planned"
            | "inProgress"
            | "rejected"
            | "completed";
        },
        number,
        Name
      >;
      create: FunctionReference<
        "mutation",
        "internal",
        {
          autoApprove?: boolean;
          description: string;
          kind?: "feature" | "refinement";
          title: string;
          transcript?: string;
          userId: string;
        },
        string,
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { itemId: string },
        any,
        Name
      >;
      listAll: FunctionReference<
        "query",
        "internal",
        {
          agentKey?: string;
          cursor?: string | null;
          limit?: number;
          viewer?: string | null;
        },
        { nextCursor: string | null; page: Array<any> },
        Name
      >;
      listAwaitingApproval: FunctionReference<
        "query",
        "internal",
        { agentKey?: string; limit?: number; viewer?: string | null },
        Array<any>,
        Name
      >;
      listByCreator: FunctionReference<
        "query",
        "internal",
        { limit?: number; userId: string },
        Array<{
          _creationTime: number;
          _id: string;
          hasAudio: boolean;
          mergedInto?: string;
          number: number;
          screenshotCount: number;
          state:
            | "submitted"
            | "requested"
            | "planned"
            | "inProgress"
            | "rejected"
            | "completed";
          title: string;
        }>,
        Name
      >;
      listByState: FunctionReference<
        "query",
        "internal",
        {
          agentKey?: string;
          cursor?: string | null;
          limit?: number;
          state:
            | "submitted"
            | "requested"
            | "planned"
            | "inProgress"
            | "rejected"
            | "completed";
          viewer?: string | null;
        },
        { nextCursor: string | null; page: Array<any> },
        Name
      >;
      listForTriage: FunctionReference<
        "query",
        "internal",
        { agentKey?: string; limit?: number; viewer?: string | null },
        Array<any>,
        Name
      >;
      listPublic: FunctionReference<
        "query",
        "internal",
        { cursor?: string | null; includeCommunity?: boolean; limit?: number },
        { nextCursor: string | null; page: Array<any> },
        Name
      >;
      listRefinementOpen: FunctionReference<
        "query",
        "internal",
        { agentKey?: string; limit?: number; viewer?: string | null },
        any,
        Name
      >;
      listShippedSince: FunctionReference<
        "query",
        "internal",
        { limit?: number; since: number },
        Array<{ _id: string; changelog: string; completedAt: number }>,
        Name
      >;
      merge: FunctionReference<
        "mutation",
        "internal",
        { sourceId: string; targetId: string },
        null,
        Name
      >;
      remove: FunctionReference<
        "mutation",
        "internal",
        { itemId: string },
        null,
        Name
      >;
      review: FunctionReference<
        "mutation",
        "internal",
        { approve: boolean; itemId: string; reviewerId: string },
        | "submitted"
        | "requested"
        | "planned"
        | "inProgress"
        | "rejected"
        | "completed",
        Name
      >;
      setChangelog: FunctionReference<
        "mutation",
        "internal",
        { itemId: string; text: string },
        null,
        Name
      >;
      transitionState: FunctionReference<
        "mutation",
        "internal",
        {
          itemId: string;
          state:
            | "submitted"
            | "requested"
            | "planned"
            | "inProgress"
            | "rejected"
            | "completed";
        },
        null,
        Name
      >;
    };
    notifications: {
      listForUser: FunctionReference<
        "query",
        "internal",
        { limit?: number; unreadOnly?: boolean; userId: string },
        any,
        Name
      >;
      markAllRead: FunctionReference<
        "mutation",
        "internal",
        { userId: string },
        number,
        Name
      >;
      markRead: FunctionReference<
        "mutation",
        "internal",
        { id: string; userId: string },
        null,
        Name
      >;
      unreadCount: FunctionReference<
        "query",
        "internal",
        { userId: string },
        number,
        Name
      >;
    };
    progress: {
      listRecent: FunctionReference<
        "query",
        "internal",
        { limit?: number },
        any,
        Name
      >;
      post: FunctionReference<
        "mutation",
        "internal",
        { kind: "step" | "shipped" | "note"; message: string },
        string,
        Name
      >;
    };
    settings: {
      get: FunctionReference<
        "query",
        "internal",
        {},
        { communityBoardVisible: boolean; runMode: "local" | "cloud" },
        Name
      >;
      set: FunctionReference<
        "mutation",
        "internal",
        { communityBoardVisible?: boolean; runMode?: "local" | "cloud" },
        null,
        Name
      >;
    };
    todos: {
      advance: FunctionReference<"mutation", "internal", {}, null, Name>;
      listAll: FunctionReference<"query", "internal", {}, any, Name>;
      plan: FunctionReference<
        "mutation",
        "internal",
        { items: Array<string> },
        null,
        Name
      >;
      setStatus: FunctionReference<
        "mutation",
        "internal",
        { id: string; status: "pending" | "active" | "done" },
        null,
        Name
      >;
    };
    users: {
      ensure: FunctionReference<
        "mutation",
        "internal",
        { userId: string },
        { role: "admin" | "member"; userId: string },
        Name
      >;
      get: FunctionReference<
        "query",
        "internal",
        { userId: string },
        { createdAt: number; role: "admin" | "member"; userId: string } | null,
        Name
      >;
      hasAppAdmin: FunctionReference<"query", "internal", {}, boolean, Name>;
      hasAppUsers: FunctionReference<"query", "internal", {}, boolean, Name>;
      listAdmins: FunctionReference<
        "query",
        "internal",
        {},
        Array<string>,
        Name
      >;
      setRole: FunctionReference<
        "mutation",
        "internal",
        { role: "admin" | "member"; userId: string },
        null,
        Name
      >;
    };
  };
