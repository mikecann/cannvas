// A failed build's work, so "Try again" continues from it instead of
// starting over (docs/chef-pipeline.md, "Try again").
//
// When a run fails in verification (a check, a guard it could fix, the
// frontend build) the runner posts its checkout's diff against the base
// (POST /chef-agent/attempt): at most MAX_ATTEMPT_BYTES, refused if the
// secret scan finds anything in it, stored once per run, never logged. When
// an admin presses "Try again" and the request is unchanged, the next build
// of it gets `continueFrom` and its runner fetches that diff
// (GET /chef-agent/attempt) and applies it before its agent starts: on the
// same base as is, or, when main moved meanwhile, three-way onto the new
// base; a diff that doesn't apply cleanly is dropped and the agent starts
// fresh. Everything in it is verified again, like any agent work.
import { v } from "convex/values";
import { mutation } from "./_generated/server.js";
import { auditOk, authorize, refuseAuthorized, type RunPhase } from "./chefAgent.js";
import { sha256Hex } from "./chefShared.js";
import { findSecrets } from "../chef/scrub.js";

export const MAX_ATTEMPT_BYTES = 512 * 1024;
const HEX = /^[0-9a-f]{40,64}$/;
// chefAgent's vRefusal, here: chefRuns imports chefAgent, which imports chefRuns.
const vRefusal = v.object({ ok: v.literal(false), status: v.number(), error: v.string() });

const STORE_PHASES: RunPhase[] = ["agent", "gates", "guards"];
const FETCH_PHASES: RunPhase[] = ["cloning", "cloned", "agent"];

export const store = mutation({
  args: { token: v.string(), baseTree: v.string(), diff: v.string() },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "attempt", scope: "run.report", phases: STORE_PHASES });
    if (!a.ok) return a;
    const refuse = (status: number, error: string) => refuseAuthorized(ctx, a, "attempt", status, error);
    if (!HEX.test(args.baseTree)) return await refuse(400, "baseTree must be a hex sha");
    if (args.diff.length === 0) return await refuse(400, "Empty diff");
    if (args.diff.length > MAX_ATTEMPT_BYTES) return await refuse(413, `Diff over ${MAX_ATTEMPT_BYTES} characters`);
    // Never stored with a secret in it: it would be applied in another sandbox.
    if (findSecrets(args.diff).length > 0) return await refuse(400, "The diff holds something that looks like a secret");
    const existing = await ctx.db
      .query("chefAttempts")
      .withIndex("by_runId", (q) => q.eq("runId", a.run._id))
      .first();
    const sha256 = await sha256Hex(args.diff);
    if (existing) {
      if (existing.sha256 === sha256) return { ok: true as const, stored: false };
      return await refuse(409, "A different attempt was already stored for this run");
    }
    await ctx.db.insert("chefAttempts", { runId: a.run._id, baseTree: args.baseTree, sha256, text: args.diff, createdAt: Date.now() });
    await auditOk(ctx, a, "attempt", { sha256, bytes: args.diff.length });
    return { ok: true as const, stored: true };
  },
});

/** The earlier run's work for a run that continues from it, with why that run failed. */
export const fetch = mutation({
  args: { token: v.string() },
  returns: v.union(
    vRefusal,
    v.object({
      ok: v.literal(true),
      baseTree: v.string(),
      diff: v.string(),
      sha256: v.string(),
      reason: v.string(),
      // What the earlier agent said it did (its summary, scrubbed when stored): untrusted text.
      summary: v.string(),
    }),
  ),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "attempt", scope: "run.read", phases: FETCH_PHASES });
    if (!a.ok) return a;
    const from = a.run.continueFrom;
    if (!from) return await refuseAuthorized(ctx, a, "attempt", 404, "This run continues from nothing");
    const row = await ctx.db
      .query("chefAttempts")
      .withIndex("by_runId", (q) => q.eq("runId", from))
      .first();
    const earlier = await ctx.db.get("chefRuns", from);
    if (!row || !earlier || earlier.itemId !== a.run.itemId) {
      return await refuseAuthorized(ctx, a, "attempt", 404, "The earlier attempt is gone");
    }
    await auditOk(ctx, a, "attempt", { from: String(from), sha256: row.sha256 });
    return {
      ok: true as const,
      baseTree: row.baseTree,
      diff: row.text,
      sha256: row.sha256,
      reason: earlier.failure ? `${earlier.failure.reason}` : (earlier.error ?? "").slice(0, 300),
      summary: (earlier.summary ?? "").slice(0, 4000),
    };
  },
});
