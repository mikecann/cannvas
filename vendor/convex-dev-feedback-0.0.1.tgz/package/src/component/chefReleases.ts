// The release state machine (docs/chef-pipeline.md, "Release: one state
// machine around one sha"). `chef-release` on Seth's machine drives it with
// his Convex CLI login, through the host's internal functions
// (src/client/chefRelease.ts); the panel shows the diff and approves it.
//
//   pinned -> diffReady -> approved -> merged -> sourcePushed -> gatesPassed
//   -> backendDeployed -> frontendPublished -> verified -> live -> done
//
// A rollback release runs pinned -> backendDeployed -> ... -> done on an
// earlier release's mergeSha and artifact. Every transition goes to the next
// state of its kind and nowhere else, records a checkpoint and an audit row,
// and repeating a completed step with the same facts is a no-op, so an
// interrupted release resumes from its last checkpoint.
//
// Who can do what:
// - the operator functions (prepare, uploadDiffChunk, step, recordTarget,
//   abandon, rollback, status, builtRuns, itemRuns, recordDrop) are for the
//   host's internal functions only, which `npx convex run` reaches with the
//   operator's CLI login. They take the operator's name for the audit log.
// - approve is the panel's: an admin user, the exact diff hash shown.
// - the reads for the panel (list, get, diffChunk) are admin-only.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { chefReleaseFields } from "./schema.js";
import { isAdminUser, requireAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { derivedChangelog, notifySupporters } from "./items.js";
import { userChangelog } from "../chef/changelog.js";
import { sha256Hex } from "./chefShared.js";
import { dropBuildOutputs, dropReleaseDiff, runItemIds } from "./chefRuns.js";
import { scrubWithReport } from "../chef/scrub.js";
import {
  DIFF_CHUNK_BYTES,
  DIFF_MAX_CHUNKS,
  GIT_SHA,
  SHA256_HEX,
  diffHashFromChunkHashes,
  filesInDiff,
  frontendTargetsFor,
  isDependencyFile,
  nextReleaseState,
  releaseBranch,
  releaseReached,
  type ReleaseState,
} from "../chef/release.js";

export const vRelease = v.object({
  _id: v.id("chefReleases"),
  _creationTime: v.number(),
  ...chefReleaseFields,
});

const MAX_FILES = 500;
const MAX_RUNS = 50;
const encoder = new TextEncoder();

const vStepTo = v.union(
  v.literal("merged"),
  v.literal("sourcePushed"),
  v.literal("gatesPassed"),
  v.literal("backendDeployed"),
  v.literal("frontendPublished"),
  v.literal("verified"),
  v.literal("live"),
  v.literal("done"),
);
const vTarget = v.union(v.literal("convexApp"), v.literal("staticHosting"));

export function operatorActor(operator: string): string {
  const name = operator.trim();
  if (!name || name.length > 100 || /\s/.test(name) || [...name].some((ch) => ch.charCodeAt(0) < 0x20)) {
    throw new Error("operator must be a short name without spaces");
  }
  return `operator:${name}`;
}

const short = (s: string | undefined) => (s ? s.slice(0, 12) : "none");

export async function openRelease(ctx: QueryCtx): Promise<Doc<"chefReleases"> | null> {
  return await ctx.db
    .query("chefReleases")
    .withIndex("by_open", (q) => q.eq("open", true))
    .first();
}

async function releaseBySeq(ctx: QueryCtx, seq: number): Promise<Doc<"chefReleases"> | null> {
  return await ctx.db
    .query("chefReleases")
    .withIndex("by_seq", (q) => q.eq("seq", seq))
    .unique();
}

export async function mustGet(ctx: QueryCtx, id: Id<"chefReleases">): Promise<Doc<"chefReleases">> {
  const r = await ctx.db.get("chefReleases", id);
  if (!r) throw new Error("Release not found");
  return r;
}

function isEnded(state: Doc<"chefReleases">["state"]): boolean {
  return state === "done" || state === "abandoned" || state === "rolledBack";
}

/**
 * Move a release to the next state of its kind and record the checkpoint.
 * The only place a release's state advances.
 */
export async function advance(
  ctx: MutationCtx,
  r: Doc<"chefReleases">,
  to: ReleaseState,
  actor: string,
  patch: Partial<Doc<"chefReleases">>,
  detail: Record<string, string | number | boolean | null> = {},
): Promise<void> {
  if (isEnded(r.state)) throw new Error(`Release #${r.seq} is ${r.state}`);
  const expected = nextReleaseState(r.kind, r.state as ReleaseState);
  if (to !== expected) {
    throw new Error(
      `Release #${r.seq} is ${r.state}; the next step is ${expected ?? "none"}, not ${to}`,
    );
  }
  const now = Date.now();
  await ctx.db.patch("chefReleases", r._id, {
    ...patch,
    state: to,
    inFlight: undefined,
    updatedAt: now,
    checkpoints: [...r.checkpoints, { state: to, at: now, actor }],
    ...(to === "done" ? { open: false, finishedAt: now } : {}),
  });
  await writeAudit(ctx, {
    actor,
    action: `release.${to}`,
    target: `release:${r.seq}`,
    outcome: "ok",
    detail: { seq: r.seq, kind: r.kind, from: r.state, ...detail },
  });
}

// ------------------------------------------------------------ operator

/**
 * Pin a release: `sha` is the `chef` tip, `baseSha` Code Storage `main`, and
 * `runIds` the built runs whose commits it covers. While a release is open
 * nothing else can be pinned; preparing the same pin again returns it.
 */
export const prepare = mutation({
  args: {
    operator: v.string(),
    sha: v.string(),
    baseSha: v.string(),
    runIds: v.array(v.id("chefRuns")),
    cliVersion: v.optional(v.string()),
  },
  returns: v.object({
    releaseId: v.id("chefReleases"),
    seq: v.number(),
    state: v.string(),
    resumed: v.boolean(),
  }),
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    if (!GIT_SHA.test(args.sha) || !GIT_SHA.test(args.baseSha)) {
      throw new Error("sha and baseSha must be full git commit ids");
    }
    if (args.sha === args.baseSha) throw new Error("Nothing to release: chef is main");
    if (args.runIds.length > MAX_RUNS) throw new Error(`At most ${MAX_RUNS} runs per release`);
    const open = await openRelease(ctx);
    if (open) {
      if (open.kind === "chef" && open.sha === args.sha && open.baseSha === args.baseSha) {
        return { releaseId: open._id, seq: open.seq, state: open.state, resumed: true };
      }
      throw new Error(
        `Release #${open.seq} is open (${open.state}); ship it, roll it back or abandon it first`,
      );
    }
    const runIds = [...new Set(args.runIds)];
    for (const id of runIds) {
      const run = await ctx.db.get("chefRuns", id);
      if (!run || run.status !== "built") throw new Error(`Run ${id} is not a built run`);
    }
    const last = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").first();
    const seq = (last?.seq ?? 0) + 1;
    const now = Date.now();
    const releaseId = await ctx.db.insert("chefReleases", {
      seq,
      kind: "chef",
      state: "pinned",
      open: true,
      sha: args.sha,
      baseSha: args.baseSha,
      runIds,
      targets: {},
      checkpoints: [{ state: "pinned", at: now, actor }],
      ...(args.cliVersion !== undefined ? { cliVersion: args.cliVersion.slice(0, 50) } : {}),
      preparedBy: actor,
      createdAt: now,
      updatedAt: now,
    });
    await writeAudit(ctx, {
      actor,
      action: "release.pinned",
      target: `release:${seq}`,
      outcome: "ok",
      detail: { seq, kind: "chef", sha: args.sha, baseSha: args.baseSha, runs: runIds.length },
    });
    return { releaseId, seq, state: "pinned", resumed: false };
  },
});

/**
 * One chunk of `git diff` for a pinned release, as `chunkDiff` cut it. The
 * first chunk fixes `diffHash`; a different hash after that is a changed diff
 * and is refused. Each chunk is checked against its own sha256 before it is
 * scrubbed and stored; when the last arrives, the chunk hashes must add up to
 * `diffHash`, and the release is diffReady.
 */
export const uploadDiffChunk = mutation({
  args: {
    operator: v.string(),
    releaseId: v.id("chefReleases"),
    diffHash: v.string(),
    index: v.number(),
    count: v.number(),
    text: v.string(),
  },
  returns: v.object({ state: v.string(), received: v.number() }),
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const r = await mustGet(ctx, args.releaseId);
    if (r.kind !== "chef") throw new Error("Only a chef release has a diff");
    if (!SHA256_HEX.test(args.diffHash)) throw new Error("diffHash must be hex sha256");
    if (!Number.isInteger(args.count) || args.count < 1 || args.count > DIFF_MAX_CHUNKS) {
      throw new Error(`A diff has 1 to ${DIFF_MAX_CHUNKS} chunks`);
    }
    if (!Number.isInteger(args.index) || args.index < 0 || args.index >= args.count) {
      throw new Error("Chunk index out of range");
    }
    const bytes = encoder.encode(args.text).length;
    if (bytes === 0 || bytes > DIFF_CHUNK_BYTES) throw new Error("Chunk is empty or too large");
    if (r.diffHash !== undefined && (r.diffHash !== args.diffHash || r.diffChunkCount !== args.count)) {
      throw new Error(
        `The diff changed: release #${r.seq} has diff ${short(r.diffHash)}, not ${short(args.diffHash)}. Abandon it and prepare again.`,
      );
    }
    if (r.state !== "pinned") {
      // The whole diff is in already; a resumed upload of the same diff is a no-op.
      return { state: r.state, received: r.diffChunkCount ?? 0 };
    }
    if (r.diffHash === undefined) {
      await ctx.db.patch("chefReleases", r._id, {
        diffHash: args.diffHash,
        diffChunkCount: args.count,
        updatedAt: Date.now(),
      });
    }
    const sha256 = await sha256Hex(args.text);
    const existing = await ctx.db
      .query("chefReleaseDiffChunks")
      .withIndex("by_releaseId_and_index", (q) => q.eq("releaseId", r._id).eq("index", args.index))
      .unique();
    if (existing && existing.sha256 !== sha256) {
      throw new Error(`The diff changed: chunk ${args.index} doesn't match the one already uploaded`);
    }
    if (!existing) {
      const { text, counts } = scrubWithReport(args.text);
      const redactions = Object.values(counts).reduce((a, b) => a + (b ?? 0), 0);
      await ctx.db.insert("chefReleaseDiffChunks", {
        releaseId: r._id,
        index: args.index,
        sha256,
        bytes,
        text,
        redactions,
      });
    }
    const chunks = await ctx.db
      .query("chefReleaseDiffChunks")
      .withIndex("by_releaseId_and_index", (q) => q.eq("releaseId", r._id))
      .take(DIFF_MAX_CHUNKS + 1);
    if (chunks.length < args.count) return { state: "pinned", received: chunks.length };

    const computed = await diffHashFromChunkHashes(chunks.map((c) => c.sha256));
    if (computed !== args.diffHash) {
      throw new Error("The chunks don't add up to the diff hash; abandon the release and prepare again");
    }
    const files = [...new Set(chunks.flatMap((c) => filesInDiff(c.text)))];
    const fresh = await mustGet(ctx, r._id);
    await advance(
      ctx,
      fresh,
      "diffReady",
      actor,
      {
        diffBytes: chunks.reduce((a, c) => a + c.bytes, 0),
        filesChanged: files.slice(0, MAX_FILES),
        filesTruncated: files.length > MAX_FILES,
        depsChanged: files.some(isDependencyFile),
        redactions: chunks.reduce((a, c) => a + c.redactions, 0),
      },
      { diffHash: args.diffHash, files: files.length, chunks: chunks.length },
    );
    return { state: "diffReady", received: chunks.length };
  },
});

/**
 * A checkpoint. `begin` records the step about to run (the checkpoint
 * before); `complete` records its facts and moves the release to `to`, which
 * must be the next state of its kind. Completing a step the release already
 * completed, with the same facts, is a no-op.
 */
export const step = mutation({
  args: {
    operator: v.string(),
    releaseId: v.id("chefReleases"),
    phase: v.union(v.literal("begin"), v.literal("complete")),
    to: vStepTo,
    mergeSha: v.optional(v.string()),
    diffHash: v.optional(v.string()),
    releaseBranch: v.optional(v.string()),
    artifactDigest: v.optional(v.string()),
    gates: v.optional(v.array(v.string())),
    pushId: v.optional(v.string()),
    checks: v.optional(v.array(v.object({ name: v.string(), ok: v.boolean() }))),
    mainSha: v.optional(v.string()),
  },
  returns: vRelease,
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const r = await mustGet(ctx, args.releaseId);

    if (r.state === args.to) {
      // A repeat of the step that just completed (a lost response).
      const same =
        (args.mergeSha === undefined || args.to !== "merged" || args.mergeSha === r.mergeSha) &&
        (args.artifactDigest === undefined || args.artifactDigest === r.artifactDigest) &&
        (args.mainSha === undefined || args.mainSha === r.mainSha);
      if (!same) throw new Error(`Release #${r.seq} already completed ${args.to} with other facts`);
      return r;
    }
    if (!r.open) throw new Error(`Release #${r.seq} is ${r.state}`);
    const expected = nextReleaseState(r.kind, r.state as ReleaseState);
    if (args.to !== expected) {
      throw new Error(
        `Release #${r.seq} is ${r.state}; the next step is ${expected ?? "none"}, not ${args.to}`,
      );
    }

    if (args.phase === "begin") {
      await ctx.db.patch("chefReleases", r._id, {
        inFlight: { to: args.to, at: Date.now(), actor },
        updatedAt: Date.now(),
      });
      await writeAudit(ctx, {
        actor,
        action: `release.${args.to}.begin`,
        target: `release:${r.seq}`,
        outcome: "ok",
        detail: { seq: r.seq, from: r.state },
      });
      return (await ctx.db.get("chefReleases", r._id))!;
    }

    switch (args.to) {
      case "merged": {
        if (!args.mergeSha || !GIT_SHA.test(args.mergeSha)) throw new Error("mergeSha is required");
        if (!r.approvedDiffHash || args.diffHash !== r.approvedDiffHash) {
          throw new Error(
            `The merge's diff ${short(args.diffHash)} isn't the approved diff ${short(r.approvedDiffHash)}`,
          );
        }
        await advance(ctx, r, "merged", actor, { mergeSha: args.mergeSha }, { mergeSha: args.mergeSha });
        break;
      }
      case "sourcePushed": {
        const branch = releaseBranch(r.seq);
        if (args.releaseBranch !== branch) throw new Error(`The release branch is ${branch}`);
        await advance(ctx, r, "sourcePushed", actor, { releaseBranch: branch }, { branch });
        break;
      }
      case "gatesPassed": {
        if (!args.artifactDigest || !SHA256_HEX.test(args.artifactDigest)) {
          throw new Error("artifactDigest must be hex sha256");
        }
        const gates = (args.gates ?? []).slice(0, 20).map((g) => g.slice(0, 200));
        await advance(
          ctx,
          r,
          "gatesPassed",
          actor,
          { artifactDigest: args.artifactDigest, gates },
          { artifactDigest: args.artifactDigest },
        );
        break;
      }
      case "backendDeployed": {
        if (!r.mergeSha || args.mergeSha !== r.mergeSha) {
          throw new Error(`The backend deploy must be of ${short(r.mergeSha)}`);
        }
        const pushId = args.pushId?.slice(0, 200);
        await advance(
          ctx,
          r,
          "backendDeployed",
          actor,
          { backend: { mergeSha: r.mergeSha, at: Date.now(), actor, ...(pushId ? { pushId } : {}) } },
          { mergeSha: r.mergeSha, pushId: pushId ?? null },
        );
        break;
      }
      case "frontendPublished": {
        for (const t of frontendTargetsFor(r.kind, r.artifactDigest, r.shipRunId !== undefined)) {
          const rec = r.targets[t];
          if (!rec || rec.digest !== r.artifactDigest) {
            throw new Error(`Frontend target ${t} hasn't been published with the release's artifact`);
          }
        }
        await advance(ctx, r, "frontendPublished", actor, {}, { artifactDigest: r.artifactDigest ?? null });
        break;
      }
      case "verified": {
        const checks = (args.checks ?? []).slice(0, 50).map((c) => ({ name: c.name.slice(0, 100), ok: c.ok }));
        if (checks.length === 0) throw new Error("Verification needs at least one check");
        const failed = checks.filter((c) => !c.ok).map((c) => c.name);
        if (failed.length) throw new Error(`Verification failed: ${failed.join(", ")}`);
        await advance(ctx, r, "verified", actor, { checks }, { checks: checks.length });
        break;
      }
      case "live": {
        if (!args.mainSha || !GIT_SHA.test(args.mainSha)) throw new Error("mainSha is required");
        // A chef release fast-forwards main to its merge. A rollback moves
        // main forward too, with a commit whose tree is the restored release's.
        if (r.kind !== "rollback" && args.mainSha !== r.mergeSha) {
          throw new Error("main must be the release's mergeSha");
        }
        await advance(ctx, r, "live", actor, { mainSha: args.mainSha }, { mainSha: args.mainSha });
        break;
      }
      case "done": {
        const shipped = r.kind !== "rollback" ? await completeItems(ctx, r) : 0;
        await advance(ctx, r, "done", actor, {}, { itemsCompleted: shipped });
        // A ship supersedes the run's kept diff. Its frontend stays: it is
        // what Chef rolls back to if the next ship fails its checks; the
        // frontend the earlier live release kept goes now.
        if (r.shipRunId) {
          const run = await ctx.db.get("chefRuns", r.shipRunId);
          if (run) await dropReleaseDiff(ctx, run);
          const earlier = await ctx.db
            .query("chefReleases")
            .withIndex("by_seq", (q) => q.lt("seq", r.seq))
            .order("desc")
            .take(20);
          for (const e of earlier) {
            if (e.state !== "done" || !e.shipRunId || e.shipRunId === r.shipRunId) continue;
            const old = await ctx.db.get("chefRuns", e.shipRunId);
            if (old?.frontendArtifact) await dropBuildOutputs(ctx, old);
          }
        }
        break;
      }
    }
    return (await ctx.db.get("chefReleases", r._id))!;
  },
});

/** The items a release covers are shipped: completed, requesters notified. */
export async function completeItems(ctx: MutationCtx, r: Doc<"chefReleases">): Promise<number> {
  let n = 0;
  const now = Date.now();
  // A batch run ships every request it built (chefBatches.ts).
  const itemIds: Id<"items">[] = [];
  // Requests whose own build stopped after pushing to chef, carried by a
  // later build (chefShip.alsoShipsRuns): they shipped too, and say how.
  const carried = new Map<string, number>();
  const built = new Set<string>();
  // An admin's fix or removal (chefSnapshots.adminFollowUp): the newest
  // built run of a request says which, if it is one.
  const asked = new Map<string, { seq: number; kind: "fix" | "remove" | undefined }>();
  for (const runId of r.runIds) {
    const run = await ctx.db.get("chefRuns", runId);
    if (!run) continue;
    for (const id of runItemIds(run)) {
      if (!itemIds.includes(id)) itemIds.push(id);
      if (run.status === "failed" || run.status === "cancelled") {
        if (!built.has(String(id))) carried.set(String(id), run.seq);
      } else {
        built.add(String(id));
        carried.delete(String(id));
        if ((asked.get(String(id))?.seq ?? -1) < run.seq) asked.set(String(id), { seq: run.seq, kind: run.followUp?.kind });
      }
    }
  }
  for (const itemId of itemIds) {
    const item = await ctx.db.get("items", itemId);
    if (!item || item.state === "completed") continue;
    const kind = asked.get(String(item._id))?.kind;
    // Shipped before: "What's new" listed it then.
    const shippedBefore = item.completedAt !== undefined;
    if (kind === "remove") {
      // Its change is out of the app: gone, not shipped. One that had
      // shipped gets a "What's new" line saying so (its removal's summary).
      const changelog = shippedBefore ? ((await derivedChangelog(ctx, item)) ?? `"${item.title}" was taken out of the app.`) : item.changelog;
      await ctx.db.patch("items", item._id, { state: "rejected", removedAt: now, cloudQueuedAt: undefined, changelog });
      if (shippedBefore) await notifySupporters(ctx, item._id, "stateChanged", `"${item.title}" was taken out of the app.`);
      await ctx.db.insert("devLogs", { itemId: item._id, authorId: "chef", message: `Removed in release #${r.seq}.`, stamp: now });
      continue;
    }
    // "What's new": the line users read. None written (Chef's builds rarely
    // get one by hand): from its build's summary, never a hash or a note.
    // A fix of a request that had shipped: what the fix changed.
    const changelog =
      kind === "fix" && shippedBefore
        ? ((await derivedChangelog(ctx, item)) ?? userChangelog(item.changelog))
        : (userChangelog(item.changelog) ?? (await derivedChangelog(ctx, item)));
    await ctx.db.patch("items", item._id, { state: "completed", completedAt: now, cloudQueuedAt: undefined, changelog });
    const message = `"${item.title}" has shipped!`;
    await notifySupporters(ctx, item._id, "completed", message);
    const bid = await ctx.db
      .query("bids")
      .withIndex("by_item_and_user", (q) => q.eq("itemId", item._id).eq("userId", item.createdBy))
      .first();
    if (!bid) {
      await ctx.db.insert("notifications", {
        userId: item.createdBy,
        itemId: item._id,
        type: "completed",
        message,
        isRead: false,
        stamp: now,
      });
    }
    await ctx.db.insert("devLogs", {
      itemId: item._id,
      authorId: "chef",
      message: carried.has(String(item._id))
        ? `Shipped with release #${r.seq}: its build (#${carried.get(String(item._id))}) stopped after pushing its change, and a later build carried it.`
        : kind === "fix"
          ? `Fix shipped in release #${r.seq}.`
          : `Shipped in release #${r.seq}.`,
      stamp: now,
    });
    n++;
  }
  return n;
}

/**
 * One frontend target published. The digest must be the release's artifact
 * digest, so both targets get the same build.
 */
export const recordTarget = mutation({
  args: {
    operator: v.string(),
    releaseId: v.id("chefReleases"),
    target: vTarget,
    digest: v.string(),
    detail: v.optional(v.string()),
  },
  returns: vRelease,
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const r = await mustGet(ctx, args.releaseId);
    if (!frontendTargetsFor(r.kind, r.artifactDigest, r.shipRunId !== undefined).includes(args.target)) {
      throw new Error(`Release #${r.seq} doesn't publish to ${args.target}`);
    }
    if (!r.artifactDigest || args.digest !== r.artifactDigest) {
      throw new Error(`Target ${args.target} got artifact ${short(args.digest)}, not the release's ${short(r.artifactDigest)}`);
    }
    const existing = r.targets[args.target];
    if (existing && existing.digest === args.digest) return r;
    if (r.state !== "backendDeployed") {
      throw new Error(`Release #${r.seq} is ${r.state}; frontends are published after the backend deploy`);
    }
    const rec = {
      digest: args.digest,
      at: Date.now(),
      actor,
      ...(args.detail !== undefined ? { detail: args.detail.slice(0, 200) } : {}),
    };
    await ctx.db.patch("chefReleases", r._id, {
      targets: { ...r.targets, [args.target]: rec },
      updatedAt: Date.now(),
    });
    await writeAudit(ctx, {
      actor,
      action: "release.frontendTarget",
      target: `release:${r.seq}`,
      outcome: "ok",
      detail: { seq: r.seq, target: args.target, digest: args.digest },
    });
    return (await ctx.db.get("chefReleases", r._id))!;
  },
});

/**
 * Give up on a release before anything reached production. After the
 * backend deploy the way out is a rollback.
 */
export const abandon = mutation({
  args: { operator: v.string(), releaseId: v.id("chefReleases"), reason: v.string() },
  returns: vRelease,
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const r = await mustGet(ctx, args.releaseId);
    if (r.state === "abandoned") return r;
    if (!r.open) throw new Error(`Release #${r.seq} is ${r.state}`);
    if (releaseReached(r.kind, r.state as ReleaseState, "backendDeployed") || r.deployedSha) {
      throw new Error(`Release #${r.seq} reached production (${r.state}); roll it back instead`);
    }
    const now = Date.now();
    await ctx.db.patch("chefReleases", r._id, {
      state: "abandoned",
      open: false,
      inFlight: undefined,
      finishedAt: now,
      updatedAt: now,
      endReason: args.reason.slice(0, 500),
    });
    await writeAudit(ctx, {
      actor,
      action: "release.abandoned",
      target: `release:${r.seq}`,
      outcome: "ok",
      reason: args.reason.slice(0, 500),
      detail: { seq: r.seq, from: r.state },
    });
    return (await ctx.db.get("chefReleases", r._id))!;
  },
});

/**
 * Roll release `seq` back: a new rollback release that redeploys the latest
 * earlier release that finished (and wasn't itself rolled back), with that
 * release's mergeSha and artifact. An open release being rolled back ends as
 * rolledBack. Asking again while that rollback is open returns it.
 */
export const rollback = mutation({
  args: { operator: v.string(), seq: v.number(), mainSha: v.string(), reason: v.string() },
  returns: vRelease,
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    if (!GIT_SHA.test(args.mainSha)) throw new Error("mainSha must be a full git commit id");
    const bad = await releaseBySeq(ctx, args.seq);
    if (!bad) throw new Error(`No release #${args.seq}`);
    const open = await openRelease(ctx);
    if (open && open.kind === "rollback" && open.rollbackOf === bad.seq) return open;
    if (open && open._id !== bad._id) {
      throw new Error(`Release #${open.seq} is open (${open.state}); finish or abandon it first`);
    }
    if (bad.state === "abandoned" || bad.state === "rolledBack" || bad.rolledBackBy !== undefined) {
      throw new Error(`Release #${bad.seq} is ${bad.state}${bad.rolledBackBy ? ", already rolled back" : ""}`);
    }
    if (!releaseReached(bad.kind, bad.state as ReleaseState, "backendDeployed")) {
      throw new Error(`Release #${bad.seq} never reached production (${bad.state}); abandon it instead`);
    }
    const earlier = await ctx.db
      .query("chefReleases")
      .withIndex("by_seq", (q) => q.lt("seq", bad.seq))
      .order("desc")
      .take(50);
    const prev = earlier.find(
      (e) => e.state === "done" && e.rolledBackBy === undefined && e.mergeSha && e.artifactDigest,
    );
    if (!prev) throw new Error(`No earlier finished release to roll back to from #${bad.seq}`);

    const last = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").first();
    const seq = (last?.seq ?? 0) + 1;
    const now = Date.now();
    if (bad.open) {
      await ctx.db.patch("chefReleases", bad._id, {
        state: "rolledBack",
        open: false,
        inFlight: undefined,
        rolledBackBy: seq,
        finishedAt: now,
        updatedAt: now,
        endReason: args.reason.slice(0, 500),
      });
    } else {
      await ctx.db.patch("chefReleases", bad._id, { rolledBackBy: seq, updatedAt: now });
    }
    const id = await ctx.db.insert("chefReleases", {
      seq,
      kind: "rollback",
      state: "pinned",
      open: true,
      sha: prev.mergeSha!,
      baseSha: args.mainSha,
      runIds: [],
      rollbackOf: bad.seq,
      restores: prev.seq,
      mergeSha: prev.mergeSha,
      artifactDigest: prev.artifactDigest,
      ...(prev.releaseBranch ? { releaseBranch: prev.releaseBranch } : {}),
      targets: {},
      checkpoints: [{ state: "pinned", at: now, actor }],
      preparedBy: actor,
      createdAt: now,
      updatedAt: now,
      endReason: args.reason.slice(0, 500),
    });
    await writeAudit(ctx, {
      actor,
      action: "release.rollback",
      target: `release:${seq}`,
      outcome: "ok",
      reason: args.reason.slice(0, 500),
      detail: {
        seq,
        rollbackOf: bad.seq,
        restores: prev.seq,
        mergeSha: prev.mergeSha!,
        artifactDigest: prev.artifactDigest!,
      },
    });
    return (await ctx.db.get("chefReleases", id))!;
  },
});

/** A release by number, or the open one. For the operator's CLI. */
export const status = query({
  args: { seq: v.optional(v.number()) },
  returns: v.union(vRelease, v.null()),
  handler: async (ctx, args) =>
    args.seq !== undefined ? await releaseBySeq(ctx, args.seq) : await openRelease(ctx),
});

const vRunRef = v.object({
  runId: v.id("chefRuns"),
  seq: v.number(),
  itemId: v.id("items"),
  itemNumber: v.union(v.number(), v.null()),
  commitSha: v.union(v.string(), v.null()),
  chefBefore: v.union(v.string(), v.null()),
  chefAfter: v.union(v.string(), v.null()),
  finishedAt: v.union(v.number(), v.null()),
});

async function runRef(ctx: QueryCtx, run: Doc<"chefRuns">) {
  const item = await ctx.db.get("items", run.itemId);
  return {
    runId: run._id,
    seq: run.seq,
    itemId: run.itemId,
    itemNumber: item?.number ?? null,
    commitSha: run.commitSha ?? null,
    chefBefore: run.chefBefore ?? null,
    chefAfter: run.chefAfter ?? null,
    finishedAt: run.finishedAt ?? null,
  };
}

/** Recent built runs, newest first, so the CLI can tell which ones `chef` covers. */
export const builtRuns = query({
  args: { limit: v.optional(v.number()) },
  returns: v.array(vRunRef),
  handler: async (ctx, args) => {
    const limit = Math.min(100, Math.max(1, Math.floor(args.limit ?? 50) || 50));
    const runs = await ctx.db
      .query("chefRuns")
      .withIndex("by_status", (q) => q.eq("status", "built"))
      .order("desc")
      .take(limit);
    return await Promise.all(runs.map((r) => runRef(ctx, r)));
  },
});

/** An item and its built runs, for `chef-release drop`. */
export const itemRuns = query({
  args: { itemNumber: v.number() },
  returns: v.union(
    v.null(),
    v.object({
      itemId: v.id("items"),
      title: v.string(),
      state: v.string(),
      runs: v.array(vRunRef),
    }),
  ),
  handler: async (ctx, args) => {
    const item = await ctx.db
      .query("items")
      .withIndex("by_number", (q) => q.eq("number", args.itemNumber))
      .first();
    if (!item) return null;
    const runs = await ctx.db
      .query("chefRuns")
      .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
      .take(20);
    const built = runs.filter((r) => r.status === "built");
    return {
      itemId: item._id,
      title: item.title,
      state: item.state,
      runs: await Promise.all(built.map((r) => runRef(ctx, r))),
    };
  },
});

/**
 * `chef-release drop` reverted an item's commits on `chef` with a new commit:
 * record it, and put the item back in `requested` (not queued for the cloud;
 * an admin approves it again to rebuild).
 */
export const recordDrop = mutation({
  args: {
    operator: v.string(),
    itemNumber: v.number(),
    revertSha: v.union(v.string(), v.null()),
    reverted: v.array(v.string()),
    reason: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    if (args.revertSha !== null && !GIT_SHA.test(args.revertSha)) throw new Error("Bad revertSha");
    if (args.reverted.length > 20 || args.reverted.some((s) => !GIT_SHA.test(s))) {
      throw new Error("reverted must be up to 20 commit ids");
    }
    const item = await ctx.db
      .query("items")
      .withIndex("by_number", (q) => q.eq("number", args.itemNumber))
      .first();
    if (!item) throw new Error(`No request #${args.itemNumber}`);
    if (item.state === "completed") throw new Error(`Request #${args.itemNumber} already shipped`);
    const now = Date.now();
    if (item.state === "inProgress") {
      await ctx.db.patch("items", item._id, { state: "requested", cloudQueuedAt: undefined });
    }
    await ctx.db.insert("devLogs", {
      itemId: item._id,
      authorId: "chef",
      message: args.revertSha
        ? `Dropped from chef before release (revert ${args.revertSha.slice(0, 12)}).`
        : "Dropped from chef before release.",
      stamp: now,
    });
    await writeAudit(ctx, {
      actor,
      action: "release.drop",
      target: item._id,
      outcome: "ok",
      ...(args.reason ? { reason: args.reason.slice(0, 500) } : {}),
      detail: {
        itemNumber: args.itemNumber,
        revertSha: args.revertSha,
        reverted: args.reverted.map((s) => s.slice(0, 12)).join(","),
      },
    });
    return null;
  },
});

// --------------------------------------------------------------- panel

/**
 * Seth approves the diff he was shown, by its hash. A different hash, a
 * release that isn't waiting for approval, or a dependency change without the
 * second confirmation is refused, and the refusal is audited.
 */
export const approve = mutation({
  args: {
    adminUserId: v.string(),
    releaseId: v.id("chefReleases"),
    diffHash: v.string(),
    depsAcknowledged: v.optional(v.boolean()),
  },
  returns: v.object({ approved: v.boolean(), reason: v.optional(v.string()) }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const actor = userActor(args.adminUserId);
    const r = await mustGet(ctx, args.releaseId);
    if (r.state === "approved" && r.approvedDiffHash === args.diffHash) return { approved: true };
    let reason: string | null = null;
    if (r.state !== "diffReady") reason = `release #${r.seq} is ${r.state}, not waiting for approval`;
    else if (args.diffHash !== r.diffHash) reason = "the diff hash doesn't match the release's diff";
    else if (r.depsChanged && args.depsAcknowledged !== true) {
      reason = "this diff changes dependencies; confirm the dependency change as well";
    }
    if (reason) {
      await writeAudit(ctx, {
        actor,
        action: "release.approve",
        target: `release:${r.seq}`,
        outcome: "refused",
        reason,
        detail: { seq: r.seq, diffHash: args.diffHash.slice(0, 64) },
      });
      return { approved: false, reason };
    }
    await advance(
      ctx,
      r,
      "approved",
      actor,
      {
        approvedBy: args.adminUserId,
        approvedAt: Date.now(),
        approvedDiffHash: args.diffHash,
        depsAcknowledged: args.depsAcknowledged === true,
      },
      { diffHash: args.diffHash, depsChanged: r.depsChanged === true },
    );
    return { approved: true };
  },
});

/** Releases, newest first. Admins only; [] for everyone else. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), limit: v.optional(v.number()) },
  returns: v.array(vRelease),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(100, Math.max(1, Math.floor(args.limit ?? 20) || 20));
    return await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").take(limit);
  },
});

/** One release. Admins only; null for everyone else. */
export const get = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), releaseId: v.id("chefReleases") },
  returns: v.union(vRelease, v.null()),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    return await ctx.db.get("chefReleases", args.releaseId);
  },
});

/** One chunk of a release's scrubbed diff, for the panel. Admins only. */
export const diffChunk = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    releaseId: v.id("chefReleases"),
    index: v.number(),
  },
  returns: v.union(
    v.null(),
    v.object({
      index: v.number(),
      count: v.number(),
      text: v.string(),
      sha256: v.string(),
      redactions: v.number(),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const r = await ctx.db.get("chefReleases", args.releaseId);
    if (!r) return null;
    const c = await ctx.db
      .query("chefReleaseDiffChunks")
      .withIndex("by_releaseId_and_index", (q) => q.eq("releaseId", r._id).eq("index", args.index))
      .unique();
    if (!c) return null;
    return {
      index: c.index,
      count: r.diffChunkCount ?? 0,
      text: c.text,
      sha256: c.sha256,
      redactions: c.redactions,
    };
  },
});
