// Rejected attempts with credentials nobody holds, counted instead of
// audited one by one. Anyone on the internet can call the /chef-agent/*
// routes, so a per-request audit row for a random token would let them grow
// the database without bound. The HTTP action refuses missing and malformed
// credentials before any mutation (src/client/chefHttp.ts); a well-formed
// credential that matches nothing lands here: one row per route per minute,
// incremented, and capped, after which the route answers 429 for the rest
// of the minute without writing.
//
// A credential Chef did issue but that is revoked or expired is refused the
// same way every time, and whoever holds it (a former worker, anyone it
// leaked to) can keep presenting it. `auditRepeatedRefusal` writes the
// first such refusal to chefAudit in full and keeps it there; after that,
// one chefRefusals row per credential per action per minute, counted. Live
// credentials, signed-in people, successes and every other refusal are
// still audited per request in chefAudit, permanently.
//
// Both are storage bounding, not DoS protection: a refused request past the
// cap still runs an HTTP action, a mutation, a hash and a few indexed reads.
// Rate limiting at the edge, before Convex, is future work. Rows older than
// 30 days are pruned on write, with no cron: each new minute's row deletes
// up to PRUNE_ON_WRITE expired ones (a few indexed reads, at most once per
// route or credential per minute, so it keeps ahead of what expires). The
// cleanup after each run (chefCloud's chefCleanup) and `npx chef cleanup`
// call `prune` for the rest.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { MutationCtx } from "./_generated/server.js";
import { api } from "./_generated/api.js";
import { isAdminUser } from "./access.js";
import { writeAudit, type AuditEntry } from "./chefAudit.js";

export const REJECTED_BUCKET_MS = 60_000;
/** Unknown-credential attempts counted per route per minute; past it, 429. */
export const REJECTED_PER_MINUTE = 120;
export const REJECTED_RETENTION_MS = 30 * 24 * 60 * 60 * 1000;
const PRUNE_BATCH = 500;
/** Expired rows of each table a new minute's row deletes. */
export const PRUNE_ON_WRITE = 4;

/** Delete up to `limit` rows of each table older than 30 days. Returns how many went, and whether more are left. */
async function pruneExpired(ctx: MutationCtx, now: number, limit: number): Promise<{ deleted: number; more: boolean }> {
  const cutoff = now - REJECTED_RETENTION_MS;
  const rejected = await ctx.db
    .query("chefRejected")
    .withIndex("by_bucket", (q) => q.lt("bucket", cutoff))
    .take(limit);
  for (const r of rejected) await ctx.db.delete("chefRejected", r._id);
  const refusals = await ctx.db
    .query("chefRefusals")
    .withIndex("by_bucket", (q) => q.lt("bucket", cutoff))
    .take(limit);
  for (const r of refusals) await ctx.db.delete("chefRefusals", r._id);
  return { deleted: rejected.length + refusals.length, more: rejected.length === limit || refusals.length === limit };
}

/**
 * Count one rejected attempt on `route` (an audit action name like
 * "route.run" or "agentKey.enroll"). `limited` once this minute's count is at
 * the cap: the caller answers 429, and nothing more is written.
 */
export async function noteRejected(ctx: MutationCtx, route: string): Promise<{ limited: boolean }> {
  const now = Date.now();
  const bucket = now - (now % REJECTED_BUCKET_MS);
  const name = route.slice(0, 100);
  const row = await ctx.db
    .query("chefRejected")
    .withIndex("by_route_and_bucket", (q) => q.eq("route", name).eq("bucket", bucket))
    .unique();
  if (!row) {
    await ctx.db.insert("chefRejected", { route: name, bucket, count: 1 });
    await pruneExpired(ctx, now, PRUNE_ON_WRITE);
    return { limited: false };
  }
  if (row.count >= REJECTED_PER_MINUTE) return { limited: true };
  await ctx.db.patch("chefRejected", row._id, { count: row.count + 1 });
  return { limited: false };
}

/**
 * Audit a refusal of a known credential that will repeat (revoked, expired,
 * its run over). The first one for this credential and action in the last
 * 30 days goes to chefAudit in full, for good; the rest are counted in
 * chefRefusals, one row per minute (its first refusal's reason and run),
 * pruned after 30 days. `entry.actor` names the credential by its prefix.
 */
export async function auditRepeatedRefusal(ctx: MutationCtx, entry: AuditEntry): Promise<void> {
  const now = Date.now();
  const bucket = now - (now % REJECTED_BUCKET_MS);
  const actor = entry.actor.slice(0, 200);
  const action = entry.action.slice(0, 100);
  const row = await ctx.db
    .query("chefRefusals")
    .withIndex("by_actor_action_bucket", (q) => q.eq("actor", actor).eq("action", action).eq("bucket", bucket))
    .unique();
  if (row) {
    await ctx.db.patch("chefRefusals", row._id, { count: row.count + 1, lastAt: now });
    return;
  }
  const seen = await ctx.db
    .query("chefRefusals")
    .withIndex("by_actor_action_bucket", (q) => q.eq("actor", actor).eq("action", action))
    .first();
  await ctx.db.insert("chefRefusals", {
    actor,
    action,
    bucket,
    count: 1,
    lastAt: now,
    ...(entry.reason !== undefined ? { reason: entry.reason.slice(0, 500) } : {}),
    ...(entry.runId !== undefined ? { runId: entry.runId } : {}),
  });
  await pruneExpired(ctx, now, PRUNE_ON_WRITE);
  if (!seen) {
    await writeAudit(ctx, {
      ...entry,
      detail: { ...(entry.detail ?? {}), repeats: "counted per minute in chefRefusals" },
    });
  }
}

/** Repeated refusals of known credentials, newest minute first. Admins only; [] for everyone else. */
export const listRefusals = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), limit: v.optional(v.number()) },
  returns: v.array(
    v.object({
      actor: v.string(),
      action: v.string(),
      bucket: v.number(),
      count: v.number(),
      lastAt: v.number(),
      reason: v.optional(v.string()),
      runId: v.optional(v.id("chefRuns")),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(500, Math.max(1, Math.floor(args.limit ?? 100) || 100));
    const rows = await ctx.db.query("chefRefusals").withIndex("by_bucket").order("desc").take(limit);
    return rows.map(({ actor, action, bucket, count, lastAt, reason, runId }) => ({
      actor,
      action,
      bucket,
      count,
      lastAt,
      ...(reason !== undefined ? { reason } : {}),
      ...(runId !== undefined ? { runId } : {}),
    }));
  },
});

/** Newest buckets first. Admins only; [] for everyone else. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), limit: v.optional(v.number()) },
  returns: v.array(v.object({ route: v.string(), bucket: v.number(), count: v.number() })),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const limit = Math.min(500, Math.max(1, Math.floor(args.limit ?? 100) || 100));
    const rows = await ctx.db.query("chefRejected").withIndex("by_bucket").order("desc").take(limit);
    return rows.map((r) => ({ route: r.route, bucket: r.bucket, count: r.count }));
  },
});

/**
 * Delete up to 500 chefRejected and 500 chefRefusals rows older than 30
 * days, and schedule itself again while there's more. Returns how many went.
 */
export const prune = mutation({
  args: {},
  returns: v.number(),
  handler: async (ctx): Promise<number> => {
    const { deleted, more } = await pruneExpired(ctx, Date.now(), PRUNE_BATCH);
    if (more) await ctx.scheduler.runAfter(0, api.chefRejected.prune, {});
    return deleted;
  },
});
