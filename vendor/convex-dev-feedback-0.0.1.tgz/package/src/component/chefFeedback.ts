// What the agent leaves besides its diff, reported by the runner after the
// agent is dead (docs/chef-pipeline.md, "Skill feedback" and "Spend
// approval requests"): POST /chef-agent/feedback carries the run's
// skill-feedback.jsonl, POST /chef-agent/approvals its needs-approval.jsonl.
// Run credential, `run.report` scope, the run's phase checked, one audit
// row, every string scrubbed with the presented credential as a known value.
// Stored once per run: an exact retry is a no-op, a different report for a
// run that already has one is refused.
import { v } from "convex/values";
import { paginationOptsValidator } from "convex/server";
import { mutation, query } from "./_generated/server.js";
import { vApprovalStatus, vSkillFeedbackKind } from "./schema.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { auditOk, authorize, canonicalJson, refuseAuthorized, scrubFor, vRefusal, type RunPhase } from "./chefAgent.js";
import { sha256Hex } from "./chefShared.js";
import { isAdminUser, requireAdminUser } from "./access.js";
import {
  NOTE_LIMITS,
  approvalRequestEntry,
  skillFeedbackEntry,
  type ApprovalRequest,
  type SkillFeedback,
} from "../chef/notes.js";

/** After the agent has run: the runner reports once it is dead, and may retry later. */
// Components can't use the database's paginate() (docs.convex.dev/components/authoring#pagination),
// so these lists page by index range. The cursor is the last row's `entry`
// (one run, ascending) or `_creationTime` (newest first); "" starts over.
function cursorNumber(cursor: string | null): number | null {
  if (cursor === null || cursor === "") return null;
  const n = Number(cursor);
  return Number.isFinite(n) ? n : null;
}

function pageOf<T extends { entry: number; _creationTime: number }>(
  rows: T[],
  numItems: number,
  key: "entry" | "_creationTime",
): { page: T[]; isDone: boolean; continueCursor: string } {
  const page = rows.slice(0, numItems);
  const isDone = rows.length <= numItems;
  const last = page[page.length - 1];
  return { page, isDone, continueCursor: isDone || !last ? "" : String(last[key]) };
}

export const NOTE_PHASES: RunPhase[] = ["agent", "gates", "guards", "committed", "pushing", "pushed"];

/**
 * Stores a run's entries once. Returns how many were stored, `repeat` for an
 * exact repeat, or a refusal message.
 */
export async function storeOnce<T>(
  existing: { entry: number; entryHash: string }[],
  entries: T[],
  insert: (entry: number, e: T, hash: string) => Promise<void>,
): Promise<{ stored: number } | { repeat: true } | { error: string }> {
  const hashes = await Promise.all(entries.map((e, i) => sha256Hex(canonicalJson({ v: 1, i, e }))));
  if (existing.length > 0) {
    const before = [...existing].sort((a, b) => a.entry - b.entry).map((r) => r.entryHash);
    if (before.length === hashes.length && before.every((h, i) => h === hashes[i])) return { repeat: true };
    return { error: "A different report was already stored for this run" };
  }
  for (let i = 0; i < entries.length; i++) await insert(i, entries[i], hashes[i]);
  return { stored: entries.length };
}

/** Checks and scrubs entries, or says what's wrong with the first bad one. */
export function cleanEntries<T>(
  raw: unknown[],
  entry: (x: unknown, clean: (s: string) => string) => T | null,
  clean: (s: string) => string,
): { entries: T[] } | { error: string } {
  if (raw.length > NOTE_LIMITS.entries) return { error: `At most ${NOTE_LIMITS.entries} entries` };
  const entries: T[] = [];
  for (let i = 0; i < raw.length; i++) {
    const e = entry(raw[i], clean);
    if (!e) return { error: `Entry ${i} is not valid` };
    entries.push(e);
  }
  return { entries };
}

const vRawFeedback = v.object({
  skill: v.union(v.string(), v.null()),
  kind: v.string(),
  message: v.string(),
  suggestion: v.optional(v.union(v.string(), v.null())),
});

export const reportSkillFeedback = mutation({
  args: { token: v.string(), entries: v.array(vRawFeedback) },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.number(), applied: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "feedback", scope: "run.report", phases: NOTE_PHASES });
    if (!a.ok) return a;
    const checked = cleanEntries<SkillFeedback>(args.entries, skillFeedbackEntry, scrubFor(args.token));
    if ("error" in checked) return await refuseAuthorized(ctx, a, "feedback", 400, checked.error);
    const existing = await ctx.db
      .query("chefSkillFeedback")
      .withIndex("by_runId_and_entry", (q) => q.eq("runId", a.run._id))
      .take(NOTE_LIMITS.entries + 1);
    const itemId = a.run.itemId;
    const now = Date.now();
    const r = await storeOnce(existing, checked.entries, async (entry, e, entryHash) => {
      await ctx.db.insert("chefSkillFeedback", {
        runId: a.run._id,
        itemId,
        entry,
        skill: e.skill,
        kind: e.kind,
        message: e.message,
        ...(e.suggestion !== undefined ? { suggestion: e.suggestion } : {}),
        entryHash,
        createdAt: now,
      });
    });
    if ("error" in r) return await refuseAuthorized(ctx, a, "feedback", 409, r.error);
    const stored = "stored" in r ? r.stored : 0;
    await auditOk(ctx, a, "feedback", { entries: checked.entries.length, stored, applied: "stored" in r });
    return { ok: true as const, stored, applied: "stored" in r };
  },
});

const vSkillFeedbackRow = v.object({
  id: v.string(),
  runId: v.string(),
  itemId: v.string(),
  skill: v.string(),
  kind: vSkillFeedbackKind,
  message: v.string(),
  suggestion: v.union(v.string(), v.null()),
  createdAt: v.number(),
});

export const vFeedbackPage = v.object({
  page: v.array(vSkillFeedbackRow),
  isDone: v.boolean(),
  continueCursor: v.string(),
});

/**
 * Skill feedback, admins only: one run's in the order the agent wrote it,
 * or everything (optionally for one skill), newest first. Everyone else
 * gets an empty last page.
 */
export const listSkillFeedback = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    runId: v.optional(v.string()),
    skill: v.optional(v.string()),
    paginationOpts: paginationOptsValidator,
  },
  returns: vFeedbackPage,
  handler: async (ctx, args) => {
    const empty = { page: [], isDone: true, continueCursor: "" };
    if (!(await isAdminUser(ctx, args.viewer))) return empty;
    const opts = { ...args.paginationOpts, numItems: Math.min(100, Math.max(1, args.paginationOpts.numItems)) };
    let r;
    if (args.runId !== undefined) {
      const runId = ctx.db.normalizeId("chefRuns", args.runId);
      if (runId === null) return empty;
      const after = cursorNumber(opts.cursor);
      const rows = await ctx.db
        .query("chefSkillFeedback")
        .withIndex("by_runId_and_entry", (q) =>
          after === null ? q.eq("runId", runId) : q.eq("runId", runId).gt("entry", after),
        )
        .take(opts.numItems + 1);
      r = pageOf(rows, opts.numItems, "entry");
    } else if (args.skill !== undefined) {
      const skill = args.skill;
      const before = cursorNumber(opts.cursor);
      const rows = await ctx.db
        .query("chefSkillFeedback")
        .withIndex("by_skill", (q) =>
          before === null ? q.eq("skill", skill) : q.eq("skill", skill).lt("_creationTime", before),
        )
        .order("desc")
        .take(opts.numItems + 1);
      r = pageOf(rows, opts.numItems, "_creationTime");
    } else {
      const before = cursorNumber(opts.cursor);
      const rows = await ctx.db
        .query("chefSkillFeedback")
        .withIndex("by_creation_time", (q) => (before === null ? q : q.lt("_creationTime", before)))
        .order("desc")
        .take(opts.numItems + 1);
      r = pageOf(rows, opts.numItems, "_creationTime");
    }
    return {
      page: r.page.map((x) => ({
        id: x._id,
        runId: x.runId,
        itemId: x.itemId,
        skill: x.skill,
        kind: x.kind,
        message: x.message,
        suggestion: x.suggestion ?? null,
        createdAt: x.createdAt,
      })),
      isDone: r.isDone,
      continueCursor: r.continueCursor,
    };
  },
});

// ------------------------------------------------- spend approval requests

const vRawApproval = v.object({
  action: v.string(),
  skill: v.optional(v.union(v.string(), v.null())),
  estimatedCostUsd: v.optional(v.union(v.number(), v.null())),
  why: v.string(),
  commandOrSteps: v.string(),
});

export const reportApprovalRequests = mutation({
  args: { token: v.string(), entries: v.array(vRawApproval) },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.number(), applied: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "approvals", scope: "run.report", phases: NOTE_PHASES });
    if (!a.ok) return a;
    const checked = cleanEntries<ApprovalRequest>(args.entries, approvalRequestEntry, scrubFor(args.token));
    if ("error" in checked) return await refuseAuthorized(ctx, a, "approvals", 400, checked.error);
    const existing = await ctx.db
      .query("chefApprovalRequests")
      .withIndex("by_runId_and_entry", (q) => q.eq("runId", a.run._id))
      .take(NOTE_LIMITS.entries + 1);
    const now = Date.now();
    const r = await storeOnce(existing, checked.entries, async (entry, e, entryHash) => {
      await ctx.db.insert("chefApprovalRequests", {
        runId: a.run._id,
        itemId: a.run.itemId,
        entry,
        action: e.action,
        ...(e.skill !== undefined ? { skill: e.skill } : {}),
        ...(e.estimatedCostUsd !== undefined ? { estimatedCostUsd: e.estimatedCostUsd } : {}),
        why: e.why,
        commandOrSteps: e.commandOrSteps,
        status: "pending",
        entryHash,
        createdAt: now,
      });
    });
    if ("error" in r) return await refuseAuthorized(ctx, a, "approvals", 409, r.error);
    const stored = "stored" in r ? r.stored : 0;
    await auditOk(ctx, a, "approvals", { entries: checked.entries.length, stored, applied: "stored" in r });
    return { ok: true as const, stored, applied: "stored" in r };
  },
});

const vApprovalRow = v.object({
  id: v.string(),
  runId: v.string(),
  itemId: v.string(),
  action: v.string(),
  skill: v.union(v.string(), v.null()),
  estimatedCostUsd: v.union(v.number(), v.null()),
  why: v.string(),
  commandOrSteps: v.string(),
  status: vApprovalStatus,
  decidedBy: v.union(v.string(), v.null()),
  decidedAt: v.union(v.number(), v.null()),
  decisionNote: v.union(v.string(), v.null()),
  createdAt: v.number(),
});

export const vApprovalPage = v.object({
  page: v.array(vApprovalRow),
  isDone: v.boolean(),
  continueCursor: v.string(),
});

/**
 * Approval requests, admins only: one run's in the order the agent wrote
 * them, or all of them (optionally with one status, such as `pending`),
 * newest first. Everyone else gets an empty last page.
 */
export const listApprovalRequests = query({
  args: {
    viewer: v.optional(v.union(v.string(), v.null())),
    runId: v.optional(v.string()),
    status: v.optional(vApprovalStatus),
    paginationOpts: paginationOptsValidator,
  },
  returns: vApprovalPage,
  handler: async (ctx, args) => {
    const empty = { page: [], isDone: true, continueCursor: "" };
    if (!(await isAdminUser(ctx, args.viewer))) return empty;
    const opts = { ...args.paginationOpts, numItems: Math.min(100, Math.max(1, args.paginationOpts.numItems)) };
    let r;
    if (args.runId !== undefined) {
      const runId = ctx.db.normalizeId("chefRuns", args.runId);
      if (runId === null) return empty;
      const after = cursorNumber(opts.cursor);
      const rows = await ctx.db
        .query("chefApprovalRequests")
        .withIndex("by_runId_and_entry", (q) =>
          after === null ? q.eq("runId", runId) : q.eq("runId", runId).gt("entry", after),
        )
        .take(opts.numItems + 1);
      r = pageOf(rows, opts.numItems, "entry");
    } else if (args.status !== undefined) {
      const status = args.status;
      const before = cursorNumber(opts.cursor);
      const rows = await ctx.db
        .query("chefApprovalRequests")
        .withIndex("by_status", (q) =>
          before === null ? q.eq("status", status) : q.eq("status", status).lt("_creationTime", before),
        )
        .order("desc")
        .take(opts.numItems + 1);
      r = pageOf(rows, opts.numItems, "_creationTime");
    } else {
      const before = cursorNumber(opts.cursor);
      const rows = await ctx.db
        .query("chefApprovalRequests")
        .withIndex("by_creation_time", (q) => (before === null ? q : q.lt("_creationTime", before)))
        .order("desc")
        .take(opts.numItems + 1);
      r = pageOf(rows, opts.numItems, "_creationTime");
    }
    return {
      page: r.page.map((x) => ({
        id: x._id,
        runId: x.runId,
        itemId: x.itemId,
        action: x.action,
        skill: x.skill ?? null,
        estimatedCostUsd: x.estimatedCostUsd ?? null,
        why: x.why,
        commandOrSteps: x.commandOrSteps,
        status: x.status,
        decidedBy: x.decidedBy ?? null,
        decidedAt: x.decidedAt ?? null,
        decisionNote: x.decisionNote ?? null,
        createdAt: x.createdAt,
      })),
      isDone: r.isDone,
      continueCursor: r.continueCursor,
    };
  },
});

/**
 * An admin approves or declines a pending request. This only records the
 * decision, audited; nothing carries out an approved step yet. Deciding the
 * same way again is a no-op; changing a decision is refused.
 */
export const decideApprovalRequest = mutation({
  args: {
    adminUserId: v.string(),
    requestId: v.string(),
    decision: v.union(v.literal("approved"), v.literal("declined")),
    note: v.optional(v.string()),
  },
  returns: v.object({ status: vApprovalStatus, decidedAt: v.number(), changed: v.boolean() }),
  handler: async (ctx, args) => {
    const admin = await requireAdminUser(ctx, args.adminUserId);
    const id = ctx.db.normalizeId("chefApprovalRequests", args.requestId);
    const row = id === null ? null : await ctx.db.get("chefApprovalRequests", id);
    if (!row) throw new Error("No such approval request");
    if (row.status !== "pending") {
      if (row.status === args.decision) return { status: row.status, decidedAt: row.decidedAt ?? row.createdAt, changed: false };
      throw new Error(`Already ${row.status}`);
    }
    const now = Date.now();
    const note = args.note?.trim().slice(0, NOTE_LIMITS.text);
    await ctx.db.patch("chefApprovalRequests", row._id, {
      status: args.decision,
      decidedBy: admin,
      decidedAt: now,
      ...(note ? { decisionNote: note } : {}),
    });
    await writeAudit(ctx, {
      actor: userActor(admin),
      action: `approvalRequest.${args.decision}`,
      runId: row.runId,
      target: row._id,
      outcome: "ok",
      detail: {
        action: row.action.slice(0, 200),
        estimatedCostUsd: row.estimatedCostUsd ?? null,
        ...(note ? { note: note.slice(0, 200) } : {}),
      },
    });
    return { status: args.decision, decidedAt: now, changed: true };
  },
});
