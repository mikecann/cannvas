// `npx chef ios` (docs/chef-pipeline.md, "Trying a build on your iPhone"):
// the developer's Mac builds a run's commit with xcodebuild, installs it on
// their device and reports back here, so the Ship card's iOS flag says
// "compiled ✓ / installed ✓". Nothing here runs in a sandbox.
//
// info, report: the host's CLI function (chefCloud's chefIos) only.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { writeAudit } from "./chefAudit.js";
import { betaSettingsRow } from "./chefBeta.js";
import { vCiCheck } from "./schema.js";

const SHA40 = /^[0-9a-f]{40}$/;

export const vIosInfo = v.object({
  runId: v.id("chefRuns"),
  itemNumber: v.union(v.number(), v.null()),
  title: v.string(),
  status: v.string(),
  branch: v.union(v.string(), v.null()),
  commitSha: v.string(),
  /** The preview's Convex URL (https://<preview>.convex.cloud), when it still has one. */
  previewConvexUrl: v.union(v.string(), v.null()),
  /** The beta's Convex URL, when this build is on the beta. */
  betaConvexUrl: v.union(v.string(), v.null()),
});

function cloudUrlOfSite(site: string | undefined | null): string | null {
  const m = /^https:\/\/([a-z0-9][a-z0-9-]{0,63})\.convex\.site\/?$/.exec(site ?? "");
  return m ? `https://${m[1]}.convex.cloud` : null;
}

/** A run by its id, or an item's newest run with a commit, by the item's id. */
export const info = query({
  args: { ref: v.string() },
  returns: v.union(v.null(), vIosInfo),
  handler: async (ctx, args) => {
    let run: Doc<"chefRuns"> | null = null;
    const runId = ctx.db.normalizeId("chefRuns", args.ref);
    if (runId) run = await ctx.db.get("chefRuns", runId);
    else {
      const itemId = ctx.db.normalizeId("items", args.ref);
      if (!itemId) return null;
      const runs = await ctx.db
        .query("chefRuns")
        .withIndex("by_itemId", (q) => q.eq("itemId", itemId))
        .order("desc")
        .take(20);
      run = runs.find((r) => r.commitSha && SHA40.test(r.commitSha)) ?? null;
    }
    if (!run || !run.commitSha || !SHA40.test(run.commitSha)) return null;
    const item = await ctx.db.get("items", run.itemId);
    const beta = (await betaSettingsRow(ctx))?.beta;
    const onBeta = !!beta && (beta.runId === run._id || beta.sha === run.commitSha);
    return {
      runId: run._id,
      itemNumber: item?.number ?? null,
      title: item?.title ?? "",
      status: run.status,
      branch: run.branch ?? null,
      commitSha: run.commitSha,
      previewConvexUrl: run.previewName ? cloudUrlOfSite(run.previewUrl) : null,
      betaConvexUrl: onBeta && beta ? `https://${beta.deploymentName}.convex.cloud` : null,
    };
  },
});

/** What the developer's Mac found: it compiled, it installed (on which device, by name). Audited. */
export const report = mutation({
  args: {
    operator: v.string(),
    runId: v.id("chefRuns"),
    commitSha: v.string(),
    compiled: v.boolean(),
    installed: v.boolean(),
    device: v.optional(v.string()),
    error: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (run.commitSha !== args.commitSha) throw new Error("That's not this build's commit");
    const clip = (s: string | undefined, n: number) => s?.replace(/\s+/g, " ").trim().slice(0, n) || undefined;
    const device = clip(args.device, 80);
    const error = clip(args.error, 300);
    await ctx.db.patch("chefRuns", run._id, {
      iosCheck: {
        compiled: args.compiled,
        installed: args.compiled && args.installed,
        at: Date.now(),
        ...(device ? { device } : {}),
        ...(error ? { error } : {}),
      },
    });
    await writeAudit(ctx, {
      actor: `operator:${args.operator.slice(0, 60)}`,
      action: "ios.checked",
      runId: run._id as Id<"chefRuns">,
      outcome: args.compiled && args.installed ? "ok" : "error",
      detail: { compiled: args.compiled, installed: args.installed, ...(device ? { device } : {}) },
    });
    return null;
  },
});

/**
 * The host's iOS CI (chef-cloud's chefCiCheck): this run's commit pushed to
 * GitHub for Xcode Cloud, then what it found. Only for the run's own commit;
 * a result never goes back to pending. Audited when it settles.
 */
export const recordCi = mutation({
  args: { operator: v.string(), runId: v.id("chefRuns"), check: vCiCheck },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run) throw new Error("Run not found");
    if (run.commitSha !== args.check.sha) throw new Error("That's not this build's commit");
    if (run.ciCheck && run.ciCheck.status !== "pending" && args.check.status === "pending") return null;
    const clip = (s: string | undefined, n: number) => s?.replace(/\s+/g, " ").trim().slice(0, n) || undefined;
    const url = args.check.url && /^https:\/\//.test(args.check.url) ? args.check.url.slice(0, 500) : undefined;
    const detail = clip(args.check.detail, 300);
    await ctx.db.patch("chefRuns", run._id, {
      ciCheck: { status: args.check.status, ref: args.check.ref.slice(0, 120), sha: args.check.sha, at: args.check.at, ...(url ? { url } : {}), ...(detail ? { detail } : {}) },
    });
    if (args.check.status !== "pending") {
      await writeAudit(ctx, {
        actor: `operator:${args.operator.slice(0, 60)}`,
        action: "ios.ci",
        runId: run._id as Id<"chefRuns">,
        outcome: args.check.status === "passed" ? "ok" : "error",
        detail: { status: args.check.status, ref: args.check.ref, ...(detail ? { detail } : {}) },
      });
    }
    return null;
  },
});
