// The run's orchestration entry points, scheduled by claimNextBuild in the
// claim's own transaction. The host app owns the real orchestration (Daytona
// sandboxes, secrets, egress, preview, email; build plan steps 11 to 17) on
// @convex-dev/workflow, which this component doesn't depend on, with the
// steps in packages/chef-cloud/src/client/chefLauncher.ts. startRun hands each claimed run to the
// orchestrator the host registered; reconcileRun is the fallback reconciler
// for a host that registered none.
import { v } from "convex/values";
import { internalMutation } from "./_generated/server.js";
import { writeAudit } from "./chefAudit.js";
import { finishRun, runActor } from "./chefRuns.js";
import type { FunctionHandle } from "convex/server";

/**
 * Start a claimed run: hand it to the host's orchestrator (registered with
 * chefEffects.setOrchestrator), once. The handle is scheduled in this
 * transaction and the run is stamped `orchestratedAt` in the same one, so
 * running startRun again (a retry, a second schedule) never starts a second
 * orchestration. A run from an external runner's enroll is driven by that
 * runner. With no orchestrator registered nothing drives the run; it goes
 * stale after 15 minutes and is reconciled like any other.
 */
export const startRun = internalMutation({
  args: { runId: v.id("chefRuns") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "active") return null;
    if (run.orchestratedAt !== undefined) return null;
    const external = run.startedVia === "enroll";
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    if (state?.activeRunId !== run._id) return null;
    const handle = external ? undefined : state.orchestratorHandle;
    if (handle) {
      // The host's chefRunStart: a mutation that starts the build workflow.
      await ctx.scheduler.runAfter(0, handle as FunctionHandle<"mutation">, { runId: run._id });
      await ctx.db.patch("chefRuns", run._id, { orchestratedAt: Date.now() });
    }
    await writeAudit(ctx, {
      actor: runActor(run._id),
      action: "run.started",
      runId: run._id,
      outcome: "ok",
      detail: {
        via: run.startedVia,
        external,
        orchestrator: external ? "external" : handle ? "host" : "none",
      },
    });
    return null;
  },
});

/**
 * The fallback reconciler, scheduled only when the host hasn't registered
 * its own (chefEffects.setReconciler). Without a host orchestration nothing
 * of Chef's own exists to clean up (no sandboxes, no secrets), so a cloud
 * run finishes with its pending outcome.
 *
 * An enrolled run is different: its external runner holds its own git
 * access and may still be pushing, and nothing here can stop it or read the
 * refs back. Its slot stays taken until the runner reports the push landed
 * (chefAgent.report, pushing to pushed, which finishes it as built) or an
 * admin calls `cancel({ force: true })`. That one report is accepted up to
 * LATE_PUSH_GRACE_MS (30 minutes) past the run's deadline, so a push that
 * lands right at the deadline still frees the slot. A host that creates sandboxes or
 * secrets must register its reconciler, which cleans up first and then
 * calls chefEffects.finishReconciled.
 */
export const reconcileRun = internalMutation({
  args: { runId: v.id("chefRuns") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run || run.status !== "reconciling") return null;
    if (run.startedVia === "enroll") {
      await writeAudit(ctx, {
        actor: "system:reconcile",
        action: "run.awaitingRunner",
        runId: run._id,
        outcome: "ok",
        reason:
          "no host reconciler; an external runner may still be pushing, so the slot stays taken " +
          "until it reports or an admin force-cancels",
        detail: { phase: run.phase },
      });
      return null;
    }
    await writeAudit(ctx, {
      actor: "system:reconcile",
      action: "run.reconciled",
      runId: run._id,
      outcome: "ok",
      reason: "no host reconciler registered; nothing of Chef's to clean up",
    });
    await finishRun(ctx, run._id, run.pendingOutcome ?? "failed", {
      actor: "system:reconcile",
      error: run.pendingError ?? "stale: no heartbeat or past its deadline",
    });
    return null;
  },
});
