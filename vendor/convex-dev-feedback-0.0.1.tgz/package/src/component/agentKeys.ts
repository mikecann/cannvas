// The /agent/* keys: bearer credentials for the owner's terminal agent
// (queue, claim, log, complete, and triage with the "triage" scope).
//
// Convex keeps sha256(key) and a short prefix, never the key itself: the
// plaintext is in create's return value and nowhere else. A presented key is
// verified by hashing it. Listing, creating and revoking take the admin's
// authenticated userId and check the role here, not only in the host.
//
// Rows from before hashing hold the plaintext in `key`. They keep working
// (verify falls back to them), and `migrateToHashes` rewrites them in place
// to hash plus prefix; touching a legacy key on use does the same for that
// row. The host's chefMigrateAgentKeys (chefCloud) runs the migration to the
// end, and `npx chef init` and `npx chef upgrade` run that. To retire a key that may have leaked, revoke it (`revoke`, or
// `feedback.agentKeys.revoke` from the host) and mint a new one.
import { v } from "convex/values";
import { mutation, query } from "./_generated/server.js";
import type { QueryCtx } from "./_generated/server.js";
import type { Doc } from "./_generated/dataModel.js";
import { requireAdminUser, isAdminUser } from "./access.js";
import { bytesToHex, sha256Hex } from "./chefShared.js";

export const AGENT_KEY_PREFIX = "ship";
/** "ship_" plus 8 hex characters: enough to tell keys apart, useless to an attacker. */
const PREFIX_LENGTH = AGENT_KEY_PREFIX.length + 1 + 8;

const vScope = v.union(v.literal("build"), v.literal("triage"));

function generateKey(): string {
  const bytes = new Uint8Array(24);
  crypto.getRandomValues(bytes);
  return `${AGENT_KEY_PREFIX}_${bytesToHex(bytes)}`;
}

const prefixOf = (k: Doc<"agentKeys">) => k.prefix ?? (k.key ?? "").slice(0, PREFIX_LENGTH);

/** Look a presented key up by its hash, or (rows not yet migrated) by its plaintext. */
export async function findAgentKeyRow(
  ctx: QueryCtx,
  key: string,
): Promise<Doc<"agentKeys"> | null> {
  if (!key) return null;
  const hash = await sha256Hex(key);
  const byHash = await ctx.db
    .query("agentKeys")
    .withIndex("by_hash", (q) => q.eq("hash", hash))
    .unique();
  if (byHash) return byHash;
  return await ctx.db
    .query("agentKeys")
    .withIndex("by_key", (q) => q.eq("key", key))
    .unique();
}

const vKeyOut = v.object({
  _id: v.id("agentKeys"),
  _creationTime: v.number(),
  name: v.string(),
  prefix: v.string(),
  createdBy: v.string(),
  lastUsedAt: v.optional(v.number()),
  revoked: v.boolean(),
  scopes: v.array(vScope),
  /** Still stored as plaintext: run migrateToHashes. */
  legacy: v.boolean(),
});

/** Keys for an admin: names, prefixes and scopes, never the key or its hash. [] for anyone else. */
export const list = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.array(vKeyOut),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    const rows = await ctx.db.query("agentKeys").order("desc").take(200);
    return rows.map((k) => ({
      _id: k._id,
      _creationTime: k._creationTime,
      name: k.name,
      prefix: prefixOf(k),
      createdBy: k.createdBy,
      ...(k.lastUsedAt !== undefined ? { lastUsedAt: k.lastUsedAt } : {}),
      revoked: k.revoked,
      scopes: k.scopes ?? ["build"],
      legacy: k.key !== undefined,
    }));
  },
});

/** Mint a key. The plaintext is in this return value and nowhere else. */
export const create = mutation({
  args: {
    name: v.string(),
    adminUserId: v.string(),
    // Defaults to build-only. Pass ["build","triage"] to mint a key that may
    // also approve/reject — the owner does this deliberately.
    scopes: v.optional(v.array(vScope)),
  },
  returns: v.object({ id: v.id("agentKeys"), key: v.string(), prefix: v.string() }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const key = generateKey();
    const prefix = key.slice(0, PREFIX_LENGTH);
    const id = await ctx.db.insert("agentKeys", {
      name: args.name,
      hash: await sha256Hex(key),
      prefix,
      createdBy: args.adminUserId,
      revoked: false,
      scopes: args.scopes ?? ["build"],
    });
    return { id, key, prefix };
  },
});

export const revoke = mutation({
  args: { id: v.id("agentKeys"), adminUserId: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    const row = await ctx.db.get("agentKeys", args.id);
    if (!row) return null;
    await ctx.db.patch("agentKeys", args.id, { revoked: true });
    return null;
  },
});

/** What the /agent/* routes need about a presented key; never the key or hash. */
export const verify = query({
  args: { key: v.string() },
  returns: v.union(
    v.null(),
    v.object({ _id: v.id("agentKeys"), name: v.string(), scopes: v.array(vScope) }),
  ),
  handler: async (ctx, args) => {
    const row = await findAgentKeyRow(ctx, args.key);
    if (!row || row.revoked) return null;
    return { _id: row._id, name: row.name, scopes: row.scopes ?? ["build"] };
  },
});

export const touch = mutation({
  args: { id: v.id("agentKeys") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const row = await ctx.db.get("agentKeys", args.id);
    if (!row) return null;
    await ctx.db.patch("agentKeys", args.id, {
      lastUsedAt: Date.now(),
      ...(await hashedFields(row)),
    });
    return null;
  },
});

/** For a legacy row: hash and prefix in, plaintext out. {} for a row already hashed. */
async function hashedFields(row: Doc<"agentKeys">) {
  if (row.key === undefined) return {};
  return { hash: await sha256Hex(row.key), prefix: prefixOf(row), key: undefined };
}

/**
 * Rewrite plaintext rows to hash plus prefix, in place. Existing keys keep
 * working. Idempotent; call again while `remaining` is true.
 */
export const migrateToHashes = mutation({
  args: {},
  // `prefixes`: the migrated keys' prefixes, to know which to rotate.
  returns: v.object({ migrated: v.number(), remaining: v.boolean(), prefixes: v.array(v.string()) }),
  handler: async (ctx) => {
    const BATCH = 100;
    const rows = await ctx.db
      .query("agentKeys")
      .withIndex("by_key", (q) => q.gt("key", ""))
      .take(BATCH + 1);
    const prefixes: string[] = [];
    for (const row of rows.slice(0, BATCH)) {
      await ctx.db.patch("agentKeys", row._id, await hashedFields(row));
      prefixes.push(prefixOf(row));
    }
    return { migrated: prefixes.length, remaining: rows.length > BATCH, prefixes };
  },
});

/** Whether any row still holds a plaintext key (one indexed read). */
export const hasLegacy = query({
  args: {},
  returns: v.boolean(),
  handler: async (ctx) => {
    const row = await ctx.db
      .query("agentKeys")
      .withIndex("by_key", (q) => q.gt("key", ""))
      .first();
    return row !== null;
  },
});
