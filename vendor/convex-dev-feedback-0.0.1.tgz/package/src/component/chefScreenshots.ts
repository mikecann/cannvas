// Screenshots of the built app (docs/chef-pipeline.md, "Screenshots"):
// POST /chef-agent/screenshot carries one PNG the runner took after the
// guards, with the agent dead. Run credential, `run.report` scope, the run's
// phase checked, one audit row per call. The PNG is checked (signature and
// header, size, sha256 against the runner's), stored in the component's
// file storage, and recorded once per (run, name): an exact retry is a
// no-op, a different file under a name already used is refused. At most 8
// per run and 10 MB together.
import { v } from "convex/values";
import { action, internalMutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import { internal } from "./_generated/api.js";
import type { Id } from "./_generated/dataModel.js";
import { auditOk, authorize, refuseAuthorized, vRefusal, type Authorized, type RunPhase } from "./chefAgent.js";
import { base64ToHex, sha256Hex } from "./chefShared.js";
import { isAdminUser } from "./access.js";
import { SCREENSHOT_LIMITS, isScreenshotName, isScreenshotPath, pngInfo } from "../chef/screenshots.js";

/** After the guards: the runner takes them with the agent dead, and may retry later. */
export const SCREENSHOT_PHASES: RunPhase[] = ["guards", "committed", "pushing", "pushed"];

const HEX = /^[0-9a-f]{64}$/;

const vFacts = {
  token: v.string(),
  name: v.string(),
  path: v.string(),
  size: v.number(),
  sha256: v.string(),
  claimedSha256: v.optional(v.string()),
  png: v.boolean(),
  width: v.number(),
  height: v.number(),
};

type Facts = {
  token: string;
  name: string;
  path: string;
  size: number;
  sha256: string;
  claimedSha256?: string;
  png: boolean;
  width: number;
  height: number;
};

type Check = { ok: false; status: number; error: string } | { ok: true; repeat: boolean };

/** Everything but the file itself: what precheck and record both check. */
async function check(ctx: MutationCtx, a: Authorized, f: Facts): Promise<Check> {
  const no = (status: number, error: string) => ({ ok: false as const, status, error });
  if (!isScreenshotName(f.name)) return no(400, "name must be lowercase letters, digits and dashes");
  if (!isScreenshotPath(f.path)) return no(400, "path must start with / and be plain ASCII");
  if (!f.png) return no(400, "Not a PNG");
  if (f.size > SCREENSHOT_LIMITS.fileBytes) return no(413, `At most ${SCREENSHOT_LIMITS.fileBytes} bytes per screenshot`);
  if (!HEX.test(f.sha256)) return no(400, "Bad sha256");
  if (f.claimedSha256 !== undefined && f.claimedSha256 !== f.sha256) return no(400, "The bytes don't match their sha256");
  const rows = await ctx.db
    .query("chefScreenshots")
    .withIndex("by_runId_and_name", (q) => q.eq("runId", a.run._id))
    .take(SCREENSHOT_LIMITS.pages + 1);
  const same = rows.find((r) => r.name === f.name);
  if (same) {
    if (same.sha256 === f.sha256) return { ok: true, repeat: true };
    return no(409, `A different screenshot named ${f.name} is already stored`);
  }
  if (rows.length >= SCREENSHOT_LIMITS.pages) return no(409, `At most ${SCREENSHOT_LIMITS.pages} screenshots per run`);
  const total = rows.reduce((n, r) => n + r.size, 0);
  if (total + f.size > SCREENSHOT_LIMITS.totalBytes) {
    return no(413, `At most ${SCREENSHOT_LIMITS.totalBytes} bytes of screenshots per run`);
  }
  return { ok: true, repeat: false };
}

const detailOf = (f: Facts) => ({ name: f.name.slice(0, 40), size: f.size });

/** Before the file is stored: authorized, and would be accepted. */
export const precheck = internalMutation({
  args: vFacts,
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), repeat: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "screenshot", scope: "run.report", phases: SCREENSHOT_PHASES });
    if (!a.ok) return a;
    const c = await check(ctx, a, args);
    if (!c.ok) return await refuseAuthorized(ctx, a, "screenshot", c.status, c.error, detailOf(args));
    if (c.repeat) await auditOk(ctx, a, "screenshot", { ...detailOf(args), stored: false });
    return { ok: true as const, repeat: c.repeat };
  },
});

/** After the file is stored: the same checks again, the stored file's hash, then the row. */
export const record = internalMutation({
  args: { ...vFacts, storageId: v.id("_storage") },
  returns: v.union(vRefusal, v.object({ ok: v.literal(true), stored: v.boolean() })),
  handler: async (ctx, args) => {
    const a = await authorize(ctx, args.token, { route: "screenshot", scope: "run.report", phases: SCREENSHOT_PHASES });
    if (!a.ok) return a;
    const c = await check(ctx, a, args);
    if (!c.ok) return await refuseAuthorized(ctx, a, "screenshot", c.status, c.error, detailOf(args));
    if (c.repeat) {
      await auditOk(ctx, a, "screenshot", { ...detailOf(args), stored: false });
      return { ok: true as const, stored: false };
    }
    const file = await ctx.db.system.get("_storage", args.storageId);
    if (!file || base64ToHex(file.sha256) !== args.sha256 || file.size !== args.size) {
      return await refuseAuthorized(ctx, a, "screenshot", 500, "The stored file doesn't match", detailOf(args));
    }
    await ctx.db.insert("chefScreenshots", {
      runId: a.run._id,
      itemId: a.run.itemId,
      name: args.name,
      path: args.path,
      storageId: args.storageId,
      sha256: args.sha256,
      size: args.size,
      width: args.width,
      height: args.height,
      createdAt: Date.now(),
    });
    await auditOk(ctx, a, "screenshot", { ...detailOf(args), stored: true, width: args.width, height: args.height });
    return { ok: true as const, stored: true };
  },
});

type UploadResult =
  | { ok: false; status: number; error: string }
  | { ok: true; stored: boolean; name: string; sha256: string; width: number; height: number };

/**
 * One PNG from the HTTP action. The bytes are checked here, not taken from
 * the caller: the header's width and height, the sha256 (which must equal
 * the runner's `x-chef-sha256` when it sends one). The file is stored only
 * once the run, phase and caps allow it, and deleted again if the row is
 * refused after all.
 */
export const upload = action({
  args: {
    token: v.string(),
    name: v.string(),
    path: v.string(),
    bytes: v.bytes(),
    sha256: v.optional(v.string()),
  },
  returns: v.union(
    vRefusal,
    v.object({
      ok: v.literal(true),
      stored: v.boolean(),
      name: v.string(),
      sha256: v.string(),
      width: v.number(),
      height: v.number(),
    }),
  ),
  handler: async (ctx, args): Promise<UploadResult> => {
    const bytes = new Uint8Array(args.bytes);
    // Only the first bytes for the header: a huge body is refused on size.
    const info = pngInfo(bytes.subarray(0, 64));
    const facts: Facts = {
      token: args.token,
      name: args.name,
      path: args.path,
      size: bytes.length,
      sha256: await sha256Hex(bytes),
      ...(args.sha256 !== undefined ? { claimedSha256: args.sha256.toLowerCase() } : {}),
      png: info !== null,
      width: info?.width ?? 0,
      height: info?.height ?? 0,
    };
    const done = { name: facts.name, sha256: facts.sha256, width: facts.width, height: facts.height };
    const pre = await ctx.runMutation(internal.chefScreenshots.precheck, facts);
    if (!pre.ok) return pre;
    if (pre.repeat) return { ok: true, stored: false, ...done };
    const storageId: Id<"_storage"> = await ctx.storage.store(new Blob([bytes], { type: "image/png" }));
    const rec = await ctx.runMutation(internal.chefScreenshots.record, { ...facts, storageId });
    if (!rec.ok || !rec.stored) await ctx.storage.delete(storageId);
    if (!rec.ok) return rec;
    return { ok: true, stored: rec.stored, ...done };
  },
});

export const vScreenshot = v.object({
  name: v.string(),
  path: v.string(),
  url: v.union(v.string(), v.null()),
  width: v.number(),
  height: v.number(),
  size: v.number(),
  createdAt: v.number(),
});

export async function screenshotsOf(ctx: QueryCtx, runIdText: string) {
  const runId = ctx.db.normalizeId("chefRuns", runIdText);
  if (runId === null) return [];
  const rows = await ctx.db
    .query("chefScreenshots")
    .withIndex("by_runId_and_name", (q) => q.eq("runId", runId))
    .take(SCREENSHOT_LIMITS.pages);
  // In the order they were taken, which is the plan's.
  rows.sort((x, y) => x._creationTime - y._creationTime);
  return await Promise.all(
    rows.map(async (r) => ({
      name: r.name,
      path: r.path,
      url: await ctx.storage.getUrl(r.storageId),
      width: r.width,
      height: r.height,
      size: r.size,
      createdAt: r.createdAt,
    })),
  );
}

/** One run's screenshots with their storage URLs, admins only. Everyone else gets []. */
export const listRunScreenshots = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), runId: v.string() },
  returns: v.array(vScreenshot),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return [];
    return await screenshotsOf(ctx, args.runId);
  },
});

/**
 * The same for the host's own code, such as the build email
 * (packages/chef-cloud/src/client/chefLauncher.ts). Never expose it to clients as is.
 */
export const runScreenshotsForHost = query({
  args: { runId: v.string() },
  returns: v.array(vScreenshot),
  handler: async (ctx, args) => await screenshotsOf(ctx, args.runId),
});
