import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "./_generated/server.js";
import { MAX_CHANGELOG, changelogFromSummary, userChangelog } from "../chef/changelog.js";
import { vState } from "./schema.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import { requirePrivileged, buildStatusVisible } from "./access.js";
import { deleteAttachmentsForItem, moveAttachments } from "./attachments.js";

// Args every "list all active" read accepts so the component can enforce that
// only admins or agents see the full queue (the host forwards a trusted viewer
// and/or an agentKey).
const actorArgs = {
  viewer: v.optional(v.union(v.string(), v.null())),
  agentKey: v.optional(v.string()),
};

async function nextItemNumber(ctx: any): Promise<number> {
  const counter = await ctx.db
    .query("counters")
    .withIndex("by_name", (q: any) => q.eq("name", "item"))
    .unique();
  if (!counter) {
    await ctx.db.insert("counters", { name: "item", value: 1 });
    return 1;
  }
  const next = counter.value + 1;
  await ctx.db.patch("counters", counter._id, { value: next });
  return next;
}

function enrich(item: Doc<"items">) {
  return {
    ...item,
    stats: {
      totalAmount: item.totalAmount ?? 0,
      supporterCount: item.supporterCount ?? 0,
    },
  };
}

// Coarse, user-facing lifecycle. Deliberately NOT the raw state, and NEVER a
// queue position — a vote is a signal, not a delivery promise. rejected /
// refinement / merged map to null = hidden from the public board.
type PublicStatus = "community" | "planned" | "building" | "shipped";
function publicStatus(item: Doc<"items">): PublicStatus | null {
  if (item.mergedInto || item.kind === "refinement") return null;
  switch (item.state) {
    case "submitted":
      return "community"; // requested by community, pre-triage
    case "requested":
    case "planned":
      return "planned";
    case "inProgress":
      return "building";
    case "completed":
      return "shipped";
    case "rejected":
      return null;
  }
}

// Public-safe shape: requester identity (`createdBy`) and raw `state` are
// Owner-Console-only. The public board gets title, vote total, and a coarse
// status label.
function toPublic(item: Doc<"items">) {
  return {
    _id: item._id,
    number: item.number,
    title: item.title,
    description: item.description,
    transcript: item.transcript,
    publicStatus: publicStatus(item),
    voteCount: item.totalAmount ?? 0,
    supporterCount: item.supporterCount ?? 0,
  };
}

export async function notifySupporters(
  ctx: any,
  itemId: Id<"items">,
  type:
    | "approved"
    | "rejected"
    | "stateChanged"
    | "completed"
    | "merged"
    | "devLog",
  message: string,
) {
  const bids: Doc<"bids">[] = await ctx.db
    .query("bids")
    .withIndex("by_item_and_user", (q: any) => q.eq("itemId", itemId))
    .collect();
  const seen = new Set<string>();
  for (const bid of bids) {
    if (seen.has(bid.userId)) continue;
    seen.add(bid.userId);
    await ctx.db.insert("notifications", {
      userId: bid.userId,
      itemId,
      type,
      message,
      isRead: false,
      stamp: Date.now(),
    });
  }
}

export const create = mutation({
  args: {
    userId: v.string(),
    title: v.string(),
    description: v.string(),
    autoApprove: v.optional(v.boolean()),
    kind: v.optional(v.union(v.literal("feature"), v.literal("refinement"))),
    // Optional voice-note transcript, stored apart from the description.
    transcript: v.optional(v.string()),
  },
  returns: v.id("items"),
  handler: async (ctx, args) => {
    const number = await nextItemNumber(ctx);
    // Security: only an ADMIN may auto-approve a request straight onto the
    // triage/build queue ("requested"). A member's/guest's `autoApprove` is
    // IGNORED — their request stays "submitted" (the pre-triage community
    // bucket) until an admin approves it. This closes a prompt-injection surface:
    // a non-admin cannot push arbitrary text into the state the build agent (and
    // owner tooling) acts on, even if a host mistakenly passes autoApprove:true
    // for them. Approval stays owner-controlled by construction.
    let approved = false;
    if (args.autoApprove) {
      const u = await ctx.db
        .query("users")
        .withIndex("by_userId", (q) => q.eq("userId", args.userId))
        .unique();
      approved = u?.role === "admin";
    }
    return await ctx.db.insert("items", {
      number,
      title: args.title,
      description: args.description,
      state: approved ? "requested" : "submitted",
      createdBy: args.userId,
      kind: args.kind ?? "feature",
      ...(args.transcript?.trim()
        ? { transcript: args.transcript.trim().slice(0, 20000) }
        : {}),
      totalAmount: 0,
      supporterCount: 0,
    });
  },
});

export const get = query({
  args: { itemId: v.id("items") },
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    return item ? enrich(item) : null;
  },
});

// ---------- paginated listings ----------

const listReturnShape = v.object({
  page: v.array(v.any()),
  nextCursor: v.union(v.string(), v.null()),
});

/**
 * Cursor format: the numeric `_creationTime` of the last item in the previous
 * page. `null` on the first call; the response echoes a `nextCursor` (or
 * `null` when the page is the last one).
 */
export const listByState = query({
  args: {
    state: vState,
    limit: v.optional(v.number()),
    cursor: v.optional(v.union(v.string(), v.null())),
    ...actorArgs,
  },
  returns: listReturnShape,
  handler: async (ctx, args) => {
    await requirePrivileged(ctx, args); // admins/agents only — full active queue
    const limit = Math.min(100, Math.max(1, args.limit ?? 20));
    const cursor = args.cursor ? Number(args.cursor) : null;
    const q = ctx.db
      .query("items")
      .withIndex("by_state", (q) =>
        cursor
          ? q.eq("state", args.state).lt("_creationTime", cursor)
          : q.eq("state", args.state),
      )
      .order("desc");
    const raw: Doc<"items">[] = await q.take(limit + 1);
    const visible = raw.filter((i) => !i.mergedInto);
    const page = visible.slice(0, limit).map(enrich);
    page.sort((a, b) => b.stats.totalAmount - a.stats.totalAmount);
    const nextCursor =
      visible.length > limit
        ? String(visible[limit - 1]._creationTime)
        : null;
    return { page, nextCursor };
  },
});

export const listPublic = query({
  args: {
    limit: v.optional(v.number()),
    cursor: v.optional(v.union(v.string(), v.null())),
    // Owner setting (host forwards it). When false, pre-triage requests stay
    // private and only planned/building/shipped show publicly.
    includeCommunity: v.optional(v.boolean()),
  },
  returns: listReturnShape,
  handler: async (ctx, args) => {
    const limit = Math.min(100, Math.max(1, args.limit ?? 20));
    const cursor = args.cursor ? Number(args.cursor) : null;
    const q = ctx.db
      .query("items")
      .withIndex("by_creation_time", (qq) => (cursor ? qq.lt("_creationTime", cursor) : qq))
      .order("desc");
    const raw: Doc<"items">[] = await q.take(limit * 3);
    const visible = raw.filter(
      (i) =>
        // `submitted` is the community bucket — shown for dedup so users vote on
        // an existing request instead of filing a duplicate. rejected items and
        // refinements are never public.
        (args.includeCommunity || i.state !== "submitted") &&
        i.state !== "rejected" &&
        !i.mergedInto &&
        i.kind !== "refinement",
    );
    const page = visible.slice(0, limit).map(toPublic);
    const nextCursor =
      raw.length >= limit * 3
        ? String(raw[raw.length - 1]._creationTime)
        : null;
    return { page, nextCursor };
  },
});

// Owner Console prioritization feed: everything awaiting an owner decision
// (`submitted`) plus approved-not-yet-built (`requested`), highest-voted first.
// Privileged — carries requester identity + raw state for the triage UI.
export const listForTriage = query({
  args: { limit: v.optional(v.number()), ...actorArgs },
  returns: v.array(v.any()),
  handler: async (ctx, args) => {
    await requirePrivileged(ctx, args);
    const limit = Math.min(100, Math.max(1, args.limit ?? 50));
    const submitted = await ctx.db
      .query("items")
      .withIndex("by_state", (q) => q.eq("state", "submitted"))
      .take(limit);
    const requested = await ctx.db
      .query("items")
      .withIndex("by_state", (q) => q.eq("state", "requested"))
      .take(limit);
    return [...submitted, ...requested]
      .filter((i) => !i.mergedInto && i.kind !== "refinement")
      .map(enrich)
      .sort((a, b) => b.stats.totalAmount - a.stats.totalAmount)
      .slice(0, limit);
  },
});

export const listAll = query({
  args: {
    limit: v.optional(v.number()),
    cursor: v.optional(v.union(v.string(), v.null())),
    ...actorArgs,
  },
  returns: listReturnShape,
  handler: async (ctx, args) => {
    await requirePrivileged(ctx, args); // admins/agents only
    const limit = Math.min(200, Math.max(1, args.limit ?? 100));
    const cursor = args.cursor ? Number(args.cursor) : null;
    const q = ctx.db
      .query("items")
      .withIndex("by_creation_time", (qq) => (cursor ? qq.lt("_creationTime", cursor) : qq))
      .order("desc");
    const raw: Doc<"items">[] = await q.take(limit + 1);
    const page = raw.slice(0, limit).map(enrich);
    const nextCursor =
      raw.length > limit ? String(raw[limit - 1]._creationTime) : null;
    return { page, nextCursor };
  },
});

// ---------- state transitions (with notifications) ----------

/**
 * Move an item to `state` (stamping `completedAt` on "completed"; approvals drop any
 * snapshot; leaving the cloud queue) and notify its supporters + submitter. Shared by
 * transitionState and complete so every state change notifies the same way. No-op
 * when already in that state.
 */
async function applyTransition(
  ctx: MutationCtx,
  item: Doc<"items">,
  state: Doc<"items">["state"],
): Promise<void> {
  if (item.state === state) return;
  const itemId = item._id;

  const patch: any = { state };
  if (state === "completed") patch.completedAt = Date.now();
  // Approvals outside the snapshot flow carry no snapshot, so they can never
  // start a cloud build (docs/chef-pipeline.md, "Approval binds an immutable
  // snapshot").
  if (state === "requested") patch.snapshotId = undefined;
  // Any move outside Chef takes the item out of the cloud build queue.
  patch.cloudQueuedAt = undefined;
  await ctx.db.patch("items", itemId, patch);

  const type =
    state === "requested" && item.state === "submitted"
      ? "approved"
      : state === "rejected"
        ? "rejected"
        : state === "completed"
          ? "completed"
          : "stateChanged";
  const message =
    type === "approved"
      ? `"${item.title}" was approved and is now accepting votes.`
      : type === "rejected"
        ? `"${item.title}" was rejected.`
        : type === "completed"
          ? `"${item.title}" has shipped!`
          : `"${item.title}" is now ${state}.`;
  await notifySupporters(ctx, itemId, type, message);
  // Also notify the submitter even if they haven't bid on it.
  const supporters = await ctx.db
    .query("bids")
    .withIndex("by_item_and_user", (q) => q.eq("itemId", itemId))
    .collect();
  const submitterAlreadyNotified = supporters.some(
    (b) => b.userId === item.createdBy,
  );
  if (!submitterAlreadyNotified) {
    await ctx.db.insert("notifications", {
      userId: item.createdBy,
      itemId,
      type,
      message,
      isRead: false,
      stamp: Date.now(),
    });
  }
}

export const transitionState = mutation({
  args: { itemId: v.id("items"), state: vState },
  returns: v.null(),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    await applyTransition(ctx, item, args.state);
    return null;
  },
});

// ---------- changelogs ("What's new") ----------

/**
 * Trimmed, ≤280 chars, for users (src/chef/changelog.ts): no commit hashes,
 * run or snapshot ids, no internal notes ("Built by Chef run …", "merged by
 * hand"); undefined when nothing for users is left (= clear).
 */
function cleanChangelog(text: string): string | undefined {
  return userChangelog(text)?.slice(0, MAX_CHANGELOG);
}

/**
 * A changelog line from the item's newest build that has a summary: its own
 * line under "## Each request", else the first "## What changed" bullet,
 * one plain sentence. For an item completed without a line (by hand, or
 * shipped by a later build), so "What's new" never shows nothing or junk.
 */
export async function derivedChangelog(ctx: QueryCtx, item: Doc<"items">): Promise<string | undefined> {
  const own = await ctx.db
    .query("chefRuns")
    .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
    .order("desc")
    .take(10);
  const links = await ctx.db
    .query("chefRunItems")
    .withIndex("by_itemId", (q) => q.eq("itemId", item._id))
    .order("desc")
    .take(5);
  const batched = [];
  for (const l of links) {
    const r = await ctx.db.get("chefRuns", l.runId);
    if (r) batched.push(r);
  }
  const runs = [...own, ...batched].filter((r) => r.summary).sort((a, b) => {
    // A build that built first, then the newest.
    const built = Number(b.status === "built") - Number(a.status === "built");
    return built !== 0 ? built : b.seq - a.seq;
  });
  for (const r of runs) {
    const line = changelogFromSummary(r.summary, item.number);
    if (line) return line;
  }
  return undefined;
}

/**
 * Set (or, with empty text, clear) an item's user-facing changelog line — what
 * users see under "What's new" once the item is completed. Host-gated like
 * transitionState: call it from an admin/agent path, never with raw user text.
 */
export const setChangelog = mutation({
  args: { itemId: v.id("items"), text: v.string() },
  returns: v.null(),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    await ctx.db.patch("items", args.itemId, { changelog: cleanChangelog(args.text) });
    return null;
  },
});

/**
 * Ship an item: optionally record its changelog line, then transition it to
 * "completed" (stamps completedAt, notifies supporters + submitter exactly like
 * transitionState). Host-gated.
 */
export const complete = mutation({
  args: { itemId: v.id("items"), changelog: v.optional(v.string()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    // No line (or only a note for the operator): one from its build's summary.
    const given = args.changelog !== undefined ? cleanChangelog(args.changelog) : userChangelog(item.changelog);
    const changelog = given ?? (await derivedChangelog(ctx, item));
    if (changelog !== item.changelog) await ctx.db.patch("items", args.itemId, { changelog });
    await applyTransition(ctx, item, "completed");
    return null;
  },
});

/**
 * Requests a release shipped (completed) that was rolled back afterwards (by
 * an admin, or Chef's automatic rollback): each with when that release
 * started and when its rollback began. A request completed between the two
 * was completed by that release, and is no longer live; one completed
 * earlier still is (the rollback restores the release before), and so is
 * one a later release shipped again. An abandoned rollback took nothing out.
 * Bounded: the newest releases only.
 */
async function rolledBackItems(ctx: QueryCtx): Promise<Map<Id<"items">, Array<[number, number]>>> {
  const out = new Map<Id<"items">, Array<[number, number]>>();
  const releases = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").take(100);
  for (const r of releases) {
    // Only a release that finished completed its requests.
    if (r.rolledBackBy === undefined || r.kind === "rollback" || r.state !== "done") continue;
    const by = releases.find((x) => x.seq === r.rolledBackBy);
    if (by?.state === "abandoned") continue;
    const span: [number, number] = [r.createdAt, by?.createdAt ?? r.updatedAt];
    for (const runId of r.runIds) {
      const run = await ctx.db.get("chefRuns", runId);
      if (!run) continue;
      for (const id of [run.itemId, ...(run.batch?.items.map((m) => m.itemId) ?? [])]) {
        out.set(id, [...(out.get(id) ?? []), span]);
      }
    }
  }
  return out;
}

/**
 * Release notes: completed (non-merged, non-refinement) items that have a
 * changelog and shipped after `since` (ms) and are still live (not rolled
 * back since), and shipped ones a release took
 * out after `since` (`removedAt`, its line says so), newest first. Public-safe — only
 * the admin-written changelog line and the ship time are returned.
 */
export const listShippedSince = query({
  args: { since: v.number(), limit: v.optional(v.number()) },
  returns: v.array(
    v.object({
      _id: v.id("items"),
      changelog: v.string(),
      completedAt: v.number(),
    }),
  ),
  handler: async (ctx, args) => {
    const limit = Math.min(50, Math.max(1, Math.floor(args.limit ?? 20)));
    // Completed items, newest-created first, bounded (completedAt isn't indexed;
    // ship order ≈ creation order).
    const rows = await ctx.db
      .query("items")
      .withIndex("by_state", (q) => q.eq("state", "completed"))
      .order("desc")
      .take(500);
    // And shipped requests a later release took out again (an admin's
    // Remove): their line says what was removed, at the time it was.
    const removed = await ctx.db
      .query("items")
      .withIndex("by_state", (q) => q.eq("state", "rejected"))
      .order("desc")
      .take(200);
    const pulled = await rolledBackItems(ctx);
    const at = (i: Doc<"items">) => (i.state === "rejected" ? i.removedAt : i.completedAt) ?? 0;
    const shipped = [
      ...rows.filter((i) => typeof i.completedAt === "number" && i.completedAt > args.since),
      ...removed.filter((i) => typeof i.removedAt === "number" && i.removedAt > args.since && i.completedAt !== undefined),
    ]
      .filter((i) => !i.mergedInto && i.kind !== "refinement")
      // Shipped in a release that was rolled back since: not live.
      .filter((i) => i.state !== "completed" || !(pulled.get(i._id) ?? []).some(([from, to]) => (i.completedAt ?? 0) >= from && (i.completedAt ?? 0) <= to))
      .sort((a, b) => at(b) - at(a));
    // Never a hash, an id or an operator's note; an item completed without a
    // line gets one from its build's summary, else isn't listed.
    const out: { _id: Id<"items">; changelog: string; completedAt: number }[] = [];
    for (const i of shipped) {
      if (out.length >= limit) break;
      const line = userChangelog(i.changelog) ?? (i.state === "completed" ? await derivedChangelog(ctx, i) : undefined);
      if (line) out.push({ _id: i._id, changelog: line, completedAt: at(i) });
    }
    return out;
  },
});

// ---------- merging ----------

export const merge = mutation({
  args: { sourceId: v.id("items"), targetId: v.id("items") },
  returns: v.null(),
  handler: async (ctx, args) => {
    if (args.sourceId === args.targetId) {
      throw new Error("Cannot merge an item into itself");
    }
    const source = await ctx.db.get("items", args.sourceId);
    const target = await ctx.db.get("items", args.targetId);
    if (!source) throw new Error("Source item not found");
    if (!target) throw new Error("Target item not found");
    if (source.mergedInto) throw new Error("Source is already merged");
    if (target.mergedInto)
      throw new Error("Target has itself been merged; pick the final item");

    const sourceBids: Doc<"bids">[] = await ctx.db
      .query("bids")
      .withIndex("by_item_and_user", (q) => q.eq("itemId", args.sourceId))
      .collect();

    let targetAmountDelta = 0;
    let targetSupporterDelta = 0;
    for (const bid of sourceBids) {
      const existingOnTarget = await ctx.db
        .query("bids")
        .withIndex("by_item_and_user", (q) =>
          q.eq("itemId", args.targetId).eq("userId", bid.userId),
        )
        .unique();
      if (existingOnTarget) {
        await ctx.db.patch("bids", existingOnTarget._id, {
          amount: existingOnTarget.amount + bid.amount,
        });
        await ctx.db.delete("bids", bid._id);
        targetAmountDelta += bid.amount;
      } else {
        await ctx.db.patch("bids", bid._id, { itemId: args.targetId });
        targetAmountDelta += bid.amount;
        targetSupporterDelta += 1;
      }
    }
    if (targetAmountDelta !== 0 || targetSupporterDelta !== 0) {
      await ctx.db.patch("items", args.targetId, {
        totalAmount: (target.totalAmount ?? 0) + targetAmountDelta,
        supporterCount:
          (target.supporterCount ?? 0) + targetSupporterDelta,
      });
    }
    await moveAttachments(ctx, args.sourceId, args.targetId);
    await ctx.db.patch("items", args.sourceId, {
      mergedInto: args.targetId,
      totalAmount: 0,
      supporterCount: 0,
    });

    await notifySupporters(
      ctx,
      args.targetId,
      "merged",
      `"${source.title}" was merged into "${target.title}".`,
    );
    return null;
  },
});

/**
 * Permanently delete an item and everything hanging off it (bids, dev logs,
 * notifications, attachments + their files). Host-gated like transitionState —
 * wrap it behind your own admin check. Items merged INTO this one keep their
 * `mergedInto` pointer (they are already hidden everywhere).
 */
export const remove = mutation({
  args: { itemId: v.id("items") },
  returns: v.null(),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) return null;
    const bids = await ctx.db
      .query("bids")
      .withIndex("by_item_and_user", (q) => q.eq("itemId", args.itemId))
      .collect();
    for (const b of bids) await ctx.db.delete("bids", b._id);
    const logs = await ctx.db
      .query("devLogs")
      .withIndex("by_item", (q) => q.eq("itemId", args.itemId))
      .collect();
    for (const l of logs) await ctx.db.delete("devLogs", l._id);
    const notes = await ctx.db
      .query("notifications")
      .withIndex("by_item", (q) => q.eq("itemId", args.itemId))
      .collect();
    for (const n of notes) await ctx.db.delete("notifications", n._id);
    await deleteAttachmentsForItem(ctx, args.itemId);
    await ctx.db.delete("items", args.itemId);
    return null;
  },
});

/**
 * Directly bump an item's vote total without creating a bid row.
 *
 * The host is expected to gate this behind an admin check and translate its
 * own economy onto `amount` (chips, credits, weight — the component is
 * agnostic). A dev-log entry is written for audit.
 */
export const boost = mutation({
  args: {
    itemId: v.id("items"),
    amount: v.number(),
    grantedBy: v.string(),
    reason: v.optional(v.string()),
  },
  returns: v.number(),
  handler: async (ctx, args) => {
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    if (item.mergedInto) throw new Error("Item was merged");
    const newTotal = Math.max(0, (item.totalAmount ?? 0) + args.amount);
    await ctx.db.patch("items", args.itemId, { totalAmount: newTotal });
    const sign = args.amount >= 0 ? "+" : "";
    const reason = args.reason ? ` — ${args.reason}` : "";
    await ctx.db.insert("devLogs", {
      itemId: args.itemId,
      authorId: args.grantedBy,
      message: `🎁 Boost: ${sign}${args.amount}${reason}`,
      stamp: Date.now(),
    });
    return newTotal;
  },
});

// Refinement items (kind="refinement") are agent-asked clarifying questions.
// The answer thread lives in `devLogs` keyed to the item. Open = submitted
// or requested; rejected = skipped; completed = answered & consumed.
export const listRefinementOpen = query({
  args: { limit: v.optional(v.number()), ...actorArgs },
  handler: async (ctx, args) => {
    // Build-mode chrome: visible to admins/agents always, and to anyone while
    // there are no users yet (same gate as agentState) so the scaffolding agent
    // can read answers without a provisioned key. Once users exist, key required.
    if (!(await buildStatusVisible(ctx, args))) return [];
    const limit = Math.min(50, Math.max(1, args.limit ?? 20));
    // Two states count as "open": submitted (just asked) and requested
    // (host marked it as actively awaiting an answer). We fetch both via
    // the by_kind_and_state index and merge.
    const submitted = await ctx.db
      .query("items")
      .withIndex("by_kind_and_state", (q) =>
        q.eq("kind", "refinement").eq("state", "submitted"),
      )
      .order("desc")
      .take(limit);
    const requested = await ctx.db
      .query("items")
      .withIndex("by_kind_and_state", (q) =>
        q.eq("kind", "refinement").eq("state", "requested"),
      )
      .order("desc")
      .take(limit);
    const merged = [...submitted, ...requested]
      .filter((i) => !i.mergedInto)
      .sort((a, b) => b._creationTime - a._creationTime)
      .slice(0, limit);
    return merged.map(enrich);
  },
});

/** Counts stop at this many, so a count never reads more than this many rows. */
export const COUNT_CAP = 1000;

/** How many items are in `state`, up to COUNT_CAP (COUNT_CAP means that many or more). */
export const countByState = query({
  args: { state: vState },
  returns: v.number(),
  handler: async (ctx, args) => {
    const items = await ctx.db
      .query("items")
      .withIndex("by_state", (q) => q.eq("state", args.state))
      .take(COUNT_CAP);
    return items.length;
  },
});

// ---------- approvals (members' requests wait in "submitted") ----------

/**
 * Requests from non-admins waiting for an admin, newest first (excludes merged items and
 * refinements). Admins or agents only. Pair with attachments.listForItems for their media.
 */
export const listAwaitingApproval = query({
  args: { limit: v.optional(v.number()), ...actorArgs },
  returns: v.array(v.any()),
  handler: async (ctx, args) => {
    await requirePrivileged(ctx, args);
    const limit = Math.min(100, Math.max(1, args.limit ?? 50));
    const rows = await ctx.db
      .query("items")
      .withIndex("by_state", (q) => q.eq("state", "submitted"))
      .order("desc")
      .take(limit * 2);
    return rows
      .filter((i) => !i.mergedInto && i.kind !== "refinement")
      .slice(0, limit)
      .map(enrich);
  },
});

/**
 * An admin approves (→ "requested", the build queue) or rejects (→ "rejected") a request that's
 * awaiting approval. `reviewerId` must be an admin; anything not in "submitted" is left alone.
 * Returns the item's resulting state.
 */
export const review = mutation({
  args: { itemId: v.id("items"), approve: v.boolean(), reviewerId: v.string() },
  returns: vState,
  handler: async (ctx, args) => {
    const reviewer = await ctx.db
      .query("users")
      .withIndex("by_userId", (q) => q.eq("userId", args.reviewerId))
      .unique();
    if (reviewer?.role !== "admin") throw new Error("Unauthorized: only admins can approve or reject requests.");
    const item = await ctx.db.get("items", args.itemId);
    if (!item) throw new Error("Item not found");
    if (item.state !== "submitted") return item.state;
    const state = args.approve ? ("requested" as const) : ("rejected" as const);
    await ctx.db.patch("items", args.itemId, { state });
    await ctx.db.insert("notifications", {
      userId: item.createdBy,
      itemId: item._id,
      type: args.approve ? "approved" : "rejected",
      message: args.approve ? `“${item.title}” was approved` : `“${item.title}” was declined`,
      isRead: false,
      stamp: Date.now(),
    });
    return state;
  },
});

// ---------- a requester's own items ----------

/**
 * One user's own requests (not refinements), newest first, with attachment counts — powers a
 * "your requests" list. The host forwards the AUTHENTICATED userId; it is not a privileged read
 * (everyone may see what they filed themselves).
 */
export const listByCreator = query({
  args: { userId: v.string(), limit: v.optional(v.number()) },
  returns: v.array(
    v.object({
      _id: v.id("items"),
      _creationTime: v.number(),
      number: v.number(),
      title: v.string(),
      state: vState,
      mergedInto: v.optional(v.id("items")),
      screenshotCount: v.number(),
      hasAudio: v.boolean(),
    }),
  ),
  handler: async (ctx, args) => {
    const limit = Math.min(100, Math.max(1, args.limit ?? 50));
    const rows = await ctx.db
      .query("items")
      .withIndex("by_createdBy", (q) => q.eq("createdBy", args.userId))
      .order("desc")
      .take(limit * 2);
    const mine = rows.filter((i) => i.kind !== "refinement").slice(0, limit);
    return await Promise.all(
      mine.map(async (i) => {
        // Bounded by the per-item attachment caps (≤4 screenshots + 1 voice note).
        const files = await ctx.db
          .query("attachments")
          .withIndex("by_itemId", (q) => q.eq("itemId", i._id))
          .take(10);
        return {
          _id: i._id,
          _creationTime: i._creationTime,
          number: i.number,
          title: i.title,
          state: i.state,
          ...(i.mergedInto ? { mergedInto: i.mergedInto } : {}),
          screenshotCount: files.filter((f) => f.kind === "screenshot").length,
          hasAudio: files.some((f) => f.kind === "audio"),
        };
      }),
    );
  },
});
