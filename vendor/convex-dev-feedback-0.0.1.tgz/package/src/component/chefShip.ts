// "Ship it" (docs/chef-pipeline.md, "Ship it: a cloud release"): the panel's
// merge button. The newest built run's commit is `chef`'s tip, with `main`
// merged in; its runner uploaded the release diff (`git diff main..chef`)
// and the built frontend. An admin reads that diff in the panel and ships it
// by its hash; that opens a `cloud` release, already approved, and hands it
// to the host's shipper (packages/chef-cloud/src/client/chefShip.ts), which deploys the commit
// to the host's own deployment, publishes the frontend, verifies, and only
// then fast-forwards `main`.
//
// Who can do what:
// - candidate, diffChunk: admins (the panel), null for everyone else;
// - approve: an admin, with the exact diff hash shown;
// - setShipper, info, record: the host only (component functions are never
//   public; the host's actions call them).
import { v } from "convex/values";
import { internalMutation, mutation, query } from "./_generated/server.js";
import type { MutationCtx, QueryCtx } from "./_generated/server.js";
import type { Doc, Id } from "./_generated/dataModel.js";
import type { FunctionHandle } from "convex/server";
import { hasAppAdminUser, isAdminUser, requireAdminUser } from "./access.js";
import { userActor, writeAudit } from "./chefAudit.js";
import { advance, mustGet, openRelease, operatorActor } from "./chefReleases.js";
import { readChefSettings } from "./chefSettings.js";
import { claimNextBuild, newestRunOf, refreshState, runItemIds } from "./chefRuns.js";
import { armShipCheck } from "./chefWatchdog.js";
import { MAX_FOLLOW_MERGES, coverage, followText } from "../chef/follow.js";
import { releaseReached, type ReleaseState } from "../chef/release.js";

const MAX_REQUESTS = 50;

/**
 * A release merge (chefShip.followMain): the approved commit with a newer
 * main merged in, for one open release. It ships only through that release,
 * never as a candidate of its own, and it is not on chef.
 */
export function isReleaseMerge(run: Doc<"chefRuns">): boolean {
  return run.refresh?.releaseId !== undefined;
}

export async function newestBuiltRun(ctx: QueryCtx): Promise<Doc<"chefRuns"> | null> {
  const recent = await ctx.db
    .query("chefRuns")
    .withIndex("by_status", (q) => q.eq("status", "built"))
    .order("desc")
    .take(20);
  return recent.find((r) => !isReleaseMerge(r)) ?? null;
}

/**
 * Builds newer than `run` that pushed to `chef` and then failed or were
 * cancelled (the runner pushes before the preview or beta deploy). `chef` is
 * then past `run`'s commit, so Ship it would refuse it ("chef moved since the
 * diff was approved"); the card says so before anyone approves. Newest first.
 */
export async function chefMovedPast(ctx: QueryCtx, run: Doc<"chefRuns">): Promise<{ run: Doc<"chefRuns">; number: number | null }[]> {
  const later: Doc<"chefRuns">[] = [];
  for (const status of ["failed", "cancelled"] as const) {
    const rows = await ctx.db
      .query("chefRuns")
      .withIndex("by_status", (q) => q.eq("status", status))
      .order("desc")
      .take(20);
    for (const r of rows) {
      // A release merge never moves chef (it pushes its own branch only).
      if (r._creationTime > run._creationTime && r.chefAfter !== undefined && r.chefAfter !== run.commitSha && !isReleaseMerge(r)) later.push(r);
    }
  }
  later.sort((a, b) => b._creationTime - a._creationTime);
  return await Promise.all(
    later.map(async (r) => ({ run: r, number: ((await ctx.db.get("items", r.itemId)) as Doc<"items"> | null)?.number ?? null })),
  );
}

/**
 * The requests a ship of `run` covers: built runs up to it whose request is
 * still built and not shipped (`inProgress`). A request dropped from chef
 * went back to `requested`, so it isn't here; one per request.
 */
export async function coveredRuns(ctx: QueryCtx, run: Doc<"chefRuns">) {
  const runs = await ctx.db
    .query("chefRuns")
    .withIndex("by_status", (q) => q.eq("status", "built"))
    .order("desc")
    .take(MAX_REQUESTS);
  const seen = new Set<string>();
  const out: Array<{ runId: Id<"chefRuns">; itemId: Id<"items">; number: number | null; title: string }> = [];
  for (const r of runs) {
    if (r.seq > run.seq || isReleaseMerge(r)) continue;
    // A batch run covers every request it built (chefBatches.ts).
    for (const itemId of runItemIds(r)) {
      if (seen.has(itemId)) continue;
      const item = await ctx.db.get("items", itemId);
      if (!item || item.state !== "inProgress") continue;
      seen.add(itemId);
      out.push({ runId: r._id, itemId: item._id, number: item.number ?? null, title: item.title });
    }
  }
  return out;
}

/**
 * Requests whose build failed or was cancelled after it pushed to chef (a
 * beta deploy that stopped, a preview upload's network error): their commit
 * stays on chef under every later build, so shipping `run` ships their code
 * too. Chef's builds are serial and each starts from chef's tip and pushes
 * only fast-forward, so an earlier run that pushed chef is an ancestor of
 * every later push: these are the failed or cancelled runs before `run`
 * (lower seq) that pushed (`chefAfter`, or a commit that reached `pushed`),
 * whose requests aren't shipped and aren't covered by a built run. The card
 * lists them before anyone approves; the release completes them too.
 * (Newer ones are chefMovedPast's, which blocks.) Not for a release merge.
 */
export async function alsoShipsRuns(
  ctx: QueryCtx,
  run: Doc<"chefRuns">,
  covered: ReadonlyArray<{ itemId: Id<"items"> }>,
): Promise<Array<{ runId: Id<"chefRuns">; itemId: Id<"items">; number: number | null; title: string; seq: number }>> {
  const coveredItems = new Set(covered.map((c) => String(c.itemId)));
  const out: Array<{ runId: Id<"chefRuns">; itemId: Id<"items">; number: number | null; title: string; seq: number }> = [];
  for (const status of ["failed", "cancelled"] as const) {
    const rows = await ctx.db
      .query("chefRuns")
      .withIndex("by_status", (q) => q.eq("status", status))
      .order("desc")
      .take(MAX_REQUESTS);
    for (const r of rows) {
      if (r.seq >= run.seq || isReleaseMerge(r)) continue;
      const stopped = r.endedPhase ?? r.phase;
      const pushed = r.chefAfter !== undefined || (r.commitSha !== undefined && (stopped === "pushed" || stopped === "previewing" || stopped === "done"));
      if (!pushed) continue;
      for (const itemId of runItemIds(r)) {
        if (coveredItems.has(String(itemId)) || out.some((o) => o.itemId === itemId)) continue;
        const item = await ctx.db.get("items", itemId);
        if (!item || item.state === "completed" || item.state === "rejected" || item.mergedInto) continue;
        out.push({ runId: r._id, itemId, number: item.number ?? null, title: item.title, seq: r.seq });
      }
    }
  }
  return out.sort((a, b) => a.seq - b.seq);
}

async function newestCloudRelease(ctx: QueryCtx): Promise<Doc<"chefReleases"> | null> {
  const recent = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").take(20);
  return recent.find((r) => r.kind === "cloud") ?? null;
}

const vFollowCard = v.object({
  releaseSeq: v.number(),
  status: v.string(),
  mainSha: v.string(),
  attempts: v.number(),
  // followText (src/chef/follow.ts): "Merged main in", "Resolving a conflict", "Needs you: conflict in X".
  text: v.string(),
  reason: v.union(v.string(), v.null()),
  files: v.array(v.string()),
  conflicts: v.array(v.string()),
  repaired: v.boolean(),
  // needsApproval: the merge to approve (shipApprove with this run and hash).
  runId: v.union(v.id("chefRuns"), v.null()),
  diffHash: v.union(v.string(), v.null()),
  depsChanged: v.boolean(),
  // What Chef's agent changed to merge main in (scrubbed): the only diff
  // the re-approval needs reading; the whole merged diff is in shipDiffChunk.
  resolution: v.union(v.string(), v.null()),
  resolutionTruncated: v.boolean(),
  // failed, stalled: "Try again" is shipApprove with these.
  shipRunId: v.union(v.id("chefRuns"), v.null()),
  approvedDiffHash: v.union(v.string(), v.null()),
});

const vShipRelease = v.object({
  releaseId: v.id("chefReleases"),
  seq: v.number(),
  state: v.string(),
  open: v.boolean(),
  sha: v.string(),
  shipRunId: v.union(v.id("chefRuns"), v.null()),
  approvedDiffHash: v.union(v.string(), v.null()),
  error: v.union(v.string(), v.null()),
  siteUrl: v.union(v.string(), v.null()),
  mainSha: v.union(v.string(), v.null()),
  updatedAt: v.number(),
});

function shipRelease(r: Doc<"chefReleases">) {
  return {
    releaseId: r._id,
    seq: r.seq,
    state: r.state,
    open: r.open,
    sha: r.sha,
    shipRunId: r.shipRunId ?? null,
    approvedDiffHash: r.approvedDiffHash ?? null,
    error: r.ship?.error ?? null,
    siteUrl: r.ship?.siteUrl ?? null,
    mainSha: r.mainSha ?? null,
    updatedAt: r.updatedAt,
  };
}

/**
 * What "Ship it" would ship: the newest built run (its commit is what the
 * runner fast-forwarded `chef` to), its release diff's facts, the requests it
 * covers, and the newest cloud release. `blocked` says why it can't ship
 * now. Admins only; null for everyone else.
 */
export const candidate = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())) },
  returns: v.union(
    v.null(),
    v.object({
      run: v.union(
        v.null(),
        v.object({
          runId: v.id("chefRuns"),
          seq: v.number(),
          commitSha: v.union(v.string(), v.null()),
          baseSha: v.union(v.string(), v.null()),
          hasFrontend: v.boolean(),
          finishedAt: v.union(v.number(), v.null()),
          // A merge-only build (main moved before Ship it): what main brought,
          // and whether the merged change is the one approved before.
          mergedMain: v.union(v.null(), v.object({ count: v.number(), subjects: v.array(v.string()) })),
          refresh: v.union(v.null(), v.object({ releaseSeq: v.number(), sameDiff: v.boolean() })),
          // Ship it can't ship this build as it is and merging main in failed:
          // "Try again" (exposeChefApi's retryRun) on this request rebuilds it.
          retryItemId: v.union(v.id("items"), v.null()),
          // Main moved before Ship it and Chef is merging it in: the merge-only
          // build is "queued" (waiting for the slot) or "merging". It ships on
          // its own when the merged change is the one approved.
          refreshing: v.optional(v.union(v.literal("queued"), v.literal("merging"), v.null())),
          // An open release waits for a person while it follows main: approving
          // this (newer, bigger) build ships it in that release's place.
          replaces: v.optional(v.union(v.number(), v.null())),
          diff: v.union(
            v.null(),
            v.object({
              diffHash: v.string(),
              chunkCount: v.number(),
              bytes: v.number(),
              filesChanged: v.array(v.string()),
              filesTruncated: v.boolean(),
              depsChanged: v.boolean(),
              redactions: v.number(),
            }),
          ),
        }),
      ),
      requests: v.array(
        v.object({ runId: v.id("chefRuns"), itemId: v.id("items"), number: v.union(v.number(), v.null()), title: v.string() }),
      ),
      // Requests whose build failed after pushing to chef: their code is
      // under this build, so it ships too (alsoShipsRuns). Shown before approving.
      alsoShips: v.optional(
        v.array(v.object({ runId: v.id("chefRuns"), itemId: v.id("items"), number: v.union(v.number(), v.null()), title: v.string(), seq: v.number() })),
      ),
      release: v.union(v.null(), vShipRelease),
      blocked: v.union(v.string(), v.null()),
      // The open release following main (docs/chef-pipeline.md, "When main
      // moves under Ship it"): where it is, in words, and what to approve.
      follow: v.optional(v.union(v.null(), vFollowCard)),
    }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const run = await newestBuiltRun(ctx);
    const latest = await newestCloudRelease(ctx);
    const open = await openRelease(ctx);
    const release = latest ? shipRelease(latest) : null;
    const follow = open ? await followCard(ctx, open) : null;
    if (!run) return { run: null, requests: [], release, blocked: "Nothing is built yet.", follow };
    const d = run.releaseDiff;
    const requests = await coveredRuns(ctx, run);
    const alsoShips = await alsoShipsRuns(ctx, run, requests);
    // The request's newest build: once the merge build failed, Try again.
    const newestForItem = run.shipBlocked
      ? await newestRunOf(ctx, run.itemId)
      : null;
    // Not while Chef is still merging main in: Try again would replace that.
    const refreshing = run.shipBlocked ? await refreshState(ctx, run) : null;
    const retryable =
      !!run.shipBlocked &&
      !refreshing &&
      !!newestForItem &&
      (newestForItem._id === run._id || newestForItem.status === "failed" || newestForItem.status === "cancelled");
    const movedPast = await chefMovedPast(ctx, run);
    const name = (x: { number: number | null }) => (x.number !== null ? `#${x.number}` : "a later request");
    let blocked: string | null = null;
    // A paused release (following main, waiting for a person) can be
    // replaced by a newer build that covers its requests and more.
    const replaces = open && open.kind === "cloud" && !open.runIds.includes(run._id) && pausedForFollow(open) && !open.deployedSha ? open.seq : null;
    if (latest?.state === "done" && (latest.sha === run.commitSha || latest.runIds.includes(run._id))) blocked = "This build is live.";
    else if (movedPast.length > 0) {
      const names = [...new Set(movedPast.map(name))].join(", ");
      blocked =
        `${movedPast.length === 1 ? "A newer build" : "Newer builds"} (${names}) went into chef after this one but didn't finish, ` +
        `so this build can't ship on its own. Try again on ${name(movedPast[0])}: when it builds, it ships everything together.`;
    } else if (run.shipBlocked) blocked = run.shipBlocked.reason;
    else if (!d) blocked = "This build has no release diff. Build again, or release it with chef-release.";
    else if (open && !(open.kind === "cloud" && open.runIds.includes(run._id)) && replaces === null) {
      blocked = `Release #${open.seq} is shipping (${open.state}); this build waits for its own approval after it.`;
    }
    return {
      run: {
        runId: run._id,
        seq: run.seq,
        commitSha: run.commitSha ?? null,
        baseSha: d?.baseSha ?? null,
        hasFrontend: run.frontendArtifact !== undefined,
        finishedAt: run.finishedAt ?? null,
        mergedMain: run.mergedMain ?? null,
        retryItemId: movedPast.length > 0 ? movedPast[0].run.itemId : retryable ? run.itemId : null,
        refreshing,
        refresh: run.refresh ? { releaseSeq: run.refresh.releaseSeq, sameDiff: d?.diffHash === run.refresh.approvedDiffHash } : null,
        replaces,
        diff: d
          ? {
              diffHash: d.diffHash,
              chunkCount: d.chunkCount,
              bytes: d.bytes,
              filesChanged: d.filesChanged,
              filesTruncated: d.filesTruncated,
              depsChanged: d.depsChanged,
              redactions: d.redactions,
            }
          : null,
      },
      requests,
      alsoShips,
      release,
      blocked,
      follow,
    };
  },
});


/** The shipper is stopped while the release follows main and Chef merges, or a person decides. */
export function pausedForFollow(r: Doc<"chefReleases">): boolean {
  const st = r.follow?.status;
  return st === "merging" || st === "needsApproval" || st === "failed" || st === "stalled";
}

async function followCard(ctx: QueryCtx, r: Doc<"chefReleases">) {
  const f = r.follow;
  if (!f || r.kind !== "cloud") return null;
  const run = f.runId ? await ctx.db.get("chefRuns", f.runId) : null;
  const ask = f.status === "needsApproval" && run?.releaseDiff ? run : null;
  // Conflicts Chef is resolving right now: the merge build's own report.
  const conflicts = f.conflicts ?? run?.mergeRepair?.conflicts ?? [];
  return {
    releaseSeq: r.seq,
    status: f.status,
    mainSha: f.mainSha,
    attempts: f.attempts,
    text: followText(r.seq, { ...f, conflicts }),
    reason: f.reason ?? null,
    files: f.files ?? [],
    conflicts,
    repaired: f.repaired === true,
    runId: ask?._id ?? null,
    diffHash: ask?.releaseDiff?.diffHash ?? null,
    depsChanged: ask?.releaseDiff?.depsChanged ?? false,
    resolution: ask?.mergeRepair?.diff ?? null,
    resolutionTruncated: ask?.mergeRepair?.truncated ?? false,
    shipRunId: r.shipRunId ?? null,
    approvedDiffHash: r.approvedDiffHash ?? null,
  };
}

/** One chunk of a built run's scrubbed release diff, for the panel. Admins only. */
export const diffChunk = query({
  args: { viewer: v.optional(v.union(v.string(), v.null())), runId: v.id("chefRuns"), index: v.number() },
  returns: v.union(
    v.null(),
    v.object({ index: v.number(), count: v.number(), text: v.string(), sha256: v.string(), redactions: v.number() }),
  ),
  handler: async (ctx, args) => {
    if (!(await isAdminUser(ctx, args.viewer))) return null;
    const run = await ctx.db.get("chefRuns", args.runId);
    if (!run?.releaseDiff) return null;
    const c = await ctx.db
      .query("chefRunDiffChunks")
      .withIndex("by_runId_and_index", (q) => q.eq("runId", run._id).eq("index", args.index))
      .unique();
    if (!c) return null;
    return { index: c.index, count: run.releaseDiff.chunkCount, text: c.text, sha256: c.sha256, redactions: c.redactions };
  },
});

async function shipperHandle(ctx: QueryCtx): Promise<string | undefined> {
  const state = await ctx.db
    .query("chefState")
    .withIndex("by_key", (q) => q.eq("key", "singleton"))
    .unique();
  return state?.shipperHandle;
}

export async function startShipper(ctx: MutationCtx, r: Doc<"chefReleases">, actor: string): Promise<boolean> {
  const handle = await shipperHandle(ctx);
  if (handle) {
    await ctx.scheduler.runAfter(0, handle as FunctionHandle<"action">, { releaseId: r._id });
    // The watchdog's one check for this ship (chefWatchdog.checkShip): if it
    // stops answering, the shipper starts again.
    await armShipCheck(ctx, r._id);
  }
  await writeAudit(ctx, {
    actor,
    action: "release.ship.started",
    target: `release:${r.seq}`,
    outcome: handle ? "ok" : "refused",
    ...(handle ? {} : { reason: "no shipper registered (chefShip.setShipper)" }),
    detail: { seq: r.seq },
  });
  return handle !== undefined;
}

/**
 * "Ship to live": the admin ships the newest built run, by the hash of the
 * release diff they were shown. Opens a cloud release (pinned, diffReady,
 * approved in one transaction, with the diff copied into the release) and
 * schedules the host's shipper. A different hash, an older build, a
 * dependency change without the second confirmation, or another open
 * release is refused, and the refusal is audited. Asking again for the
 * release already open (after a failure) starts the shipper again.
 */
export const approve = mutation({
  args: {
    adminUserId: v.string(),
    runId: v.id("chefRuns"),
    diffHash: v.string(),
    depsAcknowledged: v.optional(v.boolean()),
  },
  returns: v.object({
    approved: v.boolean(),
    reason: v.optional(v.string()),
    releaseId: v.optional(v.id("chefReleases")),
    seq: v.optional(v.number()),
    started: v.optional(v.boolean()),
  }),
  handler: async (ctx, args) => {
    await requireAdminUser(ctx, args.adminUserId);
    // "Ship it" is a person's decision: never the CLI's operator identity, and
    // never before an app admin has been provisioned (chefSetAdmin).
    if (args.adminUserId.startsWith("operator:") || !(await hasAppAdminUser(ctx))) {
      throw new Error("Ship it needs an app admin: run chefSetAdmin (npx chef init --admin <userId>) first.");
    }
    const actor = userActor(args.adminUserId);
    const run = await ctx.db.get("chefRuns", args.runId);
    const newest = await newestBuiltRun(ctx);
    const d = run?.releaseDiff;
    const open = await openRelease(ctx);

    // Main moved, Chef merged it in, and what ships changed (a resolution,
    // a fix, main touching the build's lines): the admin approves the merge
    // by its own hash, and the same release goes on with it.
    if (open && open.kind === "cloud" && open.follow?.status === "needsApproval" && open.follow.runId === args.runId) {
      let reason: string | null = null;
      if (!run || run.status !== "built" || !run.commitSha) reason = "that merge isn't built";
      else if (!d || d.commitSha !== run.commitSha) reason = "the merge has no release diff";
      else if (args.diffHash !== d.diffHash) reason = "the diff hash doesn't match the merge's diff";
      else if (d.depsChanged && args.depsAcknowledged !== true) reason = "this diff changes dependencies; confirm the dependency change as well";
      if (reason || !run || !d) {
        reason ??= "refused";
        await writeAudit(ctx, { actor, action: "release.ship.approve", target: `run:${args.runId}`, outcome: "refused", reason, detail: { follow: true } });
        return { approved: false, reason };
      }
      const started = await continueRelease(ctx, open, run, {
        actor,
        note: `Approved the merge of main ${(open.follow.mainSha ?? "").slice(0, 12)}`,
        approval: { adminUserId: args.adminUserId, diffHash: d.diffHash, depsAcknowledged: args.depsAcknowledged === true },
      });
      return { approved: true, releaseId: open._id, seq: open.seq, started };
    }

    if (
      open &&
      open.kind === "cloud" &&
      open.shipRunId === args.runId &&
      (open.approvedDiffHash === args.diffHash || open.diffHash === args.diffHash)
    ) {
      // Shipping again after a failure, or after following main stopped for
      // a person: the same release, from its checkpoint, on the same
      // approval. A merge that stopped starts over with the newest main.
      if (open.follow?.status === "merging") {
        return { approved: true, releaseId: open._id, seq: open.seq, started: false, reason: "Chef is merging main into this release" };
      }
      const resetFollow = open.follow !== undefined && open.follow.status !== "merged";
      if (open.ship?.error !== undefined || resetFollow) {
        await ctx.db.patch("chefReleases", open._id, {
          ...(open.ship?.error !== undefined ? { ship: { ...open.ship, error: undefined, errorAt: undefined } } : {}),
          ...(resetFollow ? { follow: undefined } : {}),
          updatedAt: Date.now(),
        });
      }
      const started = await startShipper(ctx, await mustGet(ctx, open._id), actor);
      return { approved: true, releaseId: open._id, seq: open.seq, started };
    }

    // The bigger set: a release paused while it follows main (nothing of it
    // in production) is replaced by a newer build that covers its requests.
    const replacing =
      open && open.kind === "cloud" && pausedForFollow(open) && !open.deployedSha && run && !open.runIds.includes(run._id) ? open : null;

    let reason: string | null = null;
    if (!run || run.status !== "built") reason = "that run is not a built run";
    else if (isReleaseMerge(run)) reason = "that build is a release's merge of main; it ships with its release";
    else if (!newest || newest._id !== run._id) reason = "a newer build is on chef; ship that one";
    else if ((await chefMovedPast(ctx, run)).length > 0) {
      reason = "a newer build went into chef and didn't finish; Try again on it, and ship that build";
    } else if (!d || !run.commitSha || d.commitSha !== run.commitSha) reason = "this build has no release diff";
    else if (args.diffHash !== d.diffHash) reason = "the diff hash doesn't match this build's diff";
    else if (d.baseSha === d.commitSha) reason = "nothing to ship: chef is main";
    else if (d.depsChanged && args.depsAcknowledged !== true) {
      reason = "this diff changes dependencies; confirm the dependency change as well";
    } else if (open && !replacing) reason = `release #${open.seq} is open (${open.state})`;
    if (reason || !run || !d || !run.commitSha) {
      reason ??= "refused";
      await writeAudit(ctx, {
        actor,
        action: "release.ship.approve",
        target: `run:${args.runId}`,
        outcome: "refused",
        reason,
        detail: { diffHash: args.diffHash.slice(0, 64) },
      });
      return { approved: false, reason };
    }
    if (replacing) await replacePausedRelease(ctx, replacing, actor);

    return await openCloudRelease(ctx, { ...run, commitSha: run.commitSha }, d, {
      actor,
      adminUserId: args.adminUserId,
      diffHash: args.diffHash,
      depsAcknowledged: args.depsAcknowledged === true,
    });
  },
});

/**
 * A paused release gives way to a bigger one the admin approved: abandoned
 * (nothing of it reached production), and a merge of it still waiting in
 * the queue taken out, its request back to built as it was.
 */
async function replacePausedRelease(ctx: MutationCtx, r: Doc<"chefReleases">, actor: string) {
  const now = Date.now();
  const reason = `replaced by a newer build, approved with more requests, while release #${r.seq} was following main`;
  await ctx.db.patch("chefReleases", r._id, { state: "abandoned", open: false, inFlight: undefined, finishedAt: now, updatedAt: now, endReason: reason });
  await writeAudit(ctx, { actor, action: "release.abandoned", target: `release:${r.seq}`, outcome: "ok", reason, detail: { seq: r.seq, from: r.state } });
  const shipRun = r.shipRunId ? await ctx.db.get("chefRuns", r.shipRunId) : null;
  if (shipRun) await unqueueReleaseMerge(ctx, r, shipRun);
}

/** A release merge still waiting for the slot: out of the queue, the request as it was. */
async function unqueueReleaseMerge(ctx: MutationCtx, r: Doc<"chefReleases">, shipRun: Doc<"chefRuns">) {
  const item = await ctx.db.get("items", shipRun.itemId);
  if (!item || item.state !== "requested" || !item.snapshotId) return;
  const snapshot = await ctx.db.get("chefSnapshots", item.snapshotId);
  if (snapshot?.refresh?.releaseId !== r._id) return;
  await ctx.db.patch("items", item._id, { state: "inProgress", snapshotId: shipRun.snapshotId, cloudQueuedAt: undefined });
}

/**
 * Open the cloud release for `run` (pinned, diffReady with its diff copied
 * in, approved by `adminUserId` for `diffHash`) and schedule the host's
 * shipper. The caller checked everything else (chefShip.approve, or
 * replacePausedRelease before it for a bigger set).
 */
async function openCloudRelease(
  ctx: MutationCtx,
  run: Doc<"chefRuns"> & { commitSha: string },
  d: NonNullable<Doc<"chefRuns">["releaseDiff"]>,
  o: { actor: string; adminUserId: string; diffHash: string; depsAcknowledged: boolean; carriedFrom?: number },
) {
  const { actor } = o;
  const args = { adminUserId: o.adminUserId, diffHash: o.diffHash, depsAcknowledged: o.depsAcknowledged };
  const covered = await coveredRuns(ctx, run);
  // And the requests whose failed builds' commits are under this one: they ship too.
  const also = await alsoShipsRuns(ctx, run, covered);
  const runIds = [...new Set([run._id, ...covered.map((c) => c.runId), ...also.map((a) => a.runId)])];
  const last = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").first();
  const seq = (last?.seq ?? 0) + 1;
  const now = Date.now();
  const releaseId = await ctx.db.insert("chefReleases", {
    seq,
    kind: "cloud",
    state: "pinned",
    open: true,
    sha: run.commitSha,
    baseSha: d.baseSha,
    runIds,
    // Nothing to merge: chef's commit already has main merged in, and main
    // fast-forwards to it.
    mergeSha: run.commitSha,
    ...(run.frontendArtifact ? { artifactDigest: run.frontendArtifact.sha256 } : {}),
    shipRunId: run._id,
    ship: { attempts: 0 },
    targets: {},
    checkpoints: [{ state: "pinned", at: now, actor }],
    preparedBy: actor,
    createdAt: now,
    updatedAt: now,
    diffHash: d.diffHash,
    diffChunkCount: d.chunkCount,
  });
  await writeAudit(ctx, {
    actor,
    action: "release.pinned",
    target: `release:${seq}`,
    outcome: "ok",
    detail: { seq, kind: "cloud", sha: run.commitSha, baseSha: d.baseSha, runs: runIds.length },
  });
  const chunks = await ctx.db
    .query("chefRunDiffChunks")
    .withIndex("by_runId_and_index", (q) => q.eq("runId", run._id))
    .take(64);
  if (chunks.length !== d.chunkCount) throw new Error("The build's diff is incomplete");
  for (const c of chunks) {
    await ctx.db.insert("chefReleaseDiffChunks", {
      releaseId,
      index: c.index,
      sha256: c.sha256,
      bytes: c.bytes,
      text: c.text,
      redactions: c.redactions,
    });
  }
  let r = await mustGet(ctx, releaseId);
  await advance(
    ctx,
    r,
    "diffReady",
    actor,
    {
      diffBytes: d.bytes,
      filesChanged: d.filesChanged,
      filesTruncated: d.filesTruncated,
      depsChanged: d.depsChanged,
      redactions: d.redactions,
    },
    { diffHash: d.diffHash, files: d.filesChanged.length, chunks: d.chunkCount },
  );
  r = await mustGet(ctx, releaseId);
  await advance(
    ctx,
    r,
    "approved",
    actor,
    {
      approvedBy: args.adminUserId,
      approvedAt: Date.now(),
      approvedDiffHash: args.diffHash,
      depsAcknowledged: args.depsAcknowledged === true,
      // What was approved, apart from main: a newer main merged in later
      // ships on this approval while it covers what ships (followMain).
      ...(d.change ? { approvedChange: d.change } : {}),
    },
    { diffHash: args.diffHash, depsChanged: d.depsChanged, ...(o.carriedFrom !== undefined ? { carriedFromRelease: o.carriedFrom } : {}) },
  );
  const started = await startShipper(ctx, await mustGet(ctx, releaseId), actor);
  return { approved: true, releaseId, seq, started };
}

// ------------------------------------------------- when main moves under Ship it

/**
 * "Ship it" found `main` moved since the release's commit was made: before
 * the deploy (startShip), or after it, before main could move to the
 * release (goLive). Host-only (docs/chef-pipeline.md, "When main moves
 * under Ship it"). Nothing is abandoned and the approval stays: the release
 * stays open and Chef merges the new main into the release's own commit (not
 * chef's tip: newer builds on chef wait for their own approval), in a build
 * of its own at the front of the queue, whose agent may resolve conflicts
 * and fix the checks. When it is built, `afterFollow` ships it on the same
 * approval if the build's own change is covered, else asks once. At most
 * MAX_FOLLOW_MERGES merges per approval; then a person says go again.
 */
export const followMain = mutation({
  args: { operator: v.string(), releaseId: v.id("chefReleases"), mainSha: v.string() },
  returns: v.object({ following: v.boolean(), reason: v.union(v.string(), v.null()) }),
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const r = await mustGet(ctx, args.releaseId);
    const refuse = async (reason: string) => {
      await writeAudit(ctx, { actor, action: "release.ship.follow", target: `release:${r.seq}`, outcome: "refused", reason });
      return { following: false, reason };
    };
    if (r.kind !== "cloud" || !r.open || (r.state !== "approved" && r.state !== "verified")) {
      return await refuse(`release #${r.seq} is ${r.state}`);
    }
    if (!/^[0-9a-f]{40}$/.test(args.mainSha)) return await refuse("bad main sha");
    if (r.follow?.status === "merging" && r.follow.mainSha === args.mainSha) return { following: true, reason: null };
    if (r.follow && pausedForFollow(r)) return await refuse(followText(r.seq, r.follow));
    const attempts = (r.follow?.attempts ?? 0) + 1;
    if (attempts > MAX_FOLLOW_MERGES) {
      const follow = { status: "stalled" as const, mainSha: args.mainSha, attempts: attempts - 1, at: Date.now() };
      await ctx.db.patch("chefReleases", r._id, { follow, shipWatchdogDueAt: undefined, updatedAt: Date.now() });
      return await refuse(followText(r.seq, follow));
    }
    const queued = await queueReleaseMerge(ctx, r, { mainSha: args.mainSha, attempt: attempts, actor });
    if (!queued.ok) return await refuse(queued.reason);
    return { following: true, reason: null };
  },
});

/**
 * Queue the merge of `mainSha` into the release's commit: a copy of the
 * shipped build's approved snapshot carrying the release (`refresh`), at the
 * front of the queue, claimed now if the slot is free. The release records
 * that it follows main (the shipper stops; the watchdog leaves it alone).
 */
async function queueReleaseMerge(
  ctx: MutationCtx,
  r: Doc<"chefReleases">,
  o: { mainSha: string; attempt: number; actor: string },
): Promise<{ ok: true } | { ok: false; reason: string }> {
  const run = r.shipRunId ? await ctx.db.get("chefRuns", r.shipRunId) : null;
  if (!run || run.status !== "built" || !r.approvedDiffHash || !r.approvedBy) return { ok: false, reason: "the release has no built run and approval" };
  const item = await ctx.db.get("items", run.itemId);
  const snapshot = await ctx.db.get("chefSnapshots", run.snapshotId);
  if (!item || !snapshot || snapshot.approvedAt === undefined || snapshot.approvedBy === undefined) {
    return { ok: false, reason: "the request or its approval is gone" };
  }
  if (item.state === "completed" || item.mergedInto) return { ok: false, reason: "the request moved on" };
  const now = Date.now();
  const refresh = {
    ofRunId: run._id,
    releaseSeq: r.seq,
    approvedDiffHash: r.approvedDiffHash,
    approvedBy: r.approvedBy,
    depsAcknowledged: r.depsAcknowledged === true,
    mainSha: o.mainSha,
    releaseId: r._id,
    fromSha: r.sha,
    attempt: o.attempt,
    repair: true,
  };
  const copyId = await ctx.db.insert("chefSnapshots", {
    itemId: snapshot.itemId,
    title: snapshot.title,
    description: snapshot.description,
    transcript: snapshot.transcript,
    attachments: snapshot.attachments,
    contentHash: snapshot.contentHash,
    itemUpdatedAt: snapshot.itemUpdatedAt,
    createdBy: "system:follow",
    createdAt: now,
    approvedBy: snapshot.approvedBy,
    approvedAt: snapshot.approvedAt,
    refresh,
  });
  const note = `Main moved (${o.mainSha.slice(0, 12)}): merging it into release #${r.seq} (merge ${o.attempt} of ${MAX_FOLLOW_MERGES})`;
  await ctx.db.patch("chefReleases", r._id, {
    follow: { status: "merging", mainSha: o.mainSha, attempts: o.attempt, at: now },
    ship: { ...(r.ship ?? {}), error: undefined, errorAt: undefined, retryAt: undefined },
    // The pending ship check finds this and does nothing; none is armed while it follows.
    shipWatchdogDueAt: undefined,
    inFlight: undefined,
    updatedAt: now,
    checkpoints: [...r.checkpoints, { state: r.state, at: now, actor: o.actor, note }],
  });
  // At the front of the queue; the request builds again (it is still built).
  await ctx.db.patch("items", item._id, { state: "requested", snapshotId: copyId, cloudQueuedAt: 1, continueFrom: undefined });
  const claim = await claimNextBuild(ctx, { via: "retry", actor: o.actor });
  await writeAudit(ctx, {
    actor: o.actor,
    action: "release.ship.follow",
    target: `release:${r.seq}`,
    runId: run._id,
    outcome: "ok",
    reason: note,
    detail: { seq: r.seq, mainSha: o.mainSha, fromSha: r.sha, attempt: o.attempt, claim: claim.outcome },
  });
  return { ok: true };
}

/**
 * A release merge finished (chefRuns.finishRun). Built: if the build's own
 * change is covered by the approval (src/chef/follow.ts coverage: the same
 * change, or part of it), the release goes on with the merge under the same
 * approval ("Merged main in (clean)"); otherwise it waits for one approval
 * of the merge, whose card shows the resolution. Failed: tried once more if
 * the platform failed it and merges are left, else the release waits for a
 * person with the reason and the files (the approval kept, not abandoned).
 */
export const afterFollow = internalMutation({
  args: { runId: v.id("chefRuns"), outcome: v.string(), transient: v.optional(v.boolean()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const actor = "system:follow";
    const run = await ctx.db.get("chefRuns", args.runId);
    const refresh = run?.refresh;
    if (!run || !refresh?.releaseId) return null;
    const r = await ctx.db.get("chefReleases", refresh.releaseId);
    if (!r || !r.open || r.follow?.status !== "merging" || r.follow.attempts !== refresh.attempt) {
      await writeAudit(ctx, { actor, action: "release.ship.follow", runId: run._id, outcome: "refused", reason: "the release moved on" });
      return null;
    }
    const now = Date.now();
    const stop = async (status: "failed" | "needsApproval", fields: { reason: string; files?: string[]; conflicts?: string[]; repaired?: boolean }) => {
      await ctx.db.patch("chefReleases", r._id, {
        follow: { ...r.follow!, status, runId: run._id, at: now, ...fields },
        updatedAt: now,
      });
      await writeAudit(ctx, {
        actor,
        action: "release.ship.follow",
        target: `release:${r.seq}`,
        runId: run._id,
        outcome: status === "failed" ? "error" : "ok",
        reason: fields.reason.slice(0, 500),
        detail: { seq: r.seq, status, files: (fields.files ?? []).length },
      });
    };
    if (args.outcome !== "built" || run.status !== "built") {
      const why = run.failure?.reason ?? run.error ?? args.outcome;
      if (args.transient && r.follow.attempts < MAX_FOLLOW_MERGES) {
        const q = await queueReleaseMerge(ctx, r, { mainSha: r.follow.mainSha, attempt: r.follow.attempts + 1, actor });
        if (q.ok) return null;
      }
      const conflicts = conflictFiles(why);
      // A check the merge broke: the files with problems main didn't already have.
      const broken = /new problems in (.+?)\.?$/.exec(why)?.[1]?.split(", ").slice(0, 20) ?? [];
      await stop("failed", {
        reason: why.slice(0, 500),
        ...(conflicts.length ? { conflicts, files: conflicts } : broken.length ? { files: broken } : {}),
      });
      return null;
    }
    const d = run.releaseDiff;
    if (!d || !run.commitSha || d.commitSha !== run.commitSha) {
      await stop("failed", { reason: "the merge built, but uploaded no release diff" });
      return null;
    }
    const repair = run.mergeRepair;
    const cov = d.change && r.approvedChange
      ? coverage(r.approvedChange, { ...d.change, depsChanged: d.depsChanged }, r.depsAcknowledged === true)
      : d.diffHash === r.approvedDiffHash
        ? ({ covered: true, same: true } as const)
        : ({ covered: false, reason: "what ships changed with the merge", files: d.filesChanged.slice(0, 20) } as const);
    if (cov.covered) {
      const main = d.baseSha.slice(0, 12);
      await continueRelease(ctx, r, run, {
        actor,
        note: repair
          ? `Merged main ${main} in; Chef's resolution left the approved change as it was`
          : `Merged main ${main} in (clean)${cov.same ? "" : "; part of the approved change was already on main"}`,
      });
      return null;
    }
    await stop("needsApproval", {
      reason: repair ? "Chef resolved the merge, and its resolution is new" : cov.reason,
      files: repair ? repair.files : cov.files,
      ...(repair?.conflicts.length ? { conflicts: repair.conflicts } : {}),
      repaired: repair !== undefined,
    });
    return null;
  },
});

/** The files a merge failure names: "... (a.ts, b.ts) ...". */
function conflictFiles(why: string): string[] {
  if (!/conflict|merge cleanly/i.test(why)) return [];
  const m = /\(([^()]+)\)/.exec(why);
  if (!m) return [];
  return m[1]
    .split(/, | and /)
    .map((x) => x.trim())
    .filter((x) => x && !/^\d+ more$/.test(x))
    .slice(0, 20);
}

/**
 * The release goes on with its merge of main: the merge's commit, diff and
 * frontend become what it ships, a checkpoint says so, and the shipper starts
 * again. With `approval` (the admin approved the merge) the approval moves
 * to the merge. A release that had reached production is deployed again (its
 * earlier commit is remembered, so a failure rolls back, never abandons).
 */
async function continueRelease(
  ctx: MutationCtx,
  r: Doc<"chefReleases">,
  run: Doc<"chefRuns">,
  o: { actor: string; note: string; approval?: { adminUserId: string; diffHash: string; depsAcknowledged: boolean } },
): Promise<boolean> {
  const d = run.releaseDiff!;
  const now = Date.now();
  const deployed = releaseReached("cloud", r.state as ReleaseState, "backendDeployed");
  const chunks = await ctx.db
    .query("chefRunDiffChunks")
    .withIndex("by_runId_and_index", (q) => q.eq("runId", run._id))
    .take(64);
  if (chunks.length !== d.chunkCount) throw new Error("The merge's diff is incomplete");
  const old = await ctx.db
    .query("chefReleaseDiffChunks")
    .withIndex("by_releaseId_and_index", (q) => q.eq("releaseId", r._id))
    .take(64);
  for (const c of old) await ctx.db.delete("chefReleaseDiffChunks", c._id);
  for (const c of chunks) {
    await ctx.db.insert("chefReleaseDiffChunks", { releaseId: r._id, index: c.index, sha256: c.sha256, bytes: c.bytes, text: c.text, redactions: c.redactions });
  }
  await ctx.db.patch("chefReleases", r._id, {
    state: "approved",
    sha: run.commitSha!,
    baseSha: d.baseSha,
    mergeSha: run.commitSha!,
    shipRunId: run._id,
    runIds: [...new Set([...r.runIds, run._id])],
    artifactDigest: run.frontendArtifact?.sha256,
    diffHash: d.diffHash,
    diffChunkCount: d.chunkCount,
    diffBytes: d.bytes,
    filesChanged: d.filesChanged,
    filesTruncated: d.filesTruncated,
    depsChanged: d.depsChanged,
    redactions: d.redactions,
    ...(deployed ? { deployedSha: r.deployedSha ?? r.sha, targets: {}, checks: undefined } : {}),
    ...(o.approval
      ? {
          approvedBy: o.approval.adminUserId,
          approvedAt: now,
          approvedDiffHash: o.approval.diffHash,
          depsAcknowledged: o.approval.depsAcknowledged,
          ...(d.change ? { approvedChange: d.change } : {}),
        }
      : {}),
    follow: { ...r.follow!, status: "merged", runId: run._id, mainSha: d.baseSha, at: now },
    // A fresh ship: the earlier sandbox and execution were for the earlier commit.
    ship: {
      attempts: r.ship?.attempts ?? 0,
      ...(r.ship?.emailKeys ? { emailKeys: r.ship.emailKeys } : {}),
      ...(r.ship?.deploymentName ? { deploymentName: r.ship.deploymentName } : {}),
      ...(r.ship?.siteUrl ? { siteUrl: r.ship.siteUrl } : {}),
    },
    inFlight: undefined,
    updatedAt: now,
    checkpoints: [...r.checkpoints, { state: "approved", at: now, actor: o.actor, note: o.note }],
  });
  await writeAudit(ctx, {
    actor: o.actor,
    action: o.approval ? "release.approved" : "release.ship.merged",
    target: `release:${r.seq}`,
    runId: run._id,
    outcome: "ok",
    reason: o.note.slice(0, 500),
    detail: { seq: r.seq, sha: run.commitSha!, baseSha: d.baseSha, diffHash: d.diffHash, redeploy: deployed, ...(o.approval ? { follow: true } : { sameApproval: true }) },
  });
  return await startShipper(ctx, await mustGet(ctx, r._id), o.actor);
}

/**
 * Automatic rollback (docs/chef-pipeline.md, "Automatic rollback"): a cloud
 * ship whose backend reached production and then failed its checks (the
 * live site, the health check, the migration, the frontend upload) is
 * rolled back to the release before it, with that release's own commit and
 * the frontend its build kept, by the same ship machinery: a `rollback`
 * release (restores, rollbackOf) driven by the host's shipper, which never
 * moves main (main was never moved for the failed one). The failed release
 * ends rolledBack. Refused (and the release left open with its error, as
 * before) when there is no earlier release a build shipped, or its frontend
 * is gone. Never for a rollback itself. Host-only.
 */
export const autoRollback = mutation({
  args: { operator: v.string(), releaseId: v.id("chefReleases"), reason: v.string() },
  returns: v.object({ rolledBack: v.boolean(), seq: v.optional(v.number()), restores: v.optional(v.number()), reason: v.optional(v.string()) }),
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const bad = await mustGet(ctx, args.releaseId);
    const refuse = async (reason: string) => {
      await writeAudit(ctx, { actor, action: "release.autoRollback", target: `release:${bad.seq}`, outcome: "refused", reason });
      return { rolledBack: false, reason };
    };
    if (bad.kind !== "cloud") return await refuse(`release #${bad.seq} is a ${bad.kind} release`);
    if (!bad.open) return await refuse(`release #${bad.seq} is ${bad.state}`);
    // Or a release deployed once, then merged with a newer main and deployed again.
    if (!["backendDeployed", "frontendPublished", "verified"].includes(bad.state) && !bad.deployedSha) {
      return await refuse(`release #${bad.seq} didn't reach production (${bad.state})`);
    }
    const earlier = await ctx.db
      .query("chefReleases")
      .withIndex("by_seq", (q) => q.lt("seq", bad.seq))
      .order("desc")
      .take(50);
    const prev = earlier.find((e) => e.state === "done" && e.rolledBackBy === undefined && e.mergeSha);
    if (!prev) return await refuse("there is no earlier release to roll back to");
    if (!prev.shipRunId) return await refuse(`release #${prev.seq} wasn't shipped from a build, so Chef has no frontend for it`);
    const prevRun = await ctx.db.get("chefRuns", prev.shipRunId);
    if (prev.artifactDigest && prevRun?.frontendArtifact?.sha256 !== prev.artifactDigest) {
      return await refuse(`release #${prev.seq}'s frontend is no longer kept`);
    }
    const last = await ctx.db.query("chefReleases").withIndex("by_seq").order("desc").first();
    const seq = (last?.seq ?? 0) + 1;
    const now = Date.now();
    const reason = args.reason.replace(/[\r\n]+/g, " ").slice(0, 500);
    await ctx.db.patch("chefReleases", bad._id, {
      state: "rolledBack",
      open: false,
      inFlight: undefined,
      rolledBackBy: seq,
      finishedAt: now,
      updatedAt: now,
      endReason: `failed its checks after deploying (${reason}); Chef rolled back to release #${prev.seq}`.slice(0, 500),
    });
    const id = await ctx.db.insert("chefReleases", {
      seq,
      kind: "rollback",
      state: "pinned",
      open: true,
      sha: prev.mergeSha!,
      baseSha: bad.baseSha,
      runIds: [],
      rollbackOf: bad.seq,
      restores: prev.seq,
      mergeSha: prev.mergeSha,
      ...(prev.artifactDigest ? { artifactDigest: prev.artifactDigest } : {}),
      shipRunId: prev.shipRunId,
      ship: { attempts: 0 },
      targets: {},
      checkpoints: [{ state: "pinned", at: now, actor }],
      preparedBy: actor,
      createdAt: now,
      updatedAt: now,
      endReason: `automatic rollback of release #${bad.seq}: ${reason}`.slice(0, 500),
    });
    await writeAudit(ctx, {
      actor,
      action: "release.autoRollback",
      target: `release:${seq}`,
      outcome: "ok",
      reason,
      detail: { seq, rollbackOf: bad.seq, restores: prev.seq, mergeSha: prev.mergeSha!, artifactDigest: prev.artifactDigest ?? null },
    });
    const started = await startShipper(ctx, (await mustGet(ctx, id))!, actor);
    return started ? { rolledBack: true, seq, restores: prev.seq } : { rolledBack: true, seq, restores: prev.seq, reason: "no shipper registered" };
  },
});

/**
 * A ship that failed for the platform's reasons (src/chef/recovery.ts,
 * transient): the release stays open with its error, and the host's shipper
 * starts it again after `inMs` (it adopts the sandbox and the script by
 * label, or starts them). Host-only; the host decides with `recover`.
 */
export const retryLater = mutation({
  args: { operator: v.string(), releaseId: v.id("chefReleases"), inMs: v.number() },
  returns: v.boolean(),
  handler: async (ctx, args) => {
    const r = await mustGet(ctx, args.releaseId);
    if ((r.kind !== "cloud" && r.kind !== "rollback") || !r.open) return false;
    const handle = await shipperHandle(ctx);
    if (!handle) return false;
    const inMs = Math.max(0, Math.min(args.inMs, 60 * 60_000));
    await ctx.scheduler.runAfter(inMs, handle as FunctionHandle<"action">, { releaseId: r._id });
    await ctx.db.patch("chefReleases", r._id, { ship: { ...(r.ship ?? {}), retryAt: Date.now() + inMs }, updatedAt: Date.now() });
    // The watchdog's check moves past the retry.
    await armShipCheck(ctx, r._id);
    await writeAudit(ctx, {
      actor: operatorActor(args.operator),
      action: "release.ship.autoRetry",
      target: `release:${r.seq}`,
      outcome: "ok",
      detail: { seq: r.seq, inMs, attempts: r.ship?.attempts ?? 0 },
    });
    return true;
  },
});

/**
 * Register the host's shipper (a function handle from `createFunctionHandle`
 * to an action that calls `driveShip`). `approve` schedules it with
 * `{ releaseId }`. Host-only.
 */
export const setShipper = mutation({
  args: { handle: v.union(v.string(), v.null()) },
  returns: v.null(),
  handler: async (ctx, args) => {
    const state = await ctx.db
      .query("chefState")
      .withIndex("by_key", (q) => q.eq("key", "singleton"))
      .unique();
    const patch = { shipperHandle: args.handle ?? undefined };
    if (state) await ctx.db.patch("chefState", state._id, patch);
    else await ctx.db.insert("chefState", { key: "singleton", nextSeq: 1, ...patch });
    await writeAudit(ctx, {
      actor: "system:host",
      action: "ship.shipper",
      outcome: "ok",
      detail: { registered: args.handle !== null },
    });
    return null;
  },
});

/** What the host's shipper needs: the release, the deploy key's recorded prefix, the items. Host-only. */
export const info = query({
  args: { releaseId: v.id("chefReleases") },
  returns: v.union(
    v.null(),
    v.object({
      releaseId: v.id("chefReleases"),
      seq: v.number(),
      kind: v.string(),
      state: v.string(),
      open: v.boolean(),
      sha: v.string(),
      baseSha: v.string(),
      approvedDiffHash: v.union(v.string(), v.null()),
      artifactDigest: v.union(v.string(), v.null()),
      shipRunId: v.union(v.id("chefRuns"), v.null()),
      sandboxId: v.union(v.string(), v.null()),
      executionId: v.union(v.string(), v.null()),
      sandboxIntent: v.boolean(),
      mainSha: v.union(v.string(), v.null()),
      deployKeyPrefix: v.union(v.string(), v.null()),
      // itemId and createdBy: for the requesters' "it's live" emails (chef-cloud's
      // notify.requesterEmail); `removed`: this release took the request out (Remove…), so
      // there's nothing live to tell them about. New fields, so an older chef-cloud reads on.
      requests: v.array(
        v.object({
          number: v.union(v.number(), v.null()),
          title: v.string(),
          itemId: v.id("items"),
          createdBy: v.string(),
          removed: v.optional(v.boolean()),
        }),
      ),
      attempts: v.number(),
      emailKeys: v.array(v.string()),
      // A rollback: the release it rolls back, and the one it restores.
      rollbackOf: v.optional(v.union(v.number(), v.null())),
      restores: v.optional(v.union(v.number(), v.null())),
      // An earlier commit of this release reached production (it followed
      // main after its deploy): a failure now rolls back, never abandons.
      deployedSha: v.optional(v.union(v.string(), v.null())),
      // Following main: the shipper has nothing to do until Chef or a person goes on.
      following: v.optional(v.boolean()),
    }),
  ),
  handler: async (ctx, args) => {
    const r = await ctx.db.get("chefReleases", args.releaseId);
    if (!r) return null;
    const settings = await readChefSettings(ctx);
    const requests = [];
    const seen = new Set<string>();
    for (const id of r.runIds) {
      const run = await ctx.db.get("chefRuns", id);
      for (const itemId of run ? runItemIds(run) : []) {
        if (seen.has(itemId)) continue;
        seen.add(itemId);
        const item = await ctx.db.get("items", itemId);
        if (!item) continue;
        const removed = run?.followUp?.kind === "remove" || item.removedAt !== undefined;
        requests.push({ number: item.number ?? null, title: item.title, itemId: item._id, createdBy: item.createdBy, ...(removed ? { removed } : {}) });
      }
    }
    return {
      releaseId: r._id,
      seq: r.seq,
      kind: r.kind,
      state: r.state,
      open: r.open,
      sha: r.sha,
      baseSha: r.baseSha,
      approvedDiffHash: r.approvedDiffHash ?? null,
      artifactDigest: r.artifactDigest ?? null,
      shipRunId: r.shipRunId ?? null,
      sandboxId: r.ship?.sandboxId ?? null,
      executionId: r.ship?.executionId ?? null,
      sandboxIntent: r.ship?.sandboxIntentAt !== undefined,
      mainSha: r.mainSha ?? null,
      deployKeyPrefix: settings.deployKeyPrefix,
      requests,
      attempts: r.ship?.attempts ?? 0,
      emailKeys: r.ship?.emailKeys ?? [],
      rollbackOf: r.rollbackOf ?? null,
      restores: r.restores ?? null,
      deployedSha: r.deployedSha ?? null,
      following: pausedForFollow(r),
    };
  },
});

/**
 * What the host's shipper did, on the release and in the audit log: the
 * deploy sandbox (its intent before the create), the execution, the git
 * secret's name, the deployment and site, a failure (shown in the panel),
 * the cleanup, the email. Never a secret value. Host-only.
 */
export const record = mutation({
  args: {
    operator: v.string(),
    releaseId: v.id("chefReleases"),
    event: v.union(
      v.literal("attempt"),
      v.literal("sandboxIntent"),
      v.literal("sandbox"),
      v.literal("secret"),
      v.literal("exec"),
      v.literal("deployment"),
      v.literal("error"),
      v.literal("cleanup"),
      v.literal("email"),
      v.literal("emailFailed"),
      v.literal("mirror"),
    ),
    sandboxId: v.optional(v.string()),
    executionId: v.optional(v.string()),
    secretName: v.optional(v.string()),
    deploymentName: v.optional(v.string()),
    siteUrl: v.optional(v.string()),
    error: v.optional(v.string()),
    emailId: v.optional(v.string()),
    emailKey: v.optional(v.string()),
    adopted: v.optional(v.boolean()),
    mirrorGithub: v.optional(v.string()),
    mirrorStatus: v.optional(v.union(v.literal("pushed"), v.literal("current"), v.literal("ahead"), v.literal("diverged"), v.literal("failed"))),
    mirrorSha: v.optional(v.string()),
    mirrorTarget: v.optional(v.string()),
  },
  returns: v.null(),
  handler: async (ctx, args) => {
    const actor = operatorActor(args.operator);
    const r = await mustGet(ctx, args.releaseId);
    // A cloud ship, or the rollback Chef drives after one failed its checks.
    if (r.kind !== "cloud" && !(r.kind === "rollback" && r.shipRunId)) throw new Error(`Release #${r.seq} is not a cloud ship`);
    const ship = { ...(r.ship ?? {}) };
    const now = Date.now();
    const detail: Record<string, string | number | boolean | null> = { seq: r.seq };
    switch (args.event) {
      case "attempt":
        ship.attempts = (ship.attempts ?? 0) + 1;
        ship.error = undefined;
        ship.errorAt = undefined;
        detail.attempt = ship.attempts;
        break;
      case "sandboxIntent":
        ship.sandboxIntentAt ??= now;
        break;
      case "sandbox":
        if (!args.sandboxId) throw new Error("sandboxId is required");
        ship.sandboxId = args.sandboxId.slice(0, 200);
        detail.sandboxId = ship.sandboxId;
        detail.adopted = args.adopted === true;
        break;
      case "secret":
        if (!args.secretName || !/^chef-[a-z0-9-]{1,60}$/.test(args.secretName)) throw new Error("Bad secret name");
        ship.secretName = args.secretName;
        detail.secret = args.secretName;
        break;
      case "exec":
        if (!args.executionId) throw new Error("executionId is required");
        ship.executionId = args.executionId.slice(0, 200);
        detail.executionId = ship.executionId;
        detail.adopted = args.adopted === true;
        break;
      case "deployment":
        if (args.deploymentName) ship.deploymentName = args.deploymentName.slice(0, 64);
        if (args.siteUrl) ship.siteUrl = args.siteUrl.slice(0, 300);
        detail.deploymentName = ship.deploymentName ?? null;
        break;
      case "error":
        ship.error = (args.error ?? "failed").slice(0, 2000);
        ship.errorAt = now;
        break;
      case "cleanup":
        ship.sandboxId = undefined;
        ship.executionId = undefined;
        ship.sandboxIntentAt = undefined;
        ship.secretName = undefined;
        break;
      case "email":
        if (args.emailId) ship.emailId = args.emailId.slice(0, 200);
        if (args.emailKey) {
          const key = args.emailKey.slice(0, 100);
          // Room for one key per requester too (release-<n>-item-<id>), so a
          // repeated finish still finds every key it sent.
          ship.emailKeys = [...(ship.emailKeys ?? []).filter((k) => k !== key), key].slice(-50);
          detail.key = key;
        }
        detail.emailId = ship.emailId ?? null;
        break;
      case "emailFailed":
        // The email is a courtesy: the release goes on, and the panel's error stays as it was.
        if (args.emailKey) detail.key = args.emailKey.slice(0, 100);
        break;
      case "mirror":
        // Also a courtesy: what's live is live whatever GitHub says.
        if (!args.mirrorGithub || !args.mirrorStatus) throw new Error("mirrorGithub and mirrorStatus are required");
        ship.mirror = {
          github: args.mirrorGithub.slice(0, 200),
          status: args.mirrorStatus,
          ...(args.mirrorSha ? { sha: args.mirrorSha.slice(0, 40) } : {}),
          ...(args.mirrorTarget ? { target: args.mirrorTarget.slice(0, 40) } : {}),
          ...(args.error ? { error: args.error.slice(0, 500) } : {}),
          at: now,
        };
        detail.github = ship.mirror.github;
        detail.status = ship.mirror.status;
        detail.sha = ship.mirror.sha ?? null;
        break;
    }
    await ctx.db.patch("chefReleases", r._id, { ship, updatedAt: now });
    await writeAudit(ctx, {
      actor,
      action: `release.ship.${args.event}`,
      target: `release:${r.seq}`,
      outcome:
        args.event === "error" ||
        args.event === "emailFailed" ||
        (args.event === "mirror" && (args.mirrorStatus === "failed" || args.mirrorStatus === "diverged"))
          ? "error"
          : "ok",
      ...(args.event === "error" ? { reason: ship.error } : {}),
      ...(args.event === "emailFailed" ? { reason: (args.error ?? "the email failed").slice(0, 500) } : {}),
      ...(args.event === "mirror" && args.error ? { reason: args.error.slice(0, 500) } : {}),
      detail,
    });
    return null;
  },
});
