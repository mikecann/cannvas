// The version of what @convex-dev/feedback offers @convex-dev/chef-cloud: the
// component functions chefCloud calls through the host (runs, effects'
// run side, releases, settings, keys, audit, runner config) and the client
// modules it imports (`/delivery`, `/chef/*`). Bump it when any of that
// changes in a way an older chef-cloud can't use. chefCloud checks it at
// setup and in chefSetupStatus, against the version it was built for, and
// refuses with a clear message on a mismatch.
// 2: fix rounds (chefRunnerConfig.fixRounds), learnings and "Try again".
// 3: warm snapshots (chefEffects.recordWarm, `/install-plan`, provenance's warm fields).
// 4: Ship it merges a moved main instead of refusing (chefShip.refreshForMain).
// 5: recovery (chefShip.retryLater, the run's recovery), repair commits (chefRepairs),
//    automatic rollback (chefShip.autoRollback) and the watchdog (chefWatchdog.check).
// 6: the demo video (chefDemo, recordPreview's demoLoginUrl).
// 7: preview data (chefPreviewData: settingsForHost, storeExport, exportUrl, dropExport).
// 8: the beta channel (chefBeta, the run effect keys sandbox:beta and exec:beta, the ship script's seed).
// 9: `npx chef ios` (chefIos.info and chefIos.report).
// 10: no crons: the host's one-shot cleanup (chefEffects.setCleaner, nextBranchExpiry),
//     the run's workflow ending (chefWatchdog.workflowEnded), deadline checks.
// 11: batching (chefBatches: setPlanner, applyPlan, split, list; a run's `batch`;
//     the claim's "planning" outcome; GET /run's `batch` and member attachments).
// 12: chefRunnerConfig.loginFunction (signed-in build screenshots), chefShip's
//     chefMovedPast block on approve/Ship, a run's baseSha reported as mainBefore.
// 13: Ship it follows main (chefShip.followMain and afterFollow replace
//     refreshForMain and afterRefresh): the release stays open on its
//     approval, a release merge (GET /run's `release`, pushed to its branch
//     only, no preview: runInfo.releaseMerge, the `finishMerge` step) whose
//     agent may repair the merge (the report's `mergeRepair`), chefShip.info's
//     `following` and `deployedSha`, the ship's `following` outcome.
//     Also: a run's terminal phase "ended" (and `endedPhase`), gate results'
//     `baselineOn`/`newProblems`/`baselineFiles`, the candidate's `alsoShips`,
//     and the effect keys sandbox:beta:2 / exec:beta:2 (a beta deploy tried once more).
// 14: previews are per request: recordPreview takes the request's name,
//     `chef-req-<number>` (src/chef/preview.ts; `chef-<sha12>` still), and
//     clears the link of an earlier run of the request it replaced; a run
//     whose change the web preview can't show finishes built with no preview
//     (the card's `previewNote`); a failure's kind may be "environmental"
//     (deploymentQuota).
// 15: the beta channel's demo sign-in link: chefBeta.finish takes `demoLoginUrl`
//     (the ship script's CHEF_DEMO_LOGIN_FUNCTION), so a beta run's demo opens signed in.
// 16: an admin's fix or removal of a built or shipped request
//     (chefSnapshots.adminFollowUp): a run's `followUp` may have no `reason`
//     and carry `kind`, `note` and `revertShas`, and GET /run says so; the
//     runner tells the agent (admin-feedback.md, remove-request.md) and
//     reverts first for a removal. buildState's `followUps`; a shipped
//     removal leaves its request "rejected" with `removedAt`.
export const CHEF_CONTRACT_VERSION = 16;
