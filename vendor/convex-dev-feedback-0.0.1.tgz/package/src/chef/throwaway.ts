/**
 * Tokens that exist only inside one build sandbox and can't be used
 * anywhere else (docs/chef-pipeline.md, "Secrets in the agent's transcript").
 *
 * The agent tests the app against a local backend the runner starts on
 * 127.0.0.1, with an admin key the runner made and env vars (signing keys
 * for the app's auth) set to throwaway values. While testing it sees such
 * tokens: the admin key, and sign-in JWTs that backend issues. They look
 * like secrets to the scan over its transcript (agent.jsonl), which used to
 * fail the build for them. They aren't: nothing outside the sandbox accepts
 * them, and the sandbox is deleted after the run.
 *
 * So the transcript scan lets through exactly three things, and counts them:
 * - a value the runner itself made for the sandbox (`knownThrowaway`: each
 *   local backend's admin key and instance secret), or a token carrying one;
 * - a JWT whose issuer is the local backend (http://127.0.0.1, localhost):
 *   a real credential (a Convex service token, a Code Storage token, the
 *   app's own auth on its real deployment) is issued by a real host;
 * - JWT-shaped text whose payload isn't JSON (a token cut off by `slice`,
 *   `eyJ…` in base64 data, a made-up test value): no service accepts it, so
 *   it is no credential. Build #30 failed on five of these and kept nothing.
 * Everything else still fails the build: Daytona placeholders, Chef
 * credentials, provider keys, PEM keys, deploy keys, any decodable JWT from
 * another issuer or with none. Each failure says why (`tokenVerdict`),
 * never the value. The diff is scanned with no exceptions at all: a
 * throwaway token committed to the repo still fails.
 */

import type { SecretKind } from "./scrub.js";

const LOCAL_HOSTS = new Set(["127.0.0.1", "localhost", "[::1]", "::1", "0.0.0.0"]);
// What a wrapped token's line breaks look like inside a transcript (scrub.ts BRK).
const BREAKS = /(?:\r?\n|\\r\\n|\\n)[ \t>]*/g;

function base64UrlJson(segment: string): unknown {
  const b64 = segment.replace(/-/g, "+").replace(/_/g, "/");
  const pad = b64 + "=".repeat((4 - (b64.length % 4)) % 4);
  let text: string;
  if (typeof atob === "function") {
    const bin = atob(pad);
    text = new TextDecoder().decode(Uint8Array.from(bin, (c) => c.charCodeAt(0)));
  } else {
    return null;
  }
  return JSON.parse(text);
}

/** A JWT's payload object, or null when the text has none that decodes to a JSON object. */
function jwtPayload(token: string): Record<string, unknown> | null {
  try {
    const parts = token.replace(BREAKS, "").split(".");
    if (parts.length < 2) return null;
    const payload = base64UrlJson(parts[1]);
    return payload !== null && typeof payload === "object" && !Array.isArray(payload) ? (payload as Record<string, unknown>) : null;
  } catch {
    return null;
  }
}

/** A JWT's `iss`, or null when it isn't a decodable JWT with one. */
export function jwtIssuer(token: string): string | null {
  const payload = jwtPayload(token);
  return payload && typeof payload.iss === "string" ? payload.iss : null;
}

/** What the transcript scan does with one match, and why; `why` never holds the value. */
export type TokenVerdict =
  | { allow: true; as: "knownThrowaway" | "localIssuer" | "notAToken" }
  | { allow: false; why: string };

/** The issuer as safe log text: its host, or that it isn't a URL. */
function issuerText(iss: string): string {
  try {
    return `issuer ${new URL(iss).host}`;
  } catch {
    return "an issuer that isn't a URL";
  }
}

export function tokenVerdict(kind: SecretKind, value: string, knownThrowaway: readonly string[]): TokenVerdict {
  const known = knownThrowaway.filter((v) => typeof v === "string" && v.length >= 16);
  const flat = value.replace(BREAKS, "");
  if ((kind === "jwt" || kind === "convexAdminKey") && known.some((k) => flat === k || flat.includes(k))) {
    return { allow: true, as: "knownThrowaway" };
  }
  if (kind !== "jwt") return { allow: false, why: "not one of the sandbox's own values" };
  const payload = jwtPayload(flat);
  if (payload === null) return { allow: true, as: "notAToken" };
  if (typeof payload.iss !== "string") return { allow: false, why: "a JWT with no issuer" };
  if (isLocalIssuer(payload.iss)) return { allow: true, as: "localIssuer" };
  return { allow: false, why: `a JWT from ${issuerText(payload.iss)}` };
}

/** Whether `iss` is a local backend's URL: http(s) on a loopback host. */
export function isLocalIssuer(iss: string): boolean {
  try {
    const u = new URL(iss);
    return (u.protocol === "http:" || u.protocol === "https:") && LOCAL_HOSTS.has(u.hostname);
  } catch {
    return false;
  }
}

/**
 * The scan's `allow` for the agent's transcript: true only for a token the
 * sandbox made for itself (see the file comment). `knownThrowaway` are the
 * runner's own sandbox-local values, at least 16 characters each.
 */
export function throwawayAllow(knownThrowaway: readonly string[]): (kind: SecretKind, value: string) => boolean {
  return (kind, value) => tokenVerdict(kind, value, knownThrowaway).allow;
}

/** For scanSecrets' `explain`: why a match the scan refused was refused. */
export function throwawayExplain(knownThrowaway: readonly string[]): (kind: SecretKind, value: string) => string {
  return (kind, value) => {
    const v = tokenVerdict(kind, value, knownThrowaway);
    return v.allow ? "" : v.why;
  };
}
