// What the agent leaves for people besides its diff: JSON lines it appends
// to files in the chef dir, which the runner reads after the agent is dead
// and reports to the Chef agent API. Untrusted: every line is the agent's
// output. The runner parses, bounds and scrubs them here; the server checks
// the same bounds again and scrubs again with the presented credential.

export const SKILL_FEEDBACK_FILE = "skill-feedback.jsonl";

export const SKILL_FEEDBACK_KINDS = ["wrong", "missing", "outdated", "deviation"] as const;
export type SkillFeedbackKind = (typeof SKILL_FEEDBACK_KINDS)[number];

export type SkillFeedback = {
  /** The skill's name, such as `convex`, or `none`. */
  skill: string;
  kind: SkillFeedbackKind;
  message: string;
  suggestion?: string;
};

export const APPROVAL_REQUESTS_FILE = "needs-approval.jsonl";

/**
 * A step the build needs that costs money or reaches outside the app, which
 * the agent must not take itself. Approving one only records the decision.
 */
export type ApprovalRequest = {
  /** One line: what needs doing. */
  action: string;
  /** The skill that describes the step, if one does. */
  skill?: string;
  estimatedCostUsd?: number;
  why: string;
  commandOrSteps: string;
};

export const NOTE_LIMITS = {
  /** Bytes of a notes file the runner reads. */
  fileBytes: 256 * 1024,
  /** Entries reported per file. */
  entries: 50,
  skill: 100,
  action: 300,
  text: 2000,
  steps: 4000,
  /** Above this an estimate is surely wrong; refused rather than stored. */
  costUsd: 1_000_000,
};

export type Parsed<T> = { entries: T[]; invalid: number; dropped: number };

const oneLine = (s: string, max: number) => s.replace(/\s+/g, " ").trim().slice(0, max);
const text = (s: string, max: number) => s.replace(/\r\n?/g, "\n").trim().slice(0, max);

/** One entry from untrusted JSON, or null if it isn't one. */
export function skillFeedbackEntry(x: unknown, clean: (s: string) => string = (s) => s): SkillFeedback | null {
  if (!x || typeof x !== "object" || Array.isArray(x)) return null;
  const o = x as Record<string, unknown>;
  const skill = o.skill === null || o.skill === undefined ? "none" : o.skill;
  if (typeof skill !== "string" || typeof o.message !== "string") return null;
  if (typeof o.kind !== "string" || !(SKILL_FEEDBACK_KINDS as readonly string[]).includes(o.kind)) return null;
  if (o.suggestion !== undefined && o.suggestion !== null && typeof o.suggestion !== "string") return null;
  // Scrub whole, then cut, so a cut can't split a secret past recognition.
  // Plugin skills are invoked as `chef:<name>`; store the name.
  const s = oneLine(clean(skill), NOTE_LIMITS.skill).replace(/^chef:/, "") || "none";
  const message = text(clean(o.message), NOTE_LIMITS.text);
  if (message === "") return null;
  const suggestion = typeof o.suggestion === "string" ? text(clean(o.suggestion), NOTE_LIMITS.text) : "";
  return {
    skill: s,
    kind: o.kind as SkillFeedbackKind,
    message,
    ...(suggestion !== "" ? { suggestion } : {}),
  };
}

/** One approval request from untrusted JSON, or null if it isn't one. */
export function approvalRequestEntry(x: unknown, clean: (s: string) => string = (s) => s): ApprovalRequest | null {
  if (!x || typeof x !== "object" || Array.isArray(x)) return null;
  const o = x as Record<string, unknown>;
  if (typeof o.action !== "string" || typeof o.why !== "string" || typeof o.commandOrSteps !== "string") return null;
  if (o.skill !== undefined && o.skill !== null && typeof o.skill !== "string") return null;
  const cost = o.estimatedCostUsd;
  if (cost !== undefined && cost !== null) {
    if (typeof cost !== "number" || !Number.isFinite(cost) || cost < 0 || cost > NOTE_LIMITS.costUsd) return null;
  }
  const action = oneLine(clean(o.action), NOTE_LIMITS.action);
  const why = text(clean(o.why), NOTE_LIMITS.text);
  const commandOrSteps = text(clean(o.commandOrSteps), NOTE_LIMITS.steps);
  if (action === "" || commandOrSteps === "") return null;
  const skill = typeof o.skill === "string" ? oneLine(clean(o.skill), NOTE_LIMITS.skill).replace(/^chef:/, "") : "";
  return {
    action,
    ...(skill !== "" ? { skill } : {}),
    ...(typeof cost === "number" ? { estimatedCostUsd: Math.round(cost * 100) / 100 } : {}),
    why,
    commandOrSteps,
  };
}

/**
 * Parses a JSON-lines notes file with `entry`: blank lines are skipped,
 * lines that aren't a valid entry are counted, entries past the limit are
 * dropped and counted.
 */
export function parseJsonLines<T>(content: string, entry: (x: unknown) => T | null): Parsed<T> {
  const out: Parsed<T> = { entries: [], invalid: 0, dropped: 0 };
  for (const line of content.slice(0, NOTE_LIMITS.fileBytes).split("\n")) {
    if (line.trim() === "") continue;
    let x: unknown;
    try {
      x = JSON.parse(line);
    } catch {
      out.invalid++;
      continue;
    }
    const e = entry(x);
    if (!e) {
      out.invalid++;
      continue;
    }
    if (out.entries.length >= NOTE_LIMITS.entries) out.dropped++;
    else out.entries.push(e);
  }
  return out;
}
