/**
 * What Chef does about a failure (docs/chef-pipeline.md, "Recovery: one
 * table for every failure"). Every failure, of a build, a preview, a ship,
 * a warm snapshot, or one the watchdog finds, is classified once
 * (src/chef/failures.ts classifyFailure) and then goes through `recover`,
 * which looks its code up in one table and says what happens next:
 *
 * - transient: the platform's (a sandbox, the registry, a runner that went
 *   quiet). Tried again on its own with backoff, a bounded number of times.
 * - agentFixable: the change itself (a check, a guard it can undo, the
 *   frontend). The runner gives the agent fix rounds in its own session; a
 *   preview deploy that fails on the build's own code gets one follow-up
 *   build that is told why. After that, Try again.
 * - appFixable: something in the repo Chef can fix mechanically (an
 *   out-of-date lockfile, tracked symlinks or env files). A repair sandbox
 *   (no agent, fixed commands) makes a repair commit and the panel offers
 *   "Chef can fix this: ... [Apply]"; never applied without an admin.
 * - needsHuman: one line of what went wrong and the exact thing to do.
 * - security: Chef stops. No retry, no repair, no follow-up; audited.
 *
 * Pure: the component (chefRuns.finishRun), the host's steps
 * (packages/chef-cloud) and the panel share it.
 */

import { MAX_AUTO_RETRIES, RETRY_BACKOFF_MS, type FailureInfo } from "./failures.js";
import { findDeployRefusal } from "./deployChecks.js";

export type RecoveryClass = "transient" | "agentFixable" | "appFixable" | "needsHuman" | "security";

/** The mechanical repairs a repair sandbox can make (runner/chef-repair.sh). */
export type RepairKind = "lockfile" | "symlinks" | "envFiles";

/** Where the failure happened. */
export type FailureSource = "build" | "preview" | "ship" | "warm" | "watchdog";

export type RecoveryDecision =
  | { action: "retry"; class: "transient"; inMs: number; attempt: number }
  | { action: "fixRound"; class: "agentFixable"; note: string }
  | { action: "repair"; class: "appFixable"; repair: RepairKind }
  | { action: "human"; class: RecoveryClass; note: string }
  | { action: "stop"; class: "security"; note: string };

type Row = { class: RecoveryClass; note: string; repair?: RepairKind };

/**
 * The table: every failure code classifyFailure can return. A code missing
 * here is needsHuman (tests/chef/recovery.test.ts checks every code has a
 * row).
 */
export const RECOVERY_TABLE: Readonly<Record<string, Row>> = {
  // The platform's: tried again with backoff.
  sandbox: { class: "transient", note: "the sandbox provider" },
  network: { class: "transient", note: "the sandbox's network" },
  runnerLost: { class: "transient", note: "a runner that stopped answering" },
  registry: { class: "transient", note: "the npm registry" },
  previewLost: { class: "transient", note: "a preview deploy that died: deployed again" },
  // The change itself: fix rounds in the agent's session (the runner).
  gateRegression: { class: "agentFixable", note: "fix rounds with the failing check's output" },
  guards: { class: "agentFixable", note: "fix rounds with the guard's message" },
  noChanges: { class: "agentFixable", note: "a fix round asking for the change" },
  frontend: { class: "agentFixable", note: "fix rounds with the build's output" },
  previewCode: { class: "agentFixable", note: "one follow-up build told why the preview deploy failed" },
  // The repo: a repair commit, applied only by an admin.
  lockfileOutdated: { class: "appFixable", note: "regenerate the lockfile", repair: "lockfile" },
  "deployRefused:symlinks": { class: "appFixable", note: "replace tracked symlinks", repair: "symlinks" },
  "deployRefused:envFile": { class: "appFixable", note: "stop tracking env files", repair: "envFiles" },
  // A person decides, with the exact action.
  "deployRefused:convexJson": { class: "needsHuman", note: "convex.json's functions directory" },
  "deployRefused:gitDependencies": { class: "needsHuman", note: "git dependencies can't be vendored mechanically" },
  deployRefused: { class: "needsHuman", note: "the deploy refuses the repo" },
  installUnsupported: { class: "needsHuman", note: "a package manager Chef can't use" },
  installFailed: { class: "needsHuman", note: "the install failed" },
  frontendConfig: { class: "needsHuman", note: "chefCloud's frontend option" },
  mergeConflicts: { class: "needsHuman", note: "too many conflicts for a build" },
  shipMergeConflicts: { class: "needsHuman", note: "Try again rebuilds on the new main" },
  shipMergeGate: { class: "needsHuman", note: "Try again rebuilds on the new main" },
  nothingToShip: { class: "needsHuman", note: "nothing to do" },
  spendCeiling: { class: "needsHuman", note: "the spend ceiling" },
  deadline: { class: "needsHuman", note: "split the request" },
  setup: { class: "needsHuman", note: "finish setup" },
  previewDeploy: { class: "needsHuman", note: "the deploy script's reason" },
  deploymentQuota: { class: "needsHuman", note: "the Convex team is at its deployment limit: free room, then Try again" },
  shipFailed: { class: "needsHuman", note: "the ship script's reason" },
  unknown: { class: "needsHuman", note: "read the run log" },
  // Chef stops.
  guardsTamper: { class: "security", note: "a protected path or a secret: never retried" },
  egress: { class: "security", note: "the network lockdown check failed" },
};

/** The table row for a failure: deploy refusals by their kind. */
export function recoveryRow(failure: Pick<FailureInfo, "code">, errorText = ""): Row & { key: string } {
  if (failure.code === "deployRefused") {
    const r = findDeployRefusal(errorText);
    const key = r ? `deployRefused:${r.code}` : "deployRefused";
    return { key, ...(RECOVERY_TABLE[key] ?? RECOVERY_TABLE.deployRefused) };
  }
  const row = RECOVERY_TABLE[failure.code];
  return row ? { key: failure.code, ...row } : { key: failure.code, class: "needsHuman", note: "read the run log" };
}

/**
 * What happens next. `attempt` is the attempt that failed (1 for the first
 * try of an approval). `pushed`: the build already moved chef, so trying it
 * again from scratch would build on its own work; not retried. `retried`
 * says Chef already gave this failure its one follow-up (a preview
 * follow-up build): no second one.
 */
export function recover(
  failure: FailureInfo,
  o: { source: FailureSource; errorText?: string; attempt?: number; pushed?: boolean; followedUp?: boolean; enrolled?: boolean },
): RecoveryDecision {
  const row = recoveryRow(failure, o.errorText ?? "");
  const attempt = o.attempt ?? 1;
  switch (row.class) {
    case "transient":
      // A local worker (enroll) retries itself; a pushed build isn't built again.
      if (o.enrolled || o.pushed || attempt > MAX_AUTO_RETRIES) {
        return { action: "human", class: "transient", note: failure.action };
      }
      return { action: "retry", class: "transient", inMs: RETRY_BACKOFF_MS[Math.min(attempt - 1, RETRY_BACKOFF_MS.length - 1)], attempt: attempt + 1 };
    case "agentFixable":
      // The build's fix rounds already ran in its sandbox; a preview's
      // failure gets one follow-up build, once.
      if (o.source === "preview" && !o.followedUp && !o.enrolled) return { action: "fixRound", class: "agentFixable", note: row.note };
      return { action: "human", class: "agentFixable", note: failure.action };
    case "appFixable":
      return { action: "repair", class: "appFixable", repair: row.repair! };
    case "security":
      return { action: "stop", class: "security", note: failure.action };
    default:
      return { action: "human", class: "needsHuman", note: failure.action };
  }
}

/**
 * Warm snapshots' own transient policy (packages/chef-cloud chefWarm.ts):
 * any failed build is tried again after a day, three times at most, and a
 * sandbox that can't use one starts cold, so nothing waits on it.
 */
export const WARM_RECOVERY = { class: "transient" as const, retryAfterMs: 24 * 3600_000, maxAttempts: 3 };

/** A preview deploy that died for the platform's reasons is deployed again, at most this many more times. */
export const PREVIEW_REDEPLOYS = 2;
