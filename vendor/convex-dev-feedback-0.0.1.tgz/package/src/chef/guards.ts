// Guards the runner applies to the agent's work before anything is
// committed: protected paths, dependency and lockfile changes, package.json
// scripts, odd paths and modes, conflict markers left from a merge, a diff
// size limit and a secret scan. In the
// first version every violation is fatal (there is no npm egress in the
// agent phase, so a dependency change can't have been installed anyway).

import { findSecrets, type SecretKind } from "./scrub.js";
import { hasInvisible } from "./text.js";

export type ChangeStatus = "A" | "M" | "D" | "R" | "C" | "T" | "U" | "X";

export type ChangedFile = {
  status: ChangeStatus;
  path: string;
  /** For renames and copies, the source path. */
  oldPath?: string;
  /** Octal git modes, e.g. "100644", "100755", "120000" (symlink), "160000" (submodule). */
  oldMode?: string;
  newMode?: string;
};

export type ViolationKind =
  | "protectedPath"
  | "packageScripts"
  | "dependencyChange"
  | "lockfileChange"
  | "badPackageJson"
  | "suspiciousPath"
  | "specialFile"
  | "diffTooLarge"
  | "tooManyFiles"
  | "conflictMarker"
  | "secretInDiff";

export type Violation = {
  kind: ViolationKind;
  /** The file concerned, with invisible characters left as-is; display it with `revealInvisible`. */
  path?: string;
  detail: string;
};

export type GuardInput = {
  /** From `parseRawDiffZ(git diff --raw -z <base>..)` or built by hand. */
  files: ChangedFile[];
  /**
   * File contents before and after, for files the guards read: every
   * `package.json` in the change. Missing contents for a changed
   * package.json are themselves a violation.
   */
  contents?: Record<string, { before?: string; after?: string }>;
  /** The unified diff text, for the size limit and the secret scan. */
  diffText?: string;
  /**
   * Lines that look like merge conflict markers, per path, in file order:
   * what `git grep -n` with CONFLICT_MARKER_GREP finds in the changed text
   * files (and in every file a merge left conflicted). The guards decide
   * which of them are markers (conflictMarkerLines).
   */
  conflictScan?: Record<string, { line: number; text: string }[]>;
  limits?: { maxDiffBytes?: number; maxFiles?: number };
};

export type GuardResult = {
  ok: boolean;
  violations: Violation[];
  /** True if any package.json dependency field or lockfile changed. */
  depsChanged: boolean;
  /** Secret kinds and lines found by the scan; never values. */
  secrets: { kind: SecretKind; line: number }[];
};

export const DEFAULT_LIMITS = { maxDiffBytes: 2_000_000, maxFiles: 300 };

/** Directory prefixes the agent may not touch. Compared lowercased. */
const PROTECTED_DIRS = [
  ".github/",
  "scripts/",
  "runner/",
  ".claude/",
  ".husky/",
  ".git/",
  ".devcontainer/",
  ".vscode/",
];

/** Exact paths (lowercased) the agent may not touch. */
const PROTECTED_FILES = new Set([
  "convex.json",
  "convex/chefpipeline.ts",
  "convex/convex.config.ts",
  ".npmrc",
  ".yarnrc",
  ".yarnrc.yml",
  ".nvmrc",
  ".node-version",
  ".gitmodules",
  ".gitattributes",
]);

/** File names protected wherever they appear. */
const PROTECTED_BASENAMES = new Set([
  "ship.sh",
  "chef-runner.mjs",
  "chef-preview-deploy.sh",
  "chef-release.mjs",
  ".npmrc",
  ".gitattributes",
]);

export const LOCKFILES = new Set([
  "package-lock.json",
  "npm-shrinkwrap.json",
  "yarn.lock",
  "pnpm-lock.yaml",
  "bun.lock",
  "bun.lockb",
]);

const DEPENDENCY_FIELDS = [
  "dependencies",
  "devDependencies",
  "peerDependencies",
  "optionalDependencies",
  "bundleDependencies",
  "bundledDependencies",
  "peerDependenciesMeta",
  "overrides",
  "resolutions",
  "workspaces",
  "packageManager",
  "pnpm",
  "engines",
];

/** Fields that run code or change what runs: lifecycle scripts, bins, config. */
const SCRIPT_FIELDS = ["scripts", "bin", "config", "gypfile"];

/**
 * An extended regex (git grep -E) for every line that could be a conflict
 * marker: `<<<<<<< `, `||||||| `, `>>>>>>> ` (with a label or alone) and a
 * bare `=======`. A superset; conflictMarkerLines decides.
 */
export const CONFLICT_MARKER_GREP =
  "^(<<<<<<<|>>>>>>>|[|][|][|][|][|][|][|])( |$)|^=======[[:space:]]*$";

const OPEN_MARKER = /^<{7}( |\r?$)/;
const CLOSE_MARKER = /^>{7}( |\r?$)/;
const MIDDLE_MARKER = /^(={7}\s*|\|{7}( .*|\r?))$/;

/**
 * The line numbers of conflict markers among these lines (in file order;
 * other lines may be left out). `<<<<<<< ` and `>>>>>>> ` lines count
 * anywhere; `=======` and `||||||| ` only between an opening marker and its
 * close, since `=======` alone is ordinary text (a Markdown underline).
 */
export function conflictMarkerLines(lines: readonly { line: number; text: string }[]): number[] {
  const out: number[] = [];
  let open = false;
  for (const l of lines) {
    if (OPEN_MARKER.test(l.text)) {
      out.push(l.line);
      open = true;
    } else if (CLOSE_MARKER.test(l.text)) {
      out.push(l.line);
      open = false;
    } else if (open && MIDDLE_MARKER.test(l.text)) {
      out.push(l.line);
    }
  }
  return out;
}

/** conflictMarkerLines over a whole text, lines numbered from 1. */
export function findConflictMarkers(text: string): number[] {
  return conflictMarkerLines(text.split("\n").map((t, i) => ({ line: i + 1, text: t })));
}

/**
 * Parses `git grep -n -z` output, `<path>\0<line>\0<text>\n` per match,
 * into lines per path. The path ends at the first NUL, so a newline in it
 * can't shift the rest.
 */
export function parseGrepZ(out: string): Record<string, { line: number; text: string }[]> {
  const res: Record<string, { line: number; text: string }[]> = {};
  let i = 0;
  while (i < out.length) {
    const a = out.indexOf("\0", i);
    if (a < 0) break;
    const b = out.indexOf("\0", a + 1);
    if (b < 0) throw new Error("truncated grep output");
    let c = out.indexOf("\n", b + 1);
    if (c < 0) c = out.length;
    const path = out.slice(i, a);
    const line = Number(out.slice(a + 1, b));
    if (!Number.isSafeInteger(line) || line <= 0) throw new Error("unparseable grep output");
    (res[path] ??= []).push({ line, text: out.slice(b + 1, c) });
    i = c + 1;
  }
  return res;
}

function basename(p: string): string {
  return p.slice(p.lastIndexOf("/") + 1);
}

/** Why a path is protected, or null. Case-insensitive (Seth's Mac is). */
export function protectedReason(path: string): string | null {
  const p = path.normalize("NFC").toLowerCase();
  const base = basename(p);
  for (const d of PROTECTED_DIRS) {
    if (p.startsWith(d) || p.includes(`/${d}`)) return `under ${d}`;
  }
  if (PROTECTED_FILES.has(p)) return "protected file";
  // It mounts the /chef-agent routes. Checking only the lines that mention
  // them is bypassable (comment the call out, alias it), so in this version
  // any change to the file is refused.
  if (p === "convex/http.ts") return "convex/http.ts mounts the Chef routes";
  if (PROTECTED_BASENAMES.has(base)) return `protected file name ${base}`;
  // `.env`, `.env.local`, `.envrc` and anything else starting `.env`, at any depth.
  if (base.startsWith(".env")) return "env file";
  if (/^convex\/auth[^/]*\.ts$/.test(p)) return "Convex auth config";
  return null;
}

/**
 * Why a merge conflict at this path is resolved by taking main's side
 * rather than left to the agent, or null: any path the guards protect, and
 * package.json and lockfiles, whose dependency and script fields the agent
 * may not change. main is the human-maintained base, so its side wins.
 */
export function mergeTakesMain(path: string): string | null {
  const reason = protectedReason(path);
  if (reason) return reason;
  const base = basename(path.normalize("NFC").toLowerCase());
  if (LOCKFILES.has(base)) return "lockfile";
  if (base === "package.json") return "package.json";
  return null;
}

/** Why a path looks crafted to mislead, or null. */
export function suspiciousPathReason(path: string): string | null {
  if (path === "") return "empty path";
  if (hasInvisible(path)) return "invisible or bidi characters";
  if (/\p{Cc}/u.test(path)) return "control characters";
  if (path.startsWith("/")) return "absolute path";
  if (path.includes("\\")) return "backslash";
  if (path.split("/").some((s) => s === ".." || s === "." || s === "")) {
    return "dot or empty segment";
  }
  if (path.normalize("NFC") !== path) return "not NFC normalized";
  return null;
}

/**
 * Parses `git diff --raw -z --no-renames`-or-with-renames output:
 * `:<old mode> <new mode> <old sha> <new sha> <status>\0<path>\0` and, for
 * renames and copies, a second path. Paths arrive verbatim (no quoting).
 */
export function parseRawDiffZ(out: string): ChangedFile[] {
  const fields = out.split("\0");
  const files: ChangedFile[] = [];
  let i = 0;
  while (i < fields.length) {
    const head = fields[i].replace(/^\n+/, "");
    if (head === "") {
      i++;
      continue;
    }
    const m = /^:(\d{6}) (\d{6}) [0-9a-f]+ [0-9a-f]+ ([AMDRCTUX])\d*$/.exec(head);
    if (!m) throw new Error(`unparseable raw diff entry at field ${i}`);
    const status = m[3] as ChangeStatus;
    if (status === "R" || status === "C") {
      const oldPath = fields[i + 1];
      const path = fields[i + 2];
      if (oldPath === undefined || path === undefined) {
        throw new Error("truncated raw diff");
      }
      files.push({ status, oldPath, path, oldMode: m[1], newMode: m[2] });
      i += 3;
    } else {
      const path = fields[i + 1];
      if (path === undefined) throw new Error("truncated raw diff");
      files.push({ status, path, oldMode: m[1], newMode: m[2] });
      i += 2;
    }
  }
  return files;
}

function parseJsonObject(text: string): Record<string, unknown> | null {
  try {
    const v: unknown = JSON.parse(text);
    return v && typeof v === "object" && !Array.isArray(v)
      ? (v as Record<string, unknown>)
      : null;
  } catch {
    return null;
  }
}

/** Order-insensitive deep equality for JSON values. */
function sameJson(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b || a === null || b === null) return false;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) {
      return false;
    }
    return a.every((x, i) => sameJson(x, b[i]));
  }
  if (typeof a === "object") {
    const ao = a as Record<string, unknown>;
    const bo = b as Record<string, unknown>;
    const keys = new Set([...Object.keys(ao), ...Object.keys(bo)]);
    for (const k of keys) {
      if (!Object.hasOwn(ao, k) || !Object.hasOwn(bo, k)) return false;
      if (!sameJson(ao[k], bo[k])) return false;
    }
    return true;
  }
  return false;
}

/** Field names that differ between two package.json texts. */
export function packageJsonChanges(
  before: string | undefined,
  after: string | undefined,
): { dependencyFields: string[]; scriptFields: string[]; invalid: boolean } {
  const b = before === undefined ? {} : parseJsonObject(before);
  const a = after === undefined ? {} : parseJsonObject(after);
  if (!a || !b) return { dependencyFields: [], scriptFields: [], invalid: true };
  const changed = (f: string) => !sameJson(b[f], a[f]);
  return {
    dependencyFields: DEPENDENCY_FIELDS.filter(changed),
    scriptFields: SCRIPT_FIELDS.filter(changed),
    invalid: false,
  };
}

/** Runs every guard. `ok` is true only with no violations. */
export function checkGuards(input: GuardInput): GuardResult {
  const limits = { ...DEFAULT_LIMITS, ...input.limits };
  const contents = input.contents ?? {};
  const violations: Violation[] = [];
  let depsChanged = false;

  if (input.files.length > limits.maxFiles) {
    violations.push({
      kind: "tooManyFiles",
      detail: `${input.files.length} files changed, limit ${limits.maxFiles}`,
    });
  }

  for (const f of input.files) {
    const paths = f.oldPath !== undefined ? [f.oldPath, f.path] : [f.path];
    for (const path of paths) {
      const odd = suspiciousPathReason(path);
      if (odd) violations.push({ kind: "suspiciousPath", path, detail: odd });
      const reason = protectedReason(path);
      if (reason) violations.push({ kind: "protectedPath", path, detail: reason });
      if (LOCKFILES.has(basename(path).toLowerCase())) {
        depsChanged = true;
        violations.push({
          kind: "lockfileChange",
          path,
          detail: "lockfile changed; dependencies can't change in this version",
        });
      }
    }

    for (const mode of [f.oldMode, f.newMode]) {
      if (mode === "120000") {
        violations.push({ kind: "specialFile", path: f.path, detail: "symlink" });
      } else if (mode === "160000") {
        violations.push({ kind: "specialFile", path: f.path, detail: "submodule" });
      }
    }
    if (f.status === "T" || f.status === "U" || f.status === "X") {
      violations.push({
        kind: "specialFile",
        path: f.path,
        detail: `unexpected change status ${f.status}`,
      });
    }

    for (const path of paths) {
      const lower = path.toLowerCase();
      if (basename(lower) === "package.json") {
        const c = contents[path];
        const needBefore = f.status !== "A" && !(f.status === "R" && path === f.path);
        const needAfter = f.status !== "D" && !(f.status === "R" && path === f.oldPath);
        if (!c || (needBefore && c.before === undefined) || (needAfter && c.after === undefined)) {
          violations.push({
            kind: "badPackageJson",
            path,
            detail: "contents not provided to the guard",
          });
          continue;
        }
        const ch = packageJsonChanges(
          needBefore ? c.before : undefined,
          needAfter ? c.after : undefined,
        );
        if (ch.invalid) {
          violations.push({ kind: "badPackageJson", path, detail: "not a JSON object" });
          continue;
        }
        if (ch.dependencyFields.length > 0) {
          depsChanged = true;
          violations.push({
            kind: "dependencyChange",
            path,
            detail: `changed: ${ch.dependencyFields.join(", ")}`,
          });
        }
        if (ch.scriptFields.length > 0) {
          violations.push({
            kind: "packageScripts",
            path,
            detail: `changed: ${ch.scriptFields.join(", ")}`,
          });
        }
      }
    }
  }

  for (const [path, lines] of Object.entries(input.conflictScan ?? {})) {
    const at = conflictMarkerLines(lines);
    if (at.length > 0) {
      const shown = at.slice(0, 10).join(", ") + (at.length > 10 ? ", ..." : "");
      violations.push({
        kind: "conflictMarker",
        path,
        detail: `merge conflict markers left on line${at.length > 1 ? "s" : ""} ${shown}`,
      });
    }
  }

  let secrets: GuardResult["secrets"] = [];
  if (input.diffText !== undefined) {
    const bytes = new TextEncoder().encode(input.diffText).length;
    if (bytes > limits.maxDiffBytes) {
      violations.push({
        kind: "diffTooLarge",
        detail: `diff is ${bytes} bytes, limit ${limits.maxDiffBytes}`,
      });
    }
    // Only added lines count: removing a leaked secret is fine.
    const added = input.diffText
      .split("\n")
      .map((l) => (l.startsWith("+") && !l.startsWith("+++") ? l.slice(1) : ""))
      .join("\n");
    secrets = findSecrets(added);
    for (const s of secrets) {
      violations.push({
        kind: "secretInDiff",
        detail: `${s.kind} on diff line ${s.line}`,
      });
    }
  }

  return { ok: violations.length === 0, violations, depsChanged, secrets };
}
