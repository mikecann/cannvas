/**
 * Why a run failed, in one line a person can act on, and whether trying
 * again could help (docs/chef-pipeline.md, "When a build fails").
 *
 * Every failed run's error (the runner's status, a workflow step's, the
 * reconciler's) goes through `classifyFailure`. `transient` failures are
 * the platform's: a sandbox that didn't start, a registry or proxy that
 * didn't answer, a runner that went quiet. Chef tries those again on its
 * own, a bounded number of times (chefRuns.finishRun). `deterministic` ones
 * come from the app or the request (an out-of-date lockfile, a check the
 * change broke, the agent giving up): the same build would fail the same
 * way, so they wait for a person, with what to do. `environmental` ones are
 * neither the platform's blip nor the app's code: the Convex team is out of
 * room for another deployment. Trying again on its own can't help and
 * nothing in the repo needs fixing; a person frees room, then Try again.
 *
 * Pure, shared by the component and the clients. The error is untrusted
 * text (already scrubbed); only fixed strings and short extracts of it
 * (a gate's command, a pnpm code) reach the reason.
 */

import { deployRefusalAction, findDeployRefusal } from "./deployChecks.js";

export type FailureKind = "transient" | "deterministic" | "environmental";

export type FailureInfo = {
  /** Stable, for code: lockfileOutdated, gateRegression, sandbox, ... */
  code: string;
  kind: FailureKind;
  /** One line: what went wrong. */
  reason: string;
  /** One line: what to do about it. */
  action: string;
};

/** How many times a transient failure is tried again before it is left failed. */
export const MAX_AUTO_RETRIES = 2;
/** The wait before each automatic retry: 1 minute, then 5. */
export const RETRY_BACKOFF_MS: readonly number[] = [60_000, 5 * 60_000];

const TRY_AGAIN = "Press Try again.";

// A transient cause anywhere in the text: a network error, a gateway or
// provider status, Daytona, a runner that stopped answering.
const NETWORK =
  /\b(ECONNRESET|ECONNREFUSED|ETIMEDOUT|EAI_AGAIN|ENOTFOUND|EPIPE|ENETUNREACH|socket hang up|fetch failed|network (error|timeout)|getaddrinfo|ERR_PNPM_META_FETCH_FAIL|ERR_PNPM_FETCH_\w+|ERR_PNPM_TARBALL_\w+|ERR_SOCKET_TIMEOUT|EINTEGRITY)\b/i;
const PROVIDER =
  /\b(daytona|sandbox (create|start|didn't start|failed to start)|gateway|rate limit(ed)?|too many requests|service unavailable|bad gateway|gateway timeout|internal server error)\b|\b(429|500|502|503|504)\b/i;

/** The Convex team is at its deployment limit (the CLI's DeploymentQuotaReached). */
const DEPLOYMENT_QUOTA = /DeploymentQuotaReached|deployment quota/i;

/** The command in "gate failed: <argv>[ (...)]". */
function gateCommand(error: string): string | null {
  const m = /gate failed: ([^\n(]{1,200})/.exec(error);
  return m ? m[1].trim() : null;
}

/** The first line, trimmed and cut, for an unknown failure's reason. */
function firstLine(error: string): string {
  const line = error.split("\n").map((l) => l.trim()).find((l) => l !== "") ?? "";
  const cut = line.replace(/^the runner failed in \w+: /, "");
  return cut.length > 200 ? `${cut.slice(0, 197)}...` : cut;
}

/**
 * The failure, classified. Order matters: the app's own problems are
 * checked first, so a gate's output that happens to mention ECONNRESET is
 * still the gate's failure.
 */
export function classifyFailure(error: string | null | undefined): FailureInfo {
  const e = String(error ?? "");
  const pnpm = /pnpm-lock|ERR_PNPM|pnpm/i.test(e);

  // Something in the repo the deploy scripts refuse (src/chef/deployChecks.ts):
  // the runner's check right after the clone, or a deploy script's own.
  const refusal = findDeployRefusal(e);
  if (refusal) {
    return {
      code: "deployRefused",
      kind: "deterministic",
      reason: `The preview deploy refuses this repo: ${refusal.message}.`,
      action: deployRefusalAction(refusal.code, refusal.paths),
    };
  }

  // The Convex team has no room for another deployment: the CLI's
  // `claim_preview_deployment 400 Bad Request: DeploymentQuotaReached: Your
  // team's deployment quota of 300 has been reached.` Not the build's code
  // and not main's, so nothing to fix there; the room has to be made.
  if (DEPLOYMENT_QUOTA.test(e)) {
    const limit = /deployment quota of (\d{1,7})/i.exec(e)?.[1];
    return {
      code: "deploymentQuota",
      kind: "environmental",
      reason: `Your Convex team has no room for another preview (it's at its deployment limit${limit ? ` of ${limit}` : ""}).`,
      action: "Delete old projects or previews in the Convex dashboard, or raise the team's limit, then Try again.",
    };
  }

  // The lockfile doesn't match package.json: npm ci's EUSAGE, pnpm's frozen install.
  if (/ERR_PNPM_OUTDATED_LOCKFILE|ERR_PNPM_LOCKFILE_CONFIG_MISMATCH|lockfile is not up to date|can only install packages when your package\.json and package-lock\.json/i.test(e)) {
    return {
      code: "lockfileOutdated",
      kind: "deterministic",
      reason: pnpm ? "Lockfile out of date: pnpm-lock.yaml doesn't match package.json." : "Lockfile out of date: package-lock.json doesn't match package.json.",
      action: pnpm
        ? "Run `pnpm install` and commit pnpm-lock.yaml (`npx chef sync` checks it), then Try again."
        : "Run `npm install` and commit package-lock.json (`npx chef sync` checks it), then Try again.",
    };
  }
  // The install plan refused the checkout (runner/chef-install.mjs): yarn, bun, no lockfile, git deps.
  if (/install failed: (no lockfile|[\w.-]+\.lock\w*: Chef's sandboxes|pnpm-lock\.yaml has git|pnpm-workspace\.yaml has configDependencies|package\.json's packageManager)/i.test(e)) {
    return {
      code: "installUnsupported",
      kind: "deterministic",
      reason: `Chef can't install this app: ${firstLine(e).replace(/^.*?install failed: /, "")}`,
      action: "Run `npx chef init --cloud` for the fix, commit it, then Try again.",
    };
  }
  if (/install failed/i.test(e) && NETWORK.test(e)) {
    return {
      code: "registry",
      kind: "transient",
      reason: "The npm registry didn't answer while installing the app's dependencies.",
      action: `Chef tries again on its own; if it keeps failing, ${TRY_AGAIN.toLowerCase()}`,
    };
  }
  if (/install failed/i.test(e)) {
    return {
      code: "installFailed",
      kind: "deterministic",
      reason: "Installing the app's dependencies failed.",
      action: "Check that a clean install works (`npx chef sync` runs the same check), then Try again; the run log has the installer's error.",
    };
  }
  if (/gate failed after merging main: /i.test(e)) {
    const m = /gate failed after merging main: ([^\n(]{1,200})/.exec(e);
    // Only what the merge added fails it (main's own failures don't): which files.
    const newIn = /\(new problems in ([^)\n]{1,300})\)/.exec(e)?.[1];
    return {
      code: "shipMergeGate",
      kind: "deterministic",
      reason: `Main moved since this build, and ${m ? `\`${m[1].trim()}\`` : "a check"} fails once it is merged in${
        newIn ? `: new problems in ${newIn}` : ""
      }.`,
      action: "Try again: Chef rebuilds the request on the new main, and its agent fixes it.",
    };
  }
  if (/gate failed/i.test(e)) {
    const cmd = gateCommand(e);
    const exhausted = /fix rounds?/i.test(e);
    return {
      code: "gateRegression",
      kind: "deterministic",
      reason: `${cmd ? `\`${cmd}\`` : "A check"} passed before this build and fails after it${exhausted ? ", even after Chef's fix rounds" : ""}.`,
      action: "Read the check's output in the run log. Make the request more specific (or fix the check on main), then Try again.",
    };
  }
  // The frontend build: one that never reads the Convex URL variable is the
  // host's config; any other failure is the change's.
  if (/failed in frontend|frontend build failed|^frontend: /im.test(e)) {
    if (/never uses|never read/i.test(e)) {
      return {
        code: "frontendConfig",
        kind: "deterministic",
        reason: "The app's frontend build never reads the Convex URL variable Chef sets.",
        action: "Set chefCloud's `frontend` option to the app's build command, URL variable and output directory, deploy, then Try again.",
      };
    }
    return {
      code: "frontend",
      kind: "deterministic",
      reason: "The app's frontend didn't build with this change.",
      action: "Read the build's output in the run log; make the request more specific, then Try again.",
    };
  }
  if (/the agent changed nothing/i.test(e)) {
    return {
      code: "noChanges",
      kind: "deterministic",
      reason: "The agent finished without changing anything.",
      action: "Read its summary in the run log; make the request more specific, then Try again.",
    };
  }
  // A guard that only an attempt to get around the rules trips: a protected
  // path, package.json scripts, an odd or special file, a secret in the diff.
  if (/guards failed: (protectedPath|packageScripts|suspiciousPath|specialFile|secretInDiff)\b|guards failed: .*; (protectedPath|packageScripts|suspiciousPath|specialFile|secretInDiff)\b/i.test(e)) {
    return {
      code: "guardsTamper",
      kind: "deterministic",
      reason: /secretInDiff/i.test(e)
        ? "The change contained something that looks like a secret, so Chef stopped and kept nothing."
        : "The change touched files a build may never change, so Chef stopped and kept nothing.",
      action: "Read the guard's message in the run log. Chef won't retry or repair this on its own; change the request, then Try again.",
    };
  }
  if (/guards failed/i.test(e)) {
    const what = /dependency|lockfile|depsChanged/i.test(e)
      ? "added or changed a dependency, which builds can't do yet"
      : /secret/i.test(e)
        ? "contained something that looks like a secret"
        : /conflict marker/i.test(e)
          ? "left merge conflict markers"
          : "touched files a build may not change";
    return {
      code: "guards",
      kind: "deterministic",
      reason: `The change ${what}, so Chef didn't keep it.`,
      action: "Read the guard's message in the run log; change the request (or make that change yourself on main), then Try again.",
    };
  }
  // A merge-only build (main moved before Ship it) that couldn't merge.
  if (/main doesn't merge cleanly into this build/i.test(e)) {
    const files = /into this build \(([^)]{1,300})\)/.exec(e)?.[1];
    return {
      code: "shipMergeConflicts",
      kind: "deterministic",
      reason: `Main moved since this build, and it doesn't merge cleanly${files ? ` (${files})` : ""}.`,
      action: "Try again: Chef rebuilds the request on the new main, and its agent resolves the conflicts.",
    };
  }
  if (/nothing to ship: main already has everything chef has/i.test(e)) {
    return {
      code: "nothingToShip",
      kind: "deterministic",
      reason: "Main already has everything this build would ship.",
      action: "Nothing to do.",
    };
  }
  if (/needs_attention: chef doesn't merge main cleanly/i.test(e)) {
    return {
      code: "mergeConflicts",
      kind: "deterministic",
      reason: "main and chef conflict in too many files for a build to resolve.",
      action: "Merge chef into main yourself (`git pull chef chef`), push, then Try again.",
    };
  }
  if (/egress self-test failed/i.test(e)) {
    return {
      code: "egress",
      kind: "deterministic",
      reason: "The sandbox's network lockdown check failed, so Chef stopped before anything ran.",
      action: "Nothing was exposed. Try again; if it repeats, the sandbox image's network settings need a look.",
    };
  }
  if (/spend ceiling|inference spend/i.test(e)) {
    return {
      code: "spendCeiling",
      kind: "deterministic",
      reason: "The build reached its spend cap.",
      action: "Split the request into smaller ones, or raise the cap, then Try again.",
    };
  }
  if (/past deadline|passed its deadline|took too long/i.test(e)) {
    return {
      code: "deadline",
      kind: "deterministic",
      reason: "The build ran out of time.",
      action: "Split the request into smaller ones, then Try again.",
    };
  }
  if (/chefSetup|isn't set up|aren't set up|not set up|CONVEX_SITE_URL is not set|no repo on Code Storage/i.test(e)) {
    return {
      code: "setup",
      kind: "deterministic",
      reason: "Cloud builds aren't fully set up on this deployment.",
      action: "Run `npx chef init --cloud`, then Try again.",
    };
  }
  if (/egress|proxy|credential never went live|git host wasn't reachable|wasn't reachable within/i.test(e)) {
    return {
      code: "network",
      kind: "transient",
      reason: "The sandbox's network didn't come up in time.",
      action: `Chef tries again on its own; if it keeps failing, ${TRY_AGAIN.toLowerCase()}`,
    };
  }
  if (/stale: no heartbeat|runner exited|self-test never reported|never reached pushed|preview deploy never finished/i.test(e)) {
    return {
      code: "runnerLost",
      kind: "transient",
      reason: "The build sandbox stopped answering.",
      action: `Chef tries again on its own; if it keeps failing, ${TRY_AGAIN.toLowerCase()}`,
    };
  }
  // The preview deploy script stopped, with its own reason (the launcher
  // reads it from the script's result and log; docs, "When a build fails").
  const deploy = /Preview deploy failed: (.+)/.exec(e);
  // A script that died with no result at all (killed, out of memory): the
  // platform's, so the deploy is tried again.
  if (deploy && /exited \([^)]*\) without a result/i.test(deploy[1])) {
    return {
      code: "previewLost",
      kind: "transient",
      reason: "The preview deploy stopped without saying why.",
      action: `Chef deploys the preview again on its own; if it keeps failing, ${TRY_AGAIN.toLowerCase()}`,
    };
  }
  // The build's own code doesn't deploy (a module that throws, a bad
  // import, a schema that doesn't validate): the agent can fix that.
  if (deploy && previewFailureIsCode(deploy[1])) {
    const why = deploy[1].trim();
    return {
      code: "previewCode",
      kind: "deterministic",
      reason: `The preview deploy failed on this build's code: ${why.length > 300 ? `${why.slice(0, 297)}...` : why}`,
      action: "Chef gives the request one follow-up build that is told why; if that fails too, Try again.",
    };
  }
  if (deploy && !NETWORK.test(e) && !PROVIDER.test(e)) {
    const why = deploy[1].trim();
    return {
      code: "previewDeploy",
      kind: "deterministic",
      reason: `The preview deploy failed: ${why.length > 300 ? `${why.slice(0, 297)}...` : why}`,
      action: "Read the deploy script's last lines in the run log; fix what they say on main and `npx chef sync`, then Try again.",
    };
  }
  if (NETWORK.test(e) || PROVIDER.test(e)) {
    return {
      code: "sandbox",
      kind: "transient",
      reason: "The sandbox provider had a problem.",
      action: `Chef tries again on its own; if it keeps failing, ${TRY_AGAIN.toLowerCase()}`,
    };
  }
  const line = firstLine(e);
  return {
    code: "unknown",
    kind: "deterministic",
    reason: line ? `The build failed: ${line}` : "The build failed.",
    action: `Open the run log for details, then ${TRY_AGAIN.charAt(0).toLowerCase()}${TRY_AGAIN.slice(1)}`,
  };
}

/** The reason and what to do, as one line. */
export function failureLine(f: FailureInfo): string {
  return `${f.reason} ${f.action}`;
}

/**
 * A preview deploy's failure that came from the build's own code, as the
 * Convex CLI reports it while it pushes or analyses the functions (a
 * module that throws, a bad import, a schema that doesn't validate): the
 * agent can fix that. Anything about keys, refusals or env vars is not.
 */
export function previewFailureIsCode(reason: string): boolean {
  return (
    /(Uncaught|TypeError|ReferenceError|SyntaxError|Could not resolve|Failed to analyze|InvalidModules)/.test(reason) &&
    !/deploy key|refusing to deploy|MissingEnvironmentVariables/i.test(reason)
  );
}
