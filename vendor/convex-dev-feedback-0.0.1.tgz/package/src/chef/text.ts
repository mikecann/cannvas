// Shared text helpers for the Chef pipeline. Pure functions, no Convex
// imports, so the runner, the workflow and the panel can all use them.

/**
 * Characters that change how text is displayed without being visible:
 * bidi embeddings, overrides and isolates, zero-width spaces and joiners,
 * the word joiner, invisible math operators, the BOM and the soft hyphen.
 */
const INVISIBLE_SOURCE =
  "[\\u00AD\\u061C\\u180E\\u200B-\\u200F\\u202A-\\u202E\\u2060-\\u2064\\u2066-\\u2069\\uFEFF]";

/** A fresh global regex for invisible characters (no shared lastIndex). */
export function invisibleCharsRegex(): RegExp {
  return new RegExp(INVISIBLE_SOURCE, "g");
}

/** C0 and C1 control characters other than tab and newline. */
const CONTROL_CHARS = /(?![\t\n])\p{Cc}/gu;

function codePointLabel(ch: string): string {
  return `<U+${ch.codePointAt(0)!.toString(16).toUpperCase().padStart(4, "0")}>`;
}

/**
 * Replaces invisible and direction-changing characters with visible
 * `<U+XXXX>` markers, so hidden text can't hide. Other text is unchanged.
 */
export function revealInvisible(s: string): string {
  return s.replace(invisibleCharsRegex(), codePointLabel);
}

/** True if `s` holds any invisible or direction-changing character. */
export function hasInvisible(s: string): boolean {
  return new RegExp(INVISIBLE_SOURCE).test(s);
}

/**
 * Normalizes line endings to `\n`, reveals invisible characters and marks
 * other control characters (tab and newline are kept).
 */
export function cleanMultiline(s: string): string {
  return revealInvisible(s.replace(/\r\n?/g, "\n")).replace(
    CONTROL_CHARS,
    codePointLabel,
  );
}

/**
 * One line of display text: invisible characters revealed, every run of
 * whitespace (including newlines and Unicode line separators) collapsed to
 * one space, controls marked, trimmed and cut to `max` characters.
 */
export function singleLine(s: string, max: number): string {
  const flat = revealInvisible(s)
    .replace(/[\s\u0085]+/g, " ")
    .replace(CONTROL_CHARS, codePointLabel)
    .trim();
  return truncate(flat, max);
}

/** Cuts `s` to at most `max` characters (code points), adding an ellipsis. */
export function truncate(s: string, max: number): string {
  const chars = Array.from(s);
  if (chars.length <= max) return s;
  return chars.slice(0, Math.max(0, max - 1)).join("") + "…";
}
