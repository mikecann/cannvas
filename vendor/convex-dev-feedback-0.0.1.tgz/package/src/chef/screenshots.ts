// Screenshots of the built app (docs/chef-pipeline.md, "Screenshots"). Pure
// checks shared by the screenshot helper (runner/chef-screenshot.mjs), the
// runner (runner/screenshots.ts) and the component (chefScreenshots.ts):
// the plan file the agent writes, page names and paths, and PNG headers.
//
// Everything here reads untrusted input: the plan is the agent's, and the
// PNG bytes come from a browser rendering the agent's app.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

/** In the chef dir, written by the agent: which pages to screenshot, and the seed. */
export const SCREENSHOT_PLAN_FILE = "screenshot-plan.json";

export const SCREENSHOT_LIMITS = {
  /** Pages per run. */
  pages: 8,
  /** Bytes of one PNG. */
  fileBytes: 2 * 1024 * 1024,
  /** Bytes of all of a run's PNGs together. */
  totalBytes: 10 * 1024 * 1024,
  /** Bytes of the plan file the runner reads. */
  planBytes: 16 * 1024,
  /** Width or height above this is not a screenshot we took. */
  maxDimension: 16384,
  path: 300,
  waitFor: 200,
};

/** A page's name: its file name and its key, unique per run. */
const NAME = /^[a-z0-9][a-z0-9-]{0,39}$/;
/** A path on the app: printable ASCII, no spaces or backslashes, not `//host`. */
const PATH = /^\/(?!\/)[\x21-\x7e]*$/;
/** A Convex function name, as `npx convex run` takes it (and CHEF_SEED in chef-preview-deploy.sh). */
const FUNCTION = /^[A-Za-z0-9_][A-Za-z0-9_./]*(:[A-Za-z0-9_]+)?$/;
/** A selector: printable ASCII and spaces, nothing else. */
const SELECTOR = /^[\x20-\x7e]+$/;
/** The app's sign-in link function (chefCloud's `previewLoginFunction`): `module:function`. */
export const LOGIN_FUNCTION = /^[A-Za-z0-9_]+(\/[A-Za-z0-9_]+)*:[A-Za-z_][A-Za-z0-9_]*$/;

/**
 * `signedIn: false` screenshots the page signed out, when the app has a
 * sign-in link function. `steps`: demo-script steps (src/chef/demo.ts) played
 * on the page before the screenshot, to show something behind a click (a
 * panel, a dialog), as checked by the caller's `checkSteps`.
 */
export type ScreenshotPage = { path: string; name: string; waitFor?: string; signedIn?: boolean; steps?: unknown[] };
export type ScreenshotPlan = { seed?: string; pages: ScreenshotPage[] };

/** Steps per screenshot: enough to open a panel and get to a state, no more. */
export const SCREENSHOT_PAGE_STEPS = 10;

/**
 * Checks a page's `steps` (this module has no imports, so the demo script's
 * parser comes in from the caller). Returns the checked steps, or why not.
 */
export type CheckSteps = (raw: unknown[]) => { steps: unknown[] } | { problem: string };

export const DEFAULT_SCREENSHOT_PAGES: readonly ScreenshotPage[] = [{ path: "/", name: "home" }];

export function isScreenshotName(s: unknown): s is string {
  return typeof s === "string" && NAME.test(s);
}

export function isScreenshotPath(s: unknown): s is string {
  return typeof s === "string" && s.length <= SCREENSHOT_LIMITS.path && PATH.test(s) && !s.includes("\\");
}

export function isWaitForSelector(s: unknown): s is string {
  return typeof s === "string" && s.trim() !== "" && s.length <= SCREENSHOT_LIMITS.waitFor && SELECTOR.test(s);
}

export function isSeedFunction(s: unknown): s is string {
  return typeof s === "string" && s.length <= 200 && FUNCTION.test(s) && !s.split(/[/:]/).includes("..");
}

/**
 * The plan from the agent's `screenshot-plan.json`: either a list of pages,
 * `[{"path": "/", "name": "home", "waitFor": "text=Tasks"}]`, or
 * `{"seed": "seed:demo", "pages": [...]}`. Bad entries are skipped and
 * named in `problems`; duplicate names keep the first; at most 8 pages. An
 * empty or missing plan, or one with no good page, is the home page.
 */
export function parseScreenshotPlan(text: string, checkSteps?: CheckSteps): { plan: ScreenshotPlan; problems: string[] } {
  const problems: string[] = [];
  const fallback = () => ({ plan: { pages: [...DEFAULT_SCREENSHOT_PAGES] }, problems });
  if (text.trim() === "") return fallback();
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    problems.push("the plan is not JSON");
    return fallback();
  }
  let pagesRaw: unknown;
  let seed: string | undefined;
  if (Array.isArray(raw)) {
    pagesRaw = raw;
  } else if (raw && typeof raw === "object") {
    const o = raw as Record<string, unknown>;
    pagesRaw = o.pages ?? [];
    if (o.seed !== undefined && o.seed !== null && o.seed !== "") {
      if (isSeedFunction(o.seed)) seed = o.seed;
      else problems.push("seed is not a Convex function name");
    }
  } else {
    problems.push("the plan must be a list of pages or an object with pages");
    return fallback();
  }
  if (!Array.isArray(pagesRaw)) {
    problems.push("pages must be a list");
    pagesRaw = [];
  }
  const pages: ScreenshotPage[] = [];
  const seen = new Set<string>();
  (pagesRaw as unknown[]).forEach((x, i) => {
    if (!x || typeof x !== "object" || Array.isArray(x)) return problems.push(`page ${i} is not an object`);
    const o = x as Record<string, unknown>;
    if (!isScreenshotPath(o.path)) return problems.push(`page ${i}: path must start with / and be plain ASCII`);
    if (!isScreenshotName(o.name)) return problems.push(`page ${i}: name must be lowercase letters, digits and dashes`);
    if (o.waitFor !== undefined && o.waitFor !== null && !isWaitForSelector(o.waitFor)) {
      return problems.push(`page ${i}: waitFor must be a plain selector`);
    }
    if (o.signedIn !== undefined && typeof o.signedIn !== "boolean") return problems.push(`page ${i}: signedIn must be true or false`);
    let steps: unknown[] | undefined;
    if (o.steps !== undefined && o.steps !== null) {
      if (!Array.isArray(o.steps) || o.steps.length === 0) return problems.push(`page ${i}: steps must be a list of demo steps`);
      if (o.steps.length > SCREENSHOT_PAGE_STEPS) return problems.push(`page ${i}: at most ${SCREENSHOT_PAGE_STEPS} steps`);
      if (!checkSteps) return problems.push(`page ${i}: steps aren't supported here`);
      const c = checkSteps(o.steps);
      if ("problem" in c) return problems.push(`page ${i}: ${c.problem}`);
      steps = c.steps;
    }
    if (seen.has(o.name)) return problems.push(`page ${i}: name ${o.name} is used twice`);
    if (pages.length >= SCREENSHOT_LIMITS.pages) return problems.push(`page ${i}: past the limit of ${SCREENSHOT_LIMITS.pages}`);
    seen.add(o.name);
    pages.push({
      path: o.path,
      name: o.name,
      ...(typeof o.waitFor === "string" ? { waitFor: o.waitFor } : {}),
      ...(o.signedIn === false ? { signedIn: false } : {}),
      ...(steps ? { steps } : {}),
    });
  });
  if (pages.length === 0) pages.push(...DEFAULT_SCREENSHOT_PAGES);
  return { plan: { ...(seed !== undefined ? { seed } : {}), pages }, problems };
}

const PNG_MAGIC = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a];

/**
 * Width and height from a PNG's header: the 8-byte signature, then an IHDR
 * chunk of length 13. Null for anything else, or a size out of bounds.
 */
export function pngInfo(bytes: Uint8Array): { width: number; height: number } | null {
  if (bytes.length < 33) return null;
  for (let i = 0; i < PNG_MAGIC.length; i++) if (bytes[i] !== PNG_MAGIC[i]) return null;
  const u32 = (o: number) => ((bytes[o] << 24) | (bytes[o + 1] << 16) | (bytes[o + 2] << 8) | bytes[o + 3]) >>> 0;
  if (u32(8) !== 13) return null;
  if (String.fromCharCode(bytes[12], bytes[13], bytes[14], bytes[15]) !== "IHDR") return null;
  const width = u32(16);
  const height = u32(20);
  const max = SCREENSHOT_LIMITS.maxDimension;
  if (width < 1 || height < 1 || width > max || height > max) return null;
  return { width, height };
}

/**
 * The path, query and fragment of the sign-in link the app's login function
 * returned (`{ url }`), to open on the app's own 127.0.0.1 origin: on the
 * local backend the link names the backend's site URL, but the page that
 * consumes it is the frontend's. Throws unless it is a plain path on the app.
 */
export function signInPath(link: unknown): string {
  if (typeof link !== "string" || link.length > 2000) throw new Error("the login function didn't return { url }");
  let u: URL;
  try {
    u = new URL(link, "http://127.0.0.1");
  } catch {
    throw new Error("the login function's url is not a URL");
  }
  if (u.protocol !== "http:" && u.protocol !== "https:") throw new Error("the login function's url must be http or https");
  const path = `${u.pathname}${u.search}${u.hash}`;
  if (!PATH.test(path) || path.includes("\\")) throw new Error("the login function's url is not a plain path on the app");
  return path;
}

/**
 * A URL the screenshot helper may open: http on 127.0.0.1 with an explicit
 * port, no credentials. `localhost` is refused: it can resolve to ::1 or
 * elsewhere, and the helper only ever looks at the sandbox's own loopback.
 */
export function checkLoopbackUrl(input: string): URL {
  let u: URL;
  try {
    u = new URL(input);
  } catch {
    throw new Error("not a URL");
  }
  if (u.protocol !== "http:") throw new Error("only http://127.0.0.1:<port>/ URLs are allowed");
  if (u.hostname !== "127.0.0.1") {
    throw new Error(`only http://127.0.0.1:<port>/ URLs are allowed, not ${u.hostname}`);
  }
  if (u.username !== "" || u.password !== "") throw new Error("the URL must not carry credentials");
  if (u.port === "") throw new Error("give the port, as in http://127.0.0.1:5173/");
  return u;
}
