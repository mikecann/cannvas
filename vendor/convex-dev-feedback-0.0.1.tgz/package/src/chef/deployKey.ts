// The host's own deploy key, for "Ship it" (docs/chef-pipeline.md, "Ship it:
// a cloud release"). A Convex production or development deploy key is
// `prod:<deployment>|<secret>` or `dev:<deployment>|<secret>`. The part
// before `|` names the deployment and isn't secret. No Convex imports: the
// host's action and the component both use this.

const NAME = "[a-z0-9][a-z0-9-]{0,63}";
/** `prod:<deployment>` or `dev:<deployment>`, the non-secret prefix. */
export const DEPLOY_KEY_PREFIX_RE = new RegExp(`^(prod|dev):${NAME}$`);

export function isDeployKeyPrefix(prefix: string): boolean {
  return DEPLOY_KEY_PREFIX_RE.test(prefix);
}

/**
 * Split the host's deploy key into its prefix, deployment name and secret.
 * Throws for anything else (a preview key, a bare secret, a malformed
 * prefix). Error messages never repeat any part of the input.
 */
export function splitHostDeployKey(key: string): {
  prefix: string;
  kind: "prod" | "dev";
  deploymentName: string;
  secret: string;
} {
  const trimmed = key.trim();
  const bar = trimmed.indexOf("|");
  if (bar < 0) throw new Error("Not a deploy key: expected prod:<deployment>|<secret> or dev:<deployment>|<secret>");
  const prefix = trimmed.slice(0, bar);
  const secret = trimmed.slice(bar + 1);
  if (!isDeployKeyPrefix(prefix)) {
    throw new Error(
      "CHEF_DEPLOY_KEY must be a deploy key for one deployment (prod:<deployment>|... or dev:<deployment>|...)",
    );
  }
  if (secret.length < 8 || /[\s|]/.test(secret)) throw new Error("Malformed deploy key");
  const [kind, deploymentName] = prefix.split(":") as ["prod" | "dev", string];
  return { prefix, kind, deploymentName, secret };
}

/** `happy-otter-123` from `https://happy-otter-123.convex.cloud`, or null. */
export function deploymentFromCloudUrl(url: string | undefined): string | null {
  const m = /^https:\/\/([a-z0-9][a-z0-9-]{0,63})\.convex\.cloud\/?$/.exec(url ?? "");
  return m ? m[1] : null;
}
