---
name: convex-chef
description: Let a Convex app improve itself. Adds Chef, a feature-request panel where the app's users ask for changes and an admin approves them, and optionally cloud builds, where approved requests get built by Claude Code in cloud sandboxes billed to the team's Convex bill, or on the developer's own machine with `npx chef work`. Covers the feedback board alone, install, `npx chef init`, the panel, preview and deploy keys, the deploy guard, turning cloud builds on, local builds, costs, and turning it off. TRIGGER when the user wants a feedback board or feature requests in their Convex app, wants their app to improve itself, wants to add Chef, or wants feature requests built by AI ("let users ask for features and have them built", "add Chef", "make my app build its own features"). SKIP when there is no convex/ directory.
---

# Add Chef to a Convex app

You do every step yourself. The user does two things: says yes to turning
cloud builds on, because builds spend money on their Convex bill, and, before
that, signs in to their app and sends the panel one request, so they become
its admin. Never turn cloud builds on without a yes in the user's own words.

Chef comes in two packages from one repo:

- `@convex-dev/feedback`, the feedback board: users send feature requests
  (typed, or a screenshot with a voice note), vote, and follow them; an admin
  approves them in a small panel. It has no child components and no
  dependencies of its own. It also has everything a builder talks to (the
  runs, the one-at-a-time claim, the `/chef-agent` routes and model proxy),
  and the `chef` CLI.
- `@convex-dev/chef-cloud`, cloud builds: each approved request is built by
  Claude Code on a branch, deployed to a preview, and shipped to the live app
  when the admin presses Ship it. The builds run in Daytona sandboxes, keep
  the app's git repo on Code Storage, and call Claude through the Convex AI
  gateway, all with the deployment's own service token: no accounts or API
  keys. It brings Daytona, Code Storage, Resend and `@convex-dev/workflow` as
  its own child components, so an app with the board alone never installs
  them.

Ask the user which they want if they haven't said: the board alone (stop
after step 5), or cloud builds too. `npx chef work` (step 7) needs
chef-cloud as well, for the app's repo, even with cloud builds left off.

## 1. Preflight

Stop with a clear message if one fails.

- `convex/` exists and `npx convex dev --once` succeeds.
- With cloud builds, the deployment is in the cloud: `CONVEX_DEPLOYMENT` in
  `.env.local` is `dev:<name>` or `prod:<name>`, not `anonymous:` or
  `local:`. Cloud builds can't reach a local deployment. If it's local, tell
  the user the app has to be linked to a Convex cloud project first. The
  board alone works on any deployment.
- The app's `convex` package is 1.45.0 or newer for cloud builds, 1.35.1
  for the board (`npm ls convex`). If not, `npm install convex@latest`.
- With cloud builds, the Convex CLI is logged in: `~/.convex/config.json`
  exists. init uses that login to make deploy keys. If it's missing, ask the
  user to run `npx convex login`; don't start a login yourself.
- The app is a git repo with at least one commit and a clean tree. Chef
  builds from the app's git history, and init commits its own edits. Commit
  or stash what's there first, with the user's say-so if it's their work in
  progress. Only `--write` needs the clean tree: the review run (no
  `--write`) reports a dirty tree as a FAIL with the rest and still prints
  the code. To add Chef's edits on top of uncommitted work without
  committing anything, see "Installing without committing" in step 3.
- With cloud builds, the app has a lockfile the sandboxes can install from:
  `package-lock.json` (they run `npm ci --ignore-scripts`) or
  `pnpm-lock.yaml` (pnpm's frozen install with `--ignore-scripts`, using the
  pnpm `packageManager` names, else pnpm 10 for a 9.x lockfile or 8 for a
  6.x one, fetched from the npm registry). yarn and bun aren't supported,
  and neither is no lockfile: preflight fails with
  `dependencies: yarn.lock: ...` or `dependencies: no lockfile`. Switch the
  app to npm (`npm install`, commit `package-lock.json`) or pnpm
  (`npx pnpm import` turns `yarn.lock` into `pnpm-lock.yaml`), with the
  user's say-so, and remove the old lockfile.
- With cloud builds, the lockfile installs exactly as the sandbox installs
  it. init (and `npx chef sync` later) runs the sandbox's own check with
  nothing written: `npm ci --dry-run`, or the sandbox's pnpm, frozen, with
  `--lockfile-only` (and first an offline comparison of pnpm-lock.yaml with
  package.json). A FAIL `lockfile:` line means a build would die at
  install: a local pnpm 9 can accept a lockfile the sandbox's pnpm 10
  refuses. Run the fix it prints (for pnpm, `npx pnpm@<version> install
  --lockfile-only`), commit the lockfile, and run init again. A `warn`
  (offline) can go on.
- With cloud builds, the commit has nothing the preview deploy refuses: no
  tracked `.env`, `.env.local` or `.npmrc`, no symlinks anywhere (vendored
  skills under `.claude/skills/` linked from elsewhere are the usual
  ones), `convex.json`'s `functions` inside the repo, and no git
  dependencies in `package-lock.json`. A FAIL `deploy:` line lists each
  path and the fix: `git rm --cached <path>` (and `.gitignore` it), or
  replace a symlink with a real copy of what it points to. Make the fix
  with the user's say-so, commit, and run init again; `npx chef sync`
  refuses to push such a commit too, and a build would fail at its
  preview after paying for the agent.
- The app has sign-in. Chef knows who's asking from the app's own auth
  (Convex Auth, Clerk, anything that gives Convex an identity). With no
  sign-in there's no admin, so add auth first (`convex:auth`).

## 2. Install

```sh
npm install github:convex/chef-cloud#main
```

That's `@convex-dev/feedback`, all the board needs. Cloud builds add
`@convex-dev/chef-cloud`, which `npx chef init --cloud --write` vendors for
you in step 3 (from the repo's `dist/chef-cloud` branch). By hand:

```sh
mkdir -p vendor
npm pack github:convex/chef-cloud#dist/chef-cloud --pack-destination vendor
npm install ./vendor/convex-dev-chef-cloud-0.0.1.tgz
```

Install both from the same commit of the repo: chef-cloud checks the
feedback component's contract version at setup and in `chefSetupStatus`, and
refuses with a message saying which is older.

### Vendor it

Installed from GitHub, the package fails init's preflight with
`dependencies: 1 installed from git`. That's on purpose: the build sandbox
installs with npm or pnpm and can reach the npm registry but not GitHub, so a
build of an app that depends on a GitHub URL would fail at install. Vendor it
as a tarball in the repo instead:

```sh
mkdir -p vendor
npm pack github:convex/chef-cloud#main --pack-destination vendor
```

That prints the file name, like `convex-dev-feedback-0.0.1.tgz`. Point
package.json at it and refresh the lockfile:

```json
"@convex-dev/feedback": "file:vendor/convex-dev-feedback-0.0.1.tgz"
```

```sh
npm install
git add vendor package.json package-lock.json
git commit -m "Vendor @convex-dev/feedback"
```

Do the same for any other dependency preflight lists as installed from git
(chef-cloud is already a tarball when init installed it). To update Chef
later, pack both again, change the file names if the versions moved,
`npm install`, commit.

On pnpm, use it instead (`pnpm install`, then commit `pnpm-lock.yaml`):
`npm pack` still makes the tarball, and the sandboxes install pnpm apps with
pnpm. yarn and bun apps can't build in the cloud (see Preflight); move them
to npm or pnpm first. Keep a `vendor/` that already holds other tarballs;
just add to it.

### An app already on another copy of `@convex-dev/feedback`

If the app already has the component from a different fork or an older
commit, compare before switching. After the install, run the app's
typecheck (`npx convex codegen` and `tsc` on `convex/` and the frontend):
an export the app uses that this package lacks (a host function, a client
method, a panel prop) shows up there. Also compare the component's schema:
a field the old copy stored that this one doesn't declare makes the deploy
fail on any deployment whose data has it. Port what's missing into this
package first (or drop the app's use of it, with the user's say-so), then
install.

## 3. `npx chef init`

```sh
npx chef init --no-cloud    # the feedback board alone
npx chef init --cloud       # cloud builds too
```

Without either flag it works it out: an app with chef-cloud installed (or
`chefCloud` in `convex/chef.ts`) gets cloud builds, and otherwise it asks,
and with no terminal to ask on it sets up the board alone. Pass the flag the
user chose.

While it has code edits to make, this changes nothing: it runs every
preflight check, lists all the problems at once (an uncommitted tree
included), and prints the code it would add (and, with `--cloud`, the npm
commands that vendor chef-cloud), FAILs or not; with FAILs it exits 3 after
the code. `--write` stops at a FAIL before writing anything. Once the code is all in place (a second run, or a second
deployment of an app already set up), plain `npx chef init` goes straight on
to the setup steps below, `--write` or not: it pushes the functions, hashes
old keys and creates the repo. Treat it as `--write` then, and on
`--prod` as a production deploy that needs the user's say-so. Fix any FAIL lines and run it
again until it's clean. The code it adds, only ever inserting lines. For
the board:

- `app.use(feedback)` in `convex/convex.config.ts`
- `convex/chef.ts`, with `exposeChefApi` (what the panel calls) and
  `chefAdmin` (`chefSetAdmin` and `chefMigrateAgentKeys`, for the CLI)

With `--cloud`, instead of `chefAdmin`, and more:

- `app.use(chefCloud)` next to `app.use(feedback)`
- `chefCloud(components.feedback, components.chefCloud)` in
  `convex/chef.ts`: the build steps, the workflows' entry points, setup and
  the repo functions, `chefSetAdmin` and `chefMigrateAgentKeys` included.
  All internal: only the deployment and its CLI can call them.
- no `convex/crons.ts`: Chef has no crons (see "No crons: what Chef
  schedules and when" below). An app whose crons.ts still calls `chefCrons`
  gets a note that it can go; it registers nothing now
- `mountChefAgentRoutes(http, components.feedback)` in `convex/http.ts`: the
  routes the build talks back on
- if `convex.config` requires env vars, `scripts/chef-local-env.mjs` and a
  `chef:local-env` script in package.json, which set throwaway values for
  them on the build's own local backend
- `"predev": "chef guard"` in package.json, when `npm run dev` runs
  `convex dev`, itself or through a script it starts (`npm run dev:backend`,
  `npm-run-all dev:*`). Not for a `dev` of `next dev` or `vite` alone, and a
  `convex dev --once` in another script (a ship or deploy script) doesn't
  count: `predev` only runs before `npm run dev` (see "The deploy guard"
  below)

If `convex/chef.ts` already exists it adds to it. If the app isn't on Convex
Auth, check the `getUserId` it wrote and point it at the app's identity. A
line marked "by hand" is one it couldn't place safely: make that edit, commit,
and run it again.

Upgrading an app that already has Chef: update the package(s), then run `npx
chef init --write` (it adds any new chefCloud exports) or, when the code is
already current, `npx chef upgrade`. Both push the functions and hash any
`/agent/*` key still stored in plaintext from before keys were hashed, then
check none is left. A first `--write` does this too, so an app that had the
component before (with an agent key) sees it on its first setup. If it says
it hashed some, tell the user: those keys sat in the database in the clear,
so they should revoke them and issue new ones.

### Installing without committing

When the user has work in progress they don't want committed yet, or wants
to review Chef's edits in their own commit:

```sh
npx chef init --cloud --write --no-commit    # or --no-cloud
```

This writes the file edits (and vendors chef-cloud) on a dirty tree too,
and nothing else. It skips, and says it skipped: the commit, deploying the
functions and the upgrade steps, creating the app's repo on Code Storage and
pushing HEAD to it, the `chef` remote, the preview and "Ship it" deploy keys,
and naming the admin. Those all start from a commit, so they wait. To finish:
review the edits, commit them (with the other work or on their own, the
user's call), then run `npx chef init --cloud` (or `--no-cloud`) on the
clean tree; it finds the code in place and goes on to setup.

### An app on Chef from before chef-cloud was split out

Before, `chefCloud` came from `@convex-dev/feedback` and took one
component. init stops on that with a "by hand" note, since it only inserts
lines. Move it:

1. vendor chef-cloud next to feedback (step 2), from the same commit;
2. in `convex/chef.ts`: `import { chefCloud } from "@convex-dev/chef-cloud"`
   and `chefCloud(components.feedback, components.chefCloud, ...)`, keeping
   the options; drop `chefCrons` from `convex/crons.ts` (a no-op now);
3. run `npx chef init --cloud --write`: it adds `app.use(chefCloud)` and the
   new exports (`chefRunStart`, `chefShipStart`, `chefReconcile`), pushes,
   and setup registers them with the feedback component.

What moves: the repo's name and URL, the executor and the record of each
build's sandboxes and emails now live in chef-cloud. Its first setup
re-creates the repo record (the same repo, adopted by `repoName`), and
in-flight builds are best finished or cancelled first. Runs, approvals,
releases, keys and the audit log stay where they were.

### No crons: what Chef schedules and when

Chef adds no cron and no interval to the app; an idle app has nothing of
Chef's scheduled. Each thing is scheduled once, by the event that needs
it, and does nothing if it's no longer needed:

- **The next build** is claimed in the same transaction as an approval, the
  end of any run (built, failed, cancelled, reconciled), a cloud key being
  created, or auto-build being turned on.
- **A run that stops answering**: its one deadline check, scheduled at the
  claim, sends it to reconciliation once it has had no heartbeat for 15
  minutes or passed its 90 (a heartbeating run's check reschedules itself,
  at most every 15 minutes while the run lives). A workflow that fails or
  is cancelled sends its run there at once.
- **A stuck reconciliation**: the reconciler again after 20 minutes; after 2
  hours the run finishes failed, the slot frees, the next build starts.
- **A ship that stopped answering** (45 minutes without a change): started
  again a bounded number of times, then it waits for a person.
- **Cleanup** (leftover sandboxes, secrets): once when each run finishes and
  each ship's workflow ends, on chef-cloud's workpool with retries; request
  branches once, at the oldest one's 14 days; refusal counts older than 30
  days as new ones are written.

`npx chef cleanup` runs all of it by hand. An app upgrading from
`chefCrons(crons)` loses its "chef sweep" and "chef cleanup" crons at the
next push whether or not the call stays; tell the user they can delete it
(and `convex/crons.ts`, if that was all it had).

### Batching

When more than one approved request is waiting, Chef groups the ones that
touch the same part of the app into one build (at most 4), so they don't
collide in the same files: six requests from three screens are three
builds. The grouping is one cheap model call (Haiku, through the Convex AI
gateway, a fraction of a cent) at the claim, never on a timer; it reads
each request's title, text, the screen it was asked from (ChefKit's and the
panel's `context.screen`) and votes. Each request is still built from its
own approved text.

- Nothing to set up: `npx chef init --cloud` exports `chefPlanBatches`, and
  setup (or the next build's start) registers it. An app that hasn't
  exported it builds each request alone; `npx chef init --write` adds it.
- A batch's requests move together (In progress, Ready, Done), show "Built
  together with #2, #3", and ship together. Before its build starts the
  admin can "Split out" one (the panel's Up next, ChefKit's "Built
  together"; `splitFromBatch`).
- A failed batch is tried once more together, then each request alone; one
  too big (deadline, spend cap) is split at once.
- Off: `chefCloud(..., { batching: false })`, or the `cloudBatching: false`
  setting. Turn it off if the user wants one build per request.

Tell the user to send requests from the screen they're about (or pass
`ChefKit.context` / the panel's context): the screen is the best hint for
what belongs together.

### chefCloud's options: set them before `--write`

init writes `chefCloud(components.feedback, components.chefCloud)` with no
options, and `--write` uses them at once (it creates the repo), so decide
these first. If any apply, write the `chefCloud` block in `convex/chef.ts`
yourself, with every name init listed, commit, and run `npx chef init`
again; it then reports the block as already there and keeps your options.

- `repoName` (default `"app"`): the repo on Code Storage. If the app already
  has one (an earlier hand-wired Chef, say), use its name, or init makes a
  new empty repo and the old one's branches (`chef` and its builds) are left
  behind. init's push only fast-forwards `main`, so a `main` your HEAD
  doesn't contain stops it with a message instead of diverging.
- `appName`: the app's name in build emails.
- `notify`: the owner's emails (a build is ready or failed, a release
  shipped or didn't). Off without `send` or `from`; `to` is an address or
  `async (ctx) => address`.
  - If the app already sends email (sign-in codes, say), use
    `notify: { send, to }` with its existing mailer: `send(ctx, m)` gets
    `{ to, subject, html, text, idempotencyKey, kind }`, built and escaped.
    Pass `m.idempotencyKey` on to the provider and return `{ id }` if there
    is one. The README's "Use your app's own mail" has a Resend component
    example. Chef's own Resend child stays installed (components are
    static) but unused.
  - Otherwise `notify: { from, to }` sends through Chef's bundled Resend;
    `from` must be on a sending domain verified on this deployment.
- `previewLoginFunction`: `module:function` that returns `{ url }`, a
  one-time sign-in link, for an app whose sign-in can't work on a preview's
  `.convex.site` (emailed codes, passkeys).
- `beta` (off by default): `{ siteUrl, deployKeyEnv?, mode? }`, only when
  the owner has a separate persistent beta deployment. Each successful build
  is deployed there after its preview (`"also"`) or as it (`"instead"`);
  the Ship card's button becomes "Promote to everyone". Create its key with
  `npx chef init --beta <deployment>`; never use the app's own deployment.
- `previewData` (off by default): `{ exportFunction, seedFunction }` so an
  admin can try previews on a copy of their own data. Add it only when the
  owner asks. `exportFunction` is an internal query on live taking
  `{ userId, maxBytes, includeFiles }` and answering `{ userId, ... }` with
  only that user's own rows, scrubbed and under `maxBytes`;
  `seedFunction` (`module:function`) runs on the preview with
  `{ exportUrl, sha256, bytes }`, checks the sha256, inserts a copy and
  answers `{ userId }`; `previewLoginFunction` should then accept
  `{ userId? }`. Put both in `convex/chefPipeline.ts` (protected from
  builds). The admin still has to turn "admin-copy" on in the panel.
  docs/chef-pipeline.md, "Preview data", has the exact contract.
- `skills`: `{ name: SKILL.md text }` the build agent gets, read-only. Only
  the `SKILL.md` text travels; a skill that points at other files should
  point into the checkout instead. Keep them in a generated module (a
  script that writes `convex/chefSkills.ts` from the skill files) rather
  than pasting them in.
- `fixRounds` (default 3, 0 to 5): how many times a build's agent gets its
  own session back when the runner's verification fails in a way it can
  fix (a check that passed before the build and fails after it, a guard on
  its diff, the frontend build). Checks that already fail on `main` (lint
  with existing errors, say) never fail a build, so don't fix them first
  just for Chef.
- `snapshot`: leave it unset. The default is the shared `chef-base-1`
  image, with the runner delivered into it; a `CHEF_RUNNER_SNAPSHOT` env var
  on the deployment overrides it, so remove one left over from a custom image
  (`npx convex env remove CHEF_RUNNER_SNAPSHOT`).
- `warmSnapshots` (default on, `{ keep: 2 }` at most): Chef builds the
  app's own Daytona snapshot with its dependencies already downloaded,
  from the files committed to its repo (chef-base plus npm's cache or
  pnpm's store), in the background after the first build for a lockfile.
  Builds, previews and Ship it then install offline when their lockfile
  matches, and as before when it doesn't. Leave it on; to turn it off,
  `warmSnapshots: false`, or `npx convex env set CHEF_WARM_SNAPSHOTS 0`
  without a deploy. It counts against the team's Daytona snapshots (5 per
  team), so with several Chef apps on one team lower `keep`.

The full list is in the package README, "Chef cloud builds".

### An app that was wired for Chef by hand

If the app already runs Chef with its own host code (its own Daytona, Code
Storage, workflow and orchestrator wiring), move it to chefCloud before init:

- remove the host's orchestrator, steps, reconciler, sweeps, repo bootstrap
  and snapshot code, and its `crons.interval("chef sweep" ...)` and
  `"chef cleanup"` lines: chefCloud schedules what they did itself, when
  it's due;
- call `mountChefAgentRoutes(http, components.feedback)` with no third
  argument: a `runConfig` there replaces chefCloud's;
- drop the app's own `app.use` of Daytona, Code Storage, workflow and
  workpool if nothing else in the app uses them: chef-cloud brings its own;
- if it has its own local env script, point package.json's `chef:local-env`
  at it, and init writes none;
- keep the existing repo with `repoName`, and the existing
  `CHEF_PREVIEW_DEPLOY_KEY`, preview defaults and Chef agent key: init
  keeps all three, and cloud builds stay on if they were (a key made
  before key kinds existed counts as a cloud key);
- remove env vars the old host used and chefCloud doesn't (a repo URL, a
  custom snapshot name), by name: `npx convex env remove <NAME>`. To see
  which are set, print names only, never values (`npx convex env list`
  prints values, some of them over several lines).

The `chef` branch and any request branches stay as they were. `main` moves
to your HEAD, so the next build merges `main` into `chef` first; where the
app changed under an old build, the build agent resolves the conflicts.

Then, for the board alone:

```sh
npx chef init --no-cloud --write
```

This writes and commits those edits, pushes the functions, and names the
admin if you pass `--admin <userId>` (step 5). That's all of it: go to step 4.

With cloud builds:

```sh
npx chef init --cloud --write --deploy-key
```

This vendors chef-cloud if it isn't installed, writes and commits those
edits with it, then:

1. pushes the functions, creates the app's repo on Code Storage, and pushes
   HEAD as its `main`;
2. adds a `chef` git remote. Its credential helper asks the deployment for a
   short-lived token each time; no git token is stored on the machine;
3. creates a preview deploy key with the CLI login and sets it as
   `CHEF_PREVIEW_DEPLOY_KEY`, and sets throwaway preview defaults for the env
   vars the app requires. Each build is deployed to its own preview
   deployment with this key;
4. with `--deploy-key`, creates a deploy key for this deployment and sets it
   as `CHEF_DEPLOY_KEY`. Ship it deploys with it. Without the flag init asks,
   and with no terminal it skips it and says how to add it later;
5. with `--beta <deployment>` (or when the app has chefCloud's `beta` and
   the user names the deployment when asked), creates a deploy key for that
   beta deployment, never this one, and sets it as `CHEF_BETA_DEPLOY_KEY`;
6. leaves cloud builds off. With no terminal to ask on, it stops there. If
   they're already on (a cloud Chef agent key exists), it says so and asks
   nothing.

Nothing init runs prints a key, token or env value. Don't print them
yourself: don't `env get` them, don't `cat` them. Check by name with
`npx chef status`.

If the user wants Chef to deploy to production rather than the dev
deployment, add `--prod` to every `npx chef` command. Chef's admin, keys,
repo and queue are per deployment, and requests are filed wherever the live
app's users are, which is usually production. Ask which one before step 3
rather than defaulting to dev. A checkout has one `chef` git remote, so
setting up a second deployment stops at "There is already a git remote
chef"; rename the first (`git remote rename chef chef-dev`) and run again.
That leaves the first deployment's init stopping on the same check from
then on (its remote is no longer `chef`), so treat a checkout as serving one
Chef deployment: pick it before step 3. On `--prod`, keep the flag on every
follow-up command too, including the ones init's own hints print without it
(`npx chef init --deploy-key` there means the dev deployment).

Run init again any time: each step skips what's done. After the user commits
more work, `npx chef sync` pushes HEAD to chef's `main`.

### The deploy guard

"Ship it" deploys a build to the deployment `CHEF_DEPLOY_KEY` is for and
then moves chef's `main`. A later deploy of an older checkout to that same
deployment (a local `npx convex dev`, `npx chef upgrade`) would put the old
code back and roll back what shipped. So before any deploy it makes to that
deployment, and in `npx chef sync`, the CLI refuses while chef's `main` has
commits the checkout lacks, and says to run `git pull chef main` first.
`npx chef guard` is the check on its own; init adds it as the app's
`predev` script so `npm run dev` runs it before `convex dev` (pnpm needs
`enable-pre-post-scripts` for that). A local deployment is never guarded.
Before Chef's cloud setup has run on the deployment (no
`chef:chefSetupStatus` there yet), nothing has shipped, so it passes and
says Chef's cloud builds aren't set up there yet and to run
`npx chef init --cloud`.
If the CLI can't read chef's refs it refuses too; `CHEF_SKIP_DEPLOY_GUARD=1`
deploys anyway, and only the user should decide that.

The panel is part of the app's frontend bundle. After installing or
updating Chef, rebuild and redeploy the frontend the way the app normally
does (for Convex static hosting on a dev deployment,
`npx @convex-dev/static-hosting upload --build`; never a prod deploy
without the user's say-so), or the live panel stays the old one. Step 5
depends on it: "Your Chef user id" is only in the new panel. Some agent
permission setups count any static-hosting upload as a deploy and refuse
it; then ask the user to run the upload, or to run the app locally
(`npm run dev` against the same deployment) and open the panel there.

If preflight warns that the frontend isn't Vite-style (Next.js, say), cloud
builds still build and deploy the backend, but a build's preview may have no
frontend. Tell the user, since that's what they'll click in the panel.

## 4. Mount the panel

init prints the panel mount and doesn't add it, since where it goes is up to
the app. Put it inside the Convex provider, once, on every page. For a React
app on Convex Auth:

```tsx
import { ChefPanelMount } from "@convex-dev/feedback/react";
import { useAuthToken } from "@convex-dev/auth/react";

<ChefPanelMount convexUrl={import.meta.env.VITE_CONVEX_URL} token={useAuthToken()} />
```

Next.js uses `process.env.NEXT_PUBLIC_CONVEX_URL!`. `convexUrl` is the
deployment's client URL (`https://<name>.convex.cloud`, what the app's own
`ConvexReactClient` gets), never `*_CONVEX_SITE_URL` (`.convex.site`, for
HTTP actions): the panel runs its own Convex client on it. On Clerk, pass
`getToken={() => getToken({ template: "convex" })}` instead of `token`. A
page with no bundler uses the `<chef-panel>` web component; init prints that
version when it finds no React. Use whatever init printed.

Check it typechecks, commit, `npx chef sync`, and load the app to see the
lightbulb.

## 5. Make the user the admin

Nobody becomes admin by signing in, so name the user. Ask them to sign in to
the app (on the deployment Chef was set up on; ids differ between dev and
production) and open the lightbulb: under their requests it shows "Your Chef
user id" with a Copy button. Ask them to paste it, then:

```sh
npx chef init --admin <their id>
npx chef status
```

`npx chef status` shows `adminUserId` with their id. Cloud builds and Ship it
are refused until there is one. If the app already makes its owner an admin
itself (with `feedback.users.setRole`), status shows that id and there's
nothing to do.

## 6. Turn cloud builds on

This is the one step that spends money, so ask, in one message:

> Cloud builds are ready. When they're on, each request you approve in the
> panel is built by Claude Code in a cloud sandbox and deployed to a preview,
> and that usage goes on your Convex bill: model calls up to $20 a build by
> default, plus sandbox time and the preview. Nothing runs until you approve
> a request. Turn them on?

Wait for a yes. Then:

```sh
npx chef init --enable
```

If `npx chef status` already says `cloud builds  on`, skip the question:
they were on before, and the user decided that then.

If the user would rather not pay for cloud builds, skip this step and use
step 7.

## 7. Or build on the developer's machine: `npx chef work`

`npx chef work` builds approved requests on this machine with the user's own
Claude Code subscription (or Codex with `--agent codex`), one at a time,
until it's stopped. The panel shows the run like a cloud one, marked "built
locally", and Ship it works on it. The model calls are on the user's
subscription, not the Convex bill, so Chef's $20 ceiling doesn't apply.

It needs init with chef-cloud (steps 3 to 5, `--cloud`) but not step 6:
the worker clones and pushes through the app's repo, which is chef-cloud's.
That's worker-only mode: chef-cloud installed, cloud builds left off.

By default the agent runs in a Docker container that sees only the run's
checkout, so Docker has to be running. Claude Code in a container can't use
the macOS keychain login; it needs a long-lived token. Ask the user to run
these in their own terminal, since `claude setup-token` opens a browser and
prints a token you shouldn't see:

```sh
claude setup-token
npx chef work --save-claude-token    # paste the token, then Ctrl-D
```

`--container none` skips Docker and runs the agent as the user, with full
access to their machine. Only use it if the user asks for it.

The worker only builds requests an admin wrote. The agent holds the user's
reusable Claude Code token (or Codex login) and can reach the internet, so
a member's request text could tell it to send that login somewhere. The
server only hands a worker key admin-written requests, and members' stay
queued for a cloud build (run-bound inference proxy, sandbox egress); the
worker says how many are waiting. There is no option to build members'
requests locally; if the user wants that, tell them it needs a host-side
inference proxy with a short-lived run-bound capability and container
egress limited to it, which isn't built yet. Until then, members' requests
need cloud builds.

It also needs a worker key. One command creates it on the deployment
(chefCloud's `chefCreateWorkerKey`, through `npx convex run`) and saves it
to `~/.config/chef/<deployment>.key`, mode 0600, without showing it:

```sh
npx chef work --setup
```

(The two-step version is `npx chef worker-key | npx chef work --save-key`;
`worker-key` refuses to write the key to a terminal.) Never run
`chefCreateWorkerKey` on its own: it prints the key.

A worker key only lets `npx chef work` build. It doesn't turn cloud builds
on, so in worker-only mode (step 6 skipped) nothing builds in the cloud:
approvals wait for the worker, the panel hides "Build in cloud", and a
worker's run finishes without a cloud preview (`--preview local` deploys
one from the machine with the preview deploy key). Only "Ship it" uses a
cloud sandbox, when the admin presses it.

If cloud builds are on too, both share one queue and whoever claims first
builds. With auto-build on, approvals start a cloud build at once, so the
worker rarely gets one; for local-first with cloud on, turn auto-build off
(`npx convex run chef:chefEnableCloudBuilds '{"autoBuild":false}'`) and the
worker takes each approved request when it next asks, while the admin can
still press "Build in cloud".

Then start it, and leave it running:

```sh
npx chef work
```

## 8. Trying an iOS build: `npx chef ios`

For an app with an iOS client, add `chef.ios` to package.json
(`{ "projectDir": "ios", "scheme": "App", "bundleId": "com.example.app" }`;
`xcodegen` is used when `project.yml` is there). Then, on the user's Mac
with the iPhone plugged in, `npx chef ios <runId>` fetches that build from
the `chef` remote, builds and installs it, launches it with
`-ChefConvexURL <preview>` and marks the run "compiled ✓ / installed ✓" on
the Ship card. For the app to use the preview's backend it reads
`UserDefaults.standard.string(forKey: "ChefConvexURL")` in debug builds
(docs/chef-pipeline.md, "Trying a build on your iPhone"). Never run it in a
sandbox; it refuses.

## What the user sees

- Members and signed-out visitors see a lightbulb, "Suggest a feature". They
  can type a request or send a screenshot with a voice note, and follow their
  own requests: Waiting for approval, Planned, In progress, Done.
- The admin sees Chef instead. A member's request waits under "Waiting for
  approval". Approve shows the request in full, hidden characters and all;
  "Approve and build" starts the build. The admin's own requests skip the
  queue.
- Under Cloud builds, each build shows its phases as they happen, spend,
  the preview with a one-time signed-in link, screenshots, and the log. If
  the agent wants to do something that costs money or reaches outside the
  app, it asks there instead, and the admin approves or declines.
- Each build shows its checks before and after ("failing before this
  build" doesn't block) and its fix rounds ("Fixing (round 2 of 3)", with
  why and the spend). A failed build says why in one line and what to do
  ("Lockfile out of date: run `pnpm install` and commit pnpm-lock.yaml,
  then Try again"), with what the agent tried and the raw error folded
  away, and has "Try again": the same approved text builds again in one
  step, from the failed build's work when it kept it (applied onto a `main`
  that moved since when it applies cleanly, so the agent only verifies it;
  "Earlier attempt" says whether it was used). A failed preview deploy
  shows the deploy script's own reason, and its last lines are in the
  log. Platform hiccups
  (a sandbox that didn't start, a registry timeout) are tried again on
  their own, twice at most.
- A build that failed on a repo problem Chef can fix mechanically (an
  out-of-date lockfile, tracked symlinks or env files) shows "Chef can fix
  this: ... [Apply]": a commit Chef made with no agent, on its own branch.
  Apply moves `main` to it and builds the request again; Chef never applies
  it on its own. The developer then runs `git pull chef main`.
- Each build's agent uses the official Convex plugin for its backend
  changes (the expert before, the reviewer after), and the build records
  how much it did ("plugin used: ...").
- "What Chef knows about this app" lists what builds learned (how the app
  installs and is checked, where code lives, the agents' notes, recurring
  failures) and what recent builds cost; the admin can delete any entry.
  The next build's agent starts from it.
- Each built build has a short video of the feature being used on the
  preview (the agent scripts it; Chef records it on a phone and a desktop
  screen), on the card.
- Under "Ship to the live app", a plain-language card comes first: "What
  changed" and "What to try" in the owner's words (the agent writes them as
  the first two sections of its summary), the preview with "Try it, signed
  in", the screenshots, and risk flags Chef computes from the diff itself
  (sign-in or session code, new sign-in or token paths, deletes and
  migrations, schema, payments, env vars and secrets, sharing and
  permissions, dependencies, iOS code the cloud can't compile). The code is
  under "Details", folded. "Ship to live" deploys that commit to the live
  deployment, checks the live site, and only then moves `main`. The requests
  are marked done and their requesters told. If `main` moved since the build
  (a hotfix), Ship it doesn't refuse: Chef merges it in and checks again
  with no agent, ships on the same approval when the change is the same,
  and asks again (one tap) when the merge changed it; a merge that
  conflicts or fails a check offers Try again, which rebuilds the request.
  If a ship reaches production and then fails its checks, Chef rolls back
  to the release before it on its own and emails the owner.
  Each built build shows the same card. In an iOS app with ChefKit, the
  admin's sheet has the card and Ship it too ("Ready to ship").
- Requests that touch the same part of the app are built together (see
  "Batching"): Up next shows the batch as one build with its requests and
  "Split out" on each; a batch's card lists every request, each with its
  own line, and Ship it ships them all.

Chef's work lands on the `chef` branch of the app's repo and on `main` when
shipped. To bring it into the local checkout: `git pull chef main`.

## Costs

All on the team's Convex bill, and only after step 6:

- Claude model calls through the Convex AI gateway, capped per build (default
  $20; the build stops at the cap). Fix rounds and Chef's own retries of a
  platform failure count against the same cap. A batch is one build, with
  one cap. Grouping waiting requests into batches is one Haiku call per
  claim with something new waiting (well under a cent).
- Sandbox time for the build and the preview deploy.
- Snapshot storage for warm snapshots: at most 2 per app by default, each
  chef-base plus the app's dependency caches (a few GB), and a snapshot
  build (minutes of Daytona build time) whenever the lockfile changes. They
  save the dependency download (often a minute or more) in every build,
  preview and ship. `warmSnapshots: false` or `CHEF_WARM_SNAPSHOTS=0` turns
  them off; delete leftovers in the Daytona dashboard if you do.
- The app's repo on Code Storage.
- A preview deployment per build.

Approving is what starts spending; an idle Chef costs nothing. `npx chef work`
builds use the user's own subscription instead.

## Turning it off

Cloud builds off, with the cloud key revoked (a cloud build in flight is
cleaned up). Worker keys stay, so `npx chef work` keeps building:

```sh
npx convex run chef:chefDisableCloudBuilds '{"reason":"turned off"}'
```

Everything off, worker keys too: add `"workers":true`.

Stop one build: `npx convex run chef:chefCancelRun '{"runId":"<id>"}'`.
Stop `npx chef work` with Ctrl-C; a run it's working on is marked failed and
its directory removed.

To keep the board and drop cloud builds: turn them off as above, replace the
`chefCloud(...)` block in `convex/chef.ts` with
`export const { chefSetAdmin, chefMigrateAgentKeys } = chefAdmin(components.feedback);`,
remove `chefCrons(crons)` if it is still there, the `predev` guard and `app.use(chefCloud)`, and
uninstall `@convex-dev/chef-cloud`. Its tables (the repo record, the effect
ledger) go with it; the requests, runs and audit log stay in the feedback
component.

To take Chef out entirely, also remove the panel mount, the
`mountChefAgentRoutes` line, `convex/chef.ts` and `app.use(feedback)`, then
`npx convex env remove CHEF_DEPLOY_KEY` and `CHEF_PREVIEW_DEPLOY_KEY`, and
`git remote remove chef`. The requests and build history live in the
feedback component, so ask before removing `app.use(feedback)`.

## Report

Tell the user: whether they have the board alone or cloud builds too,
whether cloud builds are on, whether a worker key exists
(`npx chef status` shows `cloud builds` and `worker keys`), which deployment Chef builds
and ships to, that builds cost up to $20 in model calls each by default plus
sandbox time on their Convex bill, where the panel is, and that they approve
requests and press Ship it there. If something failed, say which step and
what the last command printed.
