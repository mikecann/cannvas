// Types for runner/chef-repair.mjs.
export const REPAIR_KINDS: readonly ["lockfile", "symlinks", "envFiles"];
export function pnpmLockfileOnlyArgv(npm: string, version: string): string[];
export function npmLockfileOnlyArgv(npm: string): string[];
export function gitignoreAdditions(existing: string, paths: string[]): string[];
export function linkTargetInRepo(path: string, target: string): string | null;
export function repairMain(argv: string[], env: Record<string, string | undefined>, io?: { out: (s: string) => void }): Promise<number>;
