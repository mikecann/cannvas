// The two calls a local worker makes outside the runner: POST
// /chef-agent/enroll with the Chef agent key (claims the next approved
// request, returns a run credential) and POST /chef-agent/finish with the
// run credential (ends an enrolled run: built, failed, or handed to the
// host's cloud preview). Neither credential is ever logged; errors carry
// the server's message, scrubbed.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { scrub } from "../../src/chef/scrub.ts";

export type Fetch = typeof fetch;

export type Claim =
  | { outcome: "claimed"; runId: string }
  | { outcome: "busy"; runId: string }
  | { outcome: "reconciling"; runId: string }
  | { outcome: "empty"; memberRequests?: number }
  | { outcome: "disabled"; reason: string }
  // Chef is grouping waiting requests into batches (docs/chef-pipeline.md, "Batching").
  | { outcome: "planning" };

export type EnrollAnswer =
  | { kind: "run"; runId: string; credential: string; rotated: boolean; requestedBy?: "admin" | "member" }
  | { kind: "wait"; claim: Claim }
  | { kind: "refused"; status: number; error: string };

const PREFIX = "/chef-agent";

export function apiBase(siteUrl: string): string {
  return siteUrl.replace(/\/+$/, "") + PREFIX;
}

/**
 * POST /chef-agent/enroll. A network failure throws; the caller backs off.
 * `requests: "admin"` asks the server to claim only requests an admin wrote.
 */
export async function enroll(
  siteUrl: string,
  key: string,
  doFetch: Fetch = fetch,
  opts: { requests?: "admin" | "any" } = {},
): Promise<EnrollAnswer> {
  const res = await doFetch(`${apiBase(siteUrl)}/enroll`, {
    method: "POST",
    headers: { authorization: `Bearer ${key}`, "content-type": "application/json" },
    body: JSON.stringify(opts.requests ? { requests: opts.requests } : {}),
  });
  const body: any = await res.json().catch(() => null);
  const clean = (s: unknown) => scrub(String(s ?? ""), { knownValues: [key] }).slice(0, 500);
  if (!res.ok || !body || typeof body !== "object") {
    return { kind: "refused", status: res.status, error: clean(body?.error ?? res.statusText) };
  }
  const claim = body.claim as Claim | undefined;
  if (!claim || typeof claim.outcome !== "string") return { kind: "refused", status: 502, error: "no claim in the answer" };
  if (typeof body.credential === "string" && body.credential !== "" && "runId" in claim) {
    const requestedBy = body.requestedBy === "admin" || body.requestedBy === "member" ? body.requestedBy : undefined;
    return {
      kind: "run",
      runId: claim.runId,
      credential: body.credential,
      rotated: body.rotated === true,
      ...(requestedBy ? { requestedBy } : {}),
    };
  }
  return { kind: "wait", claim };
}

export type FinishBody =
  | { outcome: "failed"; error: string }
  | { outcome: "built"; error?: string; handoff?: true; previewDeploymentName?: string };

export type FinishAnswer =
  | { ok: true; finished: boolean; handedOff: boolean }
  | { ok: false; status: number; error: string };

/** POST /chef-agent/finish with the run credential. Retries a lost answer a few times; a refusal is final. */
export async function finish(
  siteUrl: string,
  credential: string,
  body: FinishBody,
  opts: { fetch?: Fetch; tries?: number; sleep?: (ms: number) => Promise<void> } = {},
): Promise<FinishAnswer> {
  const doFetch = opts.fetch ?? fetch;
  const sleep = opts.sleep ?? ((ms: number) => new Promise((r) => setTimeout(r, ms)));
  const clean = (s: unknown) => scrub(String(s ?? ""), { knownValues: [credential] }).slice(0, 500);
  const tries = opts.tries ?? 3;
  for (let i = 1; ; i++) {
    let res: Response | null = null;
    try {
      res = await doFetch(`${apiBase(siteUrl)}/finish`, {
        method: "POST",
        headers: { authorization: `Bearer ${credential}`, "content-type": "application/json" },
        body: JSON.stringify(body),
      });
    } catch (e) {
      if (i >= tries) return { ok: false, status: 0, error: clean((e as Error).message) };
      await sleep(2000 * i);
      continue;
    }
    const b: any = await res.json().catch(() => null);
    if (res.ok && b) return { ok: true, finished: b.finished === true, handedOff: b.handedOff === true };
    if (res.status >= 500 && i < tries) {
      await sleep(2000 * i);
      continue;
    }
    return { ok: false, status: res.status, error: clean(b?.error ?? res.statusText) };
  }
}

/** POST /chef-agent/heartbeat: keeps an enrolled run from going stale while the worker deploys a preview. */
export async function heartbeat(siteUrl: string, credential: string, doFetch: Fetch = fetch): Promise<string | null> {
  try {
    const res = await doFetch(`${apiBase(siteUrl)}/heartbeat`, { method: "POST", headers: { authorization: `Bearer ${credential}` } });
    const b: any = await res.json().catch(() => null);
    return res.ok && typeof b?.phase === "string" ? b.phase : null;
  } catch {
    return null;
  }
}
