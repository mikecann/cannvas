// `npx chef work --container docker` (the default): the agent, the install,
// the gates and the frontend build run in a container that sees the run's
// checkout, its chef dir and its agent dir, and nothing else of the host: no
// home directory, no SSH agent, no Docker socket, no keys. The network is
// open, since the agent's subscription needs it.
//
// It plugs in as the runner's AgentUser (runner/agent-user.ts): every
// command the runner starts "as the agent" becomes `docker exec` into one
// long-lived container, as the developer's uid and gid, so the files it
// writes in the mounts are theirs. The runner's own git stays on the host.
// Each command gets exactly the allowlisted variables
// (runner/local/env.ts), forwarded by name (`-e NAME`), so no value is ever
// in an argv; the docker client's own settings (DOCKER_HOST and so on)
// never are.
//
// Inside, the agent and its files share a uid, so the file modes the build
// sandbox relies on (a root-owned plugin and config dir) don't hold there;
// the container is the boundary instead.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { chmodSync } from "node:fs";
import type { AgentUser } from "../agent-user.ts";
import { CONTAINER_HOME, LOCAL_AGENT_ENV_KEYS } from "./env.ts";

/** Node 22 and both agent CLIs, pinned. `--image` replaces it. */
export const CLAUDE_CODE_NPM_VERSION = "2.1.293";
export const CODEX_NPM_VERSION = "0.160.1";

export const DOCKERFILE = `FROM node:22-bookworm-slim
RUN apt-get update \\
 && apt-get install -y --no-install-recommends git procps ca-certificates \\
 && rm -rf /var/lib/apt/lists/*
RUN npm install -g @anthropic-ai/claude-code@${CLAUDE_CODE_NPM_VERSION} @openai/codex@${CODEX_NPM_VERSION} \\
 && npm cache clean --force
`;

/** The image tag: the Dockerfile's hash, so a changed Dockerfile builds a new image. */
export function defaultImageTag(): string {
  return `chef-work:${createHash("sha256").update(DOCKERFILE).digest("hex").slice(0, 12)}`;
}

export type DockerRun = (args: string[], o?: { input?: string; inherit?: boolean }) => { code: number | null; stdout: string; stderr: string };

/** The docker client, with the developer's environment (it needs DOCKER_HOST, its config and contexts). */
export function dockerCli(bin: string, env: Record<string, string | undefined>): DockerRun {
  return (args, o = {}) => {
    const r = spawnSync(bin, args, {
      env: env as NodeJS.ProcessEnv,
      input: o.input,
      encoding: "utf8",
      stdio: o.inherit ? ["pipe", "inherit", "inherit"] : ["pipe", "pipe", "pipe"],
      maxBuffer: 16 * 1024 * 1024,
    });
    if (r.error) throw r.error;
    return { code: r.status, stdout: r.stdout ?? "", stderr: r.stderr ?? "" };
  };
}

/** Builds the default image unless it's there. Output goes to the terminal. */
export function ensureImage(docker: DockerRun, tag: string, log: (l: string) => void): void {
  if (docker(["image", "inspect", "--format", "{{.Id}}", tag]).code === 0) return;
  if (tag !== defaultImageTag()) throw new Error(`image ${tag} isn't here; pull or build it first`);
  log(`chef work: building ${tag} (node 22, Claude Code ${CLAUDE_CODE_NPM_VERSION}, Codex ${CODEX_NPM_VERSION}); once`);
  const r = docker(["build", "--tag", tag, "-"], { input: DOCKERFILE, inherit: true });
  if (r.code !== 0) throw new Error(`docker build failed (${r.code})`);
}

export type ContainerSpec = {
  name: string;
  image: string;
  /** Host paths, mounted read-write at the same path inside. Nothing else is. */
  mounts: string[];
  /** The checkout: every command's working directory. */
  workDir: string;
  uid: number;
  gid: number;
};

const SAFE = /^\/[A-Za-z0-9._/@+-]{1,1024}$/;

/** `docker run` for the run's container. Exported for tests. */
export function runArgs(c: ContainerSpec): string[] {
  if (!/^[a-z0-9][a-z0-9_.-]{0,62}$/.test(c.name)) throw new Error("bad container name");
  for (const m of [...c.mounts, c.workDir]) {
    if (!SAFE.test(m) || m.split("/").includes("..")) throw new Error(`refusing to mount ${JSON.stringify(m)}`);
  }
  if (!c.mounts.some((m) => c.workDir === m || c.workDir.startsWith(m + "/"))) throw new Error("the checkout must be mounted");
  return [
    "run",
    "--detach",
    "--rm",
    "--name", c.name,
    "--label", "chef-work=1",
    "--user", `${c.uid}:${c.gid}`,
    "--cap-drop", "ALL",
    "--security-opt", "no-new-privileges",
    "--pids-limit", "4096",
    "--workdir", c.workDir,
    ...c.mounts.flatMap((m) => ["--volume", `${m}:${m}`]),
    c.image,
    // pid 1 stays `sleep`, which `kill -9 -1` spares, so killAll keeps the container.
    "sh", "-c", `mkdir -p ${CONTAINER_HOME} && exec sleep infinity`,
  ];
}

/**
 * What `docker exec` forwards, by name: the agent allowlist and the
 * frontend build's placeholder URL variable (src/chef/frontend.ts), under
 * the names frameworks read it by.
 */
export const FORWARDED_ENV_KEYS: readonly string[] = [
  ...LOCAL_AGENT_ENV_KEYS,
  "NEXT_PUBLIC_CONVEX_URL",
  "EXPO_PUBLIC_CONVEX_URL",
  "PUBLIC_CONVEX_URL",
  "REACT_APP_CONVEX_URL",
];

export type DockerAgentUser = AgentUser & {
  start(): void;
  stop(): void;
  /** The argv prefix of every command: `docker exec ...`. For tests. */
  readonly execPrefix: string[];
};

export function dockerAgentUser(o: { docker: DockerRun; dockerBin: string; spec: ContainerSpec }): DockerAgentUser {
  const groups: number[] = [];
  const alive = (pgid: number) => {
    try {
      process.kill(-pgid, 0);
      return true;
    } catch {
      return false;
    }
  };
  // Every allowlisted key, by name: docker sets the ones the client's
  // environment has and leaves the rest unset.
  const execPrefix = [
    "exec",
    "--interactive",
    "--workdir", o.spec.workDir,
    ...FORWARDED_ENV_KEYS.flatMap((k) => ["--env", k]),
    o.spec.name,
  ];
  const inside = (): number[] => {
    const r = o.docker(["exec", o.spec.name, "ps", "-eo", "pid=,stat=,comm="]);
    if (r.code !== 0) return [];
    const out: number[] = [];
    for (const line of r.stdout.split("\n")) {
      const [pid, stat, comm] = line.trim().split(/\s+/);
      const n = Number(pid);
      // Not pid 1 (the container's sleep), not zombies, not this ps.
      if (!Number.isInteger(n) || n <= 1 || (stat ?? "").startsWith("Z") || comm === "ps") continue;
      out.push(n);
    }
    return out;
  };
  const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
  return {
    name: `container ${o.spec.name}`,
    execPrefix,
    command: (file, args) => ({ file: o.dockerBin, args: [...execPrefix, file, ...args] }),
    spawned: (pid) => {
      groups.push(pid);
    },
    own: async () => {},
    shareDir: async (path) => {
      chmodSync(path, 0o1770);
    },
    start: () => {
      const r = o.docker(runArgs(o.spec));
      if (r.code !== 0) throw new Error(`docker run failed: ${r.stderr.trim().split("\n").pop() ?? r.code}`);
    },
    stop: () => {
      o.docker(["rm", "--force", o.spec.name]);
    },
    killAll: async () => {
      for (let i = 0; i < 50; i++) {
        for (const g of groups.filter(alive)) {
          try {
            process.kill(-g, "SIGKILL");
          } catch {
            // Gone.
          }
        }
        // Everything of the uid but pid 1 and this shell.
        o.docker(["exec", o.spec.name, "sh", "-c", "kill -9 -1 2>/dev/null; true"]);
        if (groups.filter(alive).length === 0 && inside().length === 0) return;
        await sleep(100);
      }
      throw new Error("processes in the container survive SIGKILL");
    },
    list: async () => [...groups.filter(alive), ...inside()],
  };
}
