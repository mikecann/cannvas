// The two agents a local run can use, as adapters over the runner's plan
// (src/chef/prompt.ts planAgentRun): the same prompt.md and request.md, the
// same notes files (skill-feedback.jsonl, needs-approval.jsonl,
// screenshot-plan.json, summary.md), only the command and its output differ.
//
// - claude: the runner's own `claude -p` command, unchanged, with settings
//   that keep its permissions and drop its proxy env (no ANTHROPIC_*).
// - codex: `codex exec` headless, in Codex's workspace-write sandbox, the
//   prompt on stdin (`-`), JSONL events on stdout (`--json`), the final
//   message to a file (`--output-last-message`). Flags from `codex exec
//   --help` (codex-cli 0.160.1). Codex reads no Claude plugin, so the prompt
//   lists the skills by path.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { existsSync, readdirSync, rmSync, statSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { assertInertArgs, type AgentRunPlan } from "../../src/chef/prompt.ts";
import { claudeSettings } from "../claude-settings.ts";
import { readAgentFile, summarizeStreamJson } from "../runner.ts";
import type { AgentKind } from "./env.ts";

export type AgentAdapter = {
  kind: AgentKind;
  plan: (plan: AgentRunPlan) => AgentRunPlan;
  summarize: (line: string) => string | null;
  settingsJson: (o: { localEnv?: string[] }) => string;
  afterAgent: () => Promise<void>;
};

/** What the prompt adds for a build on the developer's machine. Fixed text, plus the runner's own paths. */
export function localPromptNote(o: { chefDir: string; skills?: { name: string; path: string }[] }): string {
  const lines = [
    "",
    "## This build runs on a developer's machine",
    "",
    "`npx chef work` runs this build on the machine of one of the app's",
    "developers instead of Chef's build sandbox. The rules above still hold.",
    "What is different:",
    "",
    "- There may be no local backend. If CONVEX_SELF_HOSTED_URL is not set,",
    "  skip `npx convex dev --once`, the seed and the screenshots, and rely on",
    "  `npm test` and `npm run typecheck`.",
    "- `chef-screenshot` may not be installed. If it isn't, say so in your",
    "  summary instead of looking at the pages.",
    "- Never deploy, and never read or use anything outside this checkout and",
    `  ${o.chefDir}: no logins, keys, SSH or other projects.`,
  ];
  if (o.skills && o.skills.length > 0) {
    lines.push(
      "",
      "Skills for this platform are files here. Read the one that fits the task",
      "before you start on it, and follow it:",
      "",
      ...o.skills.map((s) => `- ${s.name}: ${s.path}`),
    );
  }
  lines.push("");
  return lines.join("\n");
}

function withPromptNote(plan: AgentRunPlan, note: string): AgentRunPlan {
  return {
    ...plan,
    files: plan.files.map((f) => (f.path === plan.stdinPath ? { ...f, content: f.content + note } : f)),
  };
}

/** Read and write denials for paths the agent has no business in, besides the ones it can't reach anyway. */
function denyRules(paths: string[]): string[] {
  const out: string[] = [];
  for (const p of paths) {
    if (!/^\/[A-Za-z0-9._/@+-]+$/.test(p)) continue;
    // An absolute path takes two slashes in a permission rule.
    out.push(`Read(/${p}/**)`, `Edit(/${p}/**)`);
  }
  return out;
}

/**
 * The settings for a local `claude -p`: the build sandbox's permissions,
 * without its env (the proxy URL and pinned models) and its /opt/chef
 * rules, plus denials for the run's own state and the developer's secrets.
 */
export function localClaudeSettingsJson(o: { localEnv?: string[]; deny: string[] }): string {
  // Only the permissions are kept; the origin only feeds the env, which goes.
  const s = claudeSettings({ siteOrigin: "https://local.invalid", ...(o.localEnv ? { localEnv: o.localEnv } : {}) });
  const settings = {
    permissions: {
      allow: s.permissions.allow,
      deny: [...s.permissions.deny.filter((d) => !d.includes("/opt/chef")), ...denyRules(o.deny)],
    },
    skipWebFetchPreflight: s.skipWebFetchPreflight,
    disableSkillShellExecution: s.disableSkillShellExecution,
  };
  return JSON.stringify(settings, null, 2) + "\n";
}

export function claudeAdapter(o: { chefDir: string; deny: string[] }): AgentAdapter {
  return {
    kind: "claude",
    plan: (plan) => withPromptNote(plan, localPromptNote({ chefDir: o.chefDir })),
    summarize: summarizeStreamJson,
    settingsJson: ({ localEnv }) => localClaudeSettingsJson({ ...(localEnv ? { localEnv } : {}), deny: o.deny }),
    afterAgent: async () => {},
  };
}

export const CODEX_LAST_MESSAGE = "codex-last-message.txt";

/** `codex exec` for a run: checked flags only, the prompt on stdin. */
export function codexArgs(o: { workDir: string; chefDir: string; lastMessagePath: string; model?: string }): string[] {
  const args = [
    "exec",
    "--json",
    "--sandbox",
    "workspace-write",
    // The checkout has no .git (the runner keeps it), so Codex must not insist.
    "--skip-git-repo-check",
    // The developer's config.toml (MCP servers, profiles, approval policy)
    // stays out; auth still comes from CODEX_HOME.
    "--ignore-user-config",
    "--cd",
    o.workDir,
    // The notes files live in the chef dir, outside the checkout.
    "--add-dir",
    o.chefDir,
    "--output-last-message",
    o.lastMessagePath,
    ...(o.model ? ["--model", o.model] : []),
    "-",
  ];
  assertInertArgs(args);
  return args;
}

/** The skills the runner's plugin holds, by name and SKILL.md path. */
export function pluginSkills(pluginDir: string | undefined): { name: string; path: string }[] {
  if (!pluginDir) return [];
  const dir = join(pluginDir, "skills");
  if (!existsSync(dir)) return [];
  return readdirSync(dir)
    .sort()
    .filter((n) => existsSync(join(dir, n, "SKILL.md")) && statSync(join(dir, n)).isDirectory())
    .map((n) => ({ name: n, path: join(dir, n, "SKILL.md") }));
}

export function codexAdapter(o: {
  codexBin: string;
  workDir: string;
  chefDir: string;
  pluginDir?: string;
  model?: string;
  /** The run's CODEX_HOME copy, removed once the agent is dead. */
  codexHome?: string;
}): AgentAdapter {
  const lastMessagePath = join(o.chefDir, CODEX_LAST_MESSAGE);
  return {
    kind: "codex",
    plan: (plan) => {
      assertInertArgs([o.codexBin]);
      const note = localPromptNote({ chefDir: o.chefDir, skills: pluginSkills(o.pluginDir) });
      return {
        ...withPromptNote(plan, note),
        command: { file: o.codexBin, args: codexArgs({ workDir: o.workDir, chefDir: o.chefDir, lastMessagePath, ...(o.model ? { model: o.model } : {}) }), cwd: o.workDir },
      };
    },
    summarize: summarizeCodexJson,
    // Codex reads no Claude settings; the file is written but unused.
    settingsJson: () => "{}\n",
    afterAgent: async () => {
      // The login copy goes before any code the agent wrote runs.
      if (o.codexHome) rmSync(join(o.codexHome, "auth.json"), { force: true });
      // summary.md is what the prompt asks for; Codex's last message stands in when it's empty.
      const summaryPath = join(o.chefDir, "summary.md");
      try {
        const summary = existsSync(summaryPath) ? readAgentFile(summaryPath, 64 * 1024) : "";
        if (summary.trim() === "" && existsSync(lastMessagePath)) {
          writeFileSync(summaryPath, readAgentFile(lastMessagePath, 64 * 1024));
        }
      } catch {
        // Best effort, like every agent file.
      }
    },
  };
}

/**
 * One readable log line from a line of `codex exec --json`, or null for one
 * not worth a log entry. Never trusted: it's the agent's output. Unknown
 * events are named, not dropped, so a format change shows in the log.
 */
export function summarizeCodexJson(line: string): string | null {
  if (line.trim() === "") return null;
  let m: any;
  try {
    m = JSON.parse(line);
  } catch {
    return line;
  }
  if (!m || typeof m !== "object") return null;
  const cut = (s: unknown, n = 300) => {
    const t = typeof s === "string" ? s : JSON.stringify(s ?? "");
    return t.length > n ? t.slice(0, n) + "..." : t;
  };
  const type = String(m.type ?? "");
  if (type === "thread.started") return `init thread=${cut(m.thread_id, 80)}`;
  if (type === "turn.started" || type === "item.started" || type === "item.updated") return null;
  if (type === "turn.completed") {
    const u = m.usage ?? {};
    return `result success input_tokens=${Number(u.input_tokens) || 0} output_tokens=${Number(u.output_tokens) || 0}`;
  }
  if (type === "turn.failed") return `result failed ${cut(m.error?.message ?? m.error)}`;
  if (type === "error") return `error ${cut(m.message ?? m.error)}`;
  if (type === "item.completed") {
    const it = m.item ?? {};
    switch (it.type) {
      case "agent_message":
        return cut(it.text);
      case "reasoning":
        return null;
      case "command_execution":
        return `tool Bash ${cut(it.command, 200)} exit=${it.exit_code ?? "?"}`;
      case "file_change":
        return `tool Edit ${cut((Array.isArray(it.changes) ? it.changes : []).map((c: any) => `${c?.kind ?? "?"} ${c?.path ?? "?"}`).join(", "), 200)}`;
      case "mcp_tool_call":
        return `tool mcp ${cut(it.server, 40)}/${cut(it.tool, 40)}`;
      case "web_search":
        return `tool WebSearch ${cut(it.query, 200)}`;
      case "todo_list":
        return null;
      case "error":
        return `error ${cut(it.message)}`;
      default:
        return `item ${cut(it.type, 40)}`;
    }
  }
  return cut(type, 40);
}
