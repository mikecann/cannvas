// One local run: the cloud runner (runner/runner.ts runChef) on the
// developer's machine, in a fresh directory of its own, with the pieces
// that differ from the build sandbox swapped (its LocalMode):
//
// - no Daytona, no egress self-test, no second Linux user: the agent "user"
//   is a Docker container (runner/local/docker.ts) or, with
//   `--container none`, the developer in their own process groups;
// - no inference proxy: the agent is the developer's own Claude Code or
//   Codex login (runner/local/env.ts, agents.ts); Chef's spend ceiling
//   doesn't apply;
// - the git credential comes from the `chef` remote's helper, fresh for the
//   clone and for the push (runner/local/git-auth.ts).
//
// Everything else is the runner's, unchanged: the snapshot check, the clone
// of chef with main merged in (conflicts left to the agent), the prompt and
// skills, the notes files, the gates and guards, the commit, the push of the
// request branch then chef, and every phase report and log line, so the
// panel shows the run as it goes. Provenance says `runner: local` and the
// host's name.
//
// The run's directory (checkout, git dir, chef dir, agent dir) is removed
// at the end, whatever happened, unless `keep` is set.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { spawnSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { chmodSync, copyFileSync, existsSync, mkdirSync, realpathSync, rmSync } from "node:fs";
import { join } from "node:path";
import { processGroupAgentUser, type AgentUser } from "../agent-user.ts";
import { runChef, type LocalMode, type RunnerResult, type Timing } from "../runner.ts";
import { removeLockedTree } from "../skills.ts";
import { scrub } from "../../src/chef/scrub.ts";
import type { FrontendConfig } from "../frontend-artifact.ts";
import { claudeAdapter, codexAdapter, type AgentAdapter } from "./agents.ts";
import { dockerAgentUser, dockerCli, type DockerAgentUser, type DockerRun } from "./docker.ts";
import { localAgentEnv, type AgentKind, type Container } from "./env.ts";
import { fillGitAuth } from "./git-auth.ts";

export type LocalRunOpts = {
  runId: string;
  /** The run credential from enroll. Only the runner's API calls carry it. */
  credential: string;
  /** The app's https://<deployment>.convex.site. */
  siteUrl: string;
  /** The developer's checkout of the app: the `chef` remote and its helper live here. */
  appDir: string;
  /** The `chef` remote's URL. */
  remoteUrl: string;
  agent: AgentKind;
  container: Container;
  /** The developer's environment. */
  hostEnv: Record<string, string | undefined>;
  /** Where run directories go, e.g. ~/.cache/chef/work. */
  baseDir: string;
  hostname: string;
  /** For Claude Code with a token (always, in a container). */
  claudeToken?: string;
  /** ~/.codex/auth.json, copied into the run for Codex in a container. */
  codexAuthPath?: string;
  /** Skills to load, `<dir>/<name>/SKILL.md`; false for none. */
  skillsDir: string | false;
  image?: string;
  dockerBin?: string;
  claudeBin?: string;
  codexBin?: string;
  model?: string;
  /** Paths the agent is told it may not read (settings deny rules). */
  deny?: string[];
  keep?: boolean;
  /** Tests: replace the helper, the docker client, fetch, the gates, install and frontend. */
  gitAuth?: (purpose: "clone" | "push") => Promise<string>;
  docker?: DockerRun;
  fetch?: typeof fetch;
  print?: (line: string) => void;
  timing?: Partial<Timing>;
  install?: string[][];
  gates?: string[][];
  frontend?: FrontendConfig | false;
  /** Called with each phase the server confirms. */
  onPhase?: (phase: string) => void;
};

export type LocalRunHandle = {
  runDir: string;
  /** The runner's result, once the run directory is gone (or kept). */
  done: Promise<RunnerResult>;
  /** The last phase the server confirmed. */
  phase: () => string;
  /** Kills every agent process now; the runner then fails at its next step. */
  killAgents: () => Promise<void>;
};

const RUN_ID = /^[a-z0-9]{8,64}$/;

export function startLocalRun(o: LocalRunOpts): LocalRunHandle {
  if (!RUN_ID.test(o.runId)) throw new Error("bad run id");
  const print = o.print ?? ((l: string) => process.stdout.write(l + "\n"));
  const clean = (s: string) => scrub(s, { knownValues: [o.credential, ...(o.claudeToken ? [o.claudeToken] : [])] });

  mkdirSync(o.baseDir, { recursive: true, mode: 0o700 });
  const runDir = join(realpathSync(o.baseDir), `${o.runId.slice(0, 8)}-${randomBytes(3).toString("hex")}`);
  const d = {
    state: join(runDir, "state"),
    git: join(runDir, "git"),
    repo: join(runDir, "repo"),
    chef: join(runDir, "chef"),
    agent: join(runDir, "agent"),
  };
  const pluginDir = join(d.agent, "plugin");
  const claudeConfigDir = join(d.agent, "claude");
  const codexHome = join(d.agent, "codex");
  const settingsPath = join(d.agent, "claude-settings.json");
  mkdirSync(runDir, { mode: 0o700 });
  for (const p of [d.repo, d.chef, d.agent]) mkdirSync(p, { mode: 0o755 });

  const docker = o.container === "docker";
  let agentUser: AgentUser;
  let container: DockerAgentUser | null = null;
  if (docker) {
    const dockerBin = o.dockerBin ?? "docker";
    const uid = process.getuid?.() ?? 1000;
    const gid = process.getgid?.() ?? 1000;
    container = dockerAgentUser({
      docker: o.docker ?? dockerCli(dockerBin, o.hostEnv),
      dockerBin,
      spec: {
        name: `chef-work-${o.runId.slice(0, 8)}-${randomBytes(2).toString("hex")}`,
        image: o.image ?? "chef-work",
        mounts: [d.repo, d.chef, d.agent],
        workDir: d.repo,
        uid,
        gid,
      },
    });
    agentUser = container;
  } else {
    agentUser = processGroupAgentUser({ name: "developer" });
  }

  // Codex in a container logs in with a copy of the developer's auth.json,
  // in the run's agent dir, removed once the agent is dead (agents.ts).
  let codexHomeForAgent: string | undefined;
  if (o.agent === "codex" && docker) {
    if (!o.codexAuthPath || !existsSync(o.codexAuthPath)) throw new Error("Codex isn't logged in here (no ~/.codex/auth.json); run `codex login`");
    mkdirSync(codexHome, { mode: 0o700 });
    copyFileSync(o.codexAuthPath, join(codexHome, "auth.json"));
    chmodSync(join(codexHome, "auth.json"), 0o600);
    codexHomeForAgent = codexHome;
  }

  const deny = [d.state, d.git, ...(o.deny ?? [])];
  const adapter: AgentAdapter =
    o.agent === "claude"
      ? claudeAdapter({ chefDir: d.chef, deny })
      : codexAdapter({
          codexBin: o.codexBin ?? "codex",
          workDir: d.repo,
          chefDir: d.chef,
          ...(o.skillsDir !== false ? { pluginDir } : {}),
          ...(o.model ? { model: o.model } : {}),
          ...(codexHomeForAgent ? { codexHome: codexHomeForAgent } : {}),
        });

  const envFor = (x: Parameters<LocalMode["agentEnv"]>[0]) =>
    localAgentEnv({
      container: o.container,
      agent: o.agent,
      purpose: x.purpose,
      hostEnv: o.hostEnv,
      ...(o.agent === "claude" ? { claudeConfigDir } : {}),
      ...(o.claudeToken ? { claudeToken: o.claudeToken } : {}),
      ...(codexHomeForAgent ? { codexHome: codexHomeForAgent } : {}),
      ...(x.localBackend ? { localBackend: x.localBackend } : {}),
      ...(x.playwrightBrowsersPath ? { playwrightBrowsersPath: x.playwrightBrowsersPath } : {}),
    });

  // The phase as the server confirms it, from the runner's own reports and
  // heartbeats, for the worker's Ctrl-C handling and its callers.
  let phase = "launched";
  const baseFetch = o.fetch ?? fetch;
  const watchFetch = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const res = await baseFetch(input, init);
    const path = String(input);
    if (res.ok && (path.endsWith("/report") || path.endsWith("/heartbeat"))) {
      void res
        .clone()
        .json()
        .then((b: any) => {
          if (typeof b?.phase === "string" && b.phase !== phase) {
            phase = b.phase;
            o.onPhase?.(phase);
          }
        })
        .catch(() => {});
    }
    return res;
  }) as typeof fetch;

  const local: LocalMode = {
    agentEnv: envFor,
    settingsJson: adapter.settingsJson,
    agentPlan: adapter.plan,
    summarize: adapter.summarize,
    afterAgent: adapter.afterAgent,
    gitAuth:
      o.gitAuth ??
      ((purpose) => {
        void purpose;
        return fillGitAuth({ appDir: o.appDir, remoteUrl: o.remoteUrl, env: o.hostEnv });
      }),
    provenance: {
      runner: "local",
      host: o.hostname.slice(0, 100),
      model: o.model ?? (o.agent === "claude" ? "Claude Code's default (the developer's subscription)" : "Codex's default (the developer's login)"),
    },
  };

  const done = (async (): Promise<RunnerResult> => {
    try {
      if (container) container.start();
      const version = agentVersion(agentUser, o.agent === "claude" ? (o.claudeBin ?? "claude") : (o.codexBin ?? "codex"), envFor({ purpose: "gates" }));
      if (version) {
        if (o.agent === "claude") local.provenance.claudeCodeVersion = version;
        else local.provenance.model = `${local.provenance.model}, ${version}`.slice(0, 200);
      }
      return await runChef(
        {
          runId: o.runId,
          api: o.siteUrl,
          siteOrigin: o.siteUrl,
          repoUrl: o.remoteUrl,
          stateDir: d.state,
          gitDir: d.git,
          workDir: d.repo,
          chefDir: d.chef,
          settingsPath,
          skillsDir: o.skillsDir,
          pluginDir,
          claudeConfigDir,
          ...(o.claudeBin ? { claudeBin: o.claudeBin } : {}),
          // No local backend binary on a developer's machine by default;
          // the prompt says how to work without one.
          localBackend: false,
          screenshots: false,
          ...(o.install ? { install: o.install } : {}),
          ...(o.gates ? { gates: o.gates } : {}),
          ...(o.frontend !== undefined ? { frontend: o.frontend } : {}),
          runnerPath: o.hostEnv.PATH ?? "/usr/local/bin:/usr/bin:/bin",
          ...(o.timing ? { timing: o.timing } : {}),
          env: { CHEF_RUN_TOKEN: o.credential },
        },
        {
          agentUser,
          // Nothing to test: the developer's machine has the network it has.
          egressCheck: async () => ({ ok: true, probes: [] }),
          fetch: watchFetch,
          print: (l) => print(clean(l)),
          local,
        },
      );
    } catch (e) {
      return { ok: false, stage: "start", error: clean((e as Error).message) };
    } finally {
      await agentUser.killAll().catch(() => {});
      container?.stop();
      if (!o.keep) removeRunDir(runDir);
      else print(`chef work: kept ${runDir}`);
    }
  })();

  return {
    runDir,
    done,
    phase: () => phase,
    killAgents: () => agentUser.killAll(),
  };
}

/** `<bin> --version` as the agent would run it: one short line, or null. */
function agentVersion(user: AgentUser, bin: string, env: Record<string, string>): string | null {
  try {
    const cmd = user.command(bin, ["--version"]);
    const r = spawnSync(cmd.file, cmd.args, { env, encoding: "utf8", timeout: 30_000 });
    const line = (r.stdout ?? "").trim().split("\n")[0] ?? "";
    return r.status === 0 && /^[A-Za-z0-9 ._()+-]{1,80}$/.test(line) ? line : null;
  } catch {
    return null;
  }
}

/** The run's directory, read-only trees (the skills plugin, the pinned config dir) included. */
export function removeRunDir(runDir: string): void {
  removeLockedTree(join(runDir, "agent", "plugin"));
  removeLockedTree(join(runDir, "agent", "claude"));
  rmSync(runDir, { recursive: true, force: true });
}
