// The environment a local run (`npx chef work`) gives the agent and the code
// it wrote. Built from fixed values and an allowlist, like the build
// sandbox's (runner/agent-env.ts), with one difference: the model is the
// developer's own subscription, not Chef's inference proxy. So no
// ANTHROPIC_* variable is ever set here, Chef's spend ceiling doesn't apply,
// and the only credential that may reach the agent is its own login:
//
// - Claude Code in a container: CLAUDE_CODE_OAUTH_TOKEN, the long-lived
//   token from `claude setup-token` (inference only), handed to the agent's
//   own process and never to the gates;
// - Codex in a container: CODEX_HOME, a run-only copy of ~/.codex/auth.json
//   (runner/local/agents.ts removes it once the agent is dead);
// - with `--container none`: the developer's HOME, so each CLI finds its
//   usual login. The agent then runs as the developer, with everything that
//   implies; `npx chef work` says so before it starts.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import type { LocalBackendEnv } from "../agent-env.ts";

export type Container = "docker" | "none";
export type AgentKind = "claude" | "codex";

/** Every key that may reach the agent or the gates. */
export const LOCAL_AGENT_ENV_KEYS: readonly string[] = [
  "HOME",
  "USER",
  "LOGNAME",
  "SHELL",
  "PATH",
  "LANG",
  "TERM",
  "TMPDIR",
  "CI",
  "CLAUDE_CONFIG_DIR",
  "CLAUDE_CODE_OAUTH_TOKEN",
  "CODEX_HOME",
  "CONVEX_AGENT_MODE",
  "CONVEX_SELF_HOSTED_URL",
  "CONVEX_SELF_HOSTED_ADMIN_KEY",
  "VITE_CONVEX_URL",
  "PLAYWRIGHT_BROWSERS_PATH",
  "NODE_EXTRA_CA_CERTS",
];

/**
 * Only for the `docker` CLI on the host, which runs each agent command in the
 * container; runner/local/docker.ts never forwards them into it.
 */
export const DOCKER_CLIENT_ENV_KEYS: readonly string[] = ["DOCKER_HOST", "DOCKER_CONFIG", "DOCKER_CONTEXT"];

/** Keys only the agent's own process gets: its login. */
export const AGENT_ONLY_KEYS: readonly string[] = ["CLAUDE_CODE_OAUTH_TOKEN", "CODEX_HOME"];

/** The container's fixed environment. */
export const CONTAINER_HOME = "/tmp/chef-home";
export const CONTAINER_PATH = "/usr/local/bin:/usr/bin:/bin";

export type LocalEnvOpts = {
  container: Container;
  agent: AgentKind;
  purpose: "agent" | "gates";
  /** The developer's environment: HOME, PATH, USER and the docker client's settings come from here. */
  hostEnv: Record<string, string | undefined>;
  /** The run's pinned Claude Code config dir; set when the agent logs in with a token. */
  claudeConfigDir?: string;
  /** The `claude setup-token` token. Required for Claude Code in a container. */
  claudeToken?: string;
  /** A run-only CODEX_HOME holding a copy of auth.json (Codex in a container). */
  codexHome?: string;
  localBackend?: LocalBackendEnv;
  playwrightBrowsersPath?: string;
};

const LOCAL_URL = /^http:\/\/127\.0\.0\.1:\d{1,5}$/;
const PLAIN_PATH = /^\/[A-Za-z0-9._/@+-]{1,1024}$/;

export function localAgentEnv(o: LocalEnvOpts): Record<string, string> {
  const host = o.hostEnv;
  const docker = o.container === "docker";
  const user = host.USER ?? host.LOGNAME ?? "chef";
  const env: Record<string, string> = {
    HOME: docker ? CONTAINER_HOME : need(host.HOME, "HOME"),
    USER: user,
    LOGNAME: user,
    SHELL: "/bin/bash",
    PATH: docker ? CONTAINER_PATH : need(host.PATH, "PATH"),
    LANG: "C.UTF-8",
    TERM: "dumb",
    TMPDIR: docker ? "/tmp" : (host.TMPDIR ?? "/tmp"),
    CI: "1",
    CONVEX_AGENT_MODE: "anonymous",
  };
  if (o.purpose === "agent") {
    if (o.agent === "claude") {
      if (o.claudeToken !== undefined) {
        if (!/^[A-Za-z0-9._~+/=-]{20,4096}$/.test(o.claudeToken)) throw new Error("the Claude Code token doesn't look like one");
        env.CLAUDE_CODE_OAUTH_TOKEN = o.claudeToken;
      } else if (docker) {
        throw new Error("Claude Code in a container needs a token from `claude setup-token` (npx chef work --save-claude-token)");
      }
      // The pinned config dir only with a token: without one, Claude Code
      // finds the developer's login through their own config.
      if (o.claudeConfigDir !== undefined && o.claudeToken !== undefined) env.CLAUDE_CONFIG_DIR = plain(o.claudeConfigDir, "CLAUDE_CONFIG_DIR");
    } else if (o.codexHome !== undefined) {
      env.CODEX_HOME = plain(o.codexHome, "CODEX_HOME");
    } else if (docker) {
      throw new Error("Codex in a container needs a copy of its login (CODEX_HOME)");
    }
  }
  if (o.playwrightBrowsersPath !== undefined) env.PLAYWRIGHT_BROWSERS_PATH = plain(o.playwrightBrowsersPath, "PLAYWRIGHT_BROWSERS_PATH");
  if (!docker && host.NODE_EXTRA_CA_CERTS) env.NODE_EXTRA_CA_CERTS = plain(host.NODE_EXTRA_CA_CERTS, "NODE_EXTRA_CA_CERTS");
  const lb = o.localBackend;
  if (lb) {
    if (!LOCAL_URL.test(lb.url)) throw new Error("the local backend URL must be http://127.0.0.1:<port>");
    delete (env as Record<string, string | undefined>).CONVEX_AGENT_MODE;
    env.CONVEX_SELF_HOSTED_URL = lb.url;
    env.CONVEX_SELF_HOSTED_ADMIN_KEY = lb.adminKey;
    env.VITE_CONVEX_URL = lb.url;
  }
  if (docker) {
    // For the docker client on the host, which needs them to reach its
    // daemon. Never forwarded into the container.
    for (const k of DOCKER_CLIENT_ENV_KEYS) {
      const val = host[k];
      if (val) env[k] = val;
    }
    if (!env.DOCKER_CONFIG && host.HOME) env.DOCKER_CONFIG = `${host.HOME}/.docker`;
  }
  assertLocalAgentEnv(env, o);
  return env;
}

/** Only allowlisted keys, never an ANTHROPIC_* or OPENAI_* one, and the login only for the agent. */
export function assertLocalAgentEnv(env: Record<string, string>, o: Pick<LocalEnvOpts, "container" | "purpose">): void {
  for (const key of Object.keys(env)) {
    if (/^(ANTHROPIC|OPENAI)_/.test(key)) throw new Error(`a local run never sets ${key}`);
    const ok = LOCAL_AGENT_ENV_KEYS.includes(key) || (o.container === "docker" && DOCKER_CLIENT_ENV_KEYS.includes(key));
    if (!ok) throw new Error(`agent env has a key outside the allowlist: ${key}`);
    if (o.purpose === "gates" && AGENT_ONLY_KEYS.includes(key)) throw new Error(`the gates must not get ${key}`);
  }
}

function need(x: string | undefined, name: string): string {
  if (!x) throw new Error(`${name} is not set`);
  return x;
}

function plain(p: string, name: string): string {
  if (!PLAIN_PATH.test(p) || p.split("/").includes("..")) throw new Error(`${name} must be an absolute plain path`);
  return p;
}
