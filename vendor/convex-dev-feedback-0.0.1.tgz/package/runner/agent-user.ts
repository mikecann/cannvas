// How the runner runs things as the agent user, and how it makes sure none
// of the agent user's processes are left. The runner (root) starts Claude
// Code, the install, the local backend and the gates through this, and kills
// everything the agent user has before gates, guards and push.
//
// Production is `systemAgentUser("chefagent")`: the child gets the user's uid
// and gid from spawn, so the environment never passes through `sudo` or an
// argv (`sudo` resets it; `env -i K=V` would put the inference placeholder in
// argv). That needs the runner to be root. Tests use `processGroupAgentUser`,
// which runs as the current user and tracks process groups instead.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { execFileSync, spawnSync } from "node:child_process";
import { chmodSync, chownSync } from "node:fs";

export type AgentCommand = {
  file: string;
  args: string[];
  /** Passed to spawn as is. */
  uid?: number;
  gid?: number;
};

export interface AgentUser {
  readonly name: string;
  /** How to start `file args` as the agent user. Never puts env values in argv. */
  command(file: string, args: string[]): AgentCommand;
  /** Called with each pid the runner started this way (its own process group). */
  spawned(pid: number): void;
  /** Hands a path, recursively, to the agent user. */
  own(path: string): Promise<void>;
  /**
   * Lets the agent user create entries in a runner-owned directory without
   * being able to rename or remove the runner's: group the agent user's,
   * mode 01770 (sticky). The directory stays the runner's.
   */
  shareDir(path: string): Promise<void>;
  /** SIGKILLs every process of the agent user and waits until none is left. */
  killAll(): Promise<void>;
  /** The agent user's live processes. Empty means none. */
  list(): Promise<number[]>;
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** The real one: a separate Linux user. The runner must be root. */
export function systemAgentUser(name = "chefagent"): AgentUser {
  if (!/^[a-z_][a-z0-9_-]{0,31}$/.test(name)) throw new Error("bad agent user name");
  const id = (flag: string) =>
    Number(execFileSync("id", [flag, name], { encoding: "utf8" }).trim());
  const uid = id("-u");
  const gid = id("-g");
  if (!Number.isInteger(uid) || uid === 0) throw new Error("the agent user can't be root");
  const pids = (): number[] => {
    const r = spawnSync("pgrep", ["-u", String(uid)], { encoding: "utf8" });
    // pgrep exits 1 when nothing matches.
    if (r.status !== 0 && r.status !== 1) throw new Error("pgrep failed");
    return r.stdout
      .split("\n")
      .map((s) => Number(s.trim()))
      .filter((n) => Number.isInteger(n) && n > 0);
  };
  return {
    name,
    command: (file, args) => ({ file, args, uid, gid }),
    spawned: () => {},
    own: async (path) => {
      // -h and no -L: symlinks are changed themselves, never followed.
      execFileSync("chown", ["-R", "-h", `${uid}:${gid}`, path]);
    },
    shareDir: async (path) => {
      chownSync(path, process.getuid?.() ?? 0, gid);
      chmodSync(path, 0o1770);
    },
    killAll: async () => {
      for (let i = 0; i < 50; i++) {
        spawnSync("pkill", ["-KILL", "-u", String(uid)]);
        if (pids().length === 0) return;
        await sleep(100);
      }
      throw new Error(`processes of ${name} survive SIGKILL`);
    },
    list: async () => pids(),
  };
}

/**
 * For tests and local runs: the current user, with every process the runner
 * starts in its own process group. `killAll` kills those groups, so a
 * background child the agent leaves behind in its group dies with it.
 * Unlike `pkill -u`, a process that starts its own session escapes this.
 */
export function processGroupAgentUser(opts: {
  name?: string;
  /** Wraps each command, e.g. with a script that records it ran "as the agent". */
  wrap?: (file: string, args: string[]) => { file: string; args: string[] };
} = {}): AgentUser & { groups: number[] } {
  const groups: number[] = [];
  const alive = (pgid: number) => {
    try {
      process.kill(-pgid, 0);
      return true;
    } catch {
      return false;
    }
  };
  return {
    name: opts.name ?? "chefagent",
    groups,
    command: (file, args) => (opts.wrap ? opts.wrap(file, args) : { file, args }),
    spawned: (pid) => {
      groups.push(pid);
    },
    own: async () => {},
    // Same user: the sticky bit is all that can be shown here.
    shareDir: async (path) => {
      chmodSync(path, 0o1770);
    },
    killAll: async () => {
      for (let i = 0; i < 50; i++) {
        const live = groups.filter(alive);
        if (live.length === 0) return;
        for (const g of live) {
          try {
            process.kill(-g, "SIGKILL");
          } catch {
            // Already gone.
          }
        }
        await sleep(50);
      }
      throw new Error("agent processes survive SIGKILL");
    },
    list: async () => groups.filter(alive),
  };
}
