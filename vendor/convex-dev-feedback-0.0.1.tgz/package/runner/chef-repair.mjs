#!/usr/bin/env node
// A repair commit (docs/chef-pipeline.md, "Repair commits"): the mechanical
// fix for a repo problem a build or a deploy refused, made in a repair
// sandbox with no agent and no AI, by fixed commands only:
//
//   lockfile   the lockfile regenerated to match package.json, with the
//              package manager the sandboxes run (npm `install
//              --package-lock-only`, or the pinned pnpm `install
//              --lockfile-only`), never running a script
//   symlinks   each tracked symlink replaced by a copy of its file when it
//              points at a file in the repo, else no longer tracked (and
//              listed in .gitignore)
//   envFiles   .env, .env.local and .npmrc no longer tracked, and listed in
//              .gitignore (the files themselves are the developer's)
//
// The commit (parent: main as it is now, author Chef) goes to its own
// branch, chef-repair/<name>, never to main: an admin applies it from the
// panel, which fast-forwards main to it.
//
// Usage: node chef-repair.mjs <40 character sha of main>
//
// Environment (set by the launcher):
//   CHEF_REPAIR_KIND     lockfile | symlinks | envFiles
//   CHEF_REPO_URL        the app's repo (Code Storage), no credentials
//   CHEF_GIT_AUTH        the git credential (a Daytona placeholder), Basic-encoded
//   CHEF_REPAIR_BRANCH   chef-repair/<name>, a new branch
//   CHEF_RESULT_FILE     where the result goes (default /tmp/chef-repair-result.json):
//                        {kind, base, sha, branch, summary, files} or {error}
//   CHEF_WORKDIR         where to check out (default /tmp/chef-repair); must not exist
//   CHEF_NPM             npm (default npm on PATH)
//
// Nothing of the repo runs here: no lifecycle scripts, no .pnpmfile, and a
// repo whose .npmrc npm would read is refused for the lockfile repair. The
// credential reaches only git, through GIT_CONFIG_* variables.
//
// Node built-ins and chef-install.mjs (delivered next to this file) only.

import { spawnSync } from "node:child_process";
import { appendFileSync, existsSync, mkdtempSync, readFileSync, renameSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, posix } from "node:path";
import { installPlan } from "./chef-install.mjs";

export const REPAIR_KINDS = ["lockfile", "symlinks", "envFiles"];
const ENV_FILES = [".env", ".env.local", ".npmrc"];
const SHA40 = /^[0-9a-f]{40}$/;
const BRANCH = /^chef-repair\/[a-z0-9][a-z0-9-]{0,62}$/;

class Refusal extends Error {}

/** The pnpm argv that only rewrites pnpm-lock.yaml: the pinned pnpm, no scripts, no pnpmfile. */
export function pnpmLockfileOnlyArgv(npm, version) {
  if (!/^\d+\.\d+\.\d+$/.test(version)) throw new Refusal(`not an exact pnpm version: ${version}`);
  return [npm, "exec", "--yes", "--ignore-scripts", "--no-audit", "--no-fund", `--package=pnpm@${version}`, "--", "pnpm", "install", "--lockfile-only", "--ignore-scripts", "--ignore-pnpmfile", "--reporter=append-only"];
}

/** npm's argv that only rewrites package-lock.json. */
export function npmLockfileOnlyArgv(npm) {
  return [npm, "install", "--package-lock-only", "--ignore-scripts", "--no-audit", "--no-fund"];
}

/** Lines to add to .gitignore so each path is ignored (a leading slash: that path only). */
export function gitignoreAdditions(existing, paths) {
  const have = new Set(existing.split("\n").map((l) => l.trim()));
  return paths.map((p) => `/${p}`).filter((l) => !have.has(l) && !have.has(l.slice(1)));
}

/** Where a symlink at `path` with `target` points, inside the repo, or null for outside. */
export function linkTargetInRepo(path, target) {
  if (target.startsWith("/") || target.includes("\0")) return null;
  const resolved = posix.normalize(posix.join(posix.dirname(path), target));
  if (resolved === ".." || resolved.startsWith("../") || resolved === "." || resolved === "") return null;
  return resolved;
}

export async function repairMain(argv, env, io = { out: (s) => process.stdout.write(s) }) {
  const resultFile = env.CHEF_RESULT_FILE || "/tmp/chef-repair-result.json";
  const auth = env.CHEF_GIT_AUTH || "";
  const scrub = (s) => (auth && auth.length >= 8 ? String(s).split(auth).join("[redacted]") : String(s));
  const say = (s) => io.out(`chef-repair: ${scrub(s)}\n`);
  const writeResult = (r) => {
    const tmp = `${resultFile}.tmp`;
    writeFileSync(tmp, scrub(JSON.stringify(r)) + "\n");
    renameSync(tmp, resultFile);
  };
  try {
    const [main] = argv;
    const kind = env.CHEF_REPAIR_KIND || "";
    const repoUrl = env.CHEF_REPO_URL || "";
    const branch = env.CHEF_REPAIR_BRANCH || "";
    const workdir = env.CHEF_WORKDIR || "/tmp/chef-repair";
    const npm = env.CHEF_NPM || "npm";
    if (!SHA40.test(main ?? "")) throw new Refusal("main must be a 40 character sha");
    if (!REPAIR_KINDS.includes(kind)) throw new Refusal(`CHEF_REPAIR_KIND must be one of ${REPAIR_KINDS.join(", ")}`);
    if (!repoUrl || /\s/.test(repoUrl)) throw new Refusal("CHEF_REPO_URL is not set");
    if (!BRANCH.test(branch)) throw new Refusal("CHEF_REPAIR_BRANCH must be chef-repair/<name>");
    if (existsSync(workdir)) throw new Refusal("the work dir already exists");

    // git, with the credential only in this process tree's GIT_CONFIG_* and hooks off.
    const home = mkdtempSync(join(tmpdir(), "chef-repair-home-"));
    const gitEnv = {
      PATH: env.PATH || "/usr/local/bin:/usr/bin:/bin",
      HOME: home,
      LANG: "C",
      GIT_CONFIG_NOSYSTEM: "1",
      GIT_CONFIG_GLOBAL: "/dev/null",
      GIT_TERMINAL_PROMPT: "0",
      ...(auth ? { GIT_CONFIG_COUNT: "1", GIT_CONFIG_KEY_0: "http.extraHeader", GIT_CONFIG_VALUE_0: `Authorization: Basic ${auth}` } : {}),
    };
    const git = (args, o = {}) => {
      const r = spawnSync("git", ["-c", "core.hooksPath=/dev/null", "-c", "commit.gpgSign=false", "-c", "core.quotePath=false", ...args], {
        cwd: o.cwd ?? workdir,
        env: gitEnv,
        encoding: o.binary ? "buffer" : "utf8",
        maxBuffer: 256 * 1024 * 1024,
      });
      if (r.status !== 0 && !o.allowFail) throw new Error(`git ${args[0]} failed: ${scrub(String(r.stderr ?? "")).trim().slice(-500)}`);
      return r;
    };

    say(`checking out main at ${main}`);
    git(["clone", "--quiet", "--no-checkout", "--", repoUrl, workdir], { cwd: dirname(workdir) });
    git(["-c", "advice.detachedHead=false", "checkout", "--quiet", "--detach", main]);
    if (git(["rev-parse", "HEAD"]).stdout.trim() !== main) throw new Refusal(`HEAD is not ${main}`);

    let summary = "";
    const files = [];
    const ignore = [];
    if (kind === "lockfile") {
      if (existsSync(join(workdir, ".npmrc"))) throw new Refusal("the repo has .npmrc, which npm would read; remove it first (the envFiles repair does)");
      const plan = installPlan(workdir);
      if ("error" in plan) throw new Refusal(`no lockfile repair: ${plan.error}`);
      const cmd = plan.manager === "pnpm" ? pnpmLockfileOnlyArgv(npm, plan.version) : npmLockfileOnlyArgv(npm);
      const clean = { PATH: gitEnv.PATH, HOME: home, LANG: "C", npm_config_update_notifier: "false", ...(env.NODE_EXTRA_CA_CERTS ? { NODE_EXTRA_CA_CERTS: env.NODE_EXTRA_CA_CERTS } : {}) };
      say(`regenerating ${plan.lockfile}: ${cmd.slice(1).join(" ")}`);
      const r = spawnSync(cmd[0], cmd.slice(1), { cwd: workdir, env: clean, encoding: "utf8", maxBuffer: 64 * 1024 * 1024, timeout: 10 * 60_000 });
      if (r.status !== 0) throw new Error(`${plan.manager} couldn't regenerate ${plan.lockfile}: ${scrub(`${r.stdout}\n${r.stderr}`).trim().split("\n").slice(-5).join(" ")}`);
      const changed = git(["status", "--porcelain", "--untracked-files=all"]).stdout.split("\n").filter(Boolean).map((l) => l.slice(3));
      const other = changed.filter((p) => p !== plan.lockfile && !p.startsWith("node_modules/") && p !== "node_modules");
      if (other.length) throw new Refusal(`regenerating the lockfile changed more than ${plan.lockfile}: ${other.slice(0, 3).join(", ")}`);
      if (!changed.includes(plan.lockfile)) throw new Refusal(`${plan.lockfile} already matches package.json; nothing to repair`);
      git(["add", "--", plan.lockfile]);
      files.push({ path: plan.lockfile, how: "regenerated" });
      summary = `Update ${plan.lockfile} to match package.json (${plan.manager === "pnpm" ? `pnpm ${plan.version}` : "npm"}, lockfile only)`;
    } else if (kind === "symlinks") {
      const entries = git(["ls-files", "-s", "-z"]).stdout.split("\0").filter(Boolean);
      const links = entries.map((e) => /^120000 [0-9a-f]+ \d\t(.+)$/s.exec(e)?.[1]).filter(Boolean);
      if (links.length === 0) throw new Refusal("the repo has no tracked symlinks; nothing to repair");
      for (const path of links) {
        const target = git(["cat-file", "blob", `:${path}`]).stdout;
        const inRepo = linkTargetInRepo(path, target);
        const tree = inRepo ? git(["ls-tree", "-z", "HEAD", "--", inRepo], { allowFail: true }).stdout : "";
        const m = /^(100644|100755) blob [0-9a-f]+\t/.exec(tree);
        if (inRepo && m) {
          const bytes = git(["cat-file", "blob", `HEAD:${inRepo}`], { binary: true }).stdout;
          git(["rm", "--cached", "--quiet", "--", path]);
          rmSync(join(workdir, path), { force: true });
          writeFileSync(join(workdir, path), bytes, { mode: m[1] === "100755" ? 0o755 : 0o644 });
          git(["add", "--", path]);
          files.push({ path, how: `copied from ${inRepo}` });
        } else {
          git(["rm", "--cached", "--quiet", "--", path]);
          ignore.push(path);
          files.push({ path, how: "no longer tracked" });
        }
      }
      const copied = files.filter((f) => f.how.startsWith("copied")).length;
      summary = `Replace ${links.length} tracked symlink${links.length === 1 ? "" : "s"}: ${copied} with copies of their files${links.length - copied ? `, ${links.length - copied} no longer tracked` : ""}`;
    } else {
      const tracked = git(["ls-files", "-z", "--", ...ENV_FILES]).stdout.split("\0").filter(Boolean);
      if (tracked.length === 0) throw new Refusal("the repo tracks none of .env, .env.local, .npmrc; nothing to repair");
      for (const path of tracked) {
        git(["rm", "--cached", "--quiet", "--", path]);
        ignore.push(path);
        files.push({ path, how: "no longer tracked" });
      }
      summary = `Stop tracking ${tracked.join(", ")} (and ignore ${tracked.length === 1 ? "it" : "them"}); the files stay on your machine`;
    }
    if (ignore.length) {
      const gi = join(workdir, ".gitignore");
      const existing = existsSync(gi) ? readFileSync(gi, "utf8") : "";
      const add = gitignoreAdditions(existing, ignore);
      if (add.length) {
        appendFileSync(gi, `${existing && !existing.endsWith("\n") ? "\n" : ""}# Chef repair: not tracked\n${add.join("\n")}\n`);
        git(["add", "--", ".gitignore"]);
        files.push({ path: ".gitignore", how: `added ${add.join(", ")}` });
      }
    }
    const message = `Chef repair: ${summary}\n\n${files.map((f) => `- ${f.path}: ${f.how}`).join("\n")}\n`;
    const msgFile = join(home, "message.txt");
    writeFileSync(msgFile, message);
    git(["-c", "user.name=Chef", "-c", "user.email=chef@chef.invalid", "commit", "--quiet", "--no-verify", "--file", msgFile]);
    const sha = git(["rev-parse", "HEAD"]).stdout.trim();
    say(`pushing ${branch} at ${sha}`);
    git(["push", "--quiet", "--no-verify", "--porcelain", repoUrl, `${sha}:refs/heads/${branch}`]);
    writeResult({ kind, base: main, sha, branch, summary, files: files.slice(0, 50) });
    say(`done: ${summary}`);
    return 0;
  } catch (e) {
    const msg = scrub(e?.message ?? e);
    io.out(`chef-repair: error: ${msg}\n`);
    try {
      writeResult({ error: msg, refused: e instanceof Refusal });
    } catch {
      // Nothing more to say.
    }
    return 1;
  }
}

if (process.argv[1] && /chef-repair\.mjs$/.test(process.argv[1])) {
  repairMain(process.argv.slice(2), process.env).then((code) => (process.exitCode = code));
}
