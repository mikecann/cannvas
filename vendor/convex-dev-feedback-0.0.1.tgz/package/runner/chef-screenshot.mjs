#!/usr/bin/env node
// Entry point for `chef-screenshot` (runner/screenshot-helper.ts). The image
// links it as /usr/local/bin/chef-screenshot, root-owned, so the agent finds
// it on PATH and can't change it. Node 22 runs the TypeScript directly with
// type stripping.
const { helperMain } = await import("./screenshot-helper.ts");
process.exitCode = await helperMain(process.argv.slice(2), process.env, {
  out: (s) => process.stdout.write(s),
  err: (s) => process.stderr.write(s),
  cwd: process.cwd(),
});
