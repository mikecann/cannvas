// The bundled `chef-check` entry point (scripts/build-runner.mjs): what the
// agent runs to see what the runner will check (runner/check.ts).
import { checkMain } from "../check.ts";

process.exitCode = await checkMain(process.argv.slice(2), process.env, process.cwd(), (s) => process.stdout.write(s));
