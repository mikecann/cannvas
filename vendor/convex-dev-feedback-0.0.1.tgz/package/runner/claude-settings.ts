// The Claude Code settings file for a Chef build, written root-owned to
// /opt/chef/claude-settings.json and passed with `claude -p --settings`.
//
// Models come from the L1 contract test (docs/l1-contract-test.md):
// - the main model is Opus 5.5;
// - thinking is mandatory on the 5.5 models, and Claude Code's background
//   calls disable thinking through its Sonnet default, so that default is
//   Sonnet 5, which accepts it;
// - nothing may set MAX_THINKING_TOKENS=0;
// - Claude Code asks for max_tokens 64000 on every main request.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

export const CHEF_MODEL = "anthropic/claude-opus-5.5";
export const CHEF_SONNET_MODEL = "anthropic/claude-sonnet-5";
export const CHEF_HAIKU_MODEL = "anthropic/claude-haiku-4.5";

/** The inference proxy's model allowlist: the pinned model and the small ones. */
export const CHEF_MODEL_ALLOWLIST: readonly string[] = [
  CHEF_MODEL,
  CHEF_SONNET_MODEL,
  CHEF_HAIKU_MODEL,
];

/** What Claude Code sends as max_tokens on main requests (L1). */
export const CLAUDE_CODE_MAX_TOKENS = 64000;

export const CHEF_SETTINGS_PATH = "/opt/chef/claude-settings.json";

/** The runner's own directory, which the agent must not read. */
export const CHEF_RUNNER_DIR = "/opt/chef";

/** Settings keys that must never appear in the settings env. */
export const FORBIDDEN_SETTINGS_ENV: readonly string[] = [
  "ANTHROPIC_API_KEY",
  "ANTHROPIC_AUTH_TOKEN",
  "MAX_THINKING_TOKENS",
];

export type ClaudeSettings = {
  env: Record<string, string>;
  permissions: { allow: string[]; deny: string[] };
  skipWebFetchPreflight: true;
  /**
   * Skills' inline `!` commands become a fixed string instead of running
   * (https://code.claude.com/docs/en/skills, "Disabling dynamic context
   * injection"). They would run before any permission prompt could matter.
   */
  disableSkillShellExecution: true;
};

/**
 * The proxy's base URL for a deployment's site origin, for example
 * `https://happy-otter-123.convex.site` gives
 * `https://happy-otter-123.convex.site/chef-agent/ai`.
 */
export function inferenceBaseUrl(siteOrigin: string): string {
  let url: URL;
  try {
    url = new URL(siteOrigin);
  } catch {
    throw new Error("site origin is not a URL");
  }
  if (url.protocol !== "https:") throw new Error("site origin must be https");
  if (url.username || url.password) {
    throw new Error("site origin must not carry credentials");
  }
  if ((url.pathname !== "/" && url.pathname !== "") || url.search || url.hash) {
    throw new Error("site origin must be an origin, with no path or query");
  }
  return `${url.origin}/chef-agent/ai`;
}

export function claudeSettings(opts: { siteOrigin: string; localEnv?: string[] }): ClaudeSettings {
  const settings: ClaudeSettings = {
    env: {
      ANTHROPIC_BASE_URL: inferenceBaseUrl(opts.siteOrigin),
      ANTHROPIC_MODEL: CHEF_MODEL,
      ANTHROPIC_DEFAULT_OPUS_MODEL: CHEF_MODEL,
      ANTHROPIC_DEFAULT_SONNET_MODEL: CHEF_SONNET_MODEL,
      ANTHROPIC_DEFAULT_HAIKU_MODEL: CHEF_HAIKU_MODEL,
      CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS: "1",
      CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC: "1",
    },
    permissions: {
      allow: [
        "Read",
        "Edit",
        "Write",
        "Grep",
        "Glob",
        "Bash(npm test *)",
        "Bash(npm run typecheck *)",
        "Bash(npm run lint *)",
        "Bash(npm run build *)",
        "Bash(npx convex dev --once *)",
        // Looking at the app: seed the local backend, serve the frontend
        // on 127.0.0.1, screenshot it (runner/screenshot-helper.ts).
        "Bash(npx convex run *)",
        "Bash(npm run dev *)",
        "Bash(npx vite *)",
        "Bash(chef-screenshot *)",
        // The runner's localEnv command, for a push refused with
        // MissingEnvironmentVariables (src/chef/prompt.ts).
        ...(opts.localEnv ? localEnvRules(opts.localEnv) : []),
      ],
      // In Claude Code permission rules a single leading slash is relative to
      // the settings file; an absolute path takes two.
      deny: [
        "WebFetch",
        "WebSearch",
        `Read(/${CHEF_RUNNER_DIR}/**)`,
        `Edit(/${CHEF_RUNNER_DIR}/**)`,
      ],
    },
    skipWebFetchPreflight: true,
    disableSkillShellExecution: true,
  };
  for (const key of FORBIDDEN_SETTINGS_ENV) {
    if (key in settings.env) throw new Error(`settings env must not set ${key}`);
  }
  return settings;
}

/** The file's exact contents: stable key order, trailing newline. */
/** Allow rules for exactly the localEnv command, with or without more arguments. */
function localEnvRules(argv: string[]): string[] {
  if (argv.length === 0 || !argv.every((a) => /^[A-Za-z0-9@%+=:,./_-]+$/.test(a))) {
    throw new Error("localEnv must be an argv of plain tokens");
  }
  const cmd = argv.join(" ");
  return [`Bash(${cmd})`, `Bash(${cmd} *)`];
}

export function claudeSettingsJson(opts: { siteOrigin: string; localEnv?: string[] }): string {
  return JSON.stringify(claudeSettings(opts), null, 2) + "\n";
}
