// Types for runner/chef-install.mjs.
import type { InstallPlan, InstallRefusal, PlanFiles, WarmMarker } from "./chef-install-plan.mjs";
export type { InstallPlan, InstallRefusal, PlanFiles, WarmMarker };
export const PNPM_FOR_LOCKFILE: Readonly<Record<number, string>>;
export const NPM_INSTALL: readonly string[];
export function pnpmInstallArgv(version: string): string[];
export function packageManagerField(dir: string): { name: string; version: string | null } | null;
export function pnpmLockfileMajor(text: string): number | null;
export function checkoutFiles(dir: string): PlanFiles;
export function installPlan(dir: string): InstallPlan | InstallRefusal;
export function describePlan(plan: InstallPlan | InstallRefusal): string;
export function lockfileCheckArgv(plan: InstallPlan | InstallRefusal): string[];
export function lockfileFix(plan: InstallPlan | InstallRefusal): string[];
export function pnpmSpecifierMismatches(dir: string): string[] | null;
export type WarmLookup =
  | { ok: true; plan: InstallPlan; inputsHash: string; dir: string; marker: WarmMarker }
  | { ok: false; reason: string; inputsHash?: string };
export function warmLookup(dir: string, root?: string): Promise<WarmLookup>;
export function prepareWarm(lookup: Extract<WarmLookup, { ok: true }>, parent?: string): { argv: string[]; dir: string };
