// Types for runner/chef-frontend-unpack.mjs, for the tests.
export const CONVEX_URL_PLACEHOLDER: string;
export const MAX_ARTIFACT_BYTES: number;
export const MAX_ARTIFACT_FILES: number;
export const MAX_ARTIFACT_UNPACKED_BYTES: number;
export class Refusal extends Error {}
export type UnpackOptions = { inPrefix: string; parts: number; sha256: string; out: string; url: string };
export function parseArgs(argv: string[]): UnpackOptions;
export function readArchive(inPrefix: string, parts: number, sha256: string): Buffer;
export function parseTar(tar: Buffer | Uint8Array): Array<{ path: string; bytes: Buffer }>;
export function replaceAll(buf: Buffer, from: Buffer, to: Buffer): { bytes: Buffer; count: number };
export function unpack(opts: UnpackOptions): { files: number; replaced: number; filesReplaced: number };
