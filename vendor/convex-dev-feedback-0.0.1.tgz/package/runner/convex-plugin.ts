// The official Convex Claude Code plugin for the build agent
// (convex@claude-plugins-official, Apache-2.0), from the pinned copy in
// vendor/convex-plugin/ that the runner bundle carries
// (scripts/vendor-convex-plugin.mjs, scripts/build-runner.mjs). The launcher
// installs it root-owned with the runner, hash-checked, at
// /opt/chef/runner/convex-plugin.
//
// Before the agent, the runner builds the plugin the agent loads from that
// copy, like the skills plugin (runner/skills.ts): a fresh dir, root-owned,
// files 0444 and dirs 0555 under a runner-owned parent, so the agent can't
// edit, replace or add anything in it. Only an allowlist is copied, and the
// manifest and hooks file are written here rather than copied:
//
// - loaded: the skills (their `allowed-tools` and `hooks` frontmatter
//   dropped, as for Chef's own), the convex-expert and convex-reviewer
//   agents, and two offline hooks: the lint guard before Write/Edit and the
//   typecheck at Stop. They run as the agent user, with the agent's
//   environment, in the agent's sandbox: nothing they can do the agent
//   couldn't do itself.
// - off, by construction: the MCP server (no `mcpServers` in the manifest,
//   no .mcp.json; also --strict-mcp-config), the monitors (no `experimental`
//   key), commands, and the SessionStart hooks (telemetry and a network
//   version check). hooks/analytics.mjs, which the two hooks import, is a
//   no-op written here; the agent's environment also opts out
//   (CONVEX_PLUGIN_TELEMETRY=0, DO_NOT_TRACK=1), and egress would refuse it
//   anyway.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { existsSync, lstatSync, mkdirSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { assertRunnerOwnedPath, lockTree, removeLockedTree, stripSkillFrontmatter } from "./skills.ts";

/** Where the launcher installs the vendored copy, with the runner (src/client/chefDelivery.ts RUNNER_DIR). */
export const DEFAULT_CONVEX_PLUGIN_SOURCE = "/opt/chef/runner/convex-plugin";
/** Where the runner builds the plugin the agent loads. */
export const DEFAULT_CONVEX_PLUGIN_DIR = "/opt/chef-agent/convex-plugin";

export const CONVEX_PLUGIN_AGENTS = ["convex-expert.md", "convex-reviewer.md"];
export const CONVEX_PLUGIN_HOOK_SCRIPTS = ["convex-lint.mjs", "convex-typecheck.mjs"];

/** The hooks the agent's session gets: the lint guard and the typecheck, nothing at SessionStart. */
export const CONVEX_PLUGIN_HOOKS = {
  hooks: {
    PreToolUse: [
      {
        matcher: "Write|Edit|MultiEdit",
        hooks: [{ type: "command", command: 'node "${CLAUDE_PLUGIN_ROOT}/hooks/convex-lint.mjs"' }],
      },
    ],
    Stop: [
      {
        hooks: [{ type: "command", command: 'node "${CLAUDE_PLUGIN_ROOT}/hooks/convex-typecheck.mjs"', timeout: 180 }],
      },
    ],
  },
};

/** Stands in for the plugin's telemetry module: the hooks import it, and it sends nothing. */
export const ANALYTICS_STUB = `// Written by Chef's runner in place of the Convex plugin's telemetry module:
// build sandboxes send nothing anywhere.
export function capture() {}
export function isConvexProject() {
  return false;
}
`;

/**
 * Counts each run of a plugin hook (src/chef/pluginUsage.ts) by appending
 * its name to the log the runner reads after the agent, then runs the hook
 * itself in the same process (its stdin, its exit code).
 */
export const HOOK_COUNTER = `// Written by Chef's runner: counts each run of a Convex plugin hook for the
// run's record (src/chef/pluginUsage.ts), then runs the hook.
import { appendFileSync } from "node:fs";
const [log, name] = process.argv.slice(2);
if (name !== "convex-lint" && name !== "convex-typecheck") process.exit(0);
try {
  appendFileSync(log, name + "\\n");
} catch {
  // Counting is best effort.
}
await import(new URL(\`./\${name}.mjs\`, import.meta.url));
`;

/** What the plugin tells the agent it is for (its manifest's description). */
export const CONVEX_PLUGIN_BRIEF =
  "Convex: skills (convex:*) and agents (convex:convex-expert, convex:convex-reviewer). For any change under convex/, ask convex-expert (or read the matching skill) before writing it, and run convex-reviewer on your diff before finishing, fixing what it finds.";

/** Env for the agent and its hooks: the plugin's own telemetry opt-outs. */
export const CONVEX_PLUGIN_ENV: Record<string, string> = {
  CONVEX_PLUGIN_TELEMETRY: "0",
  DO_NOT_TRACK: "1",
};

const NAME = /^[a-z0-9][a-z0-9_-]{0,63}$/;
const FILE = /^[A-Za-z0-9._-]{1,128}$/;
const VERSION = /^\d+\.\d+\.\d+([-+][0-9A-Za-z.-]+)?$/;
const MAX_FILE_BYTES = 1024 * 1024;
const MAX_TOTAL_BYTES = 8 * 1024 * 1024;

export type ConvexPluginResult = {
  version: string;
  skills: string[];
  agents: string[];
  hooks: string[];
  /** What wasn't loaded, with why. */
  skipped: string[];
};

function regularFile(path: string, max = MAX_FILE_BYTES): Buffer | null {
  if (!existsSync(path)) return null;
  const s = lstatSync(path);
  if (!s.isFile() || s.size > max) return null;
  return readFileSync(path);
}

/**
 * Builds `dir` from the vendored copy at `source`. Null when there is no
 * copy (an image or a test without it): the agent runs without the plugin.
 * Throws on a copy that isn't the Convex plugin.
 */
export function buildConvexPlugin(source: string, dir: string, opts: { usageLog?: string } = {}): ConvexPluginResult | null {
  if (opts.usageLog !== undefined && !/^\/[A-Za-z0-9._/-]+$/.test(opts.usageLog)) throw new Error("usageLog must be an absolute plain path");
  removeLockedTree(dir);
  const manifestRaw = regularFile(join(source, ".claude-plugin", "plugin.json"));
  if (!manifestRaw) return null;
  const manifest = JSON.parse(manifestRaw.toString("utf8")) as { name?: unknown; version?: unknown; description?: unknown };
  if (manifest.name !== "convex" || typeof manifest.version !== "string" || !VERSION.test(manifest.version)) {
    throw new Error("the vendored Convex plugin's manifest isn't the convex plugin's");
  }
  const result: ConvexPluginResult = { version: manifest.version, skills: [], agents: [], hooks: [], skipped: [] };
  const planned: { rel: string; content: Buffer | string }[] = [];
  let total = 0;
  const plan = (rel: string, content: Buffer | string) => {
    total += content.length;
    if (total > MAX_TOTAL_BYTES) throw new Error("the vendored Convex plugin is too large");
    planned.push({ rel, content });
  };

  const skillsDir = join(source, "skills");
  if (existsSync(skillsDir) && lstatSync(skillsDir).isDirectory()) {
    for (const name of readdirSync(skillsDir).sort()) {
      const d = join(skillsDir, name);
      if (!NAME.test(name) || !lstatSync(d).isDirectory()) {
        result.skipped.push(`skill ${name.slice(0, 64)}: not a skill directory`);
        continue;
      }
      const files: { rel: string; content: Buffer | string }[] = [];
      let bad: string | null = null;
      for (const f of readdirSync(d).sort()) {
        const content = FILE.test(f) ? regularFile(join(d, f)) : null;
        if (!content) {
          bad = `${f.slice(0, 64)} is not a plain file`;
          break;
        }
        files.push({ rel: `skills/${name}/${f}`, content: f === "SKILL.md" ? stripSkillFrontmatter(content.toString("utf8")).text : content });
      }
      if (bad || !files.some((x) => x.rel.endsWith("/SKILL.md"))) {
        result.skipped.push(`skill ${name}: ${bad ?? "no SKILL.md"}`);
        continue;
      }
      for (const x of files) plan(x.rel, x.content);
      result.skills.push(name);
    }
  }
  for (const a of CONVEX_PLUGIN_AGENTS) {
    const content = regularFile(join(source, "agents", a));
    if (!content) {
      result.skipped.push(`agent ${a}: missing`);
      continue;
    }
    plan(`agents/${a}`, stripSkillFrontmatter(content.toString("utf8")).text);
    result.agents.push(a.replace(/\.md$/, ""));
  }
  for (const h of CONVEX_PLUGIN_HOOK_SCRIPTS) {
    const content = regularFile(join(source, "hooks", h));
    if (!content) {
      result.skipped.push(`hook ${h}: missing`);
      continue;
    }
    plan(`hooks/${h}`, content);
    result.hooks.push(h.replace(/\.mjs$/, ""));
  }
  // The hooks file names only the scripts that are there. With a usage log,
  // each runs through the counter (HOOK_COUNTER), which then runs it.
  const hooks = JSON.parse(JSON.stringify(CONVEX_PLUGIN_HOOKS)) as typeof CONVEX_PLUGIN_HOOKS;
  if (opts.usageLog) {
    const counted = (name: string) => `node "\${CLAUDE_PLUGIN_ROOT}/hooks/chef-count.mjs" "${opts.usageLog}" ${name}`;
    hooks.hooks.PreToolUse[0].hooks[0].command = counted("convex-lint");
    hooks.hooks.Stop[0].hooks[0].command = counted("convex-typecheck");
    plan("hooks/chef-count.mjs", HOOK_COUNTER);
  }
  if (!result.hooks.includes("convex-lint")) (hooks.hooks as Partial<typeof hooks.hooks>).PreToolUse = undefined;
  if (!result.hooks.includes("convex-typecheck")) (hooks.hooks as Partial<typeof hooks.hooks>).Stop = undefined;
  plan("hooks/hooks.json", JSON.stringify(hooks, null, 2) + "\n");
  plan("hooks/analytics.mjs", ANALYTICS_STUB);
  // Only these keys: no mcpServers, no experimental monitors, no commands.
  plan(
    ".claude-plugin/plugin.json",
    JSON.stringify(
      {
        name: "convex",
        version: result.version,
        // The brief the agent reads: what the plugin is for, and that it is
        // to be used for every change under convex/ (src/chef/prompt.ts too).
        description: CONVEX_PLUGIN_BRIEF,
        license: "Apache-2.0",
        skills: "./skills/",
        agents: result.agents.map((a) => `./agents/${a}.md`),
        // hooks/hooks.json loads from its default place.
      },
      null,
      2,
    ) + "\n",
  );

  mkdirSync(dirname(dir), { recursive: true, mode: 0o755 });
  assertRunnerOwnedPath(dirname(dir));
  for (const f of planned) {
    const path = join(dir, f.rel);
    mkdirSync(dirname(path), { recursive: true, mode: 0o755 });
    writeFileSync(path, f.content);
  }
  lockTree(dir);
  assertRunnerOwnedPath(dir);
  return result;
}
