// `chef git-credential <get|store|erase>`: a git credential helper
// (gitcredentials(7)) for chef's remote. On `get` it asks the deployment
// for a short-lived Code Storage token (chefGitCredential) and writes
// username and password to git on stdout, and nothing else, ever, to stdout.
// It answers only for the host and path of chef's remote, so the token is
// never handed to another server. `store` and `erase` do nothing: the token
// expires on its own and is never kept.
//
// Git doesn't say whether it is fetching or pushing, so the token can push
// unless `--read` is given.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { scrub } from "../src/chef/scrub.ts";
import type { Convex } from "./convex.ts";

export type CredentialRequest = Record<string, string>;

/** The `key=value` lines git writes, up to a blank line or the end. */
export function parseCredentialRequest(text: string): CredentialRequest {
  const out: CredentialRequest = {};
  for (const line of text.split("\n")) {
    const l = line.replace(/\r$/, "");
    if (l === "") break;
    const eq = l.indexOf("=");
    if (eq <= 0) continue;
    const key = l.slice(0, eq);
    // Repeated keys (wwwauth[], capability[]) aren't needed here; keep the first.
    if (!(key in out)) out[key] = l.slice(eq + 1);
  }
  return out;
}

function trimPath(p: string): string {
  return p.replace(/^\/+/, "").replace(/\/+$/, "").replace(/\.git$/, "");
}

/** Whether git is asking about chef's remote (`remoteUrl`). Null when it is, or why not. */
export function mismatch(req: CredentialRequest, remoteUrl: string): string | null {
  let u: URL;
  try {
    u = new URL(remoteUrl);
  } catch {
    return "the deployment gave no valid remote URL";
  }
  if (req.url) {
    // Git may send the whole URL instead of its parts.
    try {
      const r = new URL(req.url);
      req = { ...req, protocol: r.protocol.replace(/:$/, ""), host: r.host, path: r.pathname };
    } catch {
      return "git sent an unreadable url";
    }
  }
  if (req.protocol !== u.protocol.replace(/:$/, "")) return `protocol ${req.protocol ?? "(none)"} is not chef's`;
  if (req.host !== u.host) return `host ${req.host ?? "(none)"} is not chef's`;
  if (req.path !== undefined && trimPath(req.path) !== trimPath(u.pathname)) return "path is not chef's repo";
  return null;
}

export type CredentialAnswer = {
  remoteUrl?: unknown;
  username?: unknown;
  password?: unknown;
  expiresAt?: unknown;
};

/** The lines for git: username, password, and when git should stop reusing them. */
export function formatCredential(a: CredentialAnswer): string | null {
  const ok = (s: unknown): s is string => typeof s === "string" && s !== "" && !/[\r\n\0]/.test(s);
  if (!ok(a.username) || !ok(a.password)) return null;
  let expiry = "";
  const t = typeof a.expiresAt === "number" ? a.expiresAt : typeof a.expiresAt === "string" ? Date.parse(a.expiresAt) : NaN;
  if (Number.isFinite(t) && t > 0) expiry = `password_expiry_utc=${Math.floor((t > 1e12 ? t / 1000 : t))}\n`;
  return `username=${a.username}\npassword=${a.password}\n${expiry}`;
}

export type CredentialIo = {
  stdin: string;
  /** To git. Only the credential goes here. */
  write: (s: string) => void;
  /** To the person (stderr): why there is no credential. */
  log: (line: string) => void;
};

/** Returns the exit code. */
export async function gitCredential(
  action: string | undefined,
  convex: Convex,
  io: CredentialIo,
  opts: { read: boolean },
): Promise<number> {
  if (action === "store" || action === "erase") return 0;
  if (action !== "get") {
    io.log("usage: chef git-credential <get|store|erase>   (git runs this; see `git help credential`)");
    return 2;
  }
  const req = parseCredentialRequest(io.stdin);
  let answer: CredentialAnswer | null;
  try {
    answer = await convex.run<CredentialAnswer | null>("chefGitCredential", { write: !opts.read });
  } catch (e) {
    io.log(`chef git-credential: ${scrub(e instanceof Error ? e.message : String(e))}`);
    return 1;
  }
  if (!answer || typeof answer.remoteUrl !== "string") {
    io.log("chef git-credential: the deployment gave no credential");
    return 1;
  }
  const why = mismatch(req, answer.remoteUrl);
  if (why) {
    io.log(`chef git-credential: not answering: ${why}`);
    return 1;
  }
  const lines = formatCredential(answer);
  if (!lines) {
    io.log("chef git-credential: the deployment's credential is malformed");
    return 1;
  }
  io.write(lines);
  return 0;
}
