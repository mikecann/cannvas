// The app's repo on Code Storage, from the laptop's side: push HEAD as
// chef's `main` (a pack uploaded to the deployment, pushed from inside
// Convex, so no git token is needed here), the `chef` git remote with this
// CLI as its credential helper, and `chef sync`.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { realpathSync } from "node:fs";
import { relative } from "node:path";
import { scrub } from "../src/chef/scrub.ts";
import type { Convex } from "./convex.ts";
import { CliError, lastLines, type Deps } from "./deps.ts";

export const REMOTE_NAME = "chef";
export const MAIN = "main";
const SHA = /^[0-9a-f]{40}$/;

async function git(deps: Deps, cwd: string, args: string[], input?: string) {
  return await deps.exec("git", args, { cwd, ...(input === undefined ? {} : { input }) });
}

async function gitOk(deps: Deps, cwd: string, args: string[]): Promise<string> {
  const r = await git(deps, cwd, args);
  if (r.code !== 0) throw new CliError(`git ${args[0]} failed: ${scrub(lastLines(r.stderr, 6))}`);
  return r.stdout.trim();
}

/** chefRepoRefs' answer as branch -> sha, whatever shape it comes in. */
export function normalizeRefs(raw: unknown): Record<string, string> {
  const out: Record<string, string> = {};
  const put = (name: unknown, sha: unknown) => {
    if (typeof name === "string" && typeof sha === "string" && SHA.test(sha)) out[name.replace(/^refs\/heads\//, "")] = sha;
  };
  const obj = raw && typeof raw === "object" && "refs" in raw ? (raw as { refs: unknown }).refs : raw;
  if (Array.isArray(obj)) for (const r of obj) put(r?.ref ?? r?.name, r?.sha ?? r?.oid);
  else if (obj && typeof obj === "object") for (const [k, v] of Object.entries(obj)) put(k, v);
  return out;
}

/** The remote URL in a setup or credential answer, without any credentials in it. */
export function cleanRemoteUrl(raw: unknown): string | null {
  if (typeof raw !== "string" || raw === "") return null;
  let u: URL;
  try {
    u = new URL(raw);
  } catch {
    return null;
  }
  if (u.protocol !== "https:" && u.protocol !== "http:") return null;
  u.username = "";
  u.password = "";
  u.search = "";
  u.hash = "";
  return u.toString();
}

export type PushResult = { sha: string; before: string | null; pushed: boolean };

/**
 * Make chef's `main` this checkout's HEAD: only a new branch or a
 * fast-forward. Packs just what the remote lacks when it already has main.
 */
export async function pushHeadAsMain(deps: Deps, convex: Convex, cwd: string): Promise<PushResult> {
  const sha = await gitOk(deps, cwd, ["rev-parse", "HEAD"]);
  const refs = normalizeRefs(await convex.run("chefRepoRefs"));
  const before = refs[MAIN] ?? null;
  if (before === sha) return { sha, before, pushed: false };
  if (before) {
    const known = await git(deps, cwd, ["cat-file", "-e", `${before}^{commit}`]);
    if (known.code !== 0) {
      throw new CliError(
        `chef's main is at ${before.slice(0, 12)}, which this checkout doesn't have. ` +
          `Fetch and merge it first: git fetch ${REMOTE_NAME} && git merge ${REMOTE_NAME}/${MAIN}`,
      );
    }
    const ff = await git(deps, cwd, ["merge-base", "--is-ancestor", before, sha]);
    if (ff.code !== 0) {
      throw new CliError(
        `chef's main (${before.slice(0, 12)}) isn't an ancestor of HEAD; merge it first: git merge ${REMOTE_NAME}/${MAIN}`,
      );
    }
  }
  const pack = await deps.exec("git", ["pack-objects", "--revs", "--stdout", "-q"], {
    cwd,
    input: `${sha}\n${before ? `^${before}\n` : ""}`,
  });
  if (pack.code !== 0) throw new CliError(`git pack-objects failed: ${scrub(lastLines(pack.stderr, 6))}`);
  deps.log(`  packed ${sha.slice(0, 12)}${before ? ` since ${before.slice(0, 12)}` : ""} (${pack.stdoutBytes.length} bytes)`);

  const up = await convex.run<unknown>("chefRepoUploadUrl");
  const uploadUrl = typeof up === "string" ? up : (up as { url?: unknown } | null)?.url;
  if (typeof uploadUrl !== "string" || !/^https?:\/\//.test(uploadUrl)) throw new CliError("chefRepoUploadUrl gave no URL");
  const res = await deps.fetch(uploadUrl, {
    method: "POST",
    headers: { "Content-Type": "application/x-git-packfile" },
    body: new Uint8Array(pack.stdoutBytes),
  });
  if (!res.ok) throw new CliError(`uploading the pack failed: HTTP ${res.status}`);
  let storageId: unknown;
  try {
    storageId = JSON.parse(await res.text()).storageId;
  } catch {
    storageId = undefined;
  }
  if (typeof storageId !== "string") throw new CliError("the upload answered without a storageId");

  await convex.run("chefRepoPushPack", {
    storageId,
    ref: MAIN,
    newSha: sha,
    ...(before ? { oldSha: before } : {}),
  });
  return { sha, before, pushed: true };
}

/**
 * The credential helper line for git config: a shell function so it runs
 * from the app directory however deep in the repo git was started.
 */
export function helperCommand(opts: { self: string; gitRoot: string; appDir: string; module: string; prod: boolean }): string {
  const real = (p: string) => {
    try {
      return realpathSync(p);
    } catch {
      return p;
    }
  };
  const rel = relative(real(opts.gitRoot), real(opts.appDir));
  const extra = [
    ...(opts.module !== "chef" ? ["--module", opts.module] : []),
    ...(opts.prod ? ["--prod"] : []),
  ];
  const dir = `"$(git rev-parse --show-toplevel)"${rel ? `/${shellQuote(rel)}` : ""}`;
  return `!f() { cd ${dir} && ${opts.self} git-credential${extra.length ? " " + extra.join(" ") : ""} "$@"; }; f`;
}

function shellQuote(s: string): string {
  return /^[\w./-]+$/.test(s) ? s : `'${s.replace(/'/g, `'\\''`)}'`;
}

export type RemoteResult = { action: "added" | "unchanged"; url: string };

/**
 * `git remote add chef <url>` and the credential helper for exactly that
 * URL. Other helpers (a keychain) are cleared for it, so git never stores
 * the short-lived token anywhere.
 */
export async function configureRemote(
  deps: Deps,
  cwd: string,
  url: string,
  helper: string,
): Promise<RemoteResult> {
  const existing = await git(deps, cwd, ["remote", "get-url", REMOTE_NAME]);
  let action: RemoteResult["action"] = "unchanged";
  if (existing.code === 0) {
    if (existing.stdout.trim() !== url) {
      throw new CliError(
        `There is already a git remote "${REMOTE_NAME}" (${scrub(existing.stdout.trim())}), not chef's repo. Rename it (git remote rename ${REMOTE_NAME} <other>) and run init again.`,
      );
    }
  } else {
    await gitOk(deps, cwd, ["remote", "add", REMOTE_NAME, url]);
    action = "added";
  }
  const key = `credential.${url}`;
  await git(deps, cwd, ["config", "--local", "--unset-all", `${key}.helper`]);
  // An empty helper resets the list, so global helpers don't see this URL.
  await gitOk(deps, cwd, ["config", "--local", "--add", `${key}.helper`, ""]);
  await gitOk(deps, cwd, ["config", "--local", "--add", `${key}.helper`, helper]);
  await gitOk(deps, cwd, ["config", "--local", `${key}.useHttpPath`, "true"]);
  return { action, url };
}

/** `chef sync`: push HEAD to chef's main through the remote. Never forced. */
export async function syncToMain(deps: Deps, cwd: string): Promise<{ sha: string; output: string }> {
  const remote = await git(deps, cwd, ["remote", "get-url", REMOTE_NAME]);
  if (remote.code !== 0) throw new CliError(`No git remote "${REMOTE_NAME}"; run \`npx chef init\` first`, 2);
  const sha = await gitOk(deps, cwd, ["rev-parse", "HEAD"]);
  const dirty = await git(deps, cwd, ["status", "--porcelain", "--untracked-files=no"]);
  if (dirty.stdout.trim()) deps.log("chef sync: uncommitted changes are not pushed; only HEAD is");
  const r = await deps.exec("git", ["push", "--porcelain", REMOTE_NAME, `HEAD:refs/heads/${MAIN}`], {
    cwd,
    env: { GIT_TERMINAL_PROMPT: "0" },
  });
  const output = scrub(`${r.stdout}${r.stderr}`.trim());
  if (r.code !== 0) {
    const hint = /non-fast-forward|fetch first|rejected/.test(output)
      ? `\nchef's main has commits HEAD doesn't: git fetch ${REMOTE_NAME} && git merge ${REMOTE_NAME}/${MAIN}`
      : "";
    throw new CliError(`git push failed:\n${lastLines(output, 10)}${hint}`);
  }
  return { sha, output };
}
