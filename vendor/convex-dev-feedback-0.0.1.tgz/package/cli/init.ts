// `chef init`: set an app up for Chef. First it settles whether the app
// wants cloud builds too (--cloud / --no-cloud; an app with
// @convex-dev/chef-cloud installed or wired does; otherwise it asks). Then,
// in order:
//
//   1. preflight (nothing changes if anything fails)
//   2. with cloud builds, @convex-dev/chef-cloud vendored if it isn't
//      installed (cli/cloud.ts); then the code edits, printed; applied and
//      committed only with --write (with --write --no-commit, applied and
//      nothing else: init stops there)
//   3. the deploy guard (cli/guard.ts), push the functions, run the upgrade
//      steps (hash any /agent/* key still stored in plaintext)
//   4. the app's admin (named, never whoever signs in first)
//
// and that is all for the feedback board alone. With cloud builds:
//
//   5. create the repo, push HEAD as chef's main, the `chef` git remote
//      with this CLI as its credential helper
//   6. a preview deploy key and throwaway preview env vars
//   7. a deploy key for this deployment, for "Ship it" (offered)
//   8. a summary, and the cost question before turning builds on
//
// Every step is safe to run again. Nothing secret is printed: tokens, keys
// and env values go from one program to the next and are dropped.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { readFileSync } from "node:fs";
import { join } from "node:path";
import { CHEF_CLOUD, chefCloudDeclared, chefCloudInstalled, DEFAULT_CHEF_CLOUD_SOURCE, installChefCloud, installLines, packageManager } from "./cloud.ts";
import { Convex } from "./convex.ts";
import { CliError, type Deps } from "./deps.ts";
import { applyEdits, CHEF_CLOUD_PACKAGE, localEnvNpmScript, pendingEdits, planEdits, renderEdit } from "./edits.ts";
import { deployGuard } from "./guard.ts";
import { LOCAL_ENV_NPM_SCRIPT, LOCAL_ENV_SCRIPT, requiredEnvNames, throwawayValues, valueKinds } from "./envvars.ts";
import { Platform, previewDefaultNames } from "./platform.ts";
import { convexDirOf, preflight, renderChecks, type Deployment } from "./preflight.ts";
import { checkLockfile } from "./lockcheck.ts";
import { cleanRemoteUrl, configureRemote, helperCommand, MAIN, pushHeadAsMain, REMOTE_NAME } from "./repo.ts";

export type InitOptions = {
  cwd: string;
  module: string;
  prod: boolean;
  /** Apply (and commit) the code edits. */
  write: boolean;
  /**
   * With --write: commit the edits and go on to setup (default). False
   * (--no-commit): write the edits only, on a dirty tree too, and stop.
   */
  commit: boolean;
  /** Turn cloud builds on without asking. */
  enable: boolean;
  /**
   * The app's admin (chefSetAdmin): approves builds and ships. Asked for when
   * the app has none. Also who is recorded as setting the deploy keys.
   */
  admin?: string;
  skipPreview: boolean;
  rotatePreviewKey: boolean;
  /** Create the "Ship it" deploy key without asking. */
  deployKey?: boolean;
  /** Don't create or ask about the "Ship it" deploy key. */
  skipDeployKey?: boolean;
  /** A new "Ship it" deploy key even if CHEF_DEPLOY_KEY is set. */
  rotateDeployKey?: boolean;
  /** The beta channel: create its deploy key, for this deployment, without asking (--beta). */
  beta?: string;
  /** Don't create or ask about the beta's deploy key (--skip-beta). */
  skipBeta?: boolean;
  /** How git's credential helper runs this CLI (default `npx chef`). */
  self: string;
  /** Cloud builds too (--cloud), the feedback board alone (--no-cloud), or undefined to find out. */
  cloud?: boolean;
  /** Where to get @convex-dev/chef-cloud when it isn't installed (--cloud-from). */
  cloudFrom?: string;
};

export const COMMIT_MESSAGE = "Chef: set up cloud builds (npx chef init)";
export const FEEDBACK_COMMIT_MESSAGE = "Chef: add the feedback board (npx chef init)";
export const PREVIEW_KEY_NAME = "chef-cloud-builds";
/** The env var chefSetPreviewDeployKey reads (PREVIEW_KEY_ENV in packages/chef-cloud/src/client/chefEffects.ts). */
export const PREVIEW_KEY_ENV = "CHEF_PREVIEW_DEPLOY_KEY";
/** The env var chefSetDeployKey reads: "Ship it"'s deploy key for this deployment. */
export const DEPLOY_KEY_ENV = "CHEF_DEPLOY_KEY";
export const DEPLOY_KEY_NAME = "chef-ship-it";
/** The beta channel's deploy key (chefCloud's `beta.deployKeyEnv`, default this). */
export const BETA_KEY_ENV = "CHEF_BETA_DEPLOY_KEY";
export const BETA_KEY_NAME = "chef-beta";
const DEPLOYMENT_NAME_RE = /^[a-z0-9][a-z0-9-]{0,63}$/;

type SetupStatus = Record<string, unknown> | null;

/** How a person finds the id `--admin` takes. */
export const ADMIN_HELP = [
  "Nobody becomes Chef's admin by signing in. Sign in to the app as its owner, open the",
  'Chef panel, and copy "your Chef user id" (what your getUserId returns). Then:',
  "  npx chef init --admin <that id>",
];

function adminFrom(status: SetupStatus): string | null {
  if (!status) return null;
  const app = (x: unknown): x is string => typeof x === "string" && x !== "" && !x.startsWith("operator:");
  for (const k of ["adminUserId", "admin"]) if (app(status[k])) return status[k] as string;
  for (const k of ["adminUserIds", "admins"]) {
    const a = status[k];
    if (Array.isArray(a) && app(a[0])) return a[0];
    if (Array.isArray(a) && a[0] && typeof a[0] === "object" && app(a[0].userId)) return a[0].userId;
  }
  return null;
}

export function enabledFrom(status: SetupStatus): boolean {
  if (!status) return false;
  return status.cloudEnabled === true || status.enabled === true || status.cloudBuildsEnabled === true || status.cloudBuilds === "enabled";
}

function readConfig(convexDir: string): string | null {
  try {
    return readFileSync(join(convexDir, "convex.config.ts"), "utf8");
  } catch {
    return null;
  }
}

/** Required names whose preview default is missing, with both halves of any keypair one half of which is missing. */
export function missingWithPairs(required: string[], have: Set<string>): string[] {
  const kinds = valueKinds(required);
  const missing = new Set(required.filter((n) => !have.has(n)));
  const prefix = (n: string) => n.replace(/_?(PRIVATE_KEY|JWKS)$/, "");
  for (const n of [...missing]) {
    if (kinds[n] !== "keypair") continue;
    for (const m of required) if (kinds[m] === "keypair" && prefix(m) === prefix(n)) missing.add(m);
  }
  return required.filter((n) => missing.has(n));
}

/**
 * The upgrade step for /agent/* keys from before they were hashed: run
 * chefMigrateAgentKeys (it loops to the end), check no plaintext row is
 * left, and say how many there were. Throws if any is left.
 */
export async function migrateAgentKeys(convex: Convex, log: (s: string) => void, module: string): Promise<number> {
  let r: { migrated?: unknown; legacyRemaining?: unknown; prefixes?: unknown } | null;
  try {
    r = await convex.run("chefMigrateAgentKeys");
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (/Could not find|not found|No such function/i.test(msg)) {
      throw new CliError(
        `${module}:chefMigrateAgentKeys isn't exported. Add it to the chefCloud (or chefAdmin) exports in convex/${module}.ts ` +
          "(`npx chef init --write` does), then run this again.",
        3,
      );
    }
    throw e;
  }
  const migrated = typeof r?.migrated === "number" ? r.migrated : 0;
  if (r?.legacyRemaining !== false) {
    throw new CliError(`${module}:chefMigrateAgentKeys left /agent/* keys stored in plaintext; run it again`);
  }
  if (migrated === 0) {
    log("  /agent/* keys: none stored in plaintext");
  } else {
    log(`  /agent/* keys: hashed ${migrated} key${migrated === 1 ? "" : "s"} that ${migrated === 1 ? "was" : "were"} stored in plaintext.`);
    const prefixes = Array.isArray(r?.prefixes) ? r.prefixes.filter((p): p is string => typeof p === "string") : [];
    if (prefixes.length) log(`  ${prefixes.join(", ")}${migrated > prefixes.length ? ` and ${migrated - prefixes.length} more` : ""}`);
    log("  Anyone who saw the database (an export, a dashboard session) could have read them: revoke");
    log("  them in the admin UI and issue new ones.");
  }
  return migrated;
}

/** Whether convex/<module>.ts already calls chefCloud: an app with cloud builds wired. */
function chefModuleUsesCloud(convexDir: string, module: string): boolean {
  try {
    return /\bchefCloud\s*\(/.test(readFileSync(join(convexDir, `${module}.ts`), "utf8"));
  } catch {
    return false;
  }
}

/**
 * Cloud builds or the feedback board alone: what the flags say, else an app
 * that has chef-cloud (installed, in package.json, or called) does, else ask.
 * No terminal to ask on means the feedback board alone.
 */
async function wantsCloud(o: InitOptions, deps: Deps, convexDir: string): Promise<boolean> {
  if (o.cloud !== undefined) return o.cloud;
  if (chefCloudInstalled(o.cwd) || chefCloudDeclared(o.cwd) || chefModuleUsesCloud(convexDir, o.module)) return true;
  if (o.enable || o.deployKey || o.rotateDeployKey) return true;
  const log = deps.log;
  log("");
  log("Cloud builds");
  log("  The feedback board is requests, voting, approvals and the panel. Cloud builds add");
  log("  Chef building approved requests in sandboxes, previews and \"Ship it\", from a second");
  log(`  package, ${CHEF_CLOUD}, billed to your team's Convex bill when used.`);
  const a = await deps.ask("Set up cloud builds too? [y/N] ");
  if (a === null) {
    log("  No terminal to ask on: the feedback board alone. `npx chef init --cloud` adds cloud builds.");
    return false;
  }
  return /^y(es)?$/i.test(a.trim());
}

/** Name the app's admin (--admin, or asked for when there is none): approves requests, builds and ships. */
async function nameAdmin(o: InitOptions, deps: Deps, convex: Convex, existing: string | null): Promise<string | null> {
  const log = deps.log;
  let appAdmin = existing;
  let named = o.admin?.trim() || null;
  if (!named && !appAdmin) {
    for (const l of ADMIN_HELP) log(`  ${l}`);
    const a = await deps.ask("  The admin's Chef user id (blank to skip for now): ");
    named = a?.trim() || null;
  }
  if (named && named !== appAdmin) {
    const r = await convex.run<{ userId?: string; wasAdmin?: boolean } | null>("chefSetAdmin", { userId: named });
    appAdmin = typeof r?.userId === "string" ? r.userId : named;
    log(`  ${appAdmin} ${r?.wasAdmin ? "is already an admin" : "is now an admin"}`);
  } else if (appAdmin) {
    log(`  ${appAdmin}`);
  } else {
    log("  none yet");
  }
  return appAdmin;
}

/** The rest of init for the feedback board alone: the admin and a summary. */
async function feedbackOnly(
  o: InitOptions,
  deps: Deps,
  convex: Convex,
  target: string,
  migrated: number,
  edits: ReturnType<typeof planEdits>,
): Promise<number> {
  const log = deps.log;
  log("Admin");
  const appAdmin = await nameAdmin(o, deps, convex, null);
  log("");
  log("Summary");
  log(`  deployment   ${target}`);
  log(`  the board    exposeChefApi and chefAdmin in convex/${o.module}.ts`);
  log(`  admin        ${appAdmin ?? "none yet: `npx chef init --admin <userId>` names one"}`);
  if (migrated > 0) log(`  agent keys   ${migrated} hashed from plaintext; rotate them`);
  const panel = edits.find((e) => e.title === "show the panel");
  if (panel?.action === "manual") log("  panel        not mounted yet; see \"by hand\" above");
  log(`  cloud builds not set up: \`npx chef init --cloud\` adds them (${CHEF_CLOUD_PACKAGE})`);
  log("");
  log("The feedback board is set up.");
  return 0;
}

/**
 * `--write --no-commit`: the file edits only. Setup pushes HEAD and deploys
 * what's committed, so everything after the edits waits for a commit; say
 * what was skipped and how to finish.
 */
function skippedSetup(o: InitOptions, deps: Deps, cloud: boolean, files: string[]): number {
  const log = deps.log;
  if (files.length === 0) {
    log("");
    log("The code is already in place; nothing to write.");
  }
  log("");
  log("Skipped (--no-commit):");
  log("  committing the edits");
  log("  deploying the functions and the upgrade steps (hashing old /agent/* keys)");
  if (cloud) {
    log("  creating the app's repo on Code Storage, pushing HEAD as its main, and the `chef` git remote");
    log("  the preview deploy key and preview env defaults, and \"Ship it\"'s deploy key");
  }
  log("  naming the admin");
  log("");
  log("To finish setup: review the edits, commit them (with your other work, or on their own), then run");
  log(`  npx chef init${cloud ? " --cloud" : " --no-cloud"}${o.prod ? " --prod" : ""}`);
  return 0;
}

export async function init(o: InitOptions, deps: Deps): Promise<number> {
  const log = deps.log;
  log(`chef init: ${o.cwd}`);
  const cloud = await wantsCloud(o, deps, convexDirOf(o.cwd));
  log(`Mode: ${cloud ? `the feedback board and cloud builds (${CHEF_CLOUD})` : "the feedback board alone (--cloud for cloud builds)"}`);

  // 1. Preflight. Every check runs, so one pass lists every problem. With
  // --write a FAIL stops init here; the review (no --write) still prints
  // the code it would add, so one run shows both, and stops after that.
  log("");
  log("Preflight");
  const noCommit = o.write && !o.commit;
  const pf = await preflight(o.cwd, deps, { cloud, allowDirty: noCommit });
  for (const l of renderChecks(pf.checks)) log(l);
  let failed = !pf.ok;
  // The build sandbox's install, run here with nothing written: a lockfile
  // it would refuse costs a paid sandbox to find otherwise. Not when the
  // lockfile already failed.
  if (cloud && !pf.checks.some((c) => (c.name === "dependencies" || c.name === "lockfile") && c.status === "fail")) {
    const lock = await checkLockfile(o.cwd, deps);
    for (const l of renderChecks([lock])) log(l);
    if (lock.status === "fail") failed = true;
  }
  // Nothing to plan the code from without a functions directory of the app's own.
  const canPlan = pf.checks.some((c) => c.name === "functions" && c.status !== "fail");
  if (failed && (o.write || !canPlan)) {
    log("");
    log("Fix the FAIL lines above and run `npx chef init` again. Nothing was changed.");
    return 3;
  }
  const deployment = pf.deployment as Deployment;
  const gitRoot = pf.gitRoot as string;

  // 2. Code: chef-cloud itself first, then the edits.
  const source = o.cloudFrom ?? deps.env.CHEF_CLOUD_PACKAGE?.trim() ?? DEFAULT_CHEF_CLOUD_SOURCE;
  const installCloud = cloud && !chefCloudInstalled(o.cwd);
  const requiredEnv = cloud ? requiredEnvNames(readConfig(pf.convexDir)) : [];
  const edits = planEdits({ appDir: o.cwd, convexDir: pf.convexDir, module: o.module, frontend: pf.frontend, requiredEnv, cloud });
  log("");
  log("Code");
  if (installCloud) {
    log(`  ${CHEF_CLOUD}: not installed; vendored from ${source} (the build sandbox reaches only npm)`);
    for (const l of installLines(source, packageManager(o.cwd))) log(`    $ ${l}`);
  }
  for (const e of edits) for (const l of renderEdit(e, o.cwd)) log(l);
  const pending = pendingEdits(edits);
  const blocking = edits.filter((e) => e.action === "manual" && !e.optional);
  if (failed) {
    // The review with preflight FAILs: the code above is what --write adds once they're fixed.
    log("");
    log(
      `Fix the FAIL lines in the preflight above${blocking.length > 0 ? `, make the edits marked "by hand" in ${blocking.map((e) => e.file).join(", ")}` : ""}, ` +
        `then run \`npx chef init --write${cloud ? " --cloud" : " --no-cloud"}\` to make the edits above. Nothing was changed.`,
    );
    return 3;
  }
  // Edits that need a person come first, so a half-wired app is never committed.
  if (blocking.length > 0) {
    log("");
    log(`Make the edits marked "by hand" in ${blocking.map((e) => e.file).join(", ")}, commit them, and run init again. Nothing was changed.`);
    return 3;
  }
  if (pending.length > 0 || installCloud) {
    if (!o.write) {
      log("");
      log(`Run \`npx chef init --write${cloud && o.cloud === undefined && !installCloud ? "" : cloud ? " --cloud" : ""}\` to make the edits above and commit them. Nothing was changed.`);
      log("(`--write --no-commit` makes them without committing, and stops before setup.)");
      return 0;
    }
    const written: string[] = [];
    if (installCloud) {
      log("");
      log(`Installing ${CHEF_CLOUD}`);
      written.push(...(await installChefCloud(o.cwd, deps, source)));
      log(`  ${written[0]}`);
    }
    written.push(...applyEdits(pending, o.cwd));
    const files = [...new Set(written)];
    log("");
    log(`Wrote ${files.join(", ")}`);
    if (noCommit) return skippedSetup(o, deps, cloud, files);
    const message = cloud ? COMMIT_MESSAGE : FEEDBACK_COMMIT_MESSAGE;
    const add = await deps.exec("git", ["add", "--", ...files], { cwd: o.cwd });
    const commit =
      add.code === 0 ? await deps.exec("git", ["commit", "-q", "-m", message, "--", ...files], { cwd: o.cwd }) : add;
    if (commit.code !== 0) {
      throw new CliError(`Committing the edits failed (they are written; commit them yourself and run init again):\n${commit.stderr.trim()}`);
    }
    const sha = (await deps.exec("git", ["rev-parse", "--short=12", "HEAD"], { cwd: o.cwd })).stdout.trim();
    log(`Committed ${sha}: ${message}`);
  }

  // --no-commit with nothing to write: still no setup, which needs it all committed.
  if (noCommit) return skippedSetup(o, deps, cloud, []);

  const convex = new Convex(deps, { cwd: o.cwd, module: o.module, prod: o.prod });
  const target = o.prod ? "production" : `${deployment.kind}:${deployment.name}`;

  // 3. The guard, the functions, the upgrade steps.
  log("");
  const guard = await deployGuard(convex, deps, o.cwd, { prod: o.prod });
  if (!guard.ok) throw new CliError(guard.message, 3);
  log(`Deploying functions to ${target}`);
  await convex.push();
  log("Upgrade");
  const migrated = await migrateAgentKeys(convex, log, o.module);

  if (!cloud) return await feedbackOnly(o, deps, convex, target, migrated, edits);

  log("Repo");
  const setup = await convex.run<Record<string, unknown> | null>("chefRepoSetup");
  let remoteUrl = cleanRemoteUrl(setup?.remoteUrl ?? setup?.repoUrl ?? setup?.url);
  if (!remoteUrl) {
    // Only its URL is kept; the password is dropped unread.
    const cred = await convex.run<Record<string, unknown> | null>("chefGitCredential", { write: false });
    remoteUrl = cleanRemoteUrl(cred?.remoteUrl);
  }
  if (!remoteUrl) throw new CliError("chefRepoSetup gave no remote URL");
  if (typeof setup?.repo === "string") log(`  ${setup.repo}${setup.created === true ? " (created)" : ""}`);

  // 4. The git remote, before the push, so its hints work.
  const helper = helperCommand({ self: o.self, gitRoot, appDir: o.cwd, module: o.module, prod: o.prod });
  const remote = await configureRemote(deps, o.cwd, remoteUrl, helper);
  log(`  git remote ${REMOTE_NAME} ${remote.action === "added" ? "added" : "already set"}: ${remoteUrl}`);
  const push = await pushHeadAsMain(deps, convex, o.cwd);
  log(
    push.pushed
      ? `  ${MAIN} ${push.before ? push.before.slice(0, 12) : "(new)"} -> ${push.sha.slice(0, 12)}`
      : `  ${MAIN} is already ${push.sha.slice(0, 12)}`,
  );

  // 5. Preview key and preview env.
  let status: SetupStatus = null;
  try {
    status = await convex.run<SetupStatus>("chefSetupStatus");
  } catch (e) {
    log(`  (chefSetupStatus: ${e instanceof Error ? e.message : String(e)})`);
  }
  const summary: string[] = [];

  // The app's admin: approves builds and ships. Cloud builds stay off without one.
  log("Admin");
  const appAdmin = await nameAdmin(o, deps, convex, adminFrom(status));
  if (!appAdmin) summary.push("Admin: none yet, so cloud builds stay off; `npx chef init --admin <userId>` names one.");
  if (o.skipPreview) {
    log("Previews: skipped (--skip-preview)");
  } else {
    log("Previews");
    const platform = new Platform(deps);
    const projectId = await platform.projectId(deployment.name);
    const names = await convex.envNames();
    if (names.has(PREVIEW_KEY_ENV) && !o.rotatePreviewKey) {
      log(`  ${PREVIEW_KEY_ENV} is already set (--rotate-preview-key for a new one)`);
    } else {
      const key = await platform.createPreviewDeployKey(projectId, PREVIEW_KEY_NAME);
      await convex.envSet(PREVIEW_KEY_ENV, key);
      log(`  created a preview deploy key and set ${PREVIEW_KEY_ENV}`);
    }
    // As the app's admin if there is one, else as the CLI's own operator identity.
    const adminUserId = appAdmin;
    const r = await convex.run<{ prefix?: string } | null>("chefSetPreviewDeployKey", adminUserId ? { adminUserId } : {});
    log(`  preview deploy key checked${typeof r?.prefix === "string" ? `: ${r.prefix}` : ""}`);
    if (requiredEnv.length > 0) {
      const have = previewDefaultNames(await platform.listDefaults(projectId));
      const missing = missingWithPairs(requiredEnv, have);
      if (missing.length > 0) {
        await platform.setPreviewDefaults(projectId, throwawayValues(missing));
        log(`  preview defaults set (throwaway values): ${missing.join(", ")}`);
      } else log(`  preview defaults already cover ${requiredEnv.join(", ")}`);
    }
  }

  // 6. "Ship it": a deploy key for this deployment, made with the CLI login
  // and handed straight to `convex env set` on stdin. Never printed.
  if (o.skipDeployKey) {
    log("Ship it: skipped (--skip-deploy-key)");
  } else {
    log("Ship it");
    const names = await convex.envNames();
    const set = names.has(DEPLOY_KEY_ENV);
    let create = false;
    if (set && !o.rotateDeployKey) {
      log(`  ${DEPLOY_KEY_ENV} is already set (--rotate-deploy-key for a new one)`);
    } else if (o.deployKey || o.rotateDeployKey) {
      create = true;
    } else {
      log(`  "Ship it" in the panel deploys an approved build to ${target}. It needs a deploy key`);
      log(`  for ${target}, kept in the ${DEPLOY_KEY_ENV} env var there and never printed.`);
      const a = await deps.ask(`Create one now? [y/N] `);
      if (a === null) log("  No terminal to ask on. Create it with `npx chef init --deploy-key`.");
      else create = /^y(es)?$/i.test(a.trim());
      if (!create) summary.push("Ship it: no deploy key yet; `npx chef init --deploy-key` creates one.");
    }
    if (create) {
      const key = await convex.createDeployKey(DEPLOY_KEY_NAME, deployment.name);
      await convex.envSet(DEPLOY_KEY_ENV, key);
      log(`  created a deploy key for ${target} and set ${DEPLOY_KEY_ENV}`);
    }
    if (create || (set && !(typeof status?.deployKeyPrefix === "string" && status.deployKeyPrefix))) {
      const adminUserId = appAdmin;
      const r = await convex.run<{ prefix?: string } | null>("chefSetDeployKey", adminUserId ? { adminUserId } : {});
      log(`  deploy key checked${typeof r?.prefix === "string" ? `: ${r.prefix}` : ""}`);
    }
  }

  // 6b. The beta channel (chefCloud's `beta`, off by default): a deploy key
  // for the app's persistent beta deployment, never this one. Made with the
  // CLI login, handed to `convex env set` on stdin, never printed. Only
  // with --beta, or when the app configured `beta` and the answer is yes.
  const betaStatus = status && typeof status.beta === "object" && status.beta !== null ? (status.beta as { keyEnv?: unknown; keySet?: unknown }) : null;
  const betaEnv = typeof betaStatus?.keyEnv === "string" && /^[A-Z][A-Z0-9_]*$/.test(betaStatus.keyEnv) ? betaStatus.keyEnv : BETA_KEY_ENV;
  if (o.skipBeta) {
    log("Beta: skipped (--skip-beta)");
  } else if (o.beta !== undefined || (betaStatus && betaStatus.keySet !== true)) {
    log("Beta channel");
    let betaDeployment: string | null = o.beta ?? null;
    if (betaDeployment === null) {
      log(`  chefCloud's \`beta\` deploys each successful build to a beta deployment of its own. It needs`);
      log(`  a deploy key for that deployment, kept in ${betaEnv} here and never printed.`);
      const a = await deps.ask("Create one now? Type the beta deployment's name, or press enter to skip: ");
      if (a === null) log("  No terminal to ask on. Create it with `npx chef init --beta <deployment>`.");
      else if (DEPLOYMENT_NAME_RE.test(a.trim())) betaDeployment = a.trim();
      if (betaDeployment === null) summary.push("Beta: no deploy key yet; `npx chef init --beta <deployment>` creates one.");
    }
    if (betaDeployment !== null) {
      // With --prod the app's deployment is production, not the .env.local one (often the very
      // dev deployment used as the beta); the server refuses a beta key for the app's own deployment.
      if (!o.prod && betaDeployment === deployment.name) {
        throw new CliError(`The beta must be a deployment of its own, not ${deployment.name} (the app's).`, 2);
      }
      const key = await convex.createDeployKeyFor(BETA_KEY_NAME, betaDeployment);
      await convex.envSet(betaEnv, key);
      log(`  created a deploy key for ${betaDeployment} and set ${betaEnv}`);
      if (!betaStatus) summary.push("Beta: the key is set; add `beta: { siteUrl }` to chefCloud's options to turn the channel on.");
    }
  }

  // 7. Summary and the cost question.
  log("");
  log("Summary");
  log(`  deployment   ${target}`);
  log(`  repo         ${remoteUrl} (${MAIN} ${push.sha.slice(0, 12)})`);
  log(`  git remote   ${REMOTE_NAME}, credentials from \`${o.self} git-credential\``);
  if (requiredEnv.length > 0) {
    log(`  local env    \`npm run ${LOCAL_ENV_NPM_SCRIPT}\` (${localEnvNpmScript(o.cwd) ?? `node ${LOCAL_ENV_SCRIPT}`}) sets ${requiredEnv.join(", ")} in the build`);
  }
  log(`  sync         \`${o.self} sync\` pushes your HEAD to chef's ${MAIN}`);
  if (migrated > 0) log(`  agent keys   ${migrated} hashed from plaintext; rotate them`);
  for (const l of summary) log(`  ${l}`);
  const panel = edits.find((e) => e.title === "show the panel");
  if (panel?.action === "manual") log("  panel        not mounted yet; see \"by hand\" above");

  if (enabledFrom(status)) {
    log("");
    log("Cloud builds are on.");
    return 0;
  }
  if (!appAdmin) {
    log("");
    log("Cloud builds are off, and stay off until the app has an admin to approve builds.");
    for (const l of ADMIN_HELP) log(l);
    return o.enable ? 3 : 0;
  }
  log("");
  log("Cloud builds are off. When they're on, each request an admin approves in the panel");
  log("runs in cloud sandboxes with Claude model calls, and that usage is billed to your");
  log("team's Convex bill. Nothing runs until an admin approves a request.");
  let yes = o.enable;
  if (!yes) {
    const a = await deps.ask("Turn cloud builds on now? [y/N] ");
    if (a === null) {
      log("No terminal to ask on. Turn them on with `npx chef init --enable`.");
      return 0;
    }
    yes = /^y(es)?$/i.test(a.trim());
  }
  if (!yes) {
    log("Left off. Turn them on later with `npx chef init --enable`.");
    return 0;
  }
  await convex.run("chefEnableCloudBuilds");
  log("Cloud builds are on.");
  return 0;
}
