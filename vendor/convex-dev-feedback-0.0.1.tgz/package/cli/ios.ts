// `npx chef ios <runId|itemId>` (docs/chef-pipeline.md, "Trying a build on
// your iPhone"): on the developer's Mac, never in a sandbox. Fetches the
// build's commit from the `chef` remote into a throwaway git worktree,
// generates the Xcode project (xcodegen) when the app uses it, builds with
// xcodebuild for the connected device, installs with `xcrun devicectl`,
// optionally launches it pointed at the build's preview (or beta) backend,
// and reports "compiled / installed" back to the run, where the Ship card's
// iOS flag shows it. Nothing is hardcoded to one app: the project comes from
// `chef.ios` in package.json or chef.ios.json.
//
// Only erasable TypeScript here, so Node can run it with type stripping.

import { existsSync, mkdtempSync, readdirSync, readFileSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { isAbsolute, join, normalize } from "node:path";
import type { Convex } from "./convex.ts";
import { CliError, type Deps } from "./deps.ts";
import { REMOTE_NAME } from "./repo.ts";

export type IosConfig = {
  /** The directory with the Xcode project (or xcodegen's project.yml), relative to the repo. Default ".". */
  projectDir: string;
  /** The scheme to build. */
  scheme: string;
  /** `Foo.xcodeproj` or `Foo.xcworkspace` in projectDir; default: the one there. */
  project?: string;
  workspace?: string;
  /** Run `xcodegen generate` first. Default: when projectDir has project.yml. */
  xcodegen?: boolean;
  /** Default "Debug". */
  configuration?: string;
  /** A device's UDID, identifier or name. Default: the one connected device. */
  device?: string;
  /** The app's bundle id, to launch it after installing (with the backend override). */
  bundleId?: string;
  /**
   * The launch argument the app reads to use another Convex backend (a
   * UserDefaults key: `-<key> <url>`). Default "ChefConvexURL"; false never
   * passes one. Only when the app is launched (bundleId set).
   */
  backendArg?: string | false;
  /** The development team, passed to xcodebuild as DEVELOPMENT_TEAM. */
  team?: string;
  /**
   * Extra build settings passed to xcodebuild as `NAME=value` (e.g. manual signing:
   * `{ "CODE_SIGN_STYLE": "Manual", "PROVISIONING_PROFILE_SPECIFIER": "..." }`). Names are
   * setting names (letters, digits, _); values are plain text (`$(VAR)` references allowed).
   */
  buildSettings?: Record<string, string>;
};

export type IosFlags = { device?: string; backend?: "preview" | "beta" | "none"; noLaunch?: boolean };

export type IosInfo = {
  runId: string;
  itemNumber: number | null;
  title: string;
  status: string;
  branch: string | null;
  commitSha: string;
  previewConvexUrl: string | null;
  betaConvexUrl: string | null;
};

const NAME = /^[A-Za-z0-9 ._+-]{1,100}$/;
const KEY = /^[A-Za-z][A-Za-z0-9_.]{0,63}$/;
const BUNDLE = /^[A-Za-z0-9.-]{1,155}$/;

function relInside(p: string, what: string): string {
  const n = normalize(p);
  if (isAbsolute(n) || n.split(/[\\/]/).includes("..")) throw new CliError(`chef.ios ${what} must be a path inside the repo`, 2);
  return n;
}

/** `chef.ios` in package.json, else chef.ios.json; checked. Null when there is neither. */
export function loadIosConfig(cwd: string): IosConfig | null {
  let raw: unknown = null;
  const pkg = join(cwd, "package.json");
  if (existsSync(pkg)) {
    try {
      raw = (JSON.parse(readFileSync(pkg, "utf8")) as { chef?: { ios?: unknown } }).chef?.ios ?? null;
    } catch {
      raw = null;
    }
  }
  if (raw === null && existsSync(join(cwd, "chef.ios.json"))) raw = JSON.parse(readFileSync(join(cwd, "chef.ios.json"), "utf8"));
  if (raw === null) return null;
  if (!raw || typeof raw !== "object") throw new CliError("chef.ios must be an object", 2);
  const o = raw as Record<string, unknown>;
  const str = (k: string, re: RegExp) => {
    if (o[k] === undefined) return undefined;
    if (typeof o[k] !== "string" || !re.test(o[k] as string)) throw new CliError(`chef.ios.${k} isn't valid`, 2);
    return o[k] as string;
  };
  const scheme = str("scheme", NAME);
  if (!scheme) throw new CliError("chef.ios.scheme is required (the Xcode scheme to build)", 2);
  const cfg: IosConfig = { projectDir: relInside(typeof o.projectDir === "string" ? o.projectDir : ".", "projectDir"), scheme };
  const project = str("project", /^[A-Za-z0-9 ._+-]{1,100}\.xcodeproj$/);
  const workspace = str("workspace", /^[A-Za-z0-9 ._+-]{1,100}\.xcworkspace$/);
  if (project) cfg.project = project;
  if (workspace) cfg.workspace = workspace;
  if (o.xcodegen !== undefined) cfg.xcodegen = o.xcodegen === true;
  const configuration = str("configuration", /^[A-Za-z0-9_-]{1,40}$/);
  if (configuration) cfg.configuration = configuration;
  const device = str("device", NAME);
  if (device) cfg.device = device;
  const bundleId = str("bundleId", BUNDLE);
  if (bundleId) cfg.bundleId = bundleId;
  if (o.backendArg === false) cfg.backendArg = false;
  else {
    const k = str("backendArg", KEY);
    if (k) cfg.backendArg = k;
  }
  const team = str("team", /^[A-Z0-9]{10}$/);
  if (team) cfg.team = team;
  const bs = (o as Record<string, unknown>).buildSettings;
  if (bs !== undefined) {
    if (typeof bs !== "object" || bs === null || Array.isArray(bs)) throw new CliError("chef.ios.buildSettings must be an object of NAME: value");
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(bs)) {
      if (!/^[A-Za-z_][A-Za-z0-9_]{0,63}$/.test(k)) throw new CliError(`chef.ios.buildSettings: bad setting name ${JSON.stringify(k)}`);
      if (typeof v !== "string" || v.length > 200 || /[\n\r\0`;&|<>]/.test(v)) throw new CliError(`chef.ios.buildSettings.${k}: value must be plain text`);
      out[k] = v;
    }
    cfg.buildSettings = out;
  }
  return cfg;
}

type Device = { id: string; udid: string; name: string };

/** The connected iOS devices, from `xcrun devicectl list devices --json-output`. */
export function parseDevices(json: string): Device[] {
  let o: any;
  try {
    o = JSON.parse(json);
  } catch {
    return [];
  }
  const list: any[] = Array.isArray(o?.result?.devices) ? o.result.devices : [];
  return list
    .filter((d) => (d?.hardwareProperties?.platform ?? "") === "iOS")
    .filter((d) => (d?.connectionProperties?.pairingState ?? "paired") === "paired")
    .filter((d) => (d?.connectionProperties?.tunnelState ?? "") !== "unavailable")
    .map((d) => ({
      id: String(d.identifier ?? ""),
      udid: String(d.hardwareProperties?.udid ?? d.identifier ?? ""),
      name: String(d.deviceProperties?.name ?? "iPhone"),
    }))
    .filter((d) => d.id && d.udid);
}

/** The .app xcodebuild made for a device, under the derived data path. */
export function findApp(derived: string, configuration: string): string | null {
  const dir = join(derived, "Build", "Products", `${configuration}-iphoneos`);
  if (!existsSync(dir)) return null;
  const apps = readdirSync(dir).filter((f) => f.endsWith(".app"));
  return apps.length === 1 ? join(dir, apps[0]) : null;
}

function tail(s: string, n = 12): string {
  return s.split("\n").filter((l) => l.trim()).slice(-n).join("\n");
}

/** Refuses to run anywhere but the developer's own Mac. */
export function checkHost(platform: string, env: Record<string, string | undefined>): void {
  if (platform !== "darwin") throw new CliError("chef ios builds with Xcode: run it on your Mac", 2);
  if (env.DAYTONA_SANDBOX_ID || env.CHEF_RUN_ID || env.CHEF_AGENT_KEY) {
    throw new CliError("chef ios runs on your own Mac, never in a build sandbox", 2);
  }
}

export async function runIos(
  ref: string,
  cwd: string,
  deps: Deps,
  convex: Convex,
  flags: IosFlags,
  o: { platform?: string; tmp?: () => string } = {},
): Promise<number> {
  checkHost(o.platform ?? process.platform, deps.env);
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(ref)) throw new CliError("chef ios takes a run id or a request (item) id", 2);
  const cfg = loadIosConfig(cwd);
  if (!cfg) {
    throw new CliError(
      'No iOS config: add "chef": { "ios": { "projectDir": "ios", "scheme": "App" } } to package.json (or chef.ios.json). docs/chef-pipeline.md, "Trying a build on your iPhone"',
      2,
    );
  }
  const log = deps.log;
  const info = await convex.run<IosInfo | null>("chefIos", { ref });
  if (!info) throw new CliError(`No build with a commit for ${ref}`, 2);
  const label = `${info.itemNumber !== null ? `#${info.itemNumber} ` : ""}${info.title || `run ${info.runId}`}`;
  log(`chef ios: ${label}, ${info.commitSha.slice(0, 12)}`);

  const report = async (compiled: boolean, installed: boolean, device?: string, error?: string) => {
    try {
      await convex.run("chefIos", {
        ref: info.runId,
        report: { compiled, installed, ...(device ? { device } : {}), ...(error ? { error: error.slice(0, 300) } : {}) },
      });
    } catch (e) {
      log(`chef ios: couldn't report back to the run: ${(e as Error).message}`);
    }
  };
  const git = (args: string[], at = cwd) => deps.exec("git", args, { cwd: at });

  // 1. The commit, from the chef remote, into a worktree of its own.
  const fetchRef = info.branch && /^[A-Za-z0-9._/-]{1,200}$/.test(info.branch) ? info.branch : info.commitSha;
  const fetched = await git(["fetch", "--no-tags", "--quiet", REMOTE_NAME, fetchRef]);
  if (fetched.code !== 0) throw new CliError(`git fetch ${REMOTE_NAME} ${fetchRef} failed: ${tail(fetched.stderr, 4)}`);
  if ((await git(["cat-file", "-e", `${info.commitSha}^{commit}`])).code !== 0) {
    throw new CliError(`The fetch didn't bring ${info.commitSha.slice(0, 12)}`);
  }
  const base = o.tmp ? o.tmp() : mkdtempSync(join(tmpdir(), "chef-ios-"));
  const tree = join(base, "src");
  const derived = join(base, "derived");
  const added = await git(["worktree", "add", "--detach", "--quiet", tree, info.commitSha]);
  if (added.code !== 0) throw new CliError(`git worktree add failed: ${tail(added.stderr, 4)}`);
  try {
    const proj = join(tree, cfg.projectDir);
    // 2. The Xcode project, generated when the app uses xcodegen.
    if (cfg.xcodegen ?? existsSync(join(proj, "project.yml"))) {
      log("chef ios: xcodegen generate");
      const g = await deps.exec("xcodegen", ["generate"], { cwd: proj });
      if (g.code !== 0) {
        await report(false, false, undefined, `xcodegen failed: ${tail(g.stderr || g.stdout, 3)}`);
        throw new CliError(`xcodegen failed:\n${tail(g.stderr || g.stdout)}`);
      }
    }
    // 3. The device: named, or the one connected.
    const listFile = join(base, "devices.json");
    const listed = await deps.exec("xcrun", ["devicectl", "list", "devices", "--json-output", listFile], { cwd: base });
    const devices = listed.code === 0 && existsSync(listFile) ? parseDevices(readFileSync(listFile, "utf8")) : [];
    const want = flags.device ?? cfg.device;
    const device = want ? devices.find((d) => d.id === want || d.udid === want || d.name === want) : devices.length === 1 ? devices[0] : undefined;
    if (!device) {
      throw new CliError(
        want
          ? `No connected device "${want}" (connected: ${devices.map((d) => d.name).join(", ") || "none"})`
          : devices.length === 0
            ? "No iPhone connected (and paired): plug one in, or set chef.ios.device"
            : `Several devices are connected (${devices.map((d) => d.name).join(", ")}): pass --device <name> or set chef.ios.device`,
        2,
      );
    }
    // 4. Build for that device.
    const configuration = cfg.configuration ?? "Debug";
    const container = cfg.workspace
      ? ["-workspace", cfg.workspace]
      : cfg.project
        ? ["-project", cfg.project]
        : [];
    log(`chef ios: building ${cfg.scheme} (${configuration}) for ${device.name}`);
    const built = await deps.exec(
      "xcodebuild",
      [
        ...container,
        "-scheme",
        cfg.scheme,
        "-configuration",
        configuration,
        "-destination",
        `id=${device.udid}`,
        "-derivedDataPath",
        derived,
        "-allowProvisioningUpdates",
        ...(cfg.team ? [`DEVELOPMENT_TEAM=${cfg.team}`] : []),
        // argv, never a shell: values are passed through literally (xcodebuild expands $(VAR)).
        ...Object.entries(cfg.buildSettings ?? {}).map(([k, v]) => `${k}=${v}`),
        "build",
      ],
      { cwd: proj },
    );
    const app = built.code === 0 ? findApp(derived, configuration) : null;
    if (!app) {
      const why = built.code === 0 ? "xcodebuild made no single .app" : `xcodebuild failed: ${tail(built.stdout + built.stderr, 3)}`;
      await report(false, false, device.name, why);
      throw new CliError(built.code === 0 ? why : `xcodebuild failed:\n${tail(built.stdout + built.stderr, 20)}`);
    }
    log("chef ios: compiled ✓");
    // 5. Install.
    const inst = await deps.exec("xcrun", ["devicectl", "device", "install", "app", "--device", device.id, app], { cwd: base });
    if (inst.code !== 0) {
      await report(true, false, device.name, `install failed: ${tail(inst.stderr || inst.stdout, 3)}`);
      throw new CliError(`devicectl install failed:\n${tail(inst.stderr || inst.stdout)}`);
    }
    log(`chef ios: installed ✓ on ${device.name}`);
    await report(true, true, device.name);
    // 6. Launch it, pointed at the build's backend when the app takes the override.
    if (cfg.bundleId && !flags.noLaunch) {
      const which = flags.backend ?? (info.previewConvexUrl ? "preview" : info.betaConvexUrl ? "beta" : "none");
      const url = which === "preview" ? info.previewConvexUrl : which === "beta" ? info.betaConvexUrl : null;
      if (which !== "none" && !url) log(`chef ios: this build has no ${which} backend now; launching with the app's own`);
      const arg = cfg.backendArg === false ? null : (cfg.backendArg ?? "ChefConvexURL");
      const launchArgs = url && arg ? ["--", `-${arg}`, url] : [];
      const launched = await deps.exec(
        "xcrun",
        ["devicectl", "device", "process", "launch", "--device", device.id, "--terminate-existing", cfg.bundleId, ...launchArgs],
        { cwd: base },
      );
      if (launched.code === 0) log(`chef ios: launched${url && arg ? ` against ${url}` : ""}`);
      else log(`chef ios: installed, but launching failed: ${tail(launched.stderr || launched.stdout, 3)}`);
    }
    deps.out(`compiled ✓ installed ✓ ${device.name}`);
    return 0;
  } finally {
    await git(["worktree", "remove", "--force", tree]);
    rmSync(base, { recursive: true, force: true });
  }
}
